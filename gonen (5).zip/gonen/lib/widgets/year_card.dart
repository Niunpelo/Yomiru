import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/attachment_model.dart';
import '../models/day_access.dart';
import '../models/entry_model.dart';
import '../providers/diary_provider.dart';
import '../theme/app_theme.dart';
import '../utils/date_labels.dart';
import 'attachment_action_bar.dart';
import 'attachments_section.dart';
import 'inspiration_sheet.dart';
import 'paper_card.dart';
import 'save_button.dart';

/// Tarjeta del año actual: es la única en la que se puede escribir, y solo
/// mientras el día seleccionado sea hoy (hasta las 23:59).
///
/// Según [access] muestra un campo de texto, el texto guardado en solo lectura
/// (el día ya terminó), o un aviso (el día aún no ha llegado o no existe).
///
/// Conviene dar a esta tarjeta una `key` que dependa del día y del año
/// mostrados: así, al cambiar de día se crea de nuevo con el texto correcto.
class CurrentYearCard extends StatefulWidget {
  const CurrentYearCard({
    super.key,
    required this.year,
    required this.date,
    required this.access,
    required this.text,
    required this.attachments,
  });

  final int year;

  /// Fecha dentro de [year], o null si ese día no existe en ese año.
  final DateTime? date;

  /// Qué se puede hacer con la tarjeta en este momento.
  final DayAccess access;

  /// Texto guardado para este día (vacío si no hay entrada).
  final String text;

  /// Fotos y notas de voz de este día.
  final List<Attachment> attachments;

  @override
  State<CurrentYearCard> createState() => _CurrentYearCardState();
}

class _CurrentYearCardState extends State<CurrentYearCard>
    with AutomaticKeepAliveClientMixin<CurrentYearCard> {
  late final TextEditingController _controller =
      TextEditingController(text: widget.text);
  final FocusNode _focusNode = FocusNode();

  /// Mientras se puede escribir, la tarjeta no se destruye al desplazar la
  /// lista: así no se pierde el foco ni el texto tecleado.
  @override
  bool get wantKeepAlive => widget.access == DayAccess.editable;

  @override
  void didUpdateWidget(CurrentYearCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.access != widget.access) {
      updateKeepAlive();
    }
    // Si el día pasa a ser hoy (por ejemplo, a medianoche viendo "mañana"),
    // el campo de texto parte del texto guardado.
    if (widget.access == DayAccess.editable &&
        oldWidget.access != DayAccess.editable) {
      _controller.text = widget.text;
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final DiaryProvider diary = context.read<DiaryProvider>();
    FocusScope.of(context).unfocus();
    await diary.saveNow(_controller.text);
  }

  /// Abre el dado: una idea para escribir. Si el usuario elige «Escribir sobre
  /// esto», la frase pasa al texto y se puede contestar debajo.
  Future<void> _openInspiration() async {
    final String? prompt = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (BuildContext sheetContext) => const InspirationSheet(),
    );
    if (prompt == null || !mounted) {
      return;
    }
    final DiaryProvider diary = context.read<DiaryProvider>();
    // Si mientras tanto terminó el día (23:59), ya no se puede escribir.
    if (!diary.canWriteCurrentYear) {
      return;
    }

    final String current = _controller.text.trimRight();
    final String text =
        current.isEmpty ? '$prompt\n\n' : '$current\n\n$prompt\n\n';
    _controller.value = TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: text.length),
    );
    // Cambiar el texto desde código no avisa al campo: se avisa a mano para
    // que se guarde igual que si se hubiera escrito.
    diary.onContentChanged(text);
    _focusNode.requestFocus();
  }

  Future<void> _deleteAttachment(Attachment attachment) async {
    final DiaryProvider diary = context.read<DiaryProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final String? error = await diary.deleteAttachment(attachment);
    if (error != null) {
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(error)));
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // Necesario para AutomaticKeepAliveClientMixin.
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final DateTime? date = widget.date;

    return PaperCard(
      emphasized: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _YearHeader(
            year: widget.year,
            weekday: date == null ? null : weekdayLabel(date),
            highlighted: true,
          ),
          const SizedBox(height: 10),
          const Divider(),
          const SizedBox(height: 12),
          ..._buildContent(context, theme, scheme),
        ],
      ),
    );
  }

  List<Widget> _buildContent(
    BuildContext context,
    ThemeData theme,
    ColorScheme scheme,
  ) {
    final TextStyle mutedStyle = TextStyle(
      fontFamily: kSerifFamily,
      fontSize: 15,
      fontStyle: FontStyle.italic,
      color: scheme.onSurfaceVariant.withValues(alpha: 0.85),
    );

    switch (widget.access) {
      case DayAccess.missing:
        return <Widget>[
          Text('Este día solo existe en los años bisiestos.', style: mutedStyle),
        ];

      case DayAccess.notYet:
        return <Widget>[
          Text(
            'Este día aún no ha llegado. Podrás escribir en él cuando sea hoy.',
            style: mutedStyle,
          ),
          const SizedBox(height: 4),
        ];

      case DayAccess.ended:
        return <Widget>[
          if (widget.text.trim().isEmpty && widget.attachments.isEmpty)
            Text('No escribiste nada este día.', style: mutedStyle),
          if (widget.text.trim().isNotEmpty)
            SelectableText(
              widget.text,
              style: theme.textTheme.bodyLarge?.copyWith(
                fontFamily: kSerifFamily,
                fontSize: 17,
                height: 1.75,
              ),
            ),
          if (widget.attachments.isNotEmpty) ...<Widget>[
            if (widget.text.trim().isNotEmpty) const SizedBox(height: 14),
            AttachmentList(attachments: widget.attachments),
          ],
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Icon(
                Icons.lock_outline_rounded,
                size: 16,
                color: scheme.onSurfaceVariant,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'Este día ya terminó (23:59). Solo se puede leer.',
                  style: theme.textTheme.labelMedium?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
        ];

      case DayAccess.editable:
        final SaveStatus status = context
            .select<DiaryProvider, SaveStatus>((DiaryProvider p) => p.saveStatus);
        return <Widget>[
          TextField(
            controller: _controller,
            focusNode: _focusNode,
            minLines: 6,
            maxLines: null,
            keyboardType: TextInputType.multiline,
            textCapitalization: TextCapitalization.sentences,
            style: theme.textTheme.bodyLarge?.copyWith(
              fontFamily: kSerifFamily,
              fontSize: 17,
              height: 1.75,
            ),
            cursorColor: scheme.primary,
            decoration: InputDecoration(
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              isDense: true,
              contentPadding: EdgeInsets.zero,
              hintText: 'Escribe sobre tu día…',
              hintStyle: TextStyle(
                fontFamily: kSerifFamily,
                fontSize: 17,
                color: scheme.onSurfaceVariant.withValues(alpha: 0.6),
              ),
            ),
            onChanged: (String text) =>
                context.read<DiaryProvider>().onContentChanged(text),
          ),
          if (widget.attachments.isNotEmpty) ...<Widget>[
            const SizedBox(height: 14),
            AttachmentList(
              attachments: widget.attachments,
              onDelete: _deleteAttachment,
            ),
          ],
          const SizedBox(height: 10),
          AttachmentActionBar(onIdea: () => unawaited(_openInspiration())),
          const SizedBox(height: 6),
          Row(
            children: <Widget>[
              // Este aviso no cambia nunca; el estado del guardado se ve en el
              // propio botón de la derecha.
              const Expanded(child: _EditHint()),
              SaveButton(
                status: status,
                hasStoredText: widget.text.trim().isNotEmpty,
                onPressed: () => unawaited(_save()),
              ),
            ],
          ),
        ];
    }
  }
}

/// Tarjeta de un año anterior: solo lectura.
class PastYearCard extends StatelessWidget {
  const PastYearCard({
    super.key,
    required this.year,
    required this.date,
    required this.entry,
    required this.attachments,
  });

  final int year;

  /// Fecha dentro de [year], o null si ese día no existió en ese año.
  final DateTime? date;

  final Entry? entry;

  /// Fotos y notas de voz de ese año (solo lectura).
  final List<Attachment> attachments;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final DateTime? day = date;
    final Entry? current = entry;

    final TextStyle mutedStyle = TextStyle(
      fontFamily: kSerifFamily,
      fontSize: 15,
      fontStyle: FontStyle.italic,
      color: scheme.onSurfaceVariant.withValues(alpha: 0.8),
    );

    final String text = current?.content ?? '';
    final bool hasText = text.trim().isNotEmpty;

    final Widget body;
    if (day == null) {
      body = Text('Este año no tuvo este día.', style: mutedStyle);
    } else if (!hasText && attachments.isEmpty) {
      body = Text('Sin entrada este año', style: mutedStyle);
    } else {
      body = Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          if (hasText)
            SelectableText(
              text,
              style: theme.textTheme.bodyLarge?.copyWith(
                fontFamily: kSerifFamily,
                fontSize: 16,
                height: 1.75,
              ),
            ),
          if (attachments.isNotEmpty) ...<Widget>[
            if (hasText) const SizedBox(height: 14),
            AttachmentList(attachments: attachments),
          ],
        ],
      );
    }

    return PaperCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _YearHeader(
            year: year,
            weekday: day == null ? null : weekdayLabel(day),
            highlighted: false,
          ),
          const SizedBox(height: 10),
          const Divider(),
          const SizedBox(height: 12),
          body,
          const SizedBox(height: 4),
        ],
      ),
    );
  }
}

class _YearHeader extends StatelessWidget {
  const _YearHeader({
    required this.year,
    required this.weekday,
    required this.highlighted,
  });

  final int year;
  final String? weekday;
  final bool highlighted;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: <Widget>[
        Text(
          '$year',
          style: TextStyle(
            fontFamily: kSerifFamily,
            fontSize: 30,
            fontWeight: FontWeight.w300,
            letterSpacing: 1,
            color: highlighted ? scheme.primary : scheme.onSurfaceVariant,
          ),
        ),
        const Spacer(),
        if (weekday != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Text(
              weekday!,
              style: theme.textTheme.labelLarge?.copyWith(
                color: scheme.onSurfaceVariant,
                fontFamily: kSerifFamily,
                letterSpacing: 0.8,
              ),
            ),
          ),
      ],
    );
  }
}

/// Aviso fijo de debajo del texto: hasta cuándo se puede editar el día.
class _EditHint extends StatelessWidget {
  const _EditHint();

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);

    return Text(
      'Puedes editar hasta las 23:59',
      style: theme.textTheme.labelMedium?.copyWith(
        color: theme.colorScheme.onSurfaceVariant,
      ),
    );
  }
}
