import 'package:flutter/material.dart';

import '../providers/diary_provider.dart';

/// Botón de guardar del día de hoy.
///
/// Dice «Guardar» (y se puede pulsar) solo cuando hay cambios sin guardar o
/// el último guardado falló. Mientras guarda dice «Guardando…», y cuando todo
/// está en la base de datos dice «Guardado» y queda apagado hasta que se
/// vuelva a cambiar algo.
class SaveButton extends StatelessWidget {
  const SaveButton({
    super.key,
    required this.status,
    required this.hasStoredText,
    required this.onPressed,
  });

  final SaveStatus status;

  /// Verdadero si el día ya tiene un texto guardado. Sirve para el estado
  /// inicial (`idle`): un día con texto guardado se ve «Guardado»; uno vacío,
  /// «Guardar» apagado, porque no hay nada que guardar.
  final bool hasStoredText;

  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    switch (status) {
      case SaveStatus.unsaved:
        return TextButton.icon(
          onPressed: onPressed,
          icon: const Icon(Icons.check_rounded, size: 18),
          label: const Text('Guardar'),
        );
      case SaveStatus.error:
        // El fallo se avisa en el propio botón (en rojo y con otro icono), sin
        // tocar el resto de la tarjeta; al pulsarlo se vuelve a intentar.
        return TextButton.icon(
          onPressed: onPressed,
          style: TextButton.styleFrom(foregroundColor: scheme.error),
          icon: const Icon(Icons.error_outline_rounded, size: 18),
          label: const Text('Guardar'),
        );
      case SaveStatus.saving:
        return TextButton.icon(
          onPressed: null,
          icon: const SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
          label: const Text('Guardando…'),
        );
      case SaveStatus.saved:
        return _saved(scheme);
      case SaveStatus.idle:
        if (hasStoredText) {
          return _saved(scheme);
        }
        return TextButton.icon(
          onPressed: null,
          icon: const Icon(Icons.check_rounded, size: 18),
          label: const Text('Guardar'),
        );
    }
  }

  Widget _saved(ColorScheme scheme) {
    return TextButton.icon(
      onPressed: null,
      style: TextButton.styleFrom(disabledForegroundColor: scheme.secondary),
      icon: const Icon(Icons.check_circle_outline_rounded, size: 18),
      label: const Text('Guardado'),
    );
  }
}
