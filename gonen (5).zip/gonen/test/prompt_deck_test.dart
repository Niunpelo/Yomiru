import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/data/writing_prompts.dart';
import 'package:gonen/utils/prompt_deck.dart';

void main() {
  group('PromptDeck', () {
    final List<String> prompts = <String>['a', 'b', 'c', 'd', 'e'];

    test('reparte todas las frases una vez antes de repetir ninguna', () {
      final PromptDeck deck = PromptDeck(prompts, random: Random(1));

      final List<String> firstRound =
          <String>[for (int i = 0; i < prompts.length; i++) deck.next()];
      final List<String> secondRound =
          <String>[for (int i = 0; i < prompts.length; i++) deck.next()];

      expect(firstRound.toSet(), prompts.toSet());
      expect(secondRound.toSet(), prompts.toSet());
    });

    test('nunca da la misma frase dos veces seguidas, tampoco al cambiar de vuelta', () {
      for (int seed = 0; seed < 25; seed++) {
        final PromptDeck deck = PromptDeck(prompts, random: Random(seed));
        String? previous;
        for (int i = 0; i < prompts.length * 6; i++) {
          final String current = deck.next();
          expect(current, isNot(previous), reason: 'semilla $seed, tirada $i');
          previous = current;
        }
      }
    });

    test('con dos frases las alterna', () {
      final PromptDeck deck = PromptDeck(<String>['x', 'y'], random: Random(7));

      final List<String> draws = <String>[for (int i = 0; i < 6; i++) deck.next()];

      for (int i = 1; i < draws.length; i++) {
        expect(draws[i], isNot(draws[i - 1]));
      }
    });

    test('con una sola frase siempre devuelve esa', () {
      final PromptDeck deck = PromptDeck(<String>['sola'], random: Random(3));

      expect(deck.next(), 'sola');
      expect(deck.next(), 'sola');
    });

    test('sin frases devuelve un texto vacío', () {
      expect(PromptDeck(<String>[]).next(), '');
    });
  });

  group('kWritingPrompts', () {
    test('hay un buen número de frases', () {
      expect(kWritingPrompts.length, greaterThanOrEqualTo(100));
    });

    test('ninguna está repetida ni vacía ni es demasiado larga', () {
      expect(kWritingPrompts.toSet().length, kWritingPrompts.length);
      for (final String prompt in kWritingPrompts) {
        expect(prompt.trim(), prompt, reason: prompt);
        expect(prompt, isNotEmpty);
        expect(prompt.length, lessThanOrEqualTo(120), reason: prompt);
      }
    });

    test('las preguntas llevan los dos signos de interrogación', () {
      for (final String prompt in kWritingPrompts) {
        expect(
          prompt.contains('¿'),
          prompt.contains('?'),
          reason: 'Signos de interrogación descuadrados en: $prompt',
        );
      }
    });
  });
}
