# Yomiru

Diario de varios años con estética de papelería japonesa. Cada día muestra, en una misma pantalla, lo que escribiste ese mismo día en los 5 últimos años (el actual más los 4 anteriores). Solo se puede escribir en el año actual; los anteriores son de solo lectura.

- **Datos**: SQLite local (`sqflite`). Cada entrada se identifica por `día "MM-DD"` + `año`.
- **Estado**: `provider`.
- **Privacidad**: bloqueo con huella, rostro o PIN del dispositivo (`local_auth`).
- **Recordatorio**: notificación diaria a la hora elegida (`flutter_local_notifications`).
- **Tema**: claro y oscuro, interfaz en español.

## Conseguir el APK con GitHub (sin instalar nada)

1. Crea un repositorio nuevo en GitHub (vacío, sin README).
2. Descomprime este ZIP y sube **todo el contenido**, incluida la carpeta oculta `.github`:
   ```bash
   cd yomiru
   git init
   git add .
   git commit -m "Yomiru"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/yomiru.git
   git push -u origin main
   ```
   Si subes los archivos arrastrándolos en la web de GitHub, comprueba que `.github/workflows/build-apk.yml` ha llegado: sin ese archivo no se compila nada.
3. Abre la pestaña **Actions** del repositorio. El workflow **Build APK** se lanza solo con cada `push` (también puedes lanzarlo a mano con *Run workflow*).
4. Cuando termine (unos 5-10 minutos), entra en la ejecución y descarga el artefacto **yomiru-apk** al final de la página. Es un ZIP que contiene `app-release.apk`.
5. Copia el APK al móvil e instálalo (Android te pedirá permitir instalar apps de este origen).

Si subes una etiqueta que empiece por `v` (por ejemplo `v1.0.0`), el APK además se publica en *Releases*.

### Qué hace el workflow

El proyecto no incluye la carpeta `android/`: el workflow la genera con `flutter create` usando la versión estable de Flutter del momento y después ejecuta `tool/patch_android.py`, que deja listo lo que exigen los plugins (desugaring, `FlutterFragmentActivity`, permisos, receptores de notificaciones, temas AppCompat e iconos). Así el proyecto sigue funcionando aunque cambien las plantillas de Flutter.

El APK se firma con la clave de depuración de Flutter: sirve para instalarlo y usarlo, pero no para subirlo a Google Play. Para Play Store tendrás que configurar tu propia clave de firma.

## Compilar en tu ordenador

Requisitos: Flutter 3.38 o superior (Dart 3.10+), Java 17 y Python 3.

```bash
flutter create --platforms=android --org com.yomiru --project-name yomiru .
python3 tool/patch_android.py
flutter pub get
flutter run                      # en un móvil o emulador
flutter build apk --release      # build/app/outputs/flutter-apk/app-release.apk
```

## Estructura

```
lib/
  main.dart                      Arranque, proveedores, tema y localización
  models/entry_model.dart        Modelo Entry (id, dayOfYear, year, content, updatedAt)
  database/database_helper.dart  SQLite: crear tabla, consultar por día, guardar o actualizar
  providers/
    diary_provider.dart          Día seleccionado, navegación, carga de 5 años, guardado automático
    settings_provider.dart       Bloqueo biométrico, recordatorio, tema
  services/
    biometric_service.dart       local_auth
    notification_service.dart    Aviso diario programado
  screens/
    home_screen.dart             Cabecera con fecha + tarjetas por año
    settings_screen.dart         Ajustes
    lock_screen.dart             Pantalla de bloqueo
  widgets/                       Tarjetas de año, cabecera de fecha, bloqueo global
  theme/app_theme.dart           Paleta washi/sumi/bermellón, claro y oscuro
tool/patch_android.py            Adapta el proyecto Android generado
.github/workflows/build-apk.yml  Compila el APK en GitHub Actions
```

## Detalles de comportamiento

- **Guardado**: el texto se guarda solo tras unos instantes sin teclear (0,9 s), al cambiar de día, al abrir Ajustes y al pasar la app a segundo plano. También hay un botón **Guardar**. Si dejas una entrada vacía, se borra y ese año vuelve a mostrar «Sin entrada este año».
- **29 de febrero**: existe como día navegable. En años no bisiestos la tarjeta lo indica en lugar de dejar escribir.
- **Cambio de día**: si la app estaba en segundo plano y pasa la medianoche, al volver muestra el nuevo día (solo si estabas viendo «hoy»).
- **Recordatorio**: usa un aviso «inexacto» para no necesitar el permiso de alarmas exactas; Android puede retrasarlo unos minutos. Se reprograma al abrir la app.
- **Bloqueo**: se pide al abrir la app y cada vez que vuelve de segundo plano; la vista previa del selector de apps queda tapada. Si el dispositivo se queda sin huella ni bloqueo de pantalla, la pantalla de bloqueo ofrece desactivarlo para que el diario no quede inaccesible.
- **Copias de seguridad**: la base de datos es un archivo local. Android puede incluirla en su copia automática a Google Drive; si no quieres eso, añade `android:allowBackup="false"` a `<application>` en el manifiesto.
