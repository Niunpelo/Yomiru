import 'package:intl/intl.dart';

/// Pone en mayúscula la primera letra.
String capitalize(String text) {
  if (text.isEmpty) {
    return text;
  }
  return text[0].toUpperCase() + text.substring(1);
}

/// Texto del día y el mes, por ejemplo "15 de Marzo".
String dayMonthLabel(DateTime date) {
  final String month = DateFormat.MMMM('es').format(date);
  return '${date.day} de ${capitalize(month)}';
}

/// Nombre del día de la semana, por ejemplo "Domingo".
String weekdayLabel(DateTime date) {
  return capitalize(DateFormat.EEEE('es').format(date));
}
