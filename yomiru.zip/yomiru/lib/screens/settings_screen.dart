import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/settings_provider.dart';
import '../theme/app_theme.dart';

const String kAppVersion = '1.0.0';

/// Ajustes: bloqueo biométrico, recordatorio diario y apariencia.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _busy = false;

  /// Ejecuta un cambio de ajustes y, si falla, enseña el motivo en un aviso.
  Future<void> _run(Future<String?> Function() action) async {
    if (_busy) {
      return;
    }
    setState(() => _busy = true);
    final String? error = await action();
    if (!mounted) {
      return;
    }
    setState(() => _busy = false);
    if (error != null) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(error)));
    }
  }

  Future<void> _pickReminderTime(SettingsProvider settings) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: settings.reminderTime,
      helpText: 'Hora del recordatorio',
      builder: (BuildContext context, Widget? child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
    if (picked == null) {
      return;
    }
    await _run(() => settings.setReminderTime(picked));
  }

  @override
  Widget build(BuildContext context) {
    final SettingsProvider settings = context.watch<SettingsProvider>();
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final String timeText = MaterialLocalizations.of(context).formatTimeOfDay(
      settings.reminderTime,
      alwaysUse24HourFormat: true,
    );

    return Scaffold(
      appBar: AppBar(title: const Text('Ajustes')),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: ListView(
              padding: const EdgeInsets.only(bottom: 32),
              children: <Widget>[
                const _SectionLabel('Privacidad'),
                SwitchListTile(
                  secondary: const Icon(Icons.fingerprint_rounded),
                  title: const Text('Bloqueo biométrico'),
                  subtitle: const Text(
                    'Pide huella, rostro o el bloqueo de pantalla al abrir Yomiru.',
                  ),
                  value: settings.biometricEnabled,
                  onChanged: _busy
                      ? null
                      : (bool value) =>
                          _run(() => settings.setBiometricEnabled(value)),
                ),
                const Divider(height: 32),
                const _SectionLabel('Recordatorio diario'),
                SwitchListTile(
                  secondary: const Icon(Icons.notifications_none_rounded),
                  title: const Text('Recordarme escribir'),
                  subtitle: const Text('Un aviso cada día a la hora elegida.'),
                  value: settings.reminderEnabled,
                  onChanged: _busy
                      ? null
                      : (bool value) =>
                          _run(() => settings.setReminderEnabled(value)),
                ),
                ListTile(
                  leading: const Icon(Icons.schedule_rounded),
                  title: const Text('Hora del recordatorio'),
                  subtitle: Text(
                    settings.reminderEnabled
                        ? 'Cada día a las $timeText'
                        : 'Se usará cuando actives el recordatorio',
                  ),
                  trailing: Text(
                    timeText,
                    style: theme.textTheme.titleLarge?.copyWith(
                      color: scheme.primary,
                    ),
                  ),
                  onTap: _busy ? null : () => _pickReminderTime(settings),
                ),
                const Divider(height: 32),
                const _SectionLabel('Apariencia'),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: SegmentedButton<ThemeMode>(
                    showSelectedIcon: false,
                    segments: const <ButtonSegment<ThemeMode>>[
                      ButtonSegment<ThemeMode>(
                        value: ThemeMode.system,
                        label: Text('Sistema'),
                        icon: Icon(Icons.brightness_auto_outlined),
                      ),
                      ButtonSegment<ThemeMode>(
                        value: ThemeMode.light,
                        label: Text('Claro'),
                        icon: Icon(Icons.light_mode_outlined),
                      ),
                      ButtonSegment<ThemeMode>(
                        value: ThemeMode.dark,
                        label: Text('Oscuro'),
                        icon: Icon(Icons.dark_mode_outlined),
                      ),
                    ],
                    selected: <ThemeMode>{settings.themeMode},
                    onSelectionChanged: (Set<ThemeMode> selection) {
                      settings.setThemeMode(selection.first);
                    },
                  ),
                ),
                const SizedBox(height: 40),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32),
                  child: Column(
                    children: <Widget>[
                      Text(
                        'Yomiru $kAppVersion',
                        style: TextStyle(
                          fontFamily: kSerifFamily,
                          fontSize: 16,
                          letterSpacing: 2,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Tus entradas se guardan en una base de datos local de '
                        'este dispositivo, sin cuentas ni servidores.',
                        textAlign: TextAlign.center,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 4),
      child: Text(
        text.toUpperCase(),
        style: theme.textTheme.labelMedium?.copyWith(
          color: theme.colorScheme.primary,
          letterSpacing: 1.6,
        ),
      ),
    );
  }
}
