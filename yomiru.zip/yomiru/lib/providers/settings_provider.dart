import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/biometric_service.dart';
import '../services/notification_service.dart';

/// Ajustes de la app: bloqueo biométrico, recordatorio diario y tema.
///
/// Los métodos que pueden fallar devuelven un mensaje de error en español
/// listo para mostrar, o null si todo ha ido bien.
class SettingsProvider extends ChangeNotifier {
  SettingsProvider({
    required BiometricService biometricService,
    NotificationService? notificationService,
  })  : _biometric = biometricService,
        _notifications = notificationService ?? NotificationService.instance;

  static const String _biometricKey = 'biometric_enabled';
  static const String _reminderEnabledKey = 'reminder_enabled';
  static const String _reminderHourKey = 'reminder_hour';
  static const String _reminderMinuteKey = 'reminder_minute';
  static const String _themeModeKey = 'theme_mode';

  final BiometricService _biometric;
  final NotificationService _notifications;
  SharedPreferences? _prefs;

  bool _biometricEnabled = false;
  bool _reminderEnabled = false;
  TimeOfDay _reminderTime = const TimeOfDay(hour: 21, minute: 0);
  ThemeMode _themeMode = ThemeMode.system;

  bool get biometricEnabled => _biometricEnabled;
  bool get reminderEnabled => _reminderEnabled;
  TimeOfDay get reminderTime => _reminderTime;
  ThemeMode get themeMode => _themeMode;

  /// Lee los ajustes guardados y reprograma el recordatorio si estaba activo.
  /// Nunca lanza excepciones: si algo falla, se usan los valores por defecto.
  Future<void> load() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      _prefs = prefs;
      _biometricEnabled = prefs.getBool(_biometricKey) ?? false;
      _reminderEnabled = prefs.getBool(_reminderEnabledKey) ?? false;
      _reminderTime = TimeOfDay(
        hour: prefs.getInt(_reminderHourKey) ?? 21,
        minute: prefs.getInt(_reminderMinuteKey) ?? 0,
      );
      final int themeIndex = prefs.getInt(_themeModeKey) ?? ThemeMode.system.index;
      if (themeIndex >= 0 && themeIndex < ThemeMode.values.length) {
        _themeMode = ThemeMode.values[themeIndex];
      }
    } catch (error) {
      debugPrint('Yomiru: no se pudieron leer los ajustes: $error');
    }

    if (_reminderEnabled) {
      try {
        // Se reprograma en cada arranque por si ha cambiado la zona horaria.
        await _notifications.scheduleDailyReminder(_reminderTime);
      } catch (error) {
        debugPrint('Yomiru: no se pudo reprogramar el recordatorio: $error');
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Seguridad biométrica
  // ---------------------------------------------------------------------------

  /// Activa o desactiva el bloqueo. En ambos casos se pide identificarse antes.
  Future<String?> setBiometricEnabled(bool enabled) async {
    if (enabled == _biometricEnabled) {
      return null;
    }

    final bool available = await _biometric.isAvailable();
    if (!available) {
      if (enabled) {
        return 'Este dispositivo no tiene huella, rostro ni bloqueo de pantalla '
            'configurados. Actívalos en los ajustes del sistema.';
      }
      // Si ya no hay forma de autenticar, se permite desactivar sin más.
      await _storeBiometric(false);
      return null;
    }

    final bool verified = await _biometric.authenticate(
      reason: enabled
          ? 'Confirma tu identidad para activar el bloqueo de Yomiru'
          : 'Confirma tu identidad para desactivar el bloqueo de Yomiru',
    );
    if (!verified) {
      return 'No se pudo verificar tu identidad.';
    }

    await _storeBiometric(enabled);
    return null;
  }

  /// Desactiva el bloqueo sin pedir autenticación. Solo lo usa la pantalla de
  /// bloqueo cuando el dispositivo ya no puede autenticar a nadie, para que el
  /// diario no quede inaccesible.
  Future<void> disableBiometricWithoutPrompt() => _storeBiometric(false);

  Future<void> _storeBiometric(bool enabled) async {
    _biometricEnabled = enabled;
    await _prefs?.setBool(_biometricKey, enabled);
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Recordatorio diario
  // ---------------------------------------------------------------------------

  Future<String?> setReminderEnabled(bool enabled) async {
    if (enabled == _reminderEnabled) {
      return null;
    }
    try {
      if (enabled) {
        final bool granted = await _notifications.requestPermission();
        if (!granted) {
          return 'Permite las notificaciones de Yomiru en los ajustes del '
              'sistema para recibir el recordatorio.';
        }
        await _notifications.scheduleDailyReminder(_reminderTime);
      } else {
        await _notifications.cancelDailyReminder();
      }
    } catch (error) {
      debugPrint('Yomiru: error con el recordatorio: $error');
      return 'No se pudo programar el recordatorio.';
    }

    _reminderEnabled = enabled;
    await _prefs?.setBool(_reminderEnabledKey, enabled);
    notifyListeners();
    return null;
  }

  Future<String?> setReminderTime(TimeOfDay time) async {
    if (_reminderEnabled) {
      try {
        await _notifications.scheduleDailyReminder(time);
      } catch (error) {
        debugPrint('Yomiru: error al cambiar la hora: $error');
        return 'No se pudo cambiar la hora del recordatorio.';
      }
    }

    _reminderTime = time;
    await _prefs?.setInt(_reminderHourKey, time.hour);
    await _prefs?.setInt(_reminderMinuteKey, time.minute);
    notifyListeners();
    return null;
  }

  // ---------------------------------------------------------------------------
  // Apariencia
  // ---------------------------------------------------------------------------

  Future<void> setThemeMode(ThemeMode mode) async {
    if (mode == _themeMode) {
      return;
    }
    _themeMode = mode;
    await _prefs?.setInt(_themeModeKey, mode.index);
    notifyListeners();
  }
}
