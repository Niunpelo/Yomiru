import 'dart:async';

import 'package:flutter/foundation.dart';

import '../database/database_helper.dart';
import '../models/entry_model.dart';

/// Estado del guardado automático del texto del año actual.
enum SaveStatus { idle, unsaved, saving, saved, error }

/// Gestiona el día seleccionado, las entradas de los últimos años y el guardado.
class DiaryProvider extends ChangeNotifier {
  DiaryProvider({DatabaseHelper? databaseHelper, this.yearsToShow = 5})
      : assert(yearsToShow >= 1),
        _db = databaseHelper ?? DatabaseHelper.instance {
    _targetCursor = _cursorFor(DateTime.now());
    _cursor = _targetCursor;
  }

  /// Año bisiesto usado como calendario de referencia. Con él existen los 366
  /// días posibles, incluido el 29 de febrero, y se puede navegar de forma
  /// circular sin depender del año actual.
  static const int _referenceYear = 2000;

  static const Duration _autosaveDelay = Duration(milliseconds: 900);

  final DatabaseHelper _db;

  /// Cuántos años se muestran por día (el actual y los anteriores).
  final int yearsToShow;

  /// Día que se está mostrando (fecha UTC dentro del año de referencia).
  late DateTime _cursor;

  /// Día al que se quiere llegar; se actualiza al instante para que pulsar
  /// varias veces seguidas ">" avance un día por pulsación aunque la carga
  /// del día anterior no haya terminado.
  late DateTime _targetCursor;

  int _entryYear = DateTime.now().year;
  Map<int, Entry> _entries = const <int, Entry>{};
  bool _isReady = false;
  bool _followingToday = true;
  String? _errorMessage;
  SaveStatus _saveStatus = SaveStatus.idle;

  int _loadToken = 0;
  Timer? _autosaveTimer;
  String? _pendingText;
  String? _pendingDayKey;
  int? _pendingYear;
  Future<void> _saveQueue = Future<void>.value();
  bool _disposed = false;

  // ---------------------------------------------------------------------------
  // Lectura del estado
  // ---------------------------------------------------------------------------

  /// Falso hasta que se han cargado las entradas por primera vez.
  bool get isReady => _isReady;

  /// Mensaje de error si no se pudo abrir el diario.
  String? get errorMessage => _errorMessage;

  /// Mes seleccionado (1-12).
  int get month => _cursor.month;

  /// Día del mes seleccionado (1-31).
  int get day => _cursor.day;

  /// Clave "MM-DD" del día seleccionado.
  String get dayKey => Entry.dayKeyFor(_cursor);

  /// Fecha de referencia (año bisiesto) para mostrar el nombre del día y del mes,
  /// incluso cuando el día seleccionado no existe en el año actual.
  DateTime get referenceDate => DateTime(_referenceYear, _cursor.month, _cursor.day);

  /// Año en el que se escribe: el año actual en el momento de cargar el día.
  int get entryYear => _entryYear;

  /// Años que se muestran, del más reciente al más antiguo.
  List<int> get years =>
      List<int>.generate(yearsToShow, (int index) => _entryYear - index);

  /// El día seleccionado dentro del año actual, o null si ese año no lo tiene
  /// (el 29 de febrero en un año no bisiesto).
  DateTime? get selectedDate => _dateInYear(_entryYear);

  /// Verdadero si se puede escribir en la tarjeta del año actual.
  bool get canWriteCurrentYear => selectedDate != null;

  /// Verdadero si el día seleccionado es el de hoy.
  bool get isToday => dayKey == Entry.dayKeyFor(DateTime.now());

  /// Indica si el día seleccionado existe en [year].
  bool dayExistsIn(int year) => _dateInYear(year) != null;

  /// Entrada guardada de un año concreto para el día seleccionado.
  Entry? entryFor(int year) => _entries[year];

  /// Entrada del año actual para el día seleccionado.
  Entry? get currentEntry => _entries[_entryYear];

  SaveStatus get saveStatus => _saveStatus;

  DateTime? _dateInYear(int year) {
    final DateTime candidate = DateTime(year, month, day);
    return candidate.month == month ? candidate : null;
  }

  // ---------------------------------------------------------------------------
  // Navegación entre días
  // ---------------------------------------------------------------------------

  /// Carga el día de hoy. Se llama una vez al abrir la pantalla principal.
  Future<void> initialize() => _showDay(_cursorFor(DateTime.now()));

  /// Vuelve a intentar la carga tras un error.
  Future<void> retry() => _showDay(_targetCursor);

  Future<void> goToToday() => _showDay(_cursorFor(DateTime.now()));

  Future<void> goToPreviousDay() => _showDay(_shift(_targetCursor, -1));

  Future<void> goToNextDay() => _showDay(_shift(_targetCursor, 1));

  /// Salta al día y mes de [date] (el año de [date] se ignora).
  Future<void> goToDate(DateTime date) => _showDay(_cursorFor(date));

  /// Se llama al volver a la app: si ha cambiado el día (o el año) mientras
  /// estaba en segundo plano, actualiza lo que se muestra.
  Future<void> refreshIfNeeded() async {
    if (!_isReady) {
      return;
    }
    final DateTime now = DateTime.now();
    final bool dayChanged = Entry.dayKeyFor(now) != dayKey;
    if (_followingToday && (dayChanged || now.year != _entryYear)) {
      await goToToday();
    } else if (now.year != _entryYear) {
      await _showDay(_targetCursor);
    }
  }

  DateTime _cursorFor(DateTime date) =>
      DateTime.utc(_referenceYear, date.month, date.day);

  DateTime _shift(DateTime from, int delta) {
    final DateTime start = DateTime.utc(_referenceYear, 1, 1);
    final int index = from.difference(start).inDays;
    // En Dart el resto con divisor positivo nunca es negativo.
    final int next = (index + delta) % 366;
    return start.add(Duration(days: next));
  }

  Future<void> _showDay(DateTime cursor) async {
    _targetCursor = cursor;
    // Antes de cambiar de día se guarda lo que haya a medias en el día actual.
    await flushPendingSave();

    final int token = ++_loadToken;
    final int year = DateTime.now().year;
    final String key = Entry.dayKeyFor(cursor);

    try {
      final List<Entry> rows = await _db.getEntriesForDay(
        key,
        fromYear: year - (yearsToShow - 1),
        toYear: year,
      );
      if (token != _loadToken || _disposed) {
        return;
      }
      _cursor = cursor;
      _entryYear = year;
      _entries = <int, Entry>{for (final Entry entry in rows) entry.year: entry};
      _followingToday = key == Entry.dayKeyFor(DateTime.now());
      _saveStatus = SaveStatus.idle;
      _errorMessage = null;
      _isReady = true;
      _notify();
    } catch (error, stackTrace) {
      debugPrint('Yomiru: error al cargar las entradas: $error\n$stackTrace');
      if (token != _loadToken || _disposed) {
        return;
      }
      _errorMessage = 'No se pudo abrir el diario.';
      _notify();
    }
  }

  // ---------------------------------------------------------------------------
  // Guardado
  // ---------------------------------------------------------------------------

  /// Se llama cada vez que el usuario cambia el texto del año actual.
  /// Guarda automáticamente cuando deja de escribir unos instantes.
  void onContentChanged(String text) {
    if (!canWriteCurrentYear) {
      return;
    }
    // Se anotan el día y el año ahora, no al guardar, para que el texto vaya
    // siempre a la entrada correcta aunque el usuario cambie de día enseguida.
    _pendingText = text;
    _pendingDayKey = dayKey;
    _pendingYear = _entryYear;

    _autosaveTimer?.cancel();
    _autosaveTimer = Timer(_autosaveDelay, () {
      unawaited(flushPendingSave());
    });

    if (_saveStatus != SaveStatus.unsaved) {
      _saveStatus = SaveStatus.unsaved;
      _notify();
    }
  }

  /// Guarda ahora mismo el texto indicado (botón "Guardar").
  Future<void> saveNow(String text) {
    if (!canWriteCurrentYear) {
      return Future<void>.value();
    }
    _pendingText = text;
    _pendingDayKey = dayKey;
    _pendingYear = _entryYear;
    return flushPendingSave();
  }

  /// Escribe en la base de datos lo que esté pendiente. Las llamadas se
  /// ejecutan una detrás de otra para que nunca se pisen entre sí.
  Future<void> flushPendingSave() {
    _autosaveTimer?.cancel();
    _autosaveTimer = null;
    _saveQueue = _saveQueue.then((_) => _writePending());
    return _saveQueue;
  }

  Future<void> _writePending() async {
    final String? text = _pendingText;
    final String? key = _pendingDayKey;
    final int? year = _pendingYear;
    if (text == null || key == null || year == null) {
      return;
    }
    _pendingText = null;
    _pendingDayKey = null;
    _pendingYear = null;

    _saveStatus = SaveStatus.saving;
    _notify();

    try {
      final Entry? saved = await _db.saveEntry(
        dayOfYear: key,
        year: year,
        content: text,
      );
      if (key == dayKey && year == _entryYear) {
        final Map<int, Entry> next = Map<int, Entry>.of(_entries);
        if (saved == null) {
          next.remove(year);
        } else {
          next[year] = saved;
        }
        _entries = next;
      }
      _saveStatus =
          _pendingText == null ? SaveStatus.saved : SaveStatus.unsaved;
    } catch (error, stackTrace) {
      debugPrint('Yomiru: error al guardar: $error\n$stackTrace');
      // Se conserva el texto para reintentar en el siguiente guardado.
      _pendingText ??= text;
      _pendingDayKey ??= key;
      _pendingYear ??= year;
      _saveStatus = SaveStatus.error;
    }
    _notify();
  }

  void _notify() {
    if (!_disposed) {
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _autosaveTimer?.cancel();
    super.dispose();
  }
}
