import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/entry_model.dart';

/// Acceso a la base de datos SQLite local donde viven todas las entradas.
class DatabaseHelper {
  DatabaseHelper._internal();

  /// Instancia única compartida por toda la aplicación.
  static final DatabaseHelper instance = DatabaseHelper._internal();

  static const String _databaseName = 'yomiru.db';
  static const int _databaseVersion = 1;
  static const String tableEntries = 'entries';

  Database? _database;
  Future<Database>? _opening;

  /// Base de datos abierta. La primera vez que se pide, se crea o se abre el archivo.
  Future<Database> get database {
    final Database? existing = _database;
    if (existing != null) {
      return Future<Database>.value(existing);
    }
    return _opening ??= _open();
  }

  Future<Database> _open() async {
    try {
      final String directory = await getDatabasesPath();
      final String path = p.join(directory, _databaseName);
      final Database db = await openDatabase(
        path,
        version: _databaseVersion,
        onCreate: _onCreate,
      );
      _database = db;
      return db;
    } catch (_) {
      // Si falla, la próxima llamada vuelve a intentarlo desde cero.
      _opening = null;
      rethrow;
    }
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $tableEntries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        day_of_year TEXT NOT NULL,
        year INTEGER NOT NULL,
        content TEXT NOT NULL,
        updated_at INTEGER NOT NULL,
        UNIQUE (day_of_year, year)
      )
    ''');
  }

  /// Entrada de un día y un año concretos, o null si no existe.
  Future<Entry?> getEntry({
    required String dayOfYear,
    required int year,
  }) async {
    final Database db = await database;
    final List<Map<String, Object?>> rows = await db.query(
      tableEntries,
      where: 'day_of_year = ? AND year = ?',
      whereArgs: <Object?>[dayOfYear, year],
      limit: 1,
    );
    if (rows.isEmpty) {
      return null;
    }
    return Entry.fromMap(rows.first);
  }

  /// Todas las entradas de un día del año ("MM-DD"), de la más reciente a la más antigua.
  ///
  /// Si se indican [fromYear] y [toYear] solo se devuelven los años de ese
  /// rango, ambos incluidos.
  Future<List<Entry>> getEntriesForDay(
    String dayOfYear, {
    int? fromYear,
    int? toYear,
  }) async {
    final Database db = await database;

    final StringBuffer where = StringBuffer('day_of_year = ?');
    final List<Object?> args = <Object?>[dayOfYear];
    if (fromYear != null) {
      where.write(' AND year >= ?');
      args.add(fromYear);
    }
    if (toYear != null) {
      where.write(' AND year <= ?');
      args.add(toYear);
    }

    final List<Map<String, Object?>> rows = await db.query(
      tableEntries,
      where: where.toString(),
      whereArgs: args,
      orderBy: 'year DESC',
    );
    return rows.map(Entry.fromMap).toList();
  }

  /// Años que tienen una entrada guardada para ese día, de más reciente a más antiguo.
  Future<List<int>> getYearsWithEntries(String dayOfYear) async {
    final Database db = await database;
    final List<Map<String, Object?>> rows = await db.query(
      tableEntries,
      columns: <String>['year'],
      where: 'day_of_year = ?',
      whereArgs: <Object?>[dayOfYear],
      orderBy: 'year DESC',
    );
    return rows.map((Map<String, Object?> row) => row['year']! as int).toList();
  }

  /// Guarda o actualiza la entrada de [dayOfYear] y [year].
  ///
  /// * Si ya existía, se actualiza su texto y su fecha de modificación.
  /// * Si no existía, se crea.
  /// * Si [content] está vacío, se borra la entrada existente (si la hay) y
  ///   se devuelve null, de modo que ese año vuelve a mostrarse como "sin entrada".
  ///
  /// Devuelve la entrada resultante, o null si no queda ninguna.
  Future<Entry?> saveEntry({
    required String dayOfYear,
    required int year,
    required String content,
    DateTime? now,
  }) async {
    final Database db = await database;
    final DateTime timestamp = now ?? DateTime.now();
    final bool blank = content.trim().isEmpty;

    return db.transaction<Entry?>((Transaction txn) async {
      final List<Map<String, Object?>> rows = await txn.query(
        tableEntries,
        where: 'day_of_year = ? AND year = ?',
        whereArgs: <Object?>[dayOfYear, year],
        limit: 1,
      );

      if (rows.isNotEmpty) {
        final Entry existing = Entry.fromMap(rows.first);
        if (blank) {
          await txn.delete(
            tableEntries,
            where: 'id = ?',
            whereArgs: <Object?>[existing.id],
          );
          return null;
        }
        if (existing.content == content) {
          return existing;
        }
        final Entry updated = existing.copyWith(
          content: content,
          updatedAt: timestamp,
        );
        await txn.update(
          tableEntries,
          updated.toMap(),
          where: 'id = ?',
          whereArgs: <Object?>[existing.id],
        );
        return updated;
      }

      if (blank) {
        return null;
      }

      final Entry created = Entry(
        dayOfYear: dayOfYear,
        year: year,
        content: content,
        updatedAt: timestamp,
      );
      final int id = await txn.insert(tableEntries, created.toMap());
      return created.copyWith(id: id);
    });
  }

  /// Borra la entrada de un día y un año concretos.
  Future<void> deleteEntry({
    required String dayOfYear,
    required int year,
  }) async {
    final Database db = await database;
    await db.delete(
      tableEntries,
      where: 'day_of_year = ? AND year = ?',
      whereArgs: <Object?>[dayOfYear, year],
    );
  }

  /// Cierra la base de datos. Solo hace falta en pruebas.
  Future<void> close() async {
    final Database? db = _database;
    _database = null;
    _opening = null;
    if (db != null) {
      await db.close();
    }
  }
}
