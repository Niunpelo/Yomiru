import 'package:flutter/material.dart';

/// Hoja de papel con borde fino sobre la que se escribe o se lee cada año.
class PaperCard extends StatelessWidget {
  const PaperCard({
    super.key,
    required this.child,
    this.emphasized = false,
  });

  final Widget child;

  /// Resalta el borde con el color de acento (tarjeta del año actual).
  final bool emphasized;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 14),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: emphasized
              ? scheme.primary.withValues(alpha: 0.55)
              : scheme.outlineVariant,
        ),
      ),
      child: child,
    );
  }
}
