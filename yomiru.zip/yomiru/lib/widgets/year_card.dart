import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/entry_model.dart';
import '../providers/diary_provider.dart';
import '../theme/app_theme.dart';
import '../utils/date_labels.dart';
import 'paper_card.dart';

/// Tarjeta del año actual: es la única en la que se puede escribir.
///
/// Conviene dar a esta tarjeta una `key` que dependa del día y del año
/// mostrados: así, al cambiar de día se crea de nuevo con el texto correcto.
class CurrentYearCard extends StatefulWidget {
  const CurrentYearCard({
    super.key,
    required this.year,
    required this.date,
    required this.initialText,
  });

  final int year;

  /// Fecha dentro de [year], o null si ese día no existe en ese año.
  final DateTime? date;

  final String initialText;

  @override
  State<CurrentYearCard> createState() => _CurrentYearCardState();
}

class _CurrentYearCardState extends State<CurrentYearCard> {
  late final TextEditingController _controller =
      TextEditingController(text: widget.initialText);
  final FocusNode _focusNode = FocusNode();

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final DiaryProvider diary = context.read<DiaryProvider>();
    FocusScope.of(context).unfocus();
    await diary.saveNow(_controller.text);
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final DateTime? date = widget.date;
    final SaveStatus status =
        context.select<DiaryProvider, SaveStatus>((DiaryProvider p) => p.saveStatus);

    return PaperCard(
      emphasized: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _YearHeader(
            year: widget.year,
            weekday: date == null ? null : weekdayLabel(date),
            highlighted: true,
          ),
          const SizedBox(height: 10),
          const Divider(),
          const SizedBox(height: 12),
          if (date == null)
            Text(
              'Este día solo existe en los años bisiestos.',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: scheme.onSurfaceVariant,
                fontStyle: FontStyle.italic,
                fontFamily: kSerifFamily,
              ),
            )
          else ...<Widget>[
            TextField(
              controller: _controller,
              focusNode: _focusNode,
              minLines: 6,
              maxLines: null,
              keyboardType: TextInputType.multiline,
              textCapitalization: TextCapitalization.sentences,
              style: theme.textTheme.bodyLarge?.copyWith(
                fontFamily: kSerifFamily,
                fontSize: 17,
                height: 1.75,
              ),
              cursorColor: scheme.primary,
              decoration: InputDecoration(
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                isDense: true,
                contentPadding: EdgeInsets.zero,
                hintText: 'Escribe sobre tu día…',
                hintStyle: TextStyle(
                  fontFamily: kSerifFamily,
                  fontSize: 17,
                  color: scheme.onSurfaceVariant.withValues(alpha: 0.6),
                ),
              ),
              onChanged: (String text) =>
                  context.read<DiaryProvider>().onContentChanged(text),
            ),
            const SizedBox(height: 8),
            Row(
              children: <Widget>[
                Expanded(child: _SaveStatusLabel(status: status)),
                TextButton.icon(
                  onPressed: status == SaveStatus.saving ? null : _save,
                  icon: const Icon(Icons.check_rounded, size: 18),
                  label: const Text('Guardar'),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

/// Tarjeta de un año anterior: solo lectura.
class PastYearCard extends StatelessWidget {
  const PastYearCard({
    super.key,
    required this.year,
    required this.date,
    required this.entry,
  });

  final int year;

  /// Fecha dentro de [year], o null si ese día no existió en ese año.
  final DateTime? date;

  final Entry? entry;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final DateTime? day = date;
    final Entry? current = entry;

    final TextStyle mutedStyle = TextStyle(
      fontFamily: kSerifFamily,
      fontSize: 15,
      fontStyle: FontStyle.italic,
      color: scheme.onSurfaceVariant.withValues(alpha: 0.8),
    );

    final Widget body;
    if (day == null) {
      body = Text('Este año no tuvo este día.', style: mutedStyle);
    } else if (current == null || current.isBlank) {
      body = Text('Sin entrada este año', style: mutedStyle);
    } else {
      body = SelectableText(
        current.content,
        style: theme.textTheme.bodyLarge?.copyWith(
          fontFamily: kSerifFamily,
          fontSize: 16,
          height: 1.75,
        ),
      );
    }

    return PaperCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _YearHeader(
            year: year,
            weekday: day == null ? null : weekdayLabel(day),
            highlighted: false,
          ),
          const SizedBox(height: 10),
          const Divider(),
          const SizedBox(height: 12),
          body,
          const SizedBox(height: 4),
        ],
      ),
    );
  }
}

class _YearHeader extends StatelessWidget {
  const _YearHeader({
    required this.year,
    required this.weekday,
    required this.highlighted,
  });

  final int year;
  final String? weekday;
  final bool highlighted;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: <Widget>[
        Text(
          '$year',
          style: TextStyle(
            fontFamily: kSerifFamily,
            fontSize: 30,
            fontWeight: FontWeight.w300,
            letterSpacing: 1,
            color: highlighted ? scheme.primary : scheme.onSurfaceVariant,
          ),
        ),
        const Spacer(),
        if (weekday != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Text(
              weekday!,
              style: theme.textTheme.labelLarge?.copyWith(
                color: scheme.onSurfaceVariant,
                fontFamily: kSerifFamily,
                letterSpacing: 0.8,
              ),
            ),
          ),
      ],
    );
  }
}

class _SaveStatusLabel extends StatelessWidget {
  const _SaveStatusLabel({required this.status});

  final SaveStatus status;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    final String text;
    Color color = scheme.onSurfaceVariant;
    switch (status) {
      case SaveStatus.idle:
        return const SizedBox.shrink();
      case SaveStatus.unsaved:
        text = 'Sin guardar…';
      case SaveStatus.saving:
        text = 'Guardando…';
      case SaveStatus.saved:
        text = 'Guardado';
        color = scheme.secondary;
      case SaveStatus.error:
        text = 'No se pudo guardar. Se reintentará.';
        color = scheme.error;
    }

    return Text(
      text,
      style: theme.textTheme.labelMedium?.copyWith(color: color),
    );
  }
}
