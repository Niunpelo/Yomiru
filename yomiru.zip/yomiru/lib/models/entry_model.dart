import 'package:flutter/foundation.dart';

/// Una entrada del diario: lo que se escribió un día concreto de un año concreto.
///
/// El día se guarda como texto "MM-DD" (por ejemplo "03-15") y el año aparte.
/// Así todas las entradas del 15 de marzo, de cualquier año, comparten la
/// misma clave y se pueden mostrar juntas.
@immutable
class Entry {
  const Entry({
    this.id,
    required this.dayOfYear,
    required this.year,
    required this.content,
    required this.updatedAt,
  });

  /// Identificador autoincremental de SQLite. Es null mientras no se ha guardado.
  final int? id;

  /// Día del año en formato "MM-DD", por ejemplo "03-15".
  final String dayOfYear;

  /// Año de la entrada, por ejemplo 2026.
  final int year;

  /// Texto del diario.
  final String content;

  /// Última vez que se modificó el texto.
  final DateTime updatedAt;

  /// Devuelve la clave "MM-DD" de una fecha.
  static String dayKeyFor(DateTime date) => dayKeyOf(date.month, date.day);

  /// Devuelve la clave "MM-DD" a partir de un mes y un día.
  static String dayKeyOf(int month, int day) {
    final String mm = month.toString().padLeft(2, '0');
    final String dd = day.toString().padLeft(2, '0');
    return '$mm-$dd';
  }

  /// Verdadero si el texto está vacío o solo tiene espacios.
  bool get isBlank => content.trim().isEmpty;

  Entry copyWith({
    int? id,
    String? dayOfYear,
    int? year,
    String? content,
    DateTime? updatedAt,
  }) {
    return Entry(
      id: id ?? this.id,
      dayOfYear: dayOfYear ?? this.dayOfYear,
      year: year ?? this.year,
      content: content ?? this.content,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  /// Convierte la entrada al formato de columnas de SQLite.
  Map<String, Object?> toMap() {
    return <String, Object?>{
      if (id != null) 'id': id,
      'day_of_year': dayOfYear,
      'year': year,
      'content': content,
      'updated_at': updatedAt.millisecondsSinceEpoch,
    };
  }

  /// Crea una entrada a partir de una fila de SQLite.
  factory Entry.fromMap(Map<String, Object?> map) {
    return Entry(
      id: map['id'] as int?,
      dayOfYear: map['day_of_year']! as String,
      year: map['year']! as int,
      content: (map['content'] as String?) ?? '',
      updatedAt: DateTime.fromMillisecondsSinceEpoch(map['updated_at']! as int),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is Entry &&
        other.id == id &&
        other.dayOfYear == dayOfYear &&
        other.year == year &&
        other.content == content &&
        other.updatedAt == updatedAt;
  }

  @override
  int get hashCode => Object.hash(id, dayOfYear, year, content, updatedAt);

  @override
  String toString() => 'Entry(id: $id, $year-$dayOfYear, ${content.length} caracteres)';
}
