import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart' show TimeOfDay;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

/// Programa el recordatorio diario para escribir en el diario.
class NotificationService {
  NotificationService._();

  /// Instancia única compartida por toda la aplicación.
  static final NotificationService instance = NotificationService._();

  static const int dailyReminderId = 1001;

  static const String _channelId = 'yomiru_daily_reminder';
  static const String _channelName = 'Recordatorio diario';
  static const String _channelDescription =
      'Aviso diario para escribir en tu diario Yomiru';

  /// Icono blanco y transparente (drawable) que añade tool/patch_android.py.
  static const String _androidIcon = 'ic_stat_yomiru';

  static const NotificationDetails _notificationDetails = NotificationDetails(
    android: AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDescription,
      importance: Importance.defaultImportance,
      priority: Priority.defaultPriority,
    ),
  );

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  /// Prepara el plugin y la zona horaria local. Se puede llamar varias veces.
  Future<void> initialize() async {
    if (_initialized) {
      return;
    }

    tz_data.initializeTimeZones();
    await _configureLocalTimezone();

    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings(_androidIcon);
    const InitializationSettings settings =
        InitializationSettings(android: androidSettings);
    await _plugin.initialize(settings: settings);

    _initialized = true;
  }

  Future<void> _configureLocalTimezone() async {
    try {
      final info = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(info.identifier));
    } catch (error) {
      debugPrint('Yomiru: zona horaria no disponible, uso el desfase: $error');
      tz.setLocalLocation(_locationFromCurrentOffset());
    }
  }

  /// Plan B: busca una zona de la base de datos con el mismo desfase horario
  /// que el dispositivo en este momento.
  tz.Location _locationFromCurrentOffset() {
    final DateTime now = DateTime.now();
    final int offsetMs = now.timeZoneOffset.inMilliseconds;
    final int nowMs = now.millisecondsSinceEpoch;
    for (final tz.Location location in tz.timeZoneDatabase.locations.values) {
      if (location.timeZone(nowMs).offset == offsetMs) {
        return location;
      }
    }
    return tz.UTC;
  }

  /// Pide permiso para mostrar notificaciones (obligatorio desde Android 13).
  Future<bool> requestPermission() async {
    await initialize();
    final AndroidFlutterLocalNotificationsPlugin? android =
        _plugin.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
    if (android == null) {
      return true;
    }
    final bool? granted = await android.requestNotificationsPermission();
    return granted ?? true;
  }

  /// Programa (o reprograma) el aviso diario a la hora indicada.
  ///
  /// Usa un aviso "inexacto" para no necesitar el permiso de alarmas exactas:
  /// Android puede retrasarlo unos minutos para ahorrar batería.
  Future<void> scheduleDailyReminder(TimeOfDay time) async {
    await initialize();
    await _plugin.cancel(id: dailyReminderId);

    await _plugin.zonedSchedule(
      id: dailyReminderId,
      title: 'Yomiru',
      body: '¿Qué ha pasado hoy? Escribe tu entrada del diario.',
      scheduledDate: _nextInstanceOf(time),
      notificationDetails: _notificationDetails,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  /// Quita el aviso diario.
  Future<void> cancelDailyReminder() async {
    await initialize();
    await _plugin.cancel(id: dailyReminderId);
  }

  /// Próxima vez que el reloj marcará [time]: hoy si aún no ha pasado, si no mañana.
  tz.TZDateTime _nextInstanceOf(TimeOfDay time) {
    final tz.TZDateTime now = tz.TZDateTime.now(tz.local);
    tz.TZDateTime scheduled = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      time.hour,
      time.minute,
    );
    if (!scheduled.isAfter(now)) {
      // Se construye con day + 1 (y no sumando 24 h) para respetar el cambio de hora.
      scheduled = tz.TZDateTime(
        tz.local,
        now.year,
        now.month,
        now.day + 1,
        time.hour,
        time.minute,
      );
    }
    return scheduled;
  }
}
