import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart' show TimeOfDay;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

import '../l10n/tr.dart';

/// Programa el recordatorio diario para escribir en el diario.
class NotificationService {
  NotificationService._();

  /// Instancia única compartida por toda la aplicación.
  static final NotificationService instance = NotificationService._();

  static const int dailyReminderId = 1001;

  /// Avisos del botón «Probar los avisos» de Ajustes (el inmediato y el
  /// programado para dentro de un minuto).
  static const int testNowId = 1002;
  static const int testScheduledId = 1003;

  /// Las cápsulas usan identificadores de aviso a partir de este número, para
  /// no chocar nunca con el recordatorio diario.
  static const int capsuleIdOffset = 100000;

  /// Hora del día (en punto) a la que avisa una cápsula del tiempo.
  static const int capsuleReminderHour = 9;

  // Android fija la importancia de un canal cuando se crea y la app ya no
  // puede subirla. Los canales antiguos («gonen_daily_reminder» y
  // «gonen_capsules») se crearon con importancia normal, que no enseña el
  // aviso emergente en pantalla; por eso los avisos usan canales nuevos (_v2)
  // con importancia alta y los antiguos se borran.
  static const List<String> _retiredChannelIds = <String>[
    'gonen_daily_reminder',
    'gonen_capsules',
  ];

  static const String _capsuleChannelId = 'gonen_capsules_v2';
  static String get _capsuleChannelName =>
      tr('Cápsulas del tiempo', 'Time capsules');
  static String get _capsuleChannelDescription => tr(
        'Aviso cuando llega el día de abrir una cápsula del tiempo',
        'Notice when the day to open a time capsule arrives',
      );

  static const String _channelId = 'gonen_daily_reminder_v2';
  static String get _channelName => tr('Recordatorio diario', 'Daily reminder');
  static String get _channelDescription => tr(
        'Aviso diario para escribir en tu diario Gonen',
        'Daily notice to write in your Gonen diary',
      );

  /// Icono blanco y transparente (drawable) que añade tool/patch_android.py.
  static const String _androidIcon = 'ic_stat_gonen';

  static NotificationDetails get _notificationDetails => NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          _channelName,
          channelDescription: _channelDescription,
          importance: Importance.high,
          priority: Priority.high,
        ),
      );

  static NotificationDetails get _capsuleNotificationDetails =>
      NotificationDetails(
        android: AndroidNotificationDetails(
          _capsuleChannelId,
          _capsuleChannelName,
          channelDescription: _capsuleChannelDescription,
          importance: Importance.high,
          priority: Priority.high,
        ),
      );

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  Future<void>? _initializing;

  /// La parte de Android del plugin (null en otras plataformas).
  AndroidFlutterLocalNotificationsPlugin? get _android =>
      _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  /// Prepara el plugin y la zona horaria local. Se puede llamar varias veces,
  /// también a la vez: todas las llamadas esperan a la misma inicialización.
  Future<void> initialize() => _initializing ??= _runInitialize();

  Future<void> _runInitialize() async {
    try {
      tz_data.initializeTimeZones();
      await _configureLocalTimezone();

      const AndroidInitializationSettings androidSettings =
          AndroidInitializationSettings(_androidIcon);
      const InitializationSettings settings =
          InitializationSettings(android: androidSettings);
      await _plugin.initialize(settings: settings);
      // Los canales se crean ya, antes de pedir permiso o programar nada: así
      // Android los conoce desde el primer momento (y el usuario los ve en los
      // ajustes del sistema) en vez de esperar al primer aviso.
      await _createChannels();
    } catch (_) {
      // Si falla, la próxima llamada vuelve a intentarlo.
      _initializing = null;
      rethrow;
    }
  }

  /// Crea (o actualiza el nombre y la descripción de) los dos canales de avisos
  /// y borra los antiguos. Repetirlo es seguro: Android ignora lo que no puede
  /// cambiar y borrar un canal que no existe no hace nada.
  Future<void> _createChannels() async {
    final AndroidFlutterLocalNotificationsPlugin? android = _android;
    if (android == null) {
      return;
    }
    for (final String retired in _retiredChannelIds) {
      await android.deleteNotificationChannel(channelId: retired);
    }
    // Importancia alta: es la que hace que el aviso salga como emergente.
    await android.createNotificationChannel(
      AndroidNotificationChannel(
        _channelId,
        _channelName,
        description: _channelDescription,
        importance: Importance.high,
      ),
    );
    await android.createNotificationChannel(
      AndroidNotificationChannel(
        _capsuleChannelId,
        _capsuleChannelName,
        description: _capsuleChannelDescription,
        importance: Importance.high,
      ),
    );
  }

  Future<void> _configureLocalTimezone() async {
    try {
      final info = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(info.identifier));
    } catch (error) {
      debugPrint('Gonen: zona horaria no disponible, uso el desfase: $error');
      tz.setLocalLocation(_locationFromCurrentOffset());
    }
  }

  /// Plan B: busca una zona de la base de datos con el mismo desfase horario
  /// que el dispositivo en este momento.
  tz.Location _locationFromCurrentOffset() {
    final DateTime now = DateTime.now();
    final int offsetMs = now.timeZoneOffset.inMilliseconds;
    final int nowMs = now.millisecondsSinceEpoch;
    for (final tz.Location location in tz.timeZoneDatabase.locations.values) {
      if (location.timeZone(nowMs).offset == offsetMs) {
        return location;
      }
    }
    return tz.UTC;
  }

  /// Pide permiso para mostrar notificaciones (obligatorio desde Android 13).
  ///
  /// Devuelve true solo si Android dejará mostrar los avisos de Gonen: aunque
  /// el permiso esté concedido, el usuario puede haber apagado las
  /// notificaciones de la app en los ajustes del sistema.
  Future<bool> requestPermission() async {
    await initialize();
    final AndroidFlutterLocalNotificationsPlugin? android = _android;
    if (android == null) {
      return true;
    }
    final bool? granted = await android.requestNotificationsPermission();
    if (granted == false) {
      return false;
    }
    final bool? enabled = await android.areNotificationsEnabled();
    return enabled ?? granted ?? true;
  }

  /// Si Android deja mostrar ahora mismo las notificaciones de Gonen (permiso
  /// concedido y avisos de la app no apagados). Ante cualquier duda devuelve
  /// true, para no avisar de un problema que quizá no existe.
  Future<bool> areNotificationsEnabled() async {
    try {
      await initialize();
      return await _android?.areNotificationsEnabled() ?? true;
    } catch (error) {
      debugPrint('Gonen: no se pudo comprobar el permiso de avisos: $error');
      return true;
    }
  }

  /// Programa (o reprograma) el aviso diario a la hora indicada.
  ///
  /// Usa un aviso "inexacto" para no necesitar el permiso de alarmas exactas:
  /// Android puede retrasarlo unos minutos para ahorrar batería.
  Future<void> scheduleDailyReminder(TimeOfDay time) async {
    await initialize();
    // La zona horaria y el idioma pueden haber cambiado desde el arranque (un
    // viaje, el cambio de idioma): se ponen al día antes de calcular la hora.
    await _configureLocalTimezone();
    await _createChannels();
    await _plugin.cancel(id: dailyReminderId);

    await _plugin.zonedSchedule(
      id: dailyReminderId,
      title: 'Gonen',
      body: tr(
        '¿Qué ha pasado hoy? Escribe tu entrada del diario.',
        'What happened today? Write your diary entry.',
      ),
      scheduledDate: _nextInstanceOf(time),
      notificationDetails: _notificationDetails,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  /// Si el recordatorio diario figura ahora mismo entre los avisos programados.
  Future<bool> isDailyReminderScheduled() async {
    await initialize();
    final List<PendingNotificationRequest> pending =
        await _plugin.pendingNotificationRequests();
    return pending.any(
      (PendingNotificationRequest request) => request.id == dailyReminderId,
    );
  }

  /// Enseña un aviso ahora mismo: comprueba el permiso, el canal y el icono.
  Future<void> showTestNotification() async {
    await initialize();
    await _createChannels();
    await _plugin.show(
      id: testNowId,
      title: 'Gonen',
      body: tr(
        'Si ves este aviso, las notificaciones de Gonen funcionan.',
        'If you can see this notice, Gonen notifications are working.',
      ),
      notificationDetails: _notificationDetails,
    );
  }

  /// Programa un aviso de prueba para dentro de [delay], igual que los reales:
  /// sirve para comprobar que llega con la app cerrada.
  Future<void> scheduleTestNotification({
    Duration delay = const Duration(minutes: 1),
  }) async {
    await initialize();
    await _configureLocalTimezone();
    await _createChannels();
    await _plugin.cancel(id: testScheduledId);
    await _plugin.zonedSchedule(
      id: testScheduledId,
      title: 'Gonen',
      body: tr(
        'Este aviso estaba programado: así llegarán el recordatorio y las '
            'cápsulas, aunque la app esté cerrada.',
        'This notice was scheduled: this is how the reminder and the capsules '
            'will arrive, even with the app closed.',
      ),
      scheduledDate: tz.TZDateTime.now(tz.local).add(delay),
      notificationDetails: _notificationDetails,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
    );
  }

  /// Quita el aviso diario.
  Future<void> cancelDailyReminder() async {
    await initialize();
    await _plugin.cancel(id: dailyReminderId);
  }

  /// Programa el aviso de una cápsula para las 09:00 de su día de apertura.
  ///
  /// El texto no menciona el título, el contenido ni quién la envió para no
  /// enseñarlos en la pantalla de bloqueo. Con [received] avisa de una cápsula
  /// que ha dejado otra persona. Devuelve false si esa hora ya ha pasado.
  Future<bool> scheduleCapsuleOpening({
    required int capsuleId,
    required DateTime openDate,
    bool received = false,
  }) async {
    await initialize();
    await _configureLocalTimezone();
    final tz.TZDateTime scheduled = tz.TZDateTime(
      tz.local,
      openDate.year,
      openDate.month,
      openDate.day,
      capsuleReminderHour,
    );
    if (!scheduled.isAfter(tz.TZDateTime.now(tz.local))) {
      return false;
    }

    await _plugin.zonedSchedule(
      id: capsuleIdOffset + capsuleId,
      title: tr('Gonen · Cápsula del tiempo', 'Gonen · Time capsule'),
      body: received
          ? tr(
              'Hoy puedes abrir una cápsula que te han dejado.',
              'Today you can open a capsule that someone left for you.',
            )
          : tr(
              'Hoy puedes abrir una cápsula que escribiste hace tiempo.',
              'Today you can open a capsule you wrote a while ago.',
            ),
      scheduledDate: scheduled,
      notificationDetails: _capsuleNotificationDetails,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
    );
    return true;
  }

  /// Quita el aviso de una cápsula (al abrirla o borrarla).
  Future<void> cancelCapsuleOpening(int capsuleId) async {
    await initialize();
    await _plugin.cancel(id: capsuleIdOffset + capsuleId);
  }

  /// Próxima vez que el reloj marcará [time]: hoy si aún no ha pasado, si no mañana.
  tz.TZDateTime _nextInstanceOf(TimeOfDay time) {
    final tz.TZDateTime now = tz.TZDateTime.now(tz.local);
    tz.TZDateTime scheduled = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      time.hour,
      time.minute,
    );
    if (!scheduled.isAfter(now)) {
      // Se construye con day + 1 (y no sumando 24 h) para respetar el cambio de hora.
      scheduled = tz.TZDateTime(
        tz.local,
        now.year,
        now.month,
        now.day + 1,
        time.hour,
        time.minute,
      );
    }
    return scheduled;
  }
}
