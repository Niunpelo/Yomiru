# Gonen

Diario de varios años con estética de papelería japonesa. El nombre viene de 五年 (*gonen*, «cinco años»). Cada día muestra, en una misma pantalla, lo que escribiste ese mismo día en años anteriores, y además puedes dejar mensajes para tu yo del futuro en **cápsulas del tiempo**.

- **Diario**: una tarjeta por año. Solo se escribe en el año actual y **solo el propio día, hasta las 23:59**; a las 00:00 la entrada queda en solo lectura (se puede leer y copiar, no editar). Los años anteriores son siempre de solo lectura.
- **Años visibles**: en *Ajustes → Diario* eliges cuántos años anteriores salen en el inicio (de 0 a 5; por defecto 4, es decir, 5 tarjetas; con 5 salen 6). Reducirlo solo oculta tarjetas: nada se borra.
- **Gonen Premium**: desbloquea adjuntar **fotos** (cámara o galería) y **notas de voz** al día y a las cápsulas, y **crear copias de seguridad**. Cuesta **9,99 €/año** (suscripción) o **14,99 € de por vida** (pago único). Ver la sección «Premium y pagos».
- **Dado de ideas** (gratis): en la tarjeta de hoy, el icono del dado 🎲 (arriba a la derecha) abre una hoja con una idea para empezar a escribir, sacada de un banco de más de cien preguntas y frases (el día, gratitud, emociones, personas, sentidos, mirar atrás y adelante, reflexión y creatividad). «Otra idea» tira el dado de nuevo sin repetir hasta que han salido todas; «Escribir sobre esto» pone la frase en el texto para contestar debajo.
- **Calendario** (gratis): cada día en el que escribiste, o guardaste una foto o una nota de voz, aparece con un sello rojo. Arriba salen tu **racha actual**, tu **mejor racha** y el total de **días escritos**. Tocar un día salta a él en el diario.
- **Buscar** (gratis): busca una palabra o frase en todo el diario, sin importar mayúsculas ni tildes («cancion» encuentra «canción»; la ñ sí se distingue). Tocar un resultado salta a ese día.
- **Copia de seguridad**: *crear* una copia es Premium; *restaurarla* es gratis. Ver «Copias de seguridad».
- **Menú lateral** (icono ☰ arriba a la izquierda): Diario, Calendario, Buscar, Cápsulas del tiempo, Copia de seguridad, Gonen Premium y Ajustes. Un punto sobre el icono avisa de que hay cápsulas listas para abrir.
- **Cápsulas del tiempo**: escribes un mensaje (con título opcional), eliges el día de apertura y queda sellado. Con Premium puedes añadirle **fotos y notas de voz**, que quedan selladas con el mensaje. No se puede leer hasta ese día; ese día, a las 09:00, llega un aviso. Tras abrirla se puede releer. Se pueden borrar en cualquier momento.
- **Datos**: SQLite local (`sqflite`). Entradas por `día "MM-DD"` + `año`; cápsulas y adjuntos en sus propias tablas. Las fotos y notas de voz son archivos en el almacenamiento privado de la app.
- **Estado**: `provider`.
- **Privacidad**: bloqueo con huella, rostro o PIN del dispositivo (`local_auth`).
- **Recordatorio**: notificación diaria a la hora elegida (`flutter_local_notifications`).
- **Tema**: claro y oscuro, interfaz en español.

## Conseguir el APK con GitHub (sin instalar nada)

### Método A: repositorio con los archivos sueltos

1. Crea un repositorio nuevo en GitHub (vacío, sin README).
2. Descomprime este ZIP y sube **todo el contenido**, incluida la carpeta oculta `.github`:
   ```bash
   cd gonen
   git init
   git add .
   git commit -m "Gonen"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/gonen.git
   git push -u origin main
   ```
   Si subes los archivos arrastrándolos en la web de GitHub, comprueba que `.github/workflows/build-apk.yml` ha llegado: sin ese archivo no se compila nada.
3. Abre la pestaña **Actions**. El workflow **Build APK** se lanza solo con cada `push` (también a mano con *Run workflow*).
4. Cuando termine (unos 5-10 minutos), entra en la ejecución y descarga el artefacto **gonen-apk** al final de la página. Es un ZIP que contiene `app-release.apk`.
5. Copia el APK al móvil e instálalo (Android te pedirá permitir instalar apps de este origen).

### Método B: subir solo el ZIP

Si GitHub no te deja subir las carpetas, sube `gonen.zip` tal cual a la raíz del repositorio y crea `.github/workflows/build-apk.yml` desde la web de GitHub con el workflow que descomprime el ZIP y compila dentro de `proyecto/gonen`. El resto es igual que en el método A.

Si subes una etiqueta que empiece por `v` (por ejemplo `v1.4.0`), el APK además se publica en *Releases*.

### Comprobar que se ha compilado la versión nueva

Cada ejecución indica qué versión ha compilado, en dos sitios:

- En la página de la ejecución, en **Annotations**, aparece un aviso azul: *«Compilando Gonen 1.4.0 desde 'gonen.zip'. Premium incluido: si»*.
- Cada ejecución sube **dos** artefactos con la versión en el nombre: `gonen-apk-v1.4.0` (el normal) y `gonen-apk-PRUEBA-premium-v1.4.0` (el de prueba con Premium).

Si pone una versión antigua (o *Premium incluido: NO*), el ZIP que hay en el repositorio no es el nuevo. En el método B el workflow elige el ZIP con la **versión más alta** de la raíz del repositorio, así que da igual que el móvil haya renombrado el archivo nuevo (por ejemplo a `gonen (1).zip`): basta con que esté subido en la raíz. Tras instalar, la versión también sale abajo en el menú lateral (el APK de prueba añade «· PRUEBA»).

### Si la compilación falla o hay errores en el código

En la página de la ejecución, en **Annotations**, el paso *Análisis estático* deja un aviso azul con el número de errores y hasta 15 avisos rojos con cada error (fichero, línea y motivo). Si algo no compila, haz una captura de esa zona: es lo que hace falta para arreglarlo. El análisis nunca detiene la compilación por sí solo: es el paso *Compilar el APK* el que falla si hay un error real.

### Qué hace el workflow

El proyecto no incluye la carpeta `android/`: el workflow la genera con `flutter create` con Flutter 3.38 (la versión está fijada en el workflow para que la compilación no cambie sola) y después ejecuta `tool/patch_android.py`, que deja listo lo que exigen los plugins (desugaring, `FlutterFragmentActivity`, permisos, receptores de notificaciones, temas AppCompat e iconos), el canal nativo para guardar y abrir copias de seguridad y las reglas de la copia automática de Android. Así no hace falta guardar en el repositorio los archivos de Android generados.

El APK se firma con la clave de depuración de Flutter: sirve para instalarlo y usarlo, pero no para subirlo a Google Play. Para Play Store tendrás que configurar tu propia clave de firma.

### Probar Premium sin pagar

Los pagos solo funcionan en una app instalada desde Google Play, así que en el APK normal de GitHub no se puede comprar nada. Por eso **cada ejecución genera dos APK**:

| Artefacto | Para qué sirve |
|-----------|----------------|
| `gonen-apk-v1.4.0` | El APK normal, con los pagos reales. |
| `gonen-apk-PRUEBA-premium-v1.4.0` | Trae **Premium desbloqueado sin pagar**: sirve para probar fotos, notas de voz (también en cápsulas) y copias de seguridad. |

Descarga el de PRUEBA al final de la página de la ejecución. En ese APK el menú lateral pone «Gonen 1.4.0 · PRUEBA» y «Gonen Premium · Activo (modo prueba)», y la pantalla Premium lo avisa. **No debe publicarse ni compartirse nunca.**

Aviso de firma: cada ejecución de GitHub firma con una clave de depuración distinta. Los dos APK de la **misma** ejecución se pueden instalar uno encima de otro, pero un APK de otra ejecución no se instala encima: hay que **desinstalar la app antes** (se pierden sus datos locales; haz antes una copia de seguridad si te importan).

## Premium y pagos

| Plan | Precio | Tipo en Google Play | ID del producto |
|------|--------|---------------------|-----------------|
| Anual | 9,99 €/año | Suscripción | `gonen_premium_yearly` |
| De por vida | 14,99 € | Producto de pago único (no consumible) | `gonen_premium_lifetime` |

Qué desbloquea: hasta 5 fotos y 2 notas de voz (máx. 5 min cada una) por día y por cápsula, y crear copias de seguridad. Ver el contenido ya guardado y **restaurar** una copia es siempre gratis, incluso si el premium caduca.

### Publicar con pagos reales

1. Crea una cuenta de **Google Play Console** (pago único de 25 USD) y una app nueva con el identificador `com.gonen.gonen` (el que genera `flutter create --org com.gonen --project-name gonen`).
2. Configura una **clave de firma propia** y compila un **AAB firmado** (`flutter build appbundle --release`). El APK de depuración no sirve para Play.
3. Sube el AAB a una pista de **pruebas internas** (los productos no aparecen hasta que hay una versión subida).
4. En *Monetizar → Productos*:
   - *Suscripciones*: crea `gonen_premium_yearly` con un plan base **anual** de 9,99 € (renovación automática).
   - *Productos integrados*: crea `gonen_premium_lifetime` de 14,99 €.
   - Los ID tienen que coincidir exactamente con los de la tabla (`lib/providers/premium_provider.dart`).
5. En *Configuración → Pruebas de licencia* añade tu cuenta de Google como **tester**: así puedes comprar sin que te cobren.
6. Rellena la **política de privacidad** y el formulario de **seguridad de los datos**. La app usa el micrófono (permiso `RECORD_AUDIO`) y la cámara a través del selector del sistema; todo se guarda solo en el dispositivo.

### Limitaciones a tener en cuenta

- **Sin servidor**: la compra la confirma Google Play en el propio móvil y la app guarda el resultado en local. No hay verificación en un servidor propio, así que alguien con un móvil modificado podría saltarse el pago. Para un diario personal es un riesgo asumible; si algún día importa, hay que añadir un servidor que valide los recibos.
- **Suscripción anual**: la app consulta a Play cada vez que se abre. Si no logra confirmarla durante más de 7 días (por ejemplo, sin conexión), el premium se pausa hasta la próxima confirmación. El pago de por vida no caduca.
- **Restaurar compras**: en la pantalla Premium hay un botón para recuperar la compra tras reinstalar o cambiar de móvil.
- **Caducidad y cancelaciones**: si cancelas la suscripción, sigue activa hasta que acabe el periodo pagado. Cuando caduca, la app puede tardar hasta 7 días en bloquear las funciones premium.
- **Reembolsos**: un reembolso del pago de por vida **no** se detecta (sin servidor, la app no se entera). Si alguna vez hace falta, se puede añadir una consulta del estado de la compra.

## Copias de seguridad

*Menú ☰ → Copia de seguridad.* La copia es **un único archivo `.gonen`** con todo el diario, las cápsulas, las fotos y las notas de voz. Al pulsar *Crear copia*, Android te deja elegir dónde guardarlo (Google Drive, la memoria del móvil, otra app...). No pasa por ningún servidor de Gonen y no hace falta ningún permiso de almacenamiento.

- **Crear** (Premium): guarda todo lo que hay en ese momento. Si una foto o nota de voz figuraba en la base de datos pero su archivo ya no existe, no entra en la copia y se avisa.
- **Restaurar** (gratis): elige un archivo `.gonen`. **Nunca borra ni sobrescribe nada**: solo añade lo que falta. Si un día ya tiene un texto distinto en el móvil, se queda el del móvil (la pantalla te dice cuántos días se han respetado así). Las cápsulas y los archivos que ya estaban no se duplican. Restaurar dos veces la misma copia no cambia nada la segunda vez.
- **Sin cifrar**: el archivo es legible por quien lo tenga. Guárdalo en un lugar privado.
- **Archivo dañado o cortado**: se detecta y se rechaza sin tocar nada de lo que ya tienes.
- **Copia automática de Android** (además de la anterior): si el móvil tiene activada la copia de Google, Android guarda también la base de datos (los textos) y la restaura al reinstalar desde Google Play o al configurar un móvil nuevo. Las fotos y las notas de voz se excluyen de esa copia (`res/xml/gonen_backup_rules.xml`) porque Google solo admite 25 MB por app y, si se pasa, **no guarda nada**. Al pasar datos de móvil a móvil con cable o Bluetooth sí viajan completos. Para tener también las fotos y las notas de voz, usa la copia en archivo.
- **Cambio de firma**: un APK firmado con otra clave no se puede instalar encima del anterior; hay que desinstalarlo y se pierden los datos locales. Haz una copia antes (la firma de depuración de GitHub puede cambiar entre ejecuciones; con tu propia clave para Google Play esto no pasa).

## Compilar en tu ordenador

Requisitos: Flutter 3.38.1 o superior (Dart 3.10+), Java 17 y Python 3. El script `tool/patch_android.py` está pensado para la plantilla de Android de Flutter 3.38; con versiones mucho más nuevas puede necesitar ajustes.

```bash
flutter create --platforms=android --org com.gonen --project-name gonen .
python3 tool/patch_android.py
flutter pub get
flutter run                      # en un móvil o emulador
flutter build apk --release      # build/app/outputs/flutter-apk/app-release.apk
flutter test                     # pruebas de modelos, reglas de edición y menú lateral
```

## Estructura

```
lib/
  main.dart                       Arranque, proveedores, tema y localización
  app_info.dart                   Versión mostrada en la app
  models/
    entry_model.dart              Entry (id, dayOfYear, year, content, updatedAt)
    capsule_model.dart            Capsule y estados: sellada / lista / abierta
    day_access.dart               Regla de las 23:59: editable / terminado / aún no / no existe
    diary_limits.dart             Límites del ajuste «años anteriores»
    attachment_model.dart         Attachment: foto o nota de voz de un día o de una cápsula
    backup_snapshot.dart          Contenido de una copia (JSON) y resultado de restaurarla
    attachment_limits.dart        Máximos por día y calidad de las fotos
    premium_entitlement.dart      Plan (anual / de por vida) y margen de 7 días de la suscripción
  database/database_helper.dart   SQLite v4: entradas, cápsulas y adjuntos (migraciones v1 → v2 → v3 → v4), días escritos y mezcla de copias
  providers/
    diary_provider.dart           Día seleccionado, navegación, guardado automático, bloqueo a medianoche
    capsules_provider.dart        Crear, abrir y borrar cápsulas; avisos
    settings_provider.dart        Años visibles, bloqueo biométrico, recordatorio, tema
    premium_provider.dart         Compras con Google Play (in_app_purchase) y estado premium
  services/
    biometric_service.dart        local_auth
    notification_service.dart     Aviso diario y avisos de cápsulas
    attachment_service.dart       Carpeta privada de fotos y notas de voz
    backup_archive.dart           Formato del archivo .gonen (escritura y lectura por trozos)
    backup_service.dart           Crear y restaurar copias de seguridad
    file_transfer_service.dart    Guardar/abrir archivos con el selector de Android (canal gonen/files)
    external_activity_guard.dart  Evita volver a bloquear la app al volver de la cámara o del pago
  screens/
    home_screen.dart              Menú lateral, cabecera con fecha y tarjetas por año
    capsules_screen.dart          Lista de cápsulas
    new_capsule_screen.dart       Escribir y sellar una cápsula
    capsule_detail_screen.dart    Cuenta atrás / abrir / leer
    calendar_screen.dart          Calendario con sellos y rachas
    search_screen.dart            Búsqueda en todo el diario
    backup_screen.dart            Crear y restaurar copias de seguridad
    premium_screen.dart           Planes, precios, restaurar compras
    image_viewer_screen.dart      Foto a pantalla completa con zoom
    settings_screen.dart          Ajustes
    lock_screen.dart              Pantalla de bloqueo
  widgets/                        Menú, tarjetas, diálogos, cabecera de fecha, bloqueo global,
                                  adjuntos (lista, barra de acciones, grabadora de voz)
  data/writing_prompts.dart       Banco de frases y preguntas del dado de ideas
  utils/                          Textos de fechas, duración, rachas (streak_stats), búsqueda (search_utils) y baraja del dado (prompt_deck)
  theme/app_theme.dart            Paleta washi/sumi/bermellón, claro y oscuro
tool/patch_android.py             Adapta el proyecto Android generado
.github/workflows/build-apk.yml   Compila el APK en GitHub Actions
```

## Detalles de comportamiento

- **Guardado**: el texto se guarda solo tras unos instantes sin teclear (0,9 s), al cambiar de día, al abrir otra pantalla y al pasar la app a segundo plano. El botón de la tarjeta dice **Guardar** solo cuando hay cambios sin guardar (o el último guardado falló); mientras guarda dice *Guardando…* y, cuando todo está en la base de datos, **Guardado** y queda apagado hasta que cambies algo. Si dejas una entrada vacía, se borra y ese año vuelve a mostrar «Sin entrada este año».
- **Regla de las 23:59**: solo se puede escribir en el día de hoy. Lo escrito antes de las 00:00 se guarda; a las 00:00 la tarjeta pasa a solo lectura aunque tengas la app abierta. Los días pasados del año actual se pueden leer pero no editar, y los días futuros no se pueden escribir todavía («Este día aún no ha llegado»). Un día que no escribiste no se puede rellenar después.
- **Fotos y notas de voz**: se añaden desde la tarjeta del año actual, solo con Premium y solo el propio día hasta las 23:59 (igual que el texto). Después quedan en solo lectura: se pueden ver y escuchar, no añadir ni borrar. Una grabación tiene que guardarse antes de las 00:00: si la terminas pasada la medianoche, se descarta (el día ya está cerrado). Cada nota se corta sola a los 5 minutos. Los archivos se guardan en la carpeta privada de la app (las fotos se reducen a 1600 px y calidad 80) y no aparecen en la galería del móvil.
- **29 de febrero**: existe como día navegable. En años no bisiestos la tarjeta lo indica en lugar de dejar escribir.
- **Cambio de día**: si la app estaba en segundo plano y pasa la medianoche, al volver muestra el nuevo día (solo si estabas viendo «hoy»). Con la app abierta a medianoche, la tarjeta se bloquea pero la pantalla no salta sola: pulsa «Hoy».
- **Cápsulas**: el aviso se programa a las 09:00 del día de apertura y no muestra el título ni el contenido en la pantalla de bloqueo. Si deniegas el permiso de notificaciones, la cápsula se guarda igualmente, pero no habrá aviso. El «sellado» es una regla de la app, no cifrado: el texto está en la base de datos local, y cambiar la fecha del teléfono permitiría abrirla antes.
- **Recordatorio diario**: usa un aviso «inexacto» para no necesitar el permiso de alarmas exactas; Android puede retrasarlo unos minutos. Se reprograma al abrir la app.
- **Bloqueo**: se pide al abrir la app y cada vez que vuelve de segundo plano; se intenta tapar la vista previa del selector de apps (Android no siempre lo permite). Si el dispositivo se queda sin huella ni bloqueo de pantalla, la pantalla de bloqueo ofrece desactivarlo para que el diario no quede inaccesible.
- **Rachas**: cuenta días seguidos en los que hay texto o alguna foto o nota de voz. Si hoy todavía no has escrito pero ayer sí, la racha sigue viva (te queda el día de hoy para mantenerla). Las fotos y notas de las cápsulas no cuentan; los 29 de febrero de años no bisiestos tampoco existen.
- **Cápsulas con fotos y notas de voz**: se añaden al escribir la cápsula (solo Premium); mientras está sellada solo se ve cuántas lleva, y al abrirla se ven y se oyen. Si sales sin sellar, los archivos se borran. Al borrar una cápsula se borran también sus archivos.
- **Copia automática de Android**: ver «Copias de seguridad». Si no quieres que Android guarde ni siquiera el texto, cambia `android:allowBackup` a `"false"` en `tool/patch_android.py`.
