import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/l10n/reminder_phrases.dart';
import 'package:gonen/services/notification_service.dart';

void main() {
  group('reminderSlotId', () {
    test('los días seguidos de la ventana, y hoy, tienen identificadores distintos', () {
      // Al renovar con el aviso de hoy aún pendiente, la ventana llega hasta
      // hoy + reminderWindowDays: hoy y ese último día no pueden coincidir.
      final int today = ReminderPhrases.epochDay(DateTime(2026, 11, 6));
      final Set<int> ids = <int>{
        for (int i = 0; i <= NotificationService.reminderWindowDays; i++)
          NotificationService.reminderSlotId(today + i),
      };
      expect(ids.length, NotificationService.reminderWindowDays + 1);
      expect(
        NotificationService.reminderSlotId(today),
        isNot(
          NotificationService.reminderSlotId(
            today + NotificationService.reminderWindowDays,
          ),
        ),
      );
    });

    test('un día y el de una vuelta completa después comparten identificador', () {
      final int day = ReminderPhrases.epochDay(DateTime(2026, 11, 6));
      expect(
        NotificationService.reminderSlotId(day),
        NotificationService.reminderSlotId(
          day + NotificationService.reminderSlotCount,
        ),
      );
    });

    test('no chocan con el aviso de relevo ni con las cápsulas', () {
      final int start = ReminderPhrases.epochDay(DateTime(2026, 1, 1));
      for (int i = 0; i < 400; i++) {
        final int id = NotificationService.reminderSlotId(start + i);
        expect(id, isNot(NotificationService.dailyReminderId));
        expect(id, greaterThanOrEqualTo(NotificationService.reminderSlotBase));
        expect(
          id,
          lessThan(
            NotificationService.reminderSlotBase +
                NotificationService.reminderSlotCount,
          ),
        );
        expect(id, lessThan(NotificationService.capsuleIdOffset));
      }
    });
  });
}
