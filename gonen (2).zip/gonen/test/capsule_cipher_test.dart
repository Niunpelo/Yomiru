import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/services/capsule_cipher.dart';

void main() {
  late Directory dir;

  setUp(() {
    dir = Directory.systemTemp.createTempSync('gonen_cipher_');
  });

  tearDown(() {
    if (dir.existsSync()) {
      dir.deleteSync(recursive: true);
    }
  });

  File fileWith(String name, List<int> bytes) {
    final File file = File('${dir.path}/$name');
    file.writeAsBytesSync(bytes);
    return file;
  }

  Uint8List sample(int length) {
    return Uint8List.fromList(
      List<int>.generate(length, (int i) => (i * 31 + 7) % 256),
    );
  }

  CapsuleCipher newCipher({List<int>? key, int seed = 1}) {
    return CapsuleCipher(masterKey: key, random: Random(seed));
  }

  group('CapsuleCipher', () {
    test('descifrar devuelve exactamente lo que se cifró', () async {
      final CapsuleCipher cipher = newCipher();
      // Incluye tamaños justo en los límites de bloque (32) y de trozo (64 KB).
      for (final int length in <int>[
        0, 1, 31, 32, 33, 65535, 65536, 65537, 200000, //
      ]) {
        final Uint8List data = sample(length);
        final File plain = fileWith('plain-$length', data);
        final File encrypted = File('${dir.path}/enc-$length');
        final File restored = File('${dir.path}/back-$length');

        await cipher.encryptFile(plain, encrypted);
        await cipher.decryptFile(encrypted, restored);

        expect(restored.readAsBytesSync(), data, reason: 'tamaño $length');
      }
    });

    test('el archivo cifrado añade solo cabecera y firma', () async {
      final CapsuleCipher cipher = newCipher();
      final File plain = fileWith('plain', sample(1000));
      final File encrypted = File('${dir.path}/enc');

      await cipher.encryptFile(plain, encrypted);

      expect(
        encrypted.lengthSync(),
        1000 + CapsuleCipher.headerLength + CapsuleCipher.tagLength,
      );
      expect(
        encrypted.readAsBytesSync().sublist(0, 8),
        utf8.encode('GONENCP1'),
      );
    });

    test('el texto original no se puede leer dentro del archivo cifrado', () async {
      final CapsuleCipher cipher = newCipher();
      final List<int> message = utf8.encode(
        'Querida Lucía, el día que abras esto ya habrá pasado mucho tiempo.',
      );
      final File plain = fileWith('plain', message);
      final File encrypted = File('${dir.path}/enc');

      await cipher.encryptFile(plain, encrypted);

      final String raw = latin1.decode(encrypted.readAsBytesSync());
      expect(raw.contains('Querida'), isFalse);
      expect(raw.contains('Lucía'), isFalse);
      expect(raw.contains('tiempo'), isFalse);
    });

    test('el mismo contenido cifrado dos veces da archivos distintos', () async {
      final CapsuleCipher cipher = newCipher();
      final File plain = fileWith('plain', sample(500));
      final File first = File('${dir.path}/enc1');
      final File second = File('${dir.path}/enc2');

      await cipher.encryptFile(plain, first);
      await cipher.encryptFile(plain, second);

      expect(first.readAsBytesSync(), isNot(second.readAsBytesSync()));
    });

    test('con otra clave no se puede descifrar', () async {
      final File plain = fileWith('plain', sample(500));
      final File encrypted = File('${dir.path}/enc');
      final File restored = File('${dir.path}/back');
      await newCipher().encryptFile(plain, encrypted);

      final CapsuleCipher other = newCipher(
        key: List<int>.generate(32, (int i) => 255 - i),
      );

      await expectLater(
        other.decryptFile(encrypted, restored),
        throwsA(isA<FormatException>()),
      );
      expect(restored.existsSync(), isFalse);
    });

    test('un byte cambiado se detecta y no deja ningún resultado', () async {
      final CapsuleCipher cipher = newCipher();
      final File plain = fileWith('plain', sample(70000));
      final File encrypted = File('${dir.path}/enc');
      final File restored = File('${dir.path}/back');
      await cipher.encryptFile(plain, encrypted);

      // Cambia un byte en medio de los datos cifrados.
      final Uint8List bytes = encrypted.readAsBytesSync();
      bytes[CapsuleCipher.headerLength + 40000] ^= 0x01;
      encrypted.writeAsBytesSync(bytes);

      await expectLater(
        cipher.decryptFile(encrypted, restored),
        throwsA(
          isA<FormatException>().having(
            (FormatException e) => e.message,
            'message',
            CapsuleCipher.damagedMessage,
          ),
        ),
      );
      expect(restored.existsSync(), isFalse);
    });

    test('un byte cambiado en la firma o en el nonce también se detecta', () async {
      final CapsuleCipher cipher = newCipher();
      final File plain = fileWith('plain', sample(300));
      final File encrypted = File('${dir.path}/enc');
      await cipher.encryptFile(plain, encrypted);
      final Uint8List original = encrypted.readAsBytesSync();

      for (final int position in <int>[
        original.length - 1, // última byte de la firma
        10, // dentro del nonce
      ]) {
        final Uint8List tampered = Uint8List.fromList(original);
        tampered[position] ^= 0x80;
        encrypted.writeAsBytesSync(tampered);

        await expectLater(
          cipher.decryptFile(encrypted, File('${dir.path}/back')),
          throwsA(isA<FormatException>()),
          reason: 'posición $position',
        );
      }
    });

    test('un archivo cortado o con bytes de más está dañado', () async {
      final CapsuleCipher cipher = newCipher();
      final File plain = fileWith('plain', sample(300));
      final File encrypted = File('${dir.path}/enc');
      await cipher.encryptFile(plain, encrypted);
      final Uint8List original = encrypted.readAsBytesSync();

      encrypted.writeAsBytesSync(original.sublist(0, original.length - 5));
      await expectLater(
        cipher.decryptFile(encrypted, File('${dir.path}/back1')),
        throwsA(isA<FormatException>()),
      );

      encrypted.writeAsBytesSync(<int>[...original, 0]);
      await expectLater(
        cipher.decryptFile(encrypted, File('${dir.path}/back2')),
        throwsA(isA<FormatException>()),
      );
    });

    test('un archivo que no es de Gonen se rechaza con su mensaje', () async {
      final CapsuleCipher cipher = newCipher();
      final File other = fileWith('foto.jpg', sample(200));

      await expectLater(
        cipher.decryptFile(other, File('${dir.path}/back')),
        throwsA(
          isA<FormatException>().having(
            (FormatException e) => e.message,
            'message',
            CapsuleCipher.notCapsuleMessage,
          ),
        ),
      );

      final File tiny = fileWith('tiny', <int>[1, 2, 3]);
      await expectLater(
        cipher.decryptFile(tiny, File('${dir.path}/back2')),
        throwsA(isA<FormatException>()),
      );
    });
  });
}
