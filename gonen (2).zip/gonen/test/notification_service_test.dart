import 'package:flutter/material.dart' show TimeOfDay;
import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/services/notification_service.dart';
import 'package:timezone/timezone.dart' as tz;

tz.TZDateTime _at(int day, int hour, int minute) =>
    tz.TZDateTime(tz.UTC, 2026, 11, day, hour, minute);

void main() {
  group('timeSinceLastDue', () {
    const TimeOfDay reminder = TimeOfDay(hour: 21, minute: 30);

    test('justo después de la hora, cuenta los minutos de retraso', () {
      expect(
        NotificationService.timeSinceLastDue(_at(6, 21, 34), reminder),
        const Duration(minutes: 4),
      );
    });

    test('antes de la hora de hoy, cuenta desde la de ayer', () {
      expect(
        NotificationService.timeSinceLastDue(_at(6, 21, 20), reminder),
        const Duration(hours: 23, minutes: 50),
      );
    });

    test('a la hora exacta no ha pasado nada de tiempo', () {
      expect(
        NotificationService.timeSinceLastDue(_at(6, 21, 30), reminder),
        Duration.zero,
      );
    });

    test('pasada la medianoche cuenta desde la hora de ayer', () {
      expect(
        NotificationService.timeSinceLastDue(_at(7, 0, 10), reminder),
        const Duration(hours: 2, minutes: 40),
      );
    });

    test('un aviso retrasado unos minutos queda dentro del margen', () {
      expect(
        NotificationService.timeSinceLastDue(_at(6, 21, 45), reminder) <
            NotificationService.reminderLateWindow,
        isTrue,
      );
      expect(
        NotificationService.timeSinceLastDue(_at(7, 1, 0), reminder) <
            NotificationService.reminderLateWindow,
        isFalse,
      );
    });
  });
}
