import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/l10n/tr.dart';
import 'package:gonen/utils/date_labels.dart';
import 'package:intl/date_symbol_data_local.dart';

void main() {
  setUpAll(() async {
    await initializeDateFormatting('es');
    await initializeDateFormatting('en');
  });

  tearDown(() => AppLocale.current = AppLanguage.es);

  group('dayOfYear y daysInYear', () {
    test('dayOfYear cuenta desde el 1 de enero', () {
      expect(dayOfYear(DateTime(2026, 1, 1)), 1);
      expect(dayOfYear(DateTime(2026, 3, 1)), 60);
      expect(dayOfYear(DateTime(2026, 12, 31)), 365);
    });

    test('dayOfYear cuenta el 29 de febrero de los años bisiestos', () {
      expect(dayOfYear(DateTime(2028, 2, 29)), 60);
      expect(dayOfYear(DateTime(2028, 3, 1)), 61);
      expect(dayOfYear(DateTime(2028, 12, 31)), 366);
    });

    test('dayOfYear no depende de la hora del día', () {
      expect(dayOfYear(DateTime(2026, 11, 5, 23, 59)), dayOfYear(DateTime(2026, 11, 5)));
    });

    test('daysInYear distingue los años bisiestos', () {
      expect(daysInYear(2026), 365);
      expect(daysInYear(2028), 366);
      expect(daysInYear(1900), 365);
      expect(daysInYear(2000), 366);
    });
  });

  group('textos de fecha', () {
    final DateTime monday = DateTime(2027, 3, 15);

    test('en español', () {
      expect(monthLabel(monday), 'Marzo');
      expect(dayMonthLabel(monday), '15 de Marzo');
      expect(weekdayLabel(monday), 'Lunes');
      expect(fullDateLabel(monday), 'Lunes, 15 de Marzo de 2027');
      expect(monthYearLabel(monday), 'Marzo 2027');
    });

    test('en inglés', () {
      AppLocale.current = AppLanguage.en;
      expect(monthLabel(monday), 'March');
      expect(dayMonthLabel(monday), 'March 15');
      expect(weekdayLabel(monday), 'Monday');
      expect(fullDateLabel(monday), 'Monday, March 15, 2027');
      expect(monthYearLabel(monday), 'March 2027');
    });
  });

  group('remainingDaysLabel', () {
    test('en español', () {
      expect(remainingDaysLabel(0), 'Ya se puede abrir');
      expect(remainingDaysLabel(1), 'Se abre mañana');
      expect(remainingDaysLabel(12), 'Faltan 12 días');
    });

    test('en inglés', () {
      AppLocale.current = AppLanguage.en;
      expect(remainingDaysLabel(0), 'Ready to open');
      expect(remainingDaysLabel(1), 'Opens tomorrow');
      expect(remainingDaysLabel(12), '12 days to go');
    });
  });
}
