import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/models/entry_model.dart';

void main() {
  group('Entry', () {
    test('dayKeyOf rellena mes y día con ceros', () {
      expect(Entry.dayKeyOf(3, 5), '03-05');
      expect(Entry.dayKeyOf(12, 31), '12-31');
    });

    test('dayKeyFor usa el mes y el día de la fecha, sin importar el año', () {
      expect(Entry.dayKeyFor(DateTime(2026, 3, 15)), '03-15');
      expect(Entry.dayKeyFor(DateTime(2024, 2, 29)), '02-29');
    });

    test('toMap y fromMap son operaciones inversas', () {
      final Entry original = Entry(
        id: 7,
        dayOfYear: '03-15',
        year: 2025,
        content: 'Un día tranquilo.',
        updatedAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
      );

      final Entry restored = Entry.fromMap(original.toMap());

      expect(restored, original);
    });

    test('toMap no incluye el id mientras es null', () {
      final Entry entry = Entry(
        dayOfYear: '01-01',
        year: 2026,
        content: 'Año nuevo',
        updatedAt: DateTime.fromMillisecondsSinceEpoch(0),
      );

      expect(entry.toMap().containsKey('id'), isFalse);
    });

    test('isBlank detecta texto vacío o solo con espacios', () {
      final DateTime now = DateTime.fromMillisecondsSinceEpoch(0);
      expect(
        Entry(dayOfYear: '01-01', year: 2026, content: '  \n ', updatedAt: now).isBlank,
        isTrue,
      );
      expect(
        Entry(dayOfYear: '01-01', year: 2026, content: 'Hola', updatedAt: now).isBlank,
        isFalse,
      );
    });
  });
}
