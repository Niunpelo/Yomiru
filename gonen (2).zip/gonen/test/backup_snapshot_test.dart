import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/models/attachment_model.dart';
import 'package:gonen/models/backup_snapshot.dart';
import 'package:gonen/models/capsule_model.dart';
import 'package:gonen/models/entry_model.dart';

BackupSnapshot _sample() {
  return BackupSnapshot(
    appVersion: '1.3.0',
    createdAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
    entries: <Entry>[
      Entry(
        id: 1,
        dayOfYear: '03-15',
        year: 2025,
        content: 'Un día con ñ y tildes: canción 🙂',
        updatedAt: DateTime.fromMillisecondsSinceEpoch(1700000001000),
      ),
    ],
    capsules: <Capsule>[
      Capsule(
        id: 4,
        title: 'Para ti',
        content: 'Hola, futuro',
        createdAt: DateTime.fromMillisecondsSinceEpoch(1700000002000),
        openDate: DateTime(2030, 1, 1),
      ),
    ],
    attachments: <Attachment>[
      Attachment(
        id: 8,
        dayOfYear: '03-15',
        year: 2025,
        type: AttachmentType.image,
        relativePath: '2025/03-15/1700000000000001.jpg',
        createdAt: DateTime.fromMillisecondsSinceEpoch(1700000003000),
      ),
      Attachment.forCapsule(
        id: 9,
        capsuleId: 4,
        type: AttachmentType.audio,
        relativePath: 'capsules/1700000000000002.m4a',
        durationMs: 12000,
        createdAt: DateTime.fromMillisecondsSinceEpoch(1700000004000),
      ),
    ],
  );
}

void main() {
  group('BackupSnapshot', () {
    test('sobrevive a pasar por JSON de texto', () {
      final BackupSnapshot original = _sample();

      final BackupSnapshot restored = BackupSnapshot.fromJson(
        jsonDecode(jsonEncode(original.toJson())),
      );

      expect(restored.appVersion, '1.3.0');
      expect(restored.createdAt, original.createdAt);
      expect(restored.entries, original.entries);
      expect(restored.capsules, original.capsules);
      expect(restored.attachments, original.attachments);
      expect(restored.attachments.last.capsuleId, 4);
      expect(restored.attachments.last.isForCapsule, isTrue);
    });

    test('una copia sin listas se lee como vacía', () {
      final BackupSnapshot snapshot =
          BackupSnapshot.fromJson(<String, Object?>{'format': 1});

      expect(snapshot.entries, isEmpty);
      expect(snapshot.capsules, isEmpty);
      expect(snapshot.attachments, isEmpty);
    });

    test('rechaza lo que no es una copia válida', () {
      expect(() => BackupSnapshot.fromJson(<Object?>[]), throwsFormatException);
      expect(() => BackupSnapshot.fromJson(null), throwsFormatException);
      expect(
        () => BackupSnapshot.fromJson(<String, Object?>{'entries': <Object?>[]}),
        throwsFormatException,
      );
      expect(
        () => BackupSnapshot.fromJson(<String, Object?>{'format': 1, 'entries': 5}),
        throwsFormatException,
      );
    });

    test('rechaza una copia de una versión más nueva', () {
      expect(
        () => BackupSnapshot.fromJson(<String, Object?>{'format': 99}),
        throwsFormatException,
      );
    });

    test('rechaza entradas con datos que faltan', () {
      expect(
        () => BackupSnapshot.fromJson(<String, Object?>{
          'format': 1,
          'entries': <Object?>[
            <String, Object?>{'day_of_year': '03-15'},
          ],
        }),
        throwsFormatException,
      );
    });
  });

  group('BackupMergeResult', () {
    test('isEmpty solo es verdadero si no se añadió nada', () {
      expect(const BackupMergeResult().isEmpty, isTrue);
      expect(const BackupMergeResult(entriesKept: 3).isEmpty, isTrue);
      expect(const BackupMergeResult(entriesAdded: 1).isEmpty, isFalse);
      expect(const BackupMergeResult(capsulesAdded: 1).isEmpty, isFalse);
      expect(const BackupMergeResult(attachmentsAdded: 1).isEmpty, isFalse);
    });
  });
}
