import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/l10n/tr.dart';
import 'package:gonen/theme/app_theme.dart';

/// Verdadero si [text] lleva algún carácter japonés o chino (kana, kanji...).
bool _hasCjk(String text) => text.runes.any(
      (int rune) =>
          (rune >= 0x3000 && rune <= 0x30FF) ||
          (rune >= 0x3400 && rune <= 0x9FFF) ||
          (rune >= 0xFF00 && rune <= 0xFFEF),
    );

void main() {
  group('AppStyle', () {
    test('hay cuatro estilos con identificadores distintos', () {
      expect(AppStyle.values.length, 4);
      expect(
        AppStyle.values.map((AppStyle s) => s.storageId).toSet().length,
        4,
      );
    });

    test('fromStorageId devuelve el mismo estilo que se guardó', () {
      for (final AppStyle style in AppStyle.values) {
        expect(AppStyle.fromStorageId(style.storageId), style);
      }
    });

    test('fromStorageId cae en la papelería con un valor desconocido', () {
      expect(AppStyle.fromStorageId(null), AppStyle.papeleria);
      expect(AppStyle.fromStorageId(''), AppStyle.papeleria);
      expect(AppStyle.fromStorageId('neon'), AppStyle.papeleria);
    });

    test('solo los dos de revista son editoriales y solo el hilo lleva hilo', () {
      expect(AppStyle.papeleria.isEditorial, isFalse);
      expect(AppStyle.hiloRojo.isEditorial, isFalse);
      expect(AppStyle.editorial.isEditorial, isTrue);
      expect(AppStyle.editorialJaponesa.isEditorial, isTrue);

      expect(AppStyle.hiloRojo.hasThread, isTrue);
      expect(
        AppStyle.values.where((AppStyle s) => s.hasThread).length,
        1,
      );
    });

    test('las esquinas son rectas solo en los editoriales', () {
      expect(AppStyle.editorial.cornerRadius, 0);
      expect(AppStyle.editorialJaponesa.cornerRadius, 0);
      expect(AppStyle.papeleria.cornerRadius, greaterThan(0));
      expect(AppStyle.hiloRojo.cornerRadius, greaterThan(0));
    });

    test('las tipografías de revista son las del paquete de fuentes', () {
      expect(AppStyle.editorial.displayFamily, 'DMSerifDisplay');
      expect(AppStyle.editorial.bodyFamily, 'Newsreader');
      expect(AppStyle.editorial.labelFamily, 'IBMPlexMono');
      expect(AppStyle.editorialJaponesa.displayFamily, 'NotoSerif');
      expect(AppStyle.papeleria.labelFamily, isNull);
    });
  });

  group('AppTheme', () {
    test('cada estilo da un tema claro y otro oscuro que lo lleva dentro', () {
      for (final AppStyle style in AppStyle.values) {
        final ThemeData light = AppTheme.light(style);
        final ThemeData dark = AppTheme.dark(style);
        expect(light.brightness, Brightness.light, reason: '$style');
        expect(dark.brightness, Brightness.dark, reason: '$style');
        expect(light.extension<GonenStyleTheme>()?.style, style);
        expect(dark.extension<GonenStyleTheme>()?.style, style);
      }
    });

    test('los estilos tienen colores distintos entre sí', () {
      final Set<int> primaries = <int>{
        for (final AppStyle style in AppStyle.values)
          AppTheme.schemeFor(style, Brightness.light).primary.toARGB32(),
      };
      // Papelería e hilo rojo comparten colores a propósito; la editorial
      // pura y la japonesa no.
      expect(primaries.length, greaterThanOrEqualTo(2));
    });
  });

  group('textos de los estilos', () {
    tearDown(() => AppLocale.current = AppLanguage.es);

    for (final AppLanguage language in AppLanguage.values) {
      testWidgets('no llevan letras japonesas (${language.code})', (
        WidgetTester tester,
      ) async {
        AppLocale.current = language;
        await tester.pumpWidget(
          LanguageScope(
            language: language,
            child: Builder(
              builder: (BuildContext context) {
                for (final AppStyle style in AppStyle.values) {
                  expect(_hasCjk(style.label(context)), isFalse);
                  expect(_hasCjk(style.description(context)), isFalse);
                  expect(style.label(context), isNotEmpty);
                  expect(style.description(context), isNotEmpty);
                }
                return const SizedBox.shrink();
              },
            ),
          ),
        );
      });
    }

    testWidgets('el nombre cambia con el idioma', (WidgetTester tester) async {
      late String es;
      late String en;
      Widget probe(AppLanguage language, void Function(String) save) {
        return LanguageScope(
          language: language,
          child: Builder(
            builder: (BuildContext context) {
              save(AppStyle.hiloRojo.label(context));
              return const SizedBox.shrink();
            },
          ),
        );
      }

      await tester.pumpWidget(probe(AppLanguage.es, (String v) => es = v));
      await tester.pumpWidget(probe(AppLanguage.en, (String v) => en = v));
      expect(es, 'Hilo rojo');
      expect(en, 'Red thread');
    });
  });
}
