import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/l10n/tr.dart';

void main() {
  tearDown(() => AppLocale.current = AppLanguage.es);

  group('AppLanguage', () {
    test('fromCode reconoce los dos idiomas y cae en español', () {
      expect(AppLanguage.fromCode('es'), AppLanguage.es);
      expect(AppLanguage.fromCode('en'), AppLanguage.en);
      expect(AppLanguage.fromCode(null), AppLanguage.es);
      expect(AppLanguage.fromCode('fr'), AppLanguage.es);
    });

    test('cada idioma tiene su nombre y su locale', () {
      expect(AppLanguage.es.nativeName, 'Español');
      expect(AppLanguage.en.nativeName, 'English');
      expect(AppLanguage.en.locale, const Locale('en'));
    });
  });

  group('tr()', () {
    test('por defecto la app está en español', () {
      expect(AppLocale.current, AppLanguage.es);
      expect(tr('Hola', 'Hello'), 'Hola');
    });

    test('sigue el idioma actual', () {
      AppLocale.current = AppLanguage.en;
      expect(tr('Hola', 'Hello'), 'Hello');
      AppLocale.current = AppLanguage.es;
      expect(tr('Hola', 'Hello'), 'Hola');
    });
  });

  group('context.tr', () {
    Widget probe(void Function(String) onText) {
      return Builder(
        builder: (BuildContext context) {
          onText(context.tr('Hola', 'Hello'));
          return const SizedBox.shrink();
        },
      );
    }

    testWidgets('sin LanguageScope usa el idioma global', (
      WidgetTester tester,
    ) async {
      String? text;
      await tester.pumpWidget(probe((String value) => text = value));
      expect(text, 'Hola');

      AppLocale.current = AppLanguage.en;
      await tester.pumpWidget(Container(key: UniqueKey()));
      await tester.pumpWidget(probe((String value) => text = value));
      expect(text, 'Hello');
    });

    testWidgets('con LanguageScope manda el idioma del scope', (
      WidgetTester tester,
    ) async {
      String? text;
      await tester.pumpWidget(
        LanguageScope(
          language: AppLanguage.en,
          child: probe((String value) => text = value),
        ),
      );
      expect(text, 'Hello');
    });

    testWidgets('al cambiar el idioma del scope se redibuja', (
      WidgetTester tester,
    ) async {
      String? text;
      Widget build(AppLanguage language) => LanguageScope(
            language: language,
            child: probe((String value) => text = value),
          );

      await tester.pumpWidget(build(AppLanguage.es));
      expect(text, 'Hola');
      await tester.pumpWidget(build(AppLanguage.en));
      expect(text, 'Hello');
    });
  });
}
