import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/services/backup_archive.dart';

Directory _tempDir() {
  final Directory dir = Directory.systemTemp.createTempSync('gonen_backup_test_');
  addTearDown(() {
    if (dir.existsSync()) {
      dir.deleteSync(recursive: true);
    }
  });
  return dir;
}

Uint8List _pattern(int length) =>
    Uint8List.fromList(List<int>.generate(length, (int i) => (i * 7 + 3) % 256));

void main() {
  group('BackupArchive', () {
    test('acepta solo rutas de adjuntos de Gonen', () {
      expect(BackupArchive.isSafeAttachmentPath('2026/03-15/1700000000000000.jpg'), isTrue);
      expect(BackupArchive.isSafeAttachmentPath('2026/12-31/5.m4a'), isTrue);
      expect(BackupArchive.isSafeAttachmentPath('capsules/1700000000000000.jpg'), isTrue);

      expect(BackupArchive.isSafeAttachmentPath('../2026/03-15/1.jpg'), isFalse);
      expect(BackupArchive.isSafeAttachmentPath('2026/03-15/../../x.jpg'), isFalse);
      expect(BackupArchive.isSafeAttachmentPath('/etc/passwd'), isFalse);
      expect(BackupArchive.isSafeAttachmentPath('capsules/../x.jpg'), isFalse);
      expect(BackupArchive.isSafeAttachmentPath('2026/03-15/1.exe'), isFalse);
      expect(BackupArchive.isSafeAttachmentPath('2026/03-15/a.jpg'), isFalse);
      expect(BackupArchive.isSafeAttachmentPath(r'2026\03-15\1.jpg'), isFalse);
      expect(BackupArchive.isSafeAttachmentPath(''), isFalse);
    });
  });

  group('BackupArchiveWriter y BackupArchiveReader', () {
    test('lo que se escribe se lee igual, incluidos archivos grandes y vacíos', () async {
      final Directory dir = _tempDir();
      final File source = File('${dir.path}/foto.bin')..writeAsBytesSync(_pattern(200000));
      final File empty = File('${dir.path}/vacio.bin')..writeAsBytesSync(<int>[]);
      final File archive = File('${dir.path}/copia.gonen');
      final Uint8List json = Uint8List.fromList(utf8.encode('{"año":"ñandú"}'));

      final BackupArchiveWriter writer = await BackupArchiveWriter.create(archive);
      await writer.addBytes('data.json', json);
      await writer.addFile('files/2026/03-15/1.jpg', source);
      await writer.addFile('files/2026/03-15/2.m4a', empty);
      await writer.close();

      final BackupArchiveReader reader = await BackupArchiveReader.open(archive);
      try {
        final BackupEntryHeader? first = await reader.next();
        expect(first?.name, 'data.json');
        expect(first?.length, json.length);
        expect(await reader.readEntryBytes(), json);

        final BackupEntryHeader? second = await reader.next();
        expect(second?.name, 'files/2026/03-15/1.jpg');
        expect(second?.length, 200000);
        final File copy = File('${dir.path}/copia.bin');
        await reader.copyEntryTo(copy);
        expect(copy.readAsBytesSync(), source.readAsBytesSync());

        final BackupEntryHeader? third = await reader.next();
        expect(third?.name, 'files/2026/03-15/2.m4a');
        expect(third?.length, 0);
        final File emptyCopy = File('${dir.path}/vacio-copia.bin');
        await reader.copyEntryTo(emptyCopy);
        expect(emptyCopy.lengthSync(), 0);

        expect(await reader.next(), isNull);
      } finally {
        await reader.close();
      }
    });

    test('next salta lo que no se ha leído de la entrada anterior', () async {
      final Directory dir = _tempDir();
      final File source = File('${dir.path}/a.bin')..writeAsBytesSync(_pattern(5000));
      final File archive = File('${dir.path}/copia.gonen');

      final BackupArchiveWriter writer = await BackupArchiveWriter.create(archive);
      await writer.addBytes('data.json', utf8.encode('{}'));
      await writer.addFile('files/a', source);
      await writer.addBytes('files/b', <int>[1, 2, 3]);
      await writer.close();

      final BackupArchiveReader reader = await BackupArchiveReader.open(archive);
      try {
        expect((await reader.next())?.name, 'data.json');
        expect((await reader.next())?.name, 'files/a');
        final BackupEntryHeader? last = await reader.next();
        expect(last?.name, 'files/b');
        expect(await reader.readEntryBytes(), <int>[1, 2, 3]);
        expect(await reader.next(), isNull);
      } finally {
        await reader.close();
      }
    });

    test('un archivo que no es de Gonen se rechaza', () async {
      final Directory dir = _tempDir();
      final File notBackup = File('${dir.path}/otro.gonen')
        ..writeAsStringSync('Esto no es una copia de seguridad');
      final File tiny = File('${dir.path}/pequeno.gonen')..writeAsBytesSync(<int>[1, 2]);

      await expectLater(
        BackupArchiveReader.open(notBackup),
        throwsA(isA<FormatException>()),
      );
      await expectLater(
        BackupArchiveReader.open(tiny),
        throwsA(isA<FormatException>()),
      );
    });

    test('una copia cortada se detecta en vez de leerse a medias', () async {
      final Directory dir = _tempDir();
      final File archive = File('${dir.path}/copia.gonen');
      final BackupArchiveWriter writer = await BackupArchiveWriter.create(archive);
      await writer.addBytes('data.json', utf8.encode('{"a":1}'));
      await writer.addBytes('files/x', _pattern(1000));
      await writer.close();

      // Se corta por la mitad del contenido de la segunda entrada.
      final Uint8List whole = archive.readAsBytesSync();
      final File cut = File('${dir.path}/cortada.gonen')
        ..writeAsBytesSync(whole.sublist(0, whole.length - 500));

      final BackupArchiveReader reader = await BackupArchiveReader.open(cut);
      try {
        expect((await reader.next())?.name, 'data.json');
        await reader.readEntryBytes();
        await expectLater(reader.next(), throwsA(isA<FormatException>()));
      } finally {
        await reader.close();
      }
    });

    test('una copia sin marca de fin se detecta', () async {
      final Directory dir = _tempDir();
      final File archive = File('${dir.path}/copia.gonen');
      final BackupArchiveWriter writer = await BackupArchiveWriter.create(archive);
      await writer.addBytes('data.json', utf8.encode('{}'));
      await writer.abort();

      final BackupArchiveReader reader = await BackupArchiveReader.open(archive);
      try {
        expect((await reader.next())?.name, 'data.json');
        await reader.readEntryBytes();
        await expectLater(reader.next(), throwsA(isA<FormatException>()));
      } finally {
        await reader.close();
      }
    });
  });
}
