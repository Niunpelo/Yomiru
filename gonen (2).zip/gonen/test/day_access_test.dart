import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/models/day_access.dart';
import 'package:gonen/models/diary_limits.dart';

void main() {
  group('dayAccessFor', () {
    final DateTime today = DateTime(2026, 11, 5);

    test('hoy se puede editar desde las 00:00 hasta las 23:59:59', () {
      expect(dayAccessFor(today, DateTime(2026, 11, 5, 0, 0, 0)), DayAccess.editable);
      expect(dayAccessFor(today, DateTime(2026, 11, 5, 12, 30)), DayAccess.editable);
      expect(
        dayAccessFor(today, DateTime(2026, 11, 5, 23, 59, 59)),
        DayAccess.editable,
      );
    });

    test('a las 00:00 del día siguiente el día pasa a solo lectura', () {
      expect(dayAccessFor(today, DateTime(2026, 11, 6, 0, 0, 0)), DayAccess.ended);
      expect(dayAccessFor(today, DateTime(2026, 11, 20, 9)), DayAccess.ended);
    });

    test('un día pasado es de solo lectura', () {
      expect(
        dayAccessFor(DateTime(2026, 1, 1), DateTime(2026, 11, 5, 10)),
        DayAccess.ended,
      );
    });

    test('un día futuro todavía no se puede escribir', () {
      expect(
        dayAccessFor(DateTime(2026, 11, 6), DateTime(2026, 11, 5, 23, 59)),
        DayAccess.notYet,
      );
    });

    test('a medianoche, "mañana" pasa a ser hoy y se puede editar', () {
      final DateTime tomorrow = DateTime(2026, 11, 6);
      expect(dayAccessFor(tomorrow, DateTime(2026, 11, 5, 23, 59, 59)), DayAccess.notYet);
      expect(dayAccessFor(tomorrow, DateTime(2026, 11, 6, 0, 0, 1)), DayAccess.editable);
    });

    test('el 31 de diciembre queda cerrado al llegar el 1 de enero', () {
      expect(
        dayAccessFor(DateTime(2026, 12, 31), DateTime(2026, 12, 31, 23, 59)),
        DayAccess.editable,
      );
      expect(
        dayAccessFor(DateTime(2026, 12, 31), DateTime(2027, 1, 1, 0, 0)),
        DayAccess.ended,
      );
    });

    test('el 29 de febrero de un año bisiesto se puede editar ese día', () {
      expect(
        dayAccessFor(DateTime(2028, 2, 29), DateTime(2028, 2, 29, 18)),
        DayAccess.editable,
      );
    });

    test('sin fecha (día que no existe ese año) devuelve missing', () {
      expect(dayAccessFor(null, DateTime(2026, 11, 5)), DayAccess.missing);
    });
  });

  group('DiaryLimits', () {
    test('clampYearsBack respeta el mínimo y el máximo', () {
      expect(DiaryLimits.clampYearsBack(-3), DiaryLimits.minYearsBack);
      expect(DiaryLimits.clampYearsBack(0), 0);
      expect(DiaryLimits.clampYearsBack(4), 4);
      expect(DiaryLimits.clampYearsBack(999), DiaryLimits.maxYearsBack);
    });

    test('se pueden mostrar como máximo 5 años anteriores', () {
      expect(DiaryLimits.maxYearsBack, 5);
      expect(DiaryLimits.clampYearsBack(20), 5);
    });

    test('el valor por defecto está dentro del rango', () {
      expect(DiaryLimits.defaultYearsBack, inInclusiveRange(
        DiaryLimits.minYearsBack,
        DiaryLimits.maxYearsBack,
      ));
    });
  });
}
