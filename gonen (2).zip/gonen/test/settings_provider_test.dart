import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/l10n/tr.dart';
import 'package:gonen/providers/settings_provider.dart';
import 'package:gonen/services/biometric_service.dart';
import 'package:gonen/theme/app_style.dart';
import 'package:shared_preferences/shared_preferences.dart';

SettingsProvider _newProvider() =>
    SettingsProvider(biometricService: BiometricService());

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  tearDown(() => AppLocale.current = AppLanguage.es);

  test('por defecto: papelería y español', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final SettingsProvider settings = _newProvider();
    await settings.load();

    expect(settings.style, AppStyle.papeleria);
    expect(settings.language, AppLanguage.es);
    expect(AppLocale.current, AppLanguage.es);
  });

  test('el estilo elegido se guarda y se recupera', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final SettingsProvider first = _newProvider();
    await first.load();

    int notifications = 0;
    first.addListener(() => notifications++);
    await first.setStyle(AppStyle.editorialJaponesa);
    expect(first.style, AppStyle.editorialJaponesa);
    expect(notifications, 1);

    // Elegir el que ya está puesto no avisa a nadie.
    await first.setStyle(AppStyle.editorialJaponesa);
    expect(notifications, 1);

    final SettingsProvider second = _newProvider();
    await second.load();
    expect(second.style, AppStyle.editorialJaponesa);
  });

  test('un estilo guardado que ya no existe vuelve a la papelería', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{
      'app_style': 'algo_que_ya_no_existe',
    });
    final SettingsProvider settings = _newProvider();
    await settings.load();
    expect(settings.style, AppStyle.papeleria);
  });

  test('el idioma elegido se guarda, se recupera y se aplica en AppLocale', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final SettingsProvider first = _newProvider();
    await first.load();

    await first.setLanguage(AppLanguage.en);
    expect(first.language, AppLanguage.en);
    expect(AppLocale.current, AppLanguage.en);

    // Se simula cerrar y abrir la app.
    AppLocale.current = AppLanguage.es;
    final SettingsProvider second = _newProvider();
    await second.load();
    expect(second.language, AppLanguage.en);
    expect(AppLocale.current, AppLanguage.en);
  });

  test('al cambiar de idioma, AppLocale ya está al día cuando se avisa', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final SettingsProvider settings = _newProvider();
    await settings.load();

    AppLanguage? seenByListener;
    settings.addListener(() => seenByListener = AppLocale.current);
    await settings.setLanguage(AppLanguage.en);
    expect(seenByListener, AppLanguage.en);
  });

  test('el modo claro/oscuro y el estilo se guardan por separado', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final SettingsProvider first = _newProvider();
    await first.load();

    await first.setThemeMode(ThemeMode.dark);
    await first.setStyle(AppStyle.editorial);
    await first.setLanguage(AppLanguage.en);

    final SettingsProvider second = _newProvider();
    await second.load();
    expect(second.themeMode, ThemeMode.dark);
    expect(second.style, AppStyle.editorial);
    expect(second.language, AppLanguage.en);
  });
}
