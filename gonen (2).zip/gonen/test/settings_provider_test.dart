import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/l10n/tr.dart';
import 'package:gonen/providers/settings_provider.dart';
import 'package:gonen/services/biometric_service.dart';
import 'package:gonen/services/notification_service.dart';
import 'package:gonen/theme/app_style.dart';
import 'package:shared_preferences/shared_preferences.dart';

SettingsProvider _newProvider() =>
    SettingsProvider(biometricService: BiometricService());

/// Avisos de mentira: cuenta cuántas veces se programa el recordatorio y deja
/// elegir si Android "permite" las notificaciones.
class _FakeNotifications implements NotificationService {
  bool allowed = true;
  int scheduled = 0;
  int ensured = 0;

  @override
  Future<bool> areNotificationsEnabled() async => allowed;

  @override
  Future<bool> requestPermission() async => allowed;

  @override
  Future<void> scheduleDailyReminder(TimeOfDay time) async => scheduled++;

  @override
  Future<void> ensureDailyReminder(TimeOfDay time) async => ensured++;

  @override
  Future<void> cancelDailyReminder() async {}

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  tearDown(() => AppLocale.current = AppLanguage.es);

  test('por defecto: editorial japonesa y español', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final SettingsProvider settings = _newProvider();
    await settings.load();

    expect(settings.style, AppStyle.editorialJaponesa);
    expect(settings.language, AppLanguage.es);
    expect(AppLocale.current, AppLanguage.es);
  });

  test('el estilo elegido se guarda y se recupera', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final SettingsProvider first = _newProvider();
    await first.load();

    int notifications = 0;
    first.addListener(() => notifications++);
    await first.setStyle(AppStyle.hiloRojo);
    expect(first.style, AppStyle.hiloRojo);
    expect(notifications, 1);

    // Elegir el que ya está puesto no avisa a nadie.
    await first.setStyle(AppStyle.hiloRojo);
    expect(notifications, 1);

    final SettingsProvider second = _newProvider();
    await second.load();
    expect(second.style, AppStyle.hiloRojo);
  });

  test('un estilo guardado que ya no existe vuelve a la editorial japonesa', () async {
    for (final String retired in <String>[
      'algo_que_ya_no_existe',
      // Los dos estilos que se quitaron de la app.
      'papeleria',
      'editorial',
    ]) {
      SharedPreferences.setMockInitialValues(<String, Object>{
        'app_style': retired,
      });
      final SettingsProvider settings = _newProvider();
      await settings.load();
      expect(settings.style, AppStyle.editorialJaponesa, reason: retired);
    }
  });

  test('el idioma elegido se guarda, se recupera y se aplica en AppLocale', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final SettingsProvider first = _newProvider();
    await first.load();

    await first.setLanguage(AppLanguage.en);
    expect(first.language, AppLanguage.en);
    expect(AppLocale.current, AppLanguage.en);

    // Se simula cerrar y abrir la app.
    AppLocale.current = AppLanguage.es;
    final SettingsProvider second = _newProvider();
    await second.load();
    expect(second.language, AppLanguage.en);
    expect(AppLocale.current, AppLanguage.en);
  });

  test('al cambiar de idioma, AppLocale ya está al día cuando se avisa', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final SettingsProvider settings = _newProvider();
    await settings.load();

    AppLanguage? seenByListener;
    settings.addListener(() => seenByListener = AppLocale.current);
    await settings.setLanguage(AppLanguage.en);
    expect(seenByListener, AppLanguage.en);
  });

  test('el modo claro/oscuro y el estilo se guardan por separado', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final SettingsProvider first = _newProvider();
    await first.load();

    await first.setThemeMode(ThemeMode.dark);
    await first.setStyle(AppStyle.hiloRojo);
    await first.setLanguage(AppLanguage.en);

    final SettingsProvider second = _newProvider();
    await second.load();
    expect(second.themeMode, ThemeMode.dark);
    expect(second.style, AppStyle.hiloRojo);
    expect(second.language, AppLanguage.en);
  });

  group('recordatorio diario', () {
    test('con el recordatorio apagado no programa nada ni avisa de bloqueo', () async {
      SharedPreferences.setMockInitialValues(<String, Object>{});
      final _FakeNotifications fake = _FakeNotifications()..allowed = false;
      final SettingsProvider settings = SettingsProvider(
        biometricService: BiometricService(),
        notificationService: fake,
      );
      await settings.load();
      await settings.refreshReminder();

      expect(fake.scheduled, 0);
      expect(fake.ensured, 0);
      expect(settings.notificationsBlocked, isFalse);
    });

    test('con el recordatorio activo lo comprueba cada vez que se pide', () async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        'reminder_enabled': true,
      });
      final _FakeNotifications fake = _FakeNotifications();
      final SettingsProvider settings = SettingsProvider(
        biometricService: BiometricService(),
        notificationService: fake,
      );
      await settings.load();
      expect(fake.scheduled, 0, reason: 'cargar los ajustes no toca los avisos');

      await settings.refreshReminder();
      await settings.refreshReminder();
      // Pide dejarlo programado, pero nunca lo reprograma a ciegas.
      expect(fake.ensured, 2);
      expect(fake.scheduled, 0);
      expect(settings.notificationsBlocked, isFalse);
    });

    test('avisa cuando Android bloquea las notificaciones y se recupera solo', () async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        'reminder_enabled': true,
      });
      final _FakeNotifications fake = _FakeNotifications()..allowed = false;
      final SettingsProvider settings = SettingsProvider(
        biometricService: BiometricService(),
        notificationService: fake,
      );
      await settings.load();

      int notifications = 0;
      settings.addListener(() => notifications++);

      await settings.refreshReminder();
      expect(settings.notificationsBlocked, isTrue);
      expect(notifications, 1);

      // Repetir la comprobación sin cambios no avisa otra vez.
      await settings.refreshReminder();
      expect(notifications, 1);

      // El usuario activa las notificaciones en los ajustes del sistema.
      fake.allowed = true;
      await settings.refreshReminder();
      expect(settings.notificationsBlocked, isFalse);
      expect(notifications, 2);
    });
  });
}
