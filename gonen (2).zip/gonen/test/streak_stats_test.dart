import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/utils/streak_stats.dart';

Set<DateTime> _days(List<List<int>> ymd) => <DateTime>{
      for (final List<int> day in ymd) DateTime(day[0], day[1], day[2]),
    };

void main() {
  final DateTime today = DateTime(2026, 11, 5);

  group('StreakStats.compute', () {
    test('sin días escritos todo es cero', () {
      final StreakStats stats = StreakStats.compute(<DateTime>{}, today);

      expect(stats.current, 0);
      expect(stats.best, 0);
      expect(stats.totalDays, 0);
    });

    test('cuenta los días seguidos hasta hoy', () {
      final StreakStats stats = StreakStats.compute(
        _days(<List<int>>[
          <int>[2026, 11, 3],
          <int>[2026, 11, 4],
          <int>[2026, 11, 5],
        ]),
        today,
      );

      expect(stats.current, 3);
      expect(stats.best, 3);
      expect(stats.totalDays, 3);
    });

    test('la racha sigue viva si hoy aún no se ha escrito pero ayer sí', () {
      final StreakStats stats = StreakStats.compute(
        _days(<List<int>>[
          <int>[2026, 11, 3],
          <int>[2026, 11, 4],
        ]),
        today,
      );

      expect(stats.current, 2);
    });

    test('la racha se pierde si falta ayer y hoy', () {
      final StreakStats stats = StreakStats.compute(
        _days(<List<int>>[
          <int>[2026, 11, 1],
          <int>[2026, 11, 2],
        ]),
        today,
      );

      expect(stats.current, 0);
      expect(stats.best, 2);
      expect(stats.totalDays, 2);
    });

    test('la mejor racha puede ser anterior a la actual', () {
      final StreakStats stats = StreakStats.compute(
        _days(<List<int>>[
          <int>[2026, 10, 1],
          <int>[2026, 10, 2],
          <int>[2026, 10, 3],
          <int>[2026, 10, 4],
          <int>[2026, 10, 5],
          <int>[2026, 11, 4],
          <int>[2026, 11, 5],
        ]),
        today,
      );

      expect(stats.current, 2);
      expect(stats.best, 5);
      expect(stats.totalDays, 7);
    });

    test('la hora no importa, solo el día', () {
      final StreakStats stats = StreakStats.compute(
        <DateTime>{DateTime(2026, 11, 4, 23, 59), DateTime(2026, 11, 5, 0, 1)},
        DateTime(2026, 11, 5, 12),
      );

      expect(stats.current, 2);
      expect(stats.totalDays, 2);
    });

    test('une días seguidos aunque haya cambio de hora o de año', () {
      final StreakStats october = StreakStats.compute(
        _days(<List<int>>[
          <int>[2026, 10, 24],
          <int>[2026, 10, 25],
          <int>[2026, 10, 26],
          <int>[2026, 10, 27],
        ]),
        DateTime(2026, 10, 27),
      );
      final StreakStats newYear = StreakStats.compute(
        _days(<List<int>>[
          <int>[2025, 12, 31],
          <int>[2026, 1, 1],
        ]),
        DateTime(2026, 1, 1),
      );

      expect(october.current, 4);
      expect(newYear.current, 2);
    });
  });
}
