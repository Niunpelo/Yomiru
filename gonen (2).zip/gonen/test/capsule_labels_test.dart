import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/models/capsule_model.dart';
import 'package:gonen/utils/capsule_labels.dart';

Capsule _capsule({String? sender, String? recipient}) {
  return Capsule(
    title: 'Hola',
    content: 'Mensaje',
    createdAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
    openDate: DateTime(2028, 1, 2),
    sender: sender,
    recipient: recipient,
  );
}

void main() {
  group('capsulePeerLabel', () {
    test('una cápsula normal no lleva etiqueta', () {
      expect(capsulePeerLabel(_capsule()), isNull);
    });

    test('una cápsula enviada dice para quién es', () {
      expect(
        capsulePeerLabel(_capsule(sender: 'Ana', recipient: 'Lucía')),
        'Para Lucía',
      );
    });

    test('una cápsula enviada sin nombre dice «otra persona»', () {
      expect(
        capsulePeerLabel(_capsule(sender: 'Ana', recipient: '  ')),
        'Para otra persona',
      );
    });

    test('una cápsula recibida dice de quién es', () {
      expect(capsulePeerLabel(_capsule(sender: 'Ana')), 'De Ana');
    });
  });
}
