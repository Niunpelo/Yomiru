import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/models/entry_model.dart';
import 'package:gonen/utils/search_utils.dart';

Entry _entry(String day, int year, String content) {
  return Entry(
    dayOfYear: day,
    year: year,
    content: content,
    updatedAt: DateTime(year),
  );
}

void main() {
  group('normalizeForSearch', () {
    test('quita tildes y mayúsculas', () {
      expect(normalizeForSearch('Canción ÁÉÍÓÚ Üñ'), 'cancion aeiou uñ');
    });

    test('respeta la ñ: "año" no es "ano"', () {
      expect(normalizeForSearch('AÑO'), 'año');
      expect(normalizeForSearch('año'), isNot(normalizeForSearch('ano')));
    });

    test('no cambia la longitud del texto', () {
      const List<String> samples = <String>[
        'Canción de cuna',
        'AÑO NUEVO',
        'hola 🙂 mundo',
        'İstanbul',
        '',
      ];
      for (final String sample in samples) {
        expect(normalizeForSearch(sample).length, sample.length, reason: sample);
      }
    });
  });

  group('SearchIndex', () {
    final List<Entry> entries = <Entry>[
      _entry('03-15', 2024, 'Fui a la playa con María'),
      _entry('03-15', 2025, 'Playa otra vez, qué calor'),
      _entry('07-01', 2025, 'Trabajo todo el día'),
      _entry('08-01', 2025, '   '),
      _entry('02-30', 2025, 'playa en un día que no existe'),
    ];
    final SearchIndex index = SearchIndex(entries);

    test('ignora las entradas vacías y las de días imposibles', () {
      expect(index.length, 3);
    });

    test('encuentra sin importar mayúsculas y devuelve lo más reciente primero', () {
      final SearchResults results = index.search('PLAYA');

      expect(results.total, 2);
      expect(results.hits.map((SearchHit hit) => hit.date).toList(), <DateTime>[
        DateTime(2025, 3, 15),
        DateTime(2024, 3, 15),
      ]);
    });

    test('encuentra sin importar las tildes y marca dónde está', () {
      final SearchResults results = index.search('maria');

      expect(results.total, 1);
      final SearchHit hit = results.hits.single;
      expect(hit.date, DateTime(2024, 3, 15));
      expect(hit.matchStart, hit.entry.content.indexOf('María'));
      expect(hit.matchLength, 5);
    });

    test('con varias palabras exige que estén todas', () {
      expect(index.search('playa calor').total, 1);
      expect(index.search('playa trabajo').total, 0);
    });

    test('no busca con menos de dos letras', () {
      expect(index.search('p').total, 0);
      expect(index.search('   ').total, 0);
    });

    test('limita los resultados que devuelve pero cuenta todos', () {
      final SearchIndex many = SearchIndex(<Entry>[
        for (int year = 2020; year < 2025; year++) _entry('01-01', year, 'nieve'),
      ]);

      final SearchResults results = many.search('nieve', limit: 2);

      expect(results.hits.length, 2);
      expect(results.total, 5);
      expect(results.hits.first.date.year, 2024);
    });
  });

  group('buildSnippet', () {
    test('recorta alrededor de la coincidencia y añade puntos suspensivos', () {
      final Snippet snippet = buildSnippet('abcdefghij', 4, 2, context: 2);

      expect(snippet.before, '…cd');
      expect(snippet.match, 'ef');
      expect(snippet.after, 'gh…');
    });

    test('no añade puntos suspensivos si el texto cabe entero', () {
      final Snippet snippet = buildSnippet('hola mundo', 5, 5);

      expect(snippet.before, 'hola ');
      expect(snippet.match, 'mundo');
      expect(snippet.after, '');
    });

    test('convierte los saltos de línea en espacios', () {
      final Snippet snippet = buildSnippet('hola\n\nmundo', 0, 4);

      expect(snippet.match, 'hola');
      expect(snippet.after, ' mundo');
    });

    test('aguanta posiciones fuera del texto', () {
      final Snippet snippet = buildSnippet('abc', 10, 4);

      expect(snippet.before + snippet.match + snippet.after, 'abc');
    });
  });
}
