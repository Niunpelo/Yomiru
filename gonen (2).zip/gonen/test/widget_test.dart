// Sustituye a la prueba de ejemplo que genera `flutter create` (hace referencia
// a una clase `MyApp` que Gonen no tiene y por eso siempre fallaba).
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/models/entry_model.dart';
import 'package:gonen/providers/capsules_provider.dart';
import 'package:gonen/providers/premium_provider.dart';
import 'package:gonen/screens/calendar_screen.dart';
import 'package:gonen/screens/search_screen.dart';
import 'package:gonen/widgets/app_drawer.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:provider/provider.dart';

/// Abre [screen] encima de una pantalla con un botón "abrir" y guarda en
/// [onResult] lo que la pantalla devuelva al cerrarse.
Widget _harness(Widget screen, void Function(DateTime? result) onResult) {
  return MaterialApp(
    home: Builder(
      builder: (BuildContext context) {
        return Scaffold(
          body: Center(
            child: ElevatedButton(
              onPressed: () async {
                final DateTime? result = await Navigator.of(context).push<DateTime>(
                  MaterialPageRoute<DateTime>(
                    builder: (BuildContext context) => screen,
                  ),
                );
                onResult(result);
              },
              child: const Text('abrir'),
            ),
          ),
        );
      },
    ),
  );
}

void main() {
  setUpAll(() async {
    await initializeDateFormatting('es');
  });

  testWidgets('el menú lateral incluye todas las secciones', (
    WidgetTester tester,
  ) async {
    final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<CapsulesProvider>(
            create: (_) => CapsulesProvider(),
          ),
          ChangeNotifierProvider<PremiumProvider>(
            create: (_) => PremiumProvider(),
          ),
        ],
        child: MaterialApp(
          home: Scaffold(
            key: scaffoldKey,
            drawer: AppDrawer(
              onOpenCalendar: () {},
              onOpenSearch: () {},
              onOpenCapsules: () {},
              onOpenBackup: () {},
              onOpenPremium: () {},
              onOpenSettings: () {},
            ),
            body: const SizedBox.shrink(),
          ),
        ),
      ),
    );

    scaffoldKey.currentState!.openDrawer();
    await tester.pumpAndSettle();

    expect(find.text('Diario'), findsOneWidget);
    expect(find.text('Calendario'), findsOneWidget);
    expect(find.text('Buscar'), findsOneWidget);
    expect(find.text('Cápsulas del tiempo'), findsOneWidget);
    expect(find.text('Copia de seguridad'), findsOneWidget);
    expect(find.text('Gonen Premium'), findsOneWidget);
    expect(find.text('Ajustes'), findsOneWidget);
  });

  testWidgets('el calendario enseña las rachas y devuelve el día tocado', (
    WidgetTester tester,
  ) async {
    DateTime? result;
    await tester.pumpWidget(
      _harness(
        CalendarScreen(
          loadDays: () async => <DateTime>{DateTime(2026, 11, 3)},
          now: () => DateTime(2026, 11, 5, 10),
        ),
        (DateTime? value) => result = value,
      ),
    );

    await tester.tap(find.text('abrir'));
    await tester.pumpAndSettle();

    expect(find.text('Racha actual'), findsOneWidget);
    expect(find.text('Mejor racha'), findsOneWidget);
    expect(find.text('Días escritos'), findsOneWidget);

    await tester.tap(find.text('4'));
    await tester.pumpAndSettle();

    expect(result, DateTime(2026, 11, 4));
  });

  testWidgets('la búsqueda encuentra una entrada sin importar las tildes', (
    WidgetTester tester,
  ) async {
    DateTime? result;
    await tester.pumpWidget(
      _harness(
        SearchScreen(
          loadEntries: () async => <Entry>[
            Entry(
              dayOfYear: '03-15',
              year: 2025,
              content: 'Una canción preciosa en la radio',
              updatedAt: DateTime(2025, 3, 15),
            ),
            Entry(
              dayOfYear: '04-01',
              year: 2025,
              content: 'Día tranquilo',
              updatedAt: DateTime(2025, 4, 1),
            ),
          ],
        ),
        (DateTime? value) => result = value,
      ),
    );

    await tester.tap(find.text('abrir'));
    await tester.pumpAndSettle();

    await tester.enterText(find.byType(TextField), 'CANCION');
    await tester.pumpAndSettle();

    expect(find.byType(ListTile), findsOneWidget);

    await tester.tap(find.byType(ListTile));
    await tester.pumpAndSettle();

    expect(result, DateTime(2025, 3, 15));
  });
}
