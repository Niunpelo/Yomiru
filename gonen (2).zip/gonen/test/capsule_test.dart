import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/models/capsule_model.dart';

Capsule _capsule({
  required DateTime openDate,
  DateTime? openedAt,
  int? id,
}) {
  return Capsule(
    id: id,
    title: 'Para mi yo del futuro',
    content: 'Espero que todo vaya bien.',
    createdAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
    openDate: openDate,
    openedAt: openedAt,
  );
}

void main() {
  group('Capsule', () {
    test('toMap y fromMap son operaciones inversas', () {
      final Capsule original = _capsule(
        id: 3,
        openDate: DateTime(2027, 3, 15),
        openedAt: DateTime.fromMillisecondsSinceEpoch(1800000000000),
      );

      expect(Capsule.fromMap(original.toMap()), original);
    });

    test('toMap no incluye el id mientras es null y guarda la fecha como texto', () {
      final Map<String, Object?> map =
          _capsule(openDate: DateTime(2027, 3, 5)).toMap();

      expect(map.containsKey('id'), isFalse);
      expect(map['open_date'], '2027-03-05');
      expect(map['opened_at'], isNull);
    });

    test('dateKey y parseDateKey son operaciones inversas', () {
      final DateTime date = DateTime(2031, 1, 9);
      expect(Capsule.dateKey(date), '2031-01-09');
      expect(Capsule.parseDateKey('2031-01-09'), date);
    });

    group('cápsulas enviadas y recibidas', () {
      Capsule shared({String? sender, String? recipient, String? uid}) {
        return Capsule(
          id: 8,
          title: 'Hola',
          content: 'Mensaje',
          createdAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
          openDate: DateTime(2028, 1, 2),
          sender: sender,
          recipient: recipient,
          uid: uid,
        );
      }

      test('una cápsula normal no es ni enviada ni recibida', () {
        final Capsule normal = _capsule(openDate: DateTime(2027, 3, 15));

        expect(normal.isSent, isFalse);
        expect(normal.isReceived, isFalse);
      });

      test('con destinatario es enviada, aunque no tenga nombre', () {
        expect(shared(sender: 'Ana', recipient: 'Lucía').isSent, isTrue);
        expect(shared(sender: 'Ana', recipient: '').isSent, isTrue);
        expect(shared(sender: 'Ana', recipient: '').isReceived, isFalse);
      });

      test('con remitente y sin destinatario es recibida', () {
        final Capsule received = shared(sender: 'Ana');

        expect(received.isReceived, isTrue);
        expect(received.isSent, isFalse);
      });

      test('toMap y fromMap conservan remitente, destinatario e identificador', () {
        final Capsule original =
            shared(sender: 'Ana', recipient: 'Lucía', uid: 'abc123');
        final Map<String, Object?> map = original.toMap();

        expect(map['sender'], 'Ana');
        expect(map['recipient'], 'Lucía');
        expect(map['uid'], 'abc123');
        expect(Capsule.fromMap(map), original);
      });

      test('copyWith no pierde remitente, destinatario ni identificador', () {
        final Capsule original =
            shared(sender: 'Ana', recipient: 'Lucía', uid: 'abc123');

        final Capsule opened = original.copyWith(
          id: 9,
          openedAt: DateTime.fromMillisecondsSinceEpoch(1800000000000),
        );

        expect(opened.sender, 'Ana');
        expect(opened.recipient, 'Lucía');
        expect(opened.uid, 'abc123');
        expect(opened.id, 9);
      });

      test('las filas antiguas, sin esas columnas, se leen sin fallar', () {
        final Capsule restored = Capsule.fromMap(<String, Object?>{
          'id': 1,
          'title': 'Antigua',
          'content': 'Texto',
          'created_at': 1700000000000,
          'open_date': '2028-01-02',
          'opened_at': null,
        });

        expect(restored.sender, isNull);
        expect(restored.recipient, isNull);
        expect(restored.uid, isNull);
        expect(restored.isSent, isFalse);
        expect(restored.isReceived, isFalse);
      });
    });

    group('statusOn', () {
      final Capsule capsule = _capsule(openDate: DateTime(2027, 3, 15));

      test('está sellada hasta el día anterior, incluso a las 23:59', () {
        expect(capsule.statusOn(DateTime(2027, 3, 14, 23, 59)), CapsuleStatus.sealed);
        expect(capsule.statusOn(DateTime(2026, 1, 1)), CapsuleStatus.sealed);
      });

      test('está lista desde las 00:00 del día de apertura', () {
        expect(capsule.statusOn(DateTime(2027, 3, 15, 0, 0)), CapsuleStatus.ready);
        expect(capsule.statusOn(DateTime(2030, 1, 1)), CapsuleStatus.ready);
      });

      test('si tiene fecha de apertura real, está abierta', () {
        final Capsule opened = capsule.copyWith(openedAt: DateTime(2027, 3, 16));
        expect(opened.statusOn(DateTime(2027, 3, 16)), CapsuleStatus.opened);
        expect(opened.statusOn(DateTime(2040, 1, 1)), CapsuleStatus.opened);
      });
    });

    group('daysUntilOpen', () {
      test('cuenta días de calendario, no horas', () {
        final Capsule capsule = _capsule(openDate: DateTime(2026, 11, 6));
        expect(capsule.daysUntilOpen(DateTime(2026, 11, 5, 23, 59)), 1);
        expect(capsule.daysUntilOpen(DateTime(2026, 11, 5, 0, 0)), 1);
      });

      test('no se desajusta con el cambio de hora', () {
        // En Europa el horario de verano empieza el 29 de marzo de 2026.
        final Capsule capsule = _capsule(openDate: DateTime(2026, 3, 30));
        expect(capsule.daysUntilOpen(DateTime(2026, 3, 28, 12)), 2);
      });

      test('vale 0 el día de apertura y después', () {
        final Capsule capsule = _capsule(openDate: DateTime(2026, 11, 5));
        expect(capsule.daysUntilOpen(DateTime(2026, 11, 5, 8)), 0);
        expect(capsule.daysUntilOpen(DateTime(2027, 1, 1)), 0);
      });
    });
  });
}
