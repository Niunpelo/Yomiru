import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/providers/diary_provider.dart';
import 'package:gonen/utils/prompt_deck.dart';
import 'package:gonen/widgets/attachment_action_bar.dart';
import 'package:gonen/widgets/inspiration_sheet.dart';
import 'package:gonen/widgets/save_button.dart';

/// Abre [sheet] desde un botón "abrir" y guarda en [onResult] lo que devuelva.
Widget _sheetHarness(Widget sheet, void Function(String? result) onResult) {
  return MaterialApp(
    home: Builder(
      builder: (BuildContext context) {
        return Scaffold(
          body: Center(
            child: ElevatedButton(
              onPressed: () async {
                final String? result = await showModalBottomSheet<String>(
                  context: context,
                  isScrollControlled: true,
                  builder: (BuildContext sheetContext) => sheet,
                );
                onResult(result);
              },
              child: const Text('abrir'),
            ),
          ),
        );
      },
    ),
  );
}

Widget _buttonHarness(SaveStatus status, bool hasText, VoidCallback onPressed) {
  return MaterialApp(
    home: Scaffold(
      body: Center(
        child: SaveButton(
          status: status,
          hasStoredText: hasText,
          onPressed: onPressed,
        ),
      ),
    ),
  );
}

bool _isEnabled(WidgetTester tester) {
  final ButtonStyleButton button = tester.widget<ButtonStyleButton>(
    find.byWidgetPredicate((Widget widget) => widget is ButtonStyleButton),
  );
  return button.onPressed != null;
}

void main() {
  group('InspirationSheet', () {
    testWidgets('enseña una frase y «Otra idea» cambia a otra distinta', (
      WidgetTester tester,
    ) async {
      final PromptDeck deck =
          PromptDeck(<String>['Frase uno', 'Frase dos'], random: Random(2));
      await tester.pumpWidget(
        _sheetHarness(InspirationSheet(deck: deck), (String? value) {}),
      );

      await tester.tap(find.text('abrir'));
      await tester.pumpAndSettle();

      final bool firstIsOne = find.text('Frase uno').evaluate().isNotEmpty;
      expect(
        find.text(firstIsOne ? 'Frase uno' : 'Frase dos'),
        findsOneWidget,
      );

      await tester.tap(find.text('Otra idea'));
      await tester.pumpAndSettle();

      expect(
        find.text(firstIsOne ? 'Frase dos' : 'Frase uno'),
        findsOneWidget,
      );
      expect(
        find.text(firstIsOne ? 'Frase uno' : 'Frase dos'),
        findsNothing,
      );
    });

    testWidgets('«Escribir sobre esto» devuelve la frase que se está viendo', (
      WidgetTester tester,
    ) async {
      String? result;
      final PromptDeck deck = PromptDeck(<String>['Única frase']);
      await tester.pumpWidget(
        _sheetHarness(InspirationSheet(deck: deck), (String? value) {
          result = value;
        }),
      );

      await tester.tap(find.text('abrir'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Escribir sobre esto'));
      await tester.pumpAndSettle();

      expect(result, 'Única frase');
    });

    testWidgets('«Cerrar» cierra sin devolver nada', (WidgetTester tester) async {
      String? result = 'sin tocar';
      final PromptDeck deck = PromptDeck(<String>['Única frase']);
      await tester.pumpWidget(
        _sheetHarness(InspirationSheet(deck: deck), (String? value) {
          result = value;
        }),
      );

      await tester.tap(find.text('abrir'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Cerrar'));
      await tester.pumpAndSettle();

      expect(result, isNull);
    });
  });

  group('Dado en la fila de adjuntos', () {
    Widget buttons({VoidCallback? onIdea, bool premium = true}) {
      return MaterialApp(
        home: Scaffold(
          body: Padding(
            padding: const EdgeInsets.all(16),
            child: AttachmentButtons(
              premium: premium,
              onCamera: () {},
              onGallery: () {},
              onVoice: () {},
              onIdea: onIdea,
            ),
          ),
        ),
      );
    }

    testWidgets('sale a la derecha del botón de voz y se puede pulsar', (
      WidgetTester tester,
    ) async {
      int presses = 0;
      await tester.pumpWidget(buttons(onIdea: () => presses++));

      final Finder dice = find.byIcon(Icons.casino_outlined);
      expect(dice, findsOneWidget);
      expect(
        tester.getTopLeft(dice).dx,
        greaterThan(tester.getTopLeft(find.text('Voz')).dx),
      );

      await tester.tap(dice);
      expect(presses, 1);
    });

    testWidgets('sin premium el dado sigue disponible y sin candado', (
      WidgetTester tester,
    ) async {
      int presses = 0;
      await tester.pumpWidget(buttons(onIdea: () => presses++, premium: false));

      // Foto, galería y voz llevan candado; el dado no.
      expect(find.byIcon(Icons.lock_outline_rounded), findsNWidgets(3));
      await tester.tap(find.byIcon(Icons.casino_outlined));
      expect(presses, 1);
    });

    testWidgets('sin onIdea (cápsulas) no hay dado', (WidgetTester tester) async {
      await tester.pumpWidget(buttons());

      expect(find.byIcon(Icons.casino_outlined), findsNothing);
    });
  });

  group('SaveButton', () {
    testWidgets('con cambios sin guardar dice «Guardar» y se puede pulsar', (
      WidgetTester tester,
    ) async {
      int presses = 0;
      await tester.pumpWidget(
        _buttonHarness(SaveStatus.unsaved, true, () => presses++),
      );

      expect(find.text('Guardar'), findsOneWidget);
      expect(_isEnabled(tester), isTrue);

      await tester.tap(find.text('Guardar'));
      expect(presses, 1);
    });

    testWidgets('si falló el guardado vuelve a decir «Guardar» con el icono de error', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(_buttonHarness(SaveStatus.error, true, () {}));

      expect(find.text('Guardar'), findsOneWidget);
      expect(find.byIcon(Icons.error_outline_rounded), findsOneWidget);
      expect(_isEnabled(tester), isTrue);
    });

    testWidgets('mientras guarda dice «Guardando…» y está apagado', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(_buttonHarness(SaveStatus.saving, true, () {}));

      expect(find.text('Guardando…'), findsOneWidget);
      expect(_isEnabled(tester), isFalse);
    });

    testWidgets('una vez guardado dice «Guardado» y está apagado', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(_buttonHarness(SaveStatus.saved, true, () {}));

      expect(find.text('Guardado'), findsOneWidget);
      expect(find.text('Guardar'), findsNothing);
      expect(_isEnabled(tester), isFalse);
    });

    testWidgets('un día con texto guardado se abre diciendo «Guardado»', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(_buttonHarness(SaveStatus.idle, true, () {}));

      expect(find.text('Guardado'), findsOneWidget);
      expect(_isEnabled(tester), isFalse);
    });

    testWidgets('un día vacío sin tocar dice «Guardar» pero apagado', (
      WidgetTester tester,
    ) async {
      await tester.pumpWidget(_buttonHarness(SaveStatus.idle, false, () {}));

      expect(find.text('Guardar'), findsOneWidget);
      expect(_isEnabled(tester), isFalse);
    });
  });
}
