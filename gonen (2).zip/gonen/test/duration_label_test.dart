import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/utils/duration_label.dart';

void main() {
  group('formatDuration', () {
    test('muestra minutos y segundos con dos cifras en los segundos', () {
      expect(formatDuration(Duration.zero), '0:00');
      expect(formatDuration(const Duration(seconds: 7)), '0:07');
      expect(formatDuration(const Duration(seconds: 65)), '1:05');
      expect(formatDuration(const Duration(minutes: 5)), '5:00');
    });

    test('ignora los milisegundos sobrantes', () {
      expect(formatDuration(const Duration(seconds: 9, milliseconds: 999)), '0:09');
    });

    test('una duración negativa se muestra como cero', () {
      expect(formatDuration(const Duration(seconds: -3)), '0:00');
    });
  });
}
