import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/l10n/tr.dart';
import 'package:gonen/models/day_template.dart';
import 'package:gonen/providers/settings_provider.dart';
import 'package:gonen/services/biometric_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

SettingsProvider _newProvider() =>
    SettingsProvider(biometricService: BiometricService());

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  tearDown(() => AppLocale.current = AppLanguage.es);

  group('DayTemplate.clean', () {
    test('quita espacios y líneas vacías de los extremos', () {
      expect(
        DayTemplate.clean('\n  ¿Cómo estoy?\n\n¿Qué ha ido bien?  \n\n'),
        '¿Cómo estoy?\n\n¿Qué ha ido bien?',
      );
    });

    test('convierte los saltos de línea de Windows', () {
      expect(DayTemplate.clean('a\r\nb'), 'a\nb');
    });

    test('no pasa del máximo', () {
      final String long = 'a' * (DayTemplate.maxLength + 50);
      expect(DayTemplate.clean(long).length, DayTemplate.maxLength);
    });

    test('no parte un emoji al cortar', () {
      final String text = '${'a' * (DayTemplate.maxLength - 1)}😀';
      final String clean = DayTemplate.clean(text);
      expect(clean, 'a' * (DayTemplate.maxLength - 1));
    });
  });

  group('DayTemplate.starter', () {
    test('sin plantilla no hay texto inicial', () {
      expect(DayTemplate.starter(''), '');
      expect(DayTemplate.starter('  \n '), '');
    });

    test('deja un hueco debajo de la plantilla', () {
      expect(DayTemplate.starter('¿Cómo estoy?'), '¿Cómo estoy?\n\n');
    });
  });

  group('DayTemplate.isUntouched / toSave', () {
    const String template = '¿Cómo me siento?\n\n¿Qué ha ido bien?';

    test('vacío o solo espacios: nada propio', () {
      expect(DayTemplate.isUntouched('', template), isTrue);
      expect(DayTemplate.isUntouched('  \n', template), isTrue);
      expect(DayTemplate.toSave('  \n', template), '');
    });

    test('la plantilla tal como apareció: nada propio, no se guarda', () {
      final String started = DayTemplate.starter(template);
      expect(DayTemplate.isUntouched(started, template), isTrue);
      expect(DayTemplate.toSave(started, template), '');
    });

    test('plantilla más respuesta: sí se guarda, entera', () {
      const String written = '$template\n\nBien. Hoy salió el sol.';
      expect(DayTemplate.isUntouched(written, template), isFalse);
      expect(DayTemplate.toSave(written, template), written);
    });

    test('texto sin plantilla: se guarda tal cual', () {
      expect(DayTemplate.isUntouched('Hola', ''), isFalse);
      expect(DayTemplate.toSave('Hola', ''), 'Hola');
    });

    test('con plantilla vacía, la plantilla en blanco no engaña', () {
      expect(DayTemplate.isUntouched('', ''), isTrue);
    });
  });

  group('SettingsProvider: plantilla del día', () {
    test('por defecto está apagada y vacía', () async {
      SharedPreferences.setMockInitialValues(<String, Object>{});
      final SettingsProvider settings = _newProvider();
      await settings.load();
      expect(settings.templateEnabled, isFalse);
      expect(settings.templateText, '');
      expect(settings.activeTemplate(premium: true), '');
    });

    test('se guarda y se recupera al abrir la app', () async {
      SharedPreferences.setMockInitialValues(<String, Object>{});
      final SettingsProvider first = _newProvider();
      await first.load();
      await first.setTemplateText('  ¿Cómo estoy?\n\n¿Qué ha ido bien?  ');
      await first.setTemplateEnabled(true);

      final SettingsProvider second = _newProvider();
      await second.load();
      expect(second.templateEnabled, isTrue);
      expect(second.templateText, '¿Cómo estoy?\n\n¿Qué ha ido bien?');
    });

    test('solo se aplica con Premium y activada', () async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        'template_enabled': true,
        'template_text': '¿Cómo estoy?',
      });
      final SettingsProvider settings = _newProvider();
      await settings.load();
      expect(settings.activeTemplate(premium: true), '¿Cómo estoy?');
      expect(settings.activeTemplate(premium: false), '');

      await settings.setTemplateEnabled(false);
      expect(settings.activeTemplate(premium: true), '');
      // El texto se conserva aunque esté apagada.
      expect(settings.templateText, '¿Cómo estoy?');
    });

    test('avisa a los widgets al cambiar el texto o el interruptor', () async {
      SharedPreferences.setMockInitialValues(<String, Object>{});
      final SettingsProvider settings = _newProvider();
      await settings.load();
      int calls = 0;
      settings.addListener(() => calls++);
      await settings.setTemplateText('Hola');
      await settings.setTemplateEnabled(true);
      expect(calls, 2);
      // Sin cambios no hay aviso.
      await settings.setTemplateText('Hola');
      await settings.setTemplateEnabled(true);
      expect(calls, 2);
    });
  });
}
