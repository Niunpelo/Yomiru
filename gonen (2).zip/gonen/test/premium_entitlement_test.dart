import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/models/premium_entitlement.dart';

void main() {
  final DateTime verified = DateTime(2026, 6, 1, 12);

  group('PremiumEntitlement', () {
    test('sin plan no hay premium', () {
      expect(PremiumEntitlement.none.isActiveAt(verified), isFalse);
    });

    test('el pago único nunca caduca', () {
      final PremiumEntitlement lifetime = PremiumEntitlement(
        plan: PremiumPlan.lifetime,
        verifiedAt: verified,
      );

      expect(lifetime.isActiveAt(verified), isTrue);
      expect(lifetime.isActiveAt(DateTime(2040, 1, 1)), isTrue);
    });

    test('el pago único vale aunque no haya fecha de verificación', () {
      const PremiumEntitlement lifetime =
          PremiumEntitlement(plan: PremiumPlan.lifetime);

      expect(lifetime.isActiveAt(DateTime(2035, 5, 5)), isTrue);
    });

    test('la suscripción vale mientras Play la haya confirmado hace poco', () {
      final PremiumEntitlement yearly = PremiumEntitlement(
        plan: PremiumPlan.yearly,
        verifiedAt: verified,
      );

      expect(yearly.isActiveAt(verified), isTrue);
      expect(yearly.isActiveAt(verified.add(const Duration(days: 6))), isTrue);
      expect(
        yearly.isActiveAt(verified.add(PremiumEntitlement.subscriptionGrace)),
        isTrue,
      );
    });

    test('la suscripción deja de valer pasado el margen sin confirmación', () {
      final PremiumEntitlement yearly = PremiumEntitlement(
        plan: PremiumPlan.yearly,
        verifiedAt: verified,
      );

      expect(
        yearly.isActiveAt(
          verified.add(PremiumEntitlement.subscriptionGrace).add(
                const Duration(minutes: 1),
              ),
        ),
        isFalse,
      );
    });

    test('la suscripción sin fecha de verificación no vale', () {
      const PremiumEntitlement yearly =
          PremiumEntitlement(plan: PremiumPlan.yearly);

      expect(yearly.isActiveAt(verified), isFalse);
    });
  });
}
