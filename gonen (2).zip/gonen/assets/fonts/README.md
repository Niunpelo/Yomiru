# Fuentes incluidas

Gonen incluye estas fuentes con licencia SIL Open Font License 1.1 (el texto de
cada licencia está en los archivos `OFL-*.txt` de esta carpeta):

- **DM Serif Display** — Colophon Foundry / Google Fonts
- **IBM Plex Mono** — IBM Corp.
- **Newsreader** — Production Type / Google Fonts
- **Noto Serif** — Google / Noto Project

Son versiones estáticas con solo el alfabeto latino (suficiente para español e
inglés); cualquier otro carácter se dibuja con la fuente del sistema.
Se generaron con `tool/make_fonts.py` a partir del repositorio google/fonts.
