"""Genera las fuentes estáticas (solo latín) que se empaquetan en Gonen."""
import sys
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.varLib import instancer
from fontTools import subset

SRC = Path("/home/claude/google/fonts/ofl")
OUT = Path("/home/claude/gonen/assets/fonts")
OUT.mkdir(parents=True, exist_ok=True)

UNICODES = (
    list(range(0x20, 0x7F)) + list(range(0xA0, 0x180)) +
    [0x2013, 0x2014, 0x2018, 0x2019, 0x201A, 0x201C, 0x201D, 0x201E,
     0x2020, 0x2022, 0x2026, 0x2030, 0x2039, 0x203A, 0x20AC, 0x2122,
     0x2212, 0x2190, 0x2191, 0x2192, 0x2193, 0x00B7]
)

def subset_font(font: TTFont, dest: Path) -> None:
    opts = subset.Options()
    opts.layout_features = ["kern", "liga", "calt", "ccmp", "locl", "mark", "mkmk"]
    opts.name_IDs = [1, 2, 3, 4, 6, 13, 14]
    opts.notdef_outline = True
    opts.glyph_names = False
    opts.hinting = False
    sub = subset.Subsetter(opts)
    sub.populate(unicodes=UNICODES)
    sub.subset(font)
    font.save(dest)
    print(f"{dest.name}: {dest.stat().st_size // 1024} KB")

def static(src: Path, dest: Path) -> None:
    subset_font(TTFont(src), dest)

def instance(src: Path, dest: Path, axes: dict) -> None:
    var = TTFont(src)
    inst = instancer.instantiateVariableFont(var, axes)
    subset_font(inst, dest)

static(SRC / "ibmplexmono/IBMPlexMono-Regular.ttf", OUT / "IBMPlexMono-Regular.ttf")
static(SRC / "ibmplexmono/IBMPlexMono-Medium.ttf", OUT / "IBMPlexMono-Medium.ttf")

noto = SRC / "notoserif/NotoSerif[wdth,wght].ttf"
noto_i = SRC / "notoserif/NotoSerif-Italic[wdth,wght].ttf"
instance(noto, OUT / "NotoSerif-Regular.ttf", {"wght": 400, "wdth": 100})
instance(noto, OUT / "NotoSerif-SemiBold.ttf", {"wght": 600, "wdth": 100})
instance(noto, OUT / "NotoSerif-Black.ttf", {"wght": 900, "wdth": 100})
instance(noto_i, OUT / "NotoSerif-Italic.ttf", {"wght": 400, "wdth": 100})
