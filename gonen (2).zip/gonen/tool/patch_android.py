#!/usr/bin/env python3
"""Adapta el proyecto Android generado por `flutter create` para Gonen.

Hace, de forma idempotente (se puede ejecutar varias veces sin duplicar nada):

  * Activa "core library desugaring" y Java 17 (lo exige flutter_local_notifications).
  * Sube compileSdk a 36 y minSdk a 24 si el SDK de Flutter usa valores menores.
  * Cambia MainActivity a FlutterFragmentActivity (lo exige local_auth) y le añade
    el canal "gonen/files", que abre el selector de archivos de Android para
    guardar y restaurar copias de seguridad sin pedir permisos de almacenamiento.
  * Excluye las fotos y notas de voz de la copia automática de Android (el texto
    sí entra), para no pasar del límite de 25 MB que Google admite por app.
  * Cambia los temas de arranque a AppCompat (lo exige local_auth en Android 8 o anterior).
  * Añade permisos y receptores al AndroidManifest.xml (huella, arranque, avisos
    programados, micrófono para las notas de voz y facturación de Google Play).
  * Pone "Gonen" como nombre de la app.
  * Crea el icono de las notificaciones y un icono de app sencillo.

Uso, desde la raíz del proyecto:

    flutter create --platforms=android --org com.gonen --project-name gonen .
    python3 tool/patch_android.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ANDROID = ROOT / "android"
APP = ANDROID / "app"
MAIN = APP / "src" / "main"
RES = MAIN / "res"

DESUGAR = "com.android.tools:desugar_jdk_libs:2.1.5"
APPCOMPAT = "androidx.appcompat:appcompat:1.7.1"
MIN_COMPILE_SDK = 36
MIN_SDK = 24
MIN_AGP = (8, 11, 1)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def log(message: str) -> None:
    print(f"[patch_android] {message}")


# ---------------------------------------------------------------------------
# Gradle
# ---------------------------------------------------------------------------


def patch_gradle() -> None:
    kts = APP / "build.gradle.kts"
    groovy = APP / "build.gradle"
    if kts.exists():
        path, is_kotlin = kts, True
    elif groovy.exists():
        path, is_kotlin = groovy, False
    else:
        sys.exit("No encuentro android/app/build.gradle(.kts). ¿Ejecutaste `flutter create`?")

    text = read(path)
    original = text

    # --- SDK ---------------------------------------------------------------
    if is_kotlin:
        text = re.sub(
            r"compileSdk\s*=\s*flutter\.compileSdkVersion",
            f"compileSdk = maxOf(flutter.compileSdkVersion, {MIN_COMPILE_SDK})",
            text,
        )
        text = re.sub(
            r"minSdk\s*=\s*flutter\.minSdkVersion",
            f"minSdk = maxOf(flutter.minSdkVersion, {MIN_SDK})",
            text,
        )
        text = re.sub(
            r"compileSdk\s*=\s*(\d+)\b",
            lambda m: f"compileSdk = {max(int(m.group(1)), MIN_COMPILE_SDK)}",
            text,
        )
        text = re.sub(
            r"minSdk\s*=\s*(\d+)\b",
            lambda m: f"minSdk = {max(int(m.group(1)), MIN_SDK)}",
            text,
        )
    else:
        text = re.sub(
            r"compileSdk(?:Version)?\s+flutter\.compileSdkVersion",
            f"compileSdk Math.max(flutter.compileSdkVersion, {MIN_COMPILE_SDK})",
            text,
        )
        text = re.sub(
            r"minSdk(?:Version)?\s+flutter\.minSdkVersion",
            f"minSdk Math.max(flutter.minSdkVersion, {MIN_SDK})",
            text,
        )

    # --- Java 17 -------------------------------------------------------------
    text = text.replace("VERSION_1_8", "VERSION_17").replace("VERSION_11", "VERSION_17")
    text = re.sub(r'jvmTarget\s*=\s*"(?:1\.8|11)"', 'jvmTarget = "17"', text)

    # --- Desugaring ----------------------------------------------------------
    if "oreLibraryDesugaringEnabled" not in text:
        flag = (
            "isCoreLibraryDesugaringEnabled = true"
            if is_kotlin
            else "coreLibraryDesugaringEnabled true"
        )
        if re.search(r"compileOptions\s*\{", text):
            text = re.sub(
                r"(compileOptions\s*\{)",
                lambda m: f"{m.group(1)}\n        {flag}",
                text,
                count=1,
            )
        else:
            block = (
                "\n    compileOptions {\n"
                f"        {flag}\n"
                "        sourceCompatibility = JavaVersion.VERSION_17\n"
                "        targetCompatibility = JavaVersion.VERSION_17\n"
                "    }"
            )
            text, count = re.subn(
                r"^(android\s*\{)",
                lambda m: m.group(1) + block,
                text,
                count=1,
                flags=re.MULTILINE,
            )
            if count == 0:
                sys.exit("No encuentro el bloque `android { ... }` en build.gradle.")

    # --- Dependencias ----------------------------------------------------------
    wanted: list[str] = []
    if DESUGAR not in text:
        wanted.append(
            f'    coreLibraryDesugaring("{DESUGAR}")'
            if is_kotlin
            else f"    coreLibraryDesugaring '{DESUGAR}'"
        )
    if APPCOMPAT not in text:
        wanted.append(
            f'    implementation("{APPCOMPAT}")'
            if is_kotlin
            else f"    implementation '{APPCOMPAT}'"
        )
    if wanted:
        if re.search(r"^dependencies\s*\{", text, flags=re.MULTILINE):
            text = re.sub(
                r"^(dependencies\s*\{)",
                lambda m: m.group(1) + "\n" + "\n".join(wanted),
                text,
                count=1,
                flags=re.MULTILINE,
            )
        else:
            text = text.rstrip() + "\n\ndependencies {\n" + "\n".join(wanted) + "\n}\n"

    if text != original:
        write(path, text)
        log(f"{path.relative_to(ROOT)} actualizado")
    else:
        log(f"{path.relative_to(ROOT)} ya estaba listo")


def check_agp_version() -> None:
    """Avisa si la versión del plugin de Android Gradle es menor que la que usa el plugin de notificaciones."""
    for name in ("settings.gradle.kts", "settings.gradle", "build.gradle.kts", "build.gradle"):
        path = ANDROID / name
        if not path.exists():
            continue
        match = re.search(
            r"com\.android\.application[\"']\s*\)?\s*version\s*[\"'](\d+)\.(\d+)\.(\d+)[\"']",
            read(path),
        )
        if match:
            found = tuple(int(part) for part in match.groups())
            if found < MIN_AGP:
                log(
                    "AVISO: el plugin de Android Gradle es "
                    f"{'.'.join(map(str, found))} y flutter_local_notifications usa "
                    f"{'.'.join(map(str, MIN_AGP))}. Actualiza Flutter o sube esa versión en {name}."
                )
            return


# ---------------------------------------------------------------------------
# Actividad principal
# ---------------------------------------------------------------------------


MAIN_ACTIVITY_KT = """package {package}

import android.app.Activity
import android.content.Intent
import android.net.Uri
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileInputStream
import java.io.IOException

// Guarda y abre archivos con el selector de documentos de Android (canal "gonen/files").
class MainActivity : FlutterFragmentActivity() {{
    private val channelName = "gonen/files"
    private val saveRequest = 4101
    private val pickRequest = 4102

    private var pendingResult: MethodChannel.Result? = null
    private var pendingSource: String? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {{
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler {{ call, result -> handle(call, result) }}
    }}

    private fun handle(call: MethodCall, result: MethodChannel.Result) {{
        when (call.method) {{
            "saveFile" -> startSave(call, result)
            "pickFile" -> startPick(result)
            else -> result.notImplemented()
        }}
    }}

    private fun startSave(call: MethodCall, result: MethodChannel.Result) {{
        if (pendingResult != null) {{
            result.error("busy", "Ya hay una operación en curso.", null)
            return
        }}
        val source = call.argument<String>("sourcePath")
        if (source == null) {{
            result.error("bad_args", "Falta el archivo que guardar.", null)
            return
        }}
        val name = call.argument<String>("suggestedName") ?: "gonen.gonen"
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {{
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, name)
        }}
        launch(intent, saveRequest, result, source)
    }}

    private fun startPick(result: MethodChannel.Result) {{
        if (pendingResult != null) {{
            result.error("busy", "Ya hay una operación en curso.", null)
            return
        }}
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {{
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }}
        launch(intent, pickRequest, result, null)
    }}

    @Suppress("DEPRECATION")
    private fun launch(intent: Intent, code: Int, result: MethodChannel.Result, source: String?) {{
        pendingResult = result
        pendingSource = source
        try {{
            startActivityForResult(intent, code)
        }} catch (e: Exception) {{
            pendingResult = null
            pendingSource = null
            result.error("no_picker", "No se pudo abrir el selector de archivos.", null)
        }}
    }}

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {{
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != saveRequest && requestCode != pickRequest) {{
            return
        }}
        val result = pendingResult ?: return
        val source = pendingSource
        pendingResult = null
        pendingSource = null

        val uri = data?.data
        if (resultCode != Activity.RESULT_OK || uri == null) {{
            if (requestCode == saveRequest) result.success(false) else result.success(null)
            return
        }}

        // Copiar un archivo grande no debe bloquear la pantalla.
        Thread {{
            try {{
                if (requestCode == saveRequest) {{
                    copyToUri(source ?: throw IOException("Falta el archivo."), uri)
                    runOnUiThread {{ result.success(true) }}
                }} else {{
                    val path = copyFromUri(uri)
                    runOnUiThread {{ result.success(path) }}
                }}
            }} catch (e: Exception) {{
                runOnUiThread {{ result.error("io", "No se pudo copiar el archivo.", e.message) }}
            }}
        }}.start()
    }}

    private fun copyToUri(sourcePath: String, uri: Uri) {{
        FileInputStream(File(sourcePath)).use {{ input ->
            val output = contentResolver.openOutputStream(uri, "wt")
                ?: throw IOException("No se pudo abrir el destino.")
            output.use {{ out -> input.copyTo(out) }}
        }}
    }}

    private fun copyFromUri(uri: Uri): String {{
        val target = File(cacheDir, "restore.gonen")
        val input = contentResolver.openInputStream(uri)
            ?: throw IOException("No se pudo abrir el archivo.")
        input.use {{ source ->
            target.outputStream().use {{ out -> source.copyTo(out) }}
        }}
        return target.absolutePath
    }}
}}
"""


def patch_main_activity() -> None:
    found = False
    for path in MAIN.rglob("MainActivity.*"):
        if path.suffix not in (".kt", ".java"):
            continue
        found = True
        text = read(path)
        patched = re.sub(r"\bFlutterActivity\b", "FlutterFragmentActivity", text)

        if path.suffix == ".kt" and "gonen/files" not in patched:
            match = re.search(r"^\s*package\s+([\w.]+)", patched, flags=re.MULTILINE)
            if match:
                patched = MAIN_ACTIVITY_KT.format(package=match.group(1))
                log(f"{path.relative_to(ROOT)} con el canal gonen/files")
            else:
                log("AVISO: MainActivity.kt no tiene `package`; no se añade el canal de archivos.")
        elif path.suffix == ".java":
            log("AVISO: MainActivity es Java; no se añade el canal de archivos.")

        if patched != text:
            write(path, patched)
            log(f"{path.relative_to(ROOT)} actualizado")
        else:
            log(f"{path.relative_to(ROOT)} ya estaba listo")
    if not found:
        sys.exit("No encuentro MainActivity.kt ni MainActivity.java.")


# ---------------------------------------------------------------------------
# AndroidManifest.xml
# ---------------------------------------------------------------------------

RECEIVERS = """
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
"""


def patch_manifest() -> None:
    path = MAIN / "AndroidManifest.xml"
    if not path.exists():
        sys.exit("No encuentro AndroidManifest.xml.")
    text = read(path)
    original = text

    for permission in (
        "android.permission.USE_BIOMETRIC",
        "android.permission.RECEIVE_BOOT_COMPLETED",
        # Notas de voz (paquete `record`).
        "android.permission.RECORD_AUDIO",
        # Pagos de Google Play (paquete `in_app_purchase`).
        "com.android.vending.BILLING",
    ):
        if permission not in text:
            text = text.replace(
                "<application",
                f'<uses-permission android:name="{permission}"/>\n    <application',
                1,
            )

    if "ScheduledNotificationReceiver" not in text:
        if "</application>" not in text:
            sys.exit("El AndroidManifest.xml no tiene la etiqueta </application>.")
        text = text.replace("</application>", RECEIVERS + "    </application>", 1)

    text = re.sub(r'android:label="[^"]*"', 'android:label="Gonen"', text, count=1)

    if text != original:
        write(path, text)
        log("AndroidManifest.xml actualizado")
    else:
        log("AndroidManifest.xml ya estaba listo")


# ---------------------------------------------------------------------------
# Copia automática de Android (Auto Backup)
# ---------------------------------------------------------------------------

# Flutter guarda los documentos de la app en `app_flutter/` (dominio "root").
# Las fotos y notas de voz pueden pesar mucho y Google solo admite 25 MB por app
# (si se pasa, no guarda NADA, ni el texto), así que quedan fuera de la copia en
# la nube. Al cambiar de móvil con cable o por Bluetooth sí pasan.
BACKUP_RULES = """<?xml version="1.0" encoding="utf-8"?>
<full-backup-content>
    <exclude domain="root" path="app_flutter/attachments" />
</full-backup-content>
"""

DATA_EXTRACTION_RULES = """<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <exclude domain="root" path="app_flutter/attachments" />
    </cloud-backup>
</data-extraction-rules>
"""


def patch_auto_backup() -> None:
    for path, content in (
        (RES / "xml" / "gonen_backup_rules.xml", BACKUP_RULES),
        (RES / "xml" / "gonen_data_extraction_rules.xml", DATA_EXTRACTION_RULES),
    ):
        if path.exists() and read(path) == content:
            continue
        write(path, content)
        log(f"{path.relative_to(ROOT)} escrito")

    manifest = MAIN / "AndroidManifest.xml"
    text = read(manifest)
    match = re.search(r"<application\b[^>]*>", text)
    if not match:
        log("AVISO: no encuentro la etiqueta <application>; no se activan las reglas de copia.")
        return

    tag = match.group(0)
    new_tag = tag
    wanted = (
        ("android:allowBackup", "true"),
        ("android:fullBackupContent", "@xml/gonen_backup_rules"),
        ("android:dataExtractionRules", "@xml/gonen_data_extraction_rules"),
    )
    for name, value in wanted:
        if re.search(rf"{re.escape(name)}\s*=", new_tag):
            new_tag = re.sub(rf'{re.escape(name)}\s*=\s*"[^"]*"', f'{name}="{value}"', new_tag)
        else:
            new_tag = new_tag.replace("<application", f'<application\n        {name}="{value}"', 1)

    if new_tag != tag:
        write(manifest, text.replace(tag, new_tag, 1))
        log("AndroidManifest.xml con las reglas de copia automática")
    else:
        log("Las reglas de copia automática ya estaban listas")


# ---------------------------------------------------------------------------
# Temas de arranque (AppCompat)
# ---------------------------------------------------------------------------


def patch_styles() -> None:
    for path in RES.glob("values*/styles.xml"):
        text = read(path)
        patched = text.replace(
            "@android:style/Theme.Light.NoTitleBar", "Theme.AppCompat.Light.NoActionBar"
        ).replace(
            "@android:style/Theme.Black.NoTitleBar", "Theme.AppCompat.NoActionBar"
        )
        if patched != text:
            write(path, patched)
            log(f"{path.relative_to(ROOT)} usa temas AppCompat")


# ---------------------------------------------------------------------------
# Recursos: icono de notificación e icono de la app
# ---------------------------------------------------------------------------

NOTIFICATION_ICON = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#00000000"
        android:strokeColor="#FFFFFFFF"
        android:strokeWidth="2"
        android:strokeLineCap="round"
        android:strokeLineJoin="round"
        android:pathData="M6,5 L18,5 M12,5 L12,11 M7,11 L16,11 L16,19 M5,19 L19,19" />
</vector>
"""

KEEP_XML = """<?xml version="1.0" encoding="utf-8"?>
<resources xmlns:tools="http://schemas.android.com/tools"
    tools:keep="@drawable/ic_stat_gonen,@mipmap/ic_launcher" />
"""

ICON_COLORS = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="gonen_icon_background">#B04A3C</color>
</resources>
"""

# Un sello bermellón con el kanji 五 (cinco, como en 五年 "gonen", cinco años) dibujado con trazos.
ICON_FOREGROUND = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#00000000"
        android:strokeColor="#FFF4EFE6"
        android:strokeWidth="5"
        android:strokeLineCap="round"
        android:strokeLineJoin="round"
        android:pathData="M36,28 L72,28 M50,28 L50,52 M38,52 L66,52 L66,80 M32,80 L76,80" />
</vector>
"""

ADAPTIVE_ICON = """<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/gonen_icon_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
"""

ADAPTIVE_ICON_THEMED = """<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/gonen_icon_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
    <monochrome android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
"""


def write_resources() -> None:
    files = {
        RES / "drawable" / "ic_stat_gonen.xml": NOTIFICATION_ICON,
        RES / "raw" / "keep.xml": KEEP_XML,
        RES / "values" / "gonen_colors.xml": ICON_COLORS,
        RES / "drawable" / "ic_launcher_foreground.xml": ICON_FOREGROUND,
        RES / "mipmap-anydpi-v26" / "ic_launcher.xml": ADAPTIVE_ICON,
        RES / "mipmap-anydpi-v33" / "ic_launcher.xml": ADAPTIVE_ICON_THEMED,
    }
    for path, content in files.items():
        if path.exists() and read(path) == content:
            continue
        write(path, content)
        log(f"{path.relative_to(ROOT)} escrito")


def main() -> None:
    if not ANDROID.exists():
        sys.exit(
            "No existe la carpeta android/. Ejecuta primero:\n"
            "  flutter create --platforms=android --org com.gonen --project-name gonen ."
        )
    patch_gradle()
    check_agp_version()
    patch_main_activity()
    patch_manifest()
    patch_auto_backup()
    patch_styles()
    write_resources()
    log("Listo.")


if __name__ == "__main__":
    main()
