import 'package:flutter/material.dart';

import '../l10n/tr.dart';

/// Los cuatro aspectos entre los que se elige en Ajustes. Cada uno trae sus
/// colores (claro y oscuro), sus tipografías y su forma de dibujar la pantalla
/// de inicio.
enum AppStyle {
  /// Papel washi cálido, tinta sumi y un acento bermellón, en tarjetas.
  papeleria('papeleria'),

  /// Igual que la papelería, con un hilo rojo que une los años.
  hiloRojo('hilo'),

  /// Revista: números enormes, tipografía de titular y líneas finas.
  editorial('editorial'),

  /// Revista sobre papel washi, con el acento bermellón.
  editorialJaponesa('editorial_japonesa');

  const AppStyle(this.storageId);

  /// Texto con el que se guarda la elección en los ajustes.
  final String storageId;

  /// Estilo guardado con ese texto; cualquier otro valor da [papeleria].
  static AppStyle fromStorageId(String? id) {
    for (final AppStyle style in AppStyle.values) {
      if (style.storageId == id) {
        return style;
      }
    }
    return AppStyle.papeleria;
  }

  /// Los dos estilos de revista: líneas finas, esquinas rectas y números grandes.
  bool get isEditorial =>
      this == AppStyle.editorial || this == AppStyle.editorialJaponesa;

  /// El hilo rojo que baja por la izquierda de las tarjetas.
  bool get hasThread => this == AppStyle.hiloRojo;

  /// Estilos que usan el papel washi y el bermellón.
  bool get isWashi => this != AppStyle.editorial;

  /// Tipografía de títulos y números grandes.
  String get displayFamily {
    switch (this) {
      case AppStyle.papeleria:
      case AppStyle.hiloRojo:
        return 'serif';
      case AppStyle.editorial:
        return 'DMSerifDisplay';
      case AppStyle.editorialJaponesa:
        return 'NotoSerif';
    }
  }

  /// Tipografía del texto del diario.
  String get bodyFamily {
    switch (this) {
      case AppStyle.papeleria:
      case AppStyle.hiloRojo:
        return 'serif';
      case AppStyle.editorial:
        return 'Newsreader';
      case AppStyle.editorialJaponesa:
        return 'NotoSerif';
    }
  }

  /// Tipografía de las etiquetas pequeñas (null = la del sistema).
  String? get labelFamily => isEditorial ? 'IBMPlexMono' : null;

  /// Peso de los números grandes y de los años.
  FontWeight get displayWeight =>
      this == AppStyle.editorialJaponesa ? FontWeight.w900 : FontWeight.w400;

  /// Radio de las esquinas de tarjetas y botones.
  double get cornerRadius => isEditorial ? 0 : 6;

  /// Nombre del estilo para el selector de Ajustes.
  String label(BuildContext context) {
    switch (this) {
      case AppStyle.papeleria:
        return context.tr('Papelería japonesa', 'Japanese stationery');
      case AppStyle.hiloRojo:
        return context.tr('Hilo rojo', 'Red thread');
      case AppStyle.editorial:
        return context.tr('Editorial', 'Editorial');
      case AppStyle.editorialJaponesa:
        return context.tr('Editorial japonesa', 'Japanese editorial');
    }
  }

  /// Frase corta que describe el estilo.
  String description(BuildContext context) {
    switch (this) {
      case AppStyle.papeleria:
        return context.tr(
          'Papel washi, tarjetas y tinta sumi.',
          'Washi paper, cards and sumi ink.',
        );
      case AppStyle.hiloRojo:
        return context.tr(
          'La papelería, con un hilo rojo que une tus años.',
          'The stationery look, with a red thread joining your years.',
        );
      case AppStyle.editorial:
        return context.tr(
          'Como una revista: números enormes y líneas finas.',
          'Like a magazine: huge numbers and fine rules.',
        );
      case AppStyle.editorialJaponesa:
        return context.tr(
          'La revista sobre papel washi, con sello bermellón.',
          'The magazine on washi paper, with a vermilion seal.',
        );
    }
  }
}

/// Lleva el [AppStyle] dentro del `ThemeData`, para que cualquier widget lo
/// consulte con `context.appStyle`.
@immutable
class GonenStyleTheme extends ThemeExtension<GonenStyleTheme> {
  const GonenStyleTheme(this.style);

  final AppStyle style;

  @override
  GonenStyleTheme copyWith({AppStyle? style}) =>
      GonenStyleTheme(style ?? this.style);

  @override
  GonenStyleTheme lerp(ThemeExtension<GonenStyleTheme>? other, double t) {
    if (other is! GonenStyleTheme) {
      return this;
    }
    return t < 0.5 ? this : other;
  }
}

extension AppStyleContext on BuildContext {
  /// Estilo visual elegido en Ajustes.
  AppStyle get appStyle =>
      Theme.of(this).extension<GonenStyleTheme>()?.style ?? AppStyle.papeleria;
}
