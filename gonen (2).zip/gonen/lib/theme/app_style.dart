import 'package:flutter/material.dart';

import '../l10n/tr.dart';

/// Los dos aspectos entre los que se elige en Ajustes. Cada uno trae sus
/// colores (claro y oscuro), sus tipografías y su forma de dibujar la pantalla
/// de inicio.
///
/// El orden es el del selector: el primero es el predeterminado.
enum AppStyle {
  /// Revista sobre papel washi, con el acento bermellón. Es el predeterminado.
  editorialJaponesa('editorial_japonesa'),

  /// Papel washi cálido, tinta sumi y un acento bermellón, en tarjetas unidas
  /// por un hilo rojo que baja por la izquierda.
  hiloRojo('hilo');

  const AppStyle(this.storageId);

  /// Estilo con el que arranca la app y al que se vuelve si lo guardado ya no
  /// existe (por ejemplo, los estilos que se retiraron en versiones antiguas).
  static const AppStyle defaultStyle = AppStyle.editorialJaponesa;

  /// Texto con el que se guarda la elección en los ajustes.
  final String storageId;

  /// Estilo guardado con ese texto; cualquier otro valor da [defaultStyle].
  static AppStyle fromStorageId(String? id) {
    for (final AppStyle style in AppStyle.values) {
      if (style.storageId == id) {
        return style;
      }
    }
    return defaultStyle;
  }

  /// El estilo de revista: líneas finas, esquinas rectas y números grandes.
  bool get isEditorial => this == AppStyle.editorialJaponesa;

  /// El hilo rojo que baja por la izquierda de las tarjetas.
  bool get hasThread => this == AppStyle.hiloRojo;

  /// Tipografía de títulos y números grandes.
  String get displayFamily {
    switch (this) {
      case AppStyle.hiloRojo:
        return 'serif';
      case AppStyle.editorialJaponesa:
        return 'NotoSerif';
    }
  }

  /// Tipografía del texto del diario.
  String get bodyFamily {
    switch (this) {
      case AppStyle.hiloRojo:
        return 'serif';
      case AppStyle.editorialJaponesa:
        return 'NotoSerif';
    }
  }

  /// Tipografía de las etiquetas pequeñas (null = la del sistema).
  String? get labelFamily => isEditorial ? 'IBMPlexMono' : null;

  /// Peso de los números grandes y de los años.
  FontWeight get displayWeight =>
      this == AppStyle.editorialJaponesa ? FontWeight.w900 : FontWeight.w400;

  /// Radio de las esquinas de tarjetas y botones.
  double get cornerRadius => isEditorial ? 0 : 6;

  /// Nombre del estilo para el selector de Ajustes.
  String label(BuildContext context) {
    switch (this) {
      case AppStyle.editorialJaponesa:
        return context.tr('Editorial japonesa', 'Japanese editorial');
      case AppStyle.hiloRojo:
        return context.tr('Hilo rojo', 'Red thread');
    }
  }

  /// Frase corta que describe el estilo.
  String description(BuildContext context) {
    switch (this) {
      case AppStyle.editorialJaponesa:
        return context.tr(
          'La revista sobre papel washi, con sello bermellón.',
          'The magazine on washi paper, with a vermilion seal.',
        );
      case AppStyle.hiloRojo:
        return context.tr(
          'Tarjetas de papel washi con un hilo rojo que une tus años.',
          'Washi paper cards with a red thread joining your years.',
        );
    }
  }
}

/// Lleva el [AppStyle] dentro del `ThemeData`, para que cualquier widget lo
/// consulte con `context.appStyle`.
@immutable
class GonenStyleTheme extends ThemeExtension<GonenStyleTheme> {
  const GonenStyleTheme(this.style);

  final AppStyle style;

  @override
  GonenStyleTheme copyWith({AppStyle? style}) =>
      GonenStyleTheme(style ?? this.style);

  @override
  GonenStyleTheme lerp(ThemeExtension<GonenStyleTheme>? other, double t) {
    if (other is! GonenStyleTheme) {
      return this;
    }
    return t < 0.5 ? this : other;
  }
}

extension AppStyleContext on BuildContext {
  /// Estilo visual elegido en Ajustes.
  AppStyle get appStyle =>
      Theme.of(this).extension<GonenStyleTheme>()?.style ?? AppStyle.defaultStyle;
}
