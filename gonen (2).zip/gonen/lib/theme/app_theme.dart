import 'package:flutter/material.dart';

import 'app_style.dart';

export 'app_style.dart';

/// Temas claro y oscuro de cada [AppStyle].
///
/// La papelería y el hilo rojo se inspiran en la papelería japonesa: papel
/// washi cálido, tinta sumi y un único acento bermellón (shu). Los dos
/// editoriales tienen líneas finas, esquinas rectas y números enormes.
class AppTheme {
  AppTheme._();

  // ---------------------------------------------------------------------------
  // Paleta washi (papelería, hilo rojo y editorial japonesa)
  // ---------------------------------------------------------------------------

  static const ColorScheme _washiLight = ColorScheme(
    brightness: Brightness.light,
    primary: Color(0xFFB04A3C),
    onPrimary: Color(0xFFFFFFFF),
    primaryContainer: Color(0xFFF1D9D2),
    onPrimaryContainer: Color(0xFF4A1B14),
    secondary: Color(0xFF6B705C),
    onSecondary: Color(0xFFFFFFFF),
    secondaryContainer: Color(0xFFE3E4D6),
    onSecondaryContainer: Color(0xFF262A1D),
    error: Color(0xFFB3261E),
    onError: Color(0xFFFFFFFF),
    surface: Color(0xFFF4EFE6),
    onSurface: Color(0xFF2B2926),
    onSurfaceVariant: Color(0xFF6E685D),
    outline: Color(0xFF8A8478),
    outlineVariant: Color(0xFFD9D0BF),
    shadow: Color(0xFF000000),
    scrim: Color(0xFF000000),
    inverseSurface: Color(0xFF2B2926),
    onInverseSurface: Color(0xFFF4EFE6),
    inversePrimary: Color(0xFFE8A99E),
    surfaceContainerLowest: Color(0xFFFFFDF8),
    surfaceContainerLow: Color(0xFFFBF8F1),
    surfaceContainer: Color(0xFFF0EADD),
    surfaceContainerHigh: Color(0xFFEAE3D4),
    surfaceContainerHighest: Color(0xFFE4DCCB),
  );

  static const ColorScheme _washiDark = ColorScheme(
    brightness: Brightness.dark,
    primary: Color(0xFFE08C7E),
    onPrimary: Color(0xFF3F140D),
    primaryContainer: Color(0xFF5C2A21),
    onPrimaryContainer: Color(0xFFF7DDD7),
    secondary: Color(0xFFB7BCA3),
    onSecondary: Color(0xFF2B2F1F),
    secondaryContainer: Color(0xFF42463A),
    onSecondaryContainer: Color(0xFFE3E4D6),
    error: Color(0xFFF2B8B5),
    onError: Color(0xFF601410),
    surface: Color(0xFF1B1A18),
    onSurface: Color(0xFFE9E3D6),
    onSurfaceVariant: Color(0xFFA8A194),
    outline: Color(0xFF7A7467),
    outlineVariant: Color(0xFF3A372F),
    shadow: Color(0xFF000000),
    scrim: Color(0xFF000000),
    inverseSurface: Color(0xFFE9E3D6),
    onInverseSurface: Color(0xFF2B2926),
    inversePrimary: Color(0xFFB04A3C),
    surfaceContainerLowest: Color(0xFF141311),
    surfaceContainerLow: Color(0xFF242220),
    surfaceContainer: Color(0xFF2B2926),
    surfaceContainerHigh: Color(0xFF34312C),
    surfaceContainerHighest: Color(0xFF3E3A34),
  );

  /// Editorial japonesa: la paleta washi con las líneas en tinta y sin tarjetas
  /// de otro color (el papel es el mismo en todas partes).
  static final ColorScheme _washiRuledLight = _washiLight.copyWith(
    outlineVariant: const Color(0xFF2B2926),
    surfaceContainerLow: const Color(0xFFF4EFE6),
  );

  static final ColorScheme _washiRuledDark = _washiDark.copyWith(
    outlineVariant: const Color(0xFFE9E3D6),
    surfaceContainerLow: const Color(0xFF1B1A18),
  );

  // ---------------------------------------------------------------------------
  // Paleta editorial
  // ---------------------------------------------------------------------------

  static const ColorScheme _editorialLight = ColorScheme(
    brightness: Brightness.light,
    primary: Color(0xFFBF3A06),
    onPrimary: Color(0xFFFFFFFF),
    primaryContainer: Color(0xFFF6D8CA),
    onPrimaryContainer: Color(0xFF4A1500),
    secondary: Color(0xFF55524B),
    onSecondary: Color(0xFFFFFFFF),
    secondaryContainer: Color(0xFFE4E1DA),
    onSecondaryContainer: Color(0xFF1E1D1A),
    error: Color(0xFFB3261E),
    onError: Color(0xFFFFFFFF),
    surface: Color(0xFFF3F1EC),
    onSurface: Color(0xFF111111),
    onSurfaceVariant: Color(0xFF55524B),
    outline: Color(0xFF8A867D),
    outlineVariant: Color(0xFF111111),
    shadow: Color(0xFF000000),
    scrim: Color(0xFF000000),
    inverseSurface: Color(0xFF111111),
    onInverseSurface: Color(0xFFF3F1EC),
    inversePrimary: Color(0xFFFF8A4C),
    surfaceContainerLowest: Color(0xFFFFFFFF),
    surfaceContainerLow: Color(0xFFF3F1EC),
    surfaceContainer: Color(0xFFECE9E2),
    surfaceContainerHigh: Color(0xFFE6E3DB),
    surfaceContainerHighest: Color(0xFFDEDAD1),
  );

  static const ColorScheme _editorialDark = ColorScheme(
    brightness: Brightness.dark,
    primary: Color(0xFFFF6A2B),
    onPrimary: Color(0xFF0E0E0D),
    primaryContainer: Color(0xFF5A2410),
    onPrimaryContainer: Color(0xFFFFD9C7),
    secondary: Color(0xFFA19D93),
    onSecondary: Color(0xFF1A1916),
    secondaryContainer: Color(0xFF3A3832),
    onSecondaryContainer: Color(0xFFE6E2D8),
    error: Color(0xFFF2B8B5),
    onError: Color(0xFF601410),
    surface: Color(0xFF0E0E0D),
    onSurface: Color(0xFFF2EFE8),
    onSurfaceVariant: Color(0xFFA19D93),
    outline: Color(0xFF8C887E),
    outlineVariant: Color(0xFFF2EFE8),
    shadow: Color(0xFF000000),
    scrim: Color(0xFF000000),
    inverseSurface: Color(0xFFF2EFE8),
    onInverseSurface: Color(0xFF0E0E0D),
    inversePrimary: Color(0xFFBF3A06),
    surfaceContainerLowest: Color(0xFF0A0A09),
    surfaceContainerLow: Color(0xFF0E0E0D),
    surfaceContainer: Color(0xFF181816),
    surfaceContainerHigh: Color(0xFF21201E),
    surfaceContainerHighest: Color(0xFF2B2A27),
  );

  /// Colores de [style] con el brillo [brightness].
  static ColorScheme schemeFor(AppStyle style, Brightness brightness) {
    final bool dark = brightness == Brightness.dark;
    switch (style) {
      case AppStyle.papeleria:
      case AppStyle.hiloRojo:
        return dark ? _washiDark : _washiLight;
      case AppStyle.editorial:
        return dark ? _editorialDark : _editorialLight;
      case AppStyle.editorialJaponesa:
        return dark ? _washiRuledDark : _washiRuledLight;
    }
  }

  static ThemeData light([AppStyle style = AppStyle.papeleria]) =>
      _build(style, Brightness.light);

  static ThemeData dark([AppStyle style = AppStyle.papeleria]) =>
      _build(style, Brightness.dark);

  // ---------------------------------------------------------------------------
  // Construcción
  // ---------------------------------------------------------------------------

  static TextTheme _textTheme(
    TextTheme base,
    ColorScheme scheme,
    AppStyle style,
  ) {
    final TextTheme text = base.apply(
      bodyColor: scheme.onSurface,
      displayColor: scheme.onSurface,
    );

    if (!style.isEditorial) {
      final String serif = style.displayFamily;
      return text.copyWith(
        displayLarge: text.displayLarge?.copyWith(fontFamily: serif),
        displayMedium: text.displayMedium?.copyWith(fontFamily: serif),
        displaySmall: text.displaySmall?.copyWith(fontFamily: serif),
        headlineLarge: text.headlineLarge?.copyWith(fontFamily: serif),
        headlineMedium: text.headlineMedium?.copyWith(
          fontFamily: serif,
          fontWeight: FontWeight.w400,
          letterSpacing: 0.4,
        ),
        headlineSmall: text.headlineSmall?.copyWith(fontFamily: serif),
        titleLarge: text.titleLarge?.copyWith(
          fontFamily: serif,
          fontWeight: FontWeight.w400,
        ),
      );
    }

    final String display = style.displayFamily;
    final String body = style.bodyFamily;
    final String label = style.labelFamily ?? body;
    final FontWeight weight = style.displayWeight;
    return text.copyWith(
      displayLarge: text.displayLarge?.copyWith(
        fontFamily: display,
        fontWeight: weight,
      ),
      displayMedium: text.displayMedium?.copyWith(
        fontFamily: display,
        fontWeight: weight,
      ),
      displaySmall: text.displaySmall?.copyWith(
        fontFamily: display,
        fontWeight: weight,
      ),
      headlineLarge: text.headlineLarge?.copyWith(
        fontFamily: display,
        fontWeight: weight,
      ),
      headlineMedium: text.headlineMedium?.copyWith(
        fontFamily: display,
        fontWeight: weight,
        letterSpacing: 0,
      ),
      headlineSmall: text.headlineSmall?.copyWith(
        fontFamily: display,
        fontWeight: weight,
      ),
      titleLarge: text.titleLarge?.copyWith(
        fontFamily: display,
        fontWeight: weight,
      ),
      titleMedium: text.titleMedium?.copyWith(fontFamily: body),
      titleSmall: text.titleSmall?.copyWith(fontFamily: body),
      bodyLarge: text.bodyLarge?.copyWith(fontFamily: body),
      bodyMedium: text.bodyMedium?.copyWith(fontFamily: body),
      bodySmall: text.bodySmall?.copyWith(fontFamily: body),
      labelLarge: text.labelLarge?.copyWith(
        fontFamily: label,
        letterSpacing: 0.8,
      ),
      labelMedium: text.labelMedium?.copyWith(
        fontFamily: label,
        letterSpacing: 0.8,
      ),
      labelSmall: text.labelSmall?.copyWith(
        fontFamily: label,
        letterSpacing: 0.6,
      ),
    );
  }

  static ThemeData _build(AppStyle style, Brightness brightness) {
    final ColorScheme scheme = schemeFor(style, brightness);
    final ThemeData base = ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
    );

    final TextTheme textTheme = _textTheme(base.textTheme, scheme, style);
    final bool editorial = style.isEditorial;
    final RoundedRectangleBorder shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(style.cornerRadius),
    );
    final RoundedRectangleBorder outlinedShape = RoundedRectangleBorder(
      borderRadius: BorderRadius.zero,
      side: BorderSide(color: scheme.outlineVariant),
    );

    return base.copyWith(
      textTheme: textTheme,
      extensions: <ThemeExtension<dynamic>>[GonenStyleTheme(style)],
      // Desde Flutter 3.35 ThemeData exige AppBarThemeData (no AppBarTheme).
      appBarTheme: AppBarThemeData(
        backgroundColor: scheme.surface,
        foregroundColor: scheme.onSurface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        shape: editorial
            ? Border(bottom: BorderSide(color: scheme.outlineVariant))
            : null,
        titleTextStyle: TextStyle(
          fontFamily: style.displayFamily,
          fontSize: editorial ? 26 : 20,
          fontWeight: style == AppStyle.editorialJaponesa
              ? FontWeight.w600
              : FontWeight.w400,
          letterSpacing: editorial ? 0.5 : 3,
          color: scheme.onSurface,
        ),
      ),
      dividerTheme: DividerThemeData(
        color: scheme.outlineVariant,
        thickness: 1,
        space: 1,
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: scheme.primary,
          shape: shape,
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(shape: shape),
      ),
      chipTheme: editorial
          ? ChipThemeData(
              shape: shape,
              side: BorderSide(color: scheme.outlineVariant),
              backgroundColor: Colors.transparent,
              labelStyle: TextStyle(
                fontFamily: style.labelFamily,
                fontSize: 12,
                letterSpacing: 0.8,
                color: scheme.onSurface,
              ),
            )
          : null,
      segmentedButtonTheme: editorial
          ? SegmentedButtonThemeData(
              style: ButtonStyle(
                shape: WidgetStatePropertyAll<OutlinedBorder>(shape),
              ),
            )
          : null,
      dialogTheme: editorial ? DialogThemeData(shape: outlinedShape) : null,
      bottomSheetTheme:
          editorial ? BottomSheetThemeData(shape: outlinedShape) : null,
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: scheme.inverseSurface,
        contentTextStyle: TextStyle(color: scheme.onInverseSurface),
        shape: shape,
      ),
      listTileTheme: ListTileThemeData(
        iconColor: scheme.onSurfaceVariant,
        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      ),
    );
  }
}
