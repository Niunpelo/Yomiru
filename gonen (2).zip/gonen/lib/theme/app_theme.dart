import 'package:flutter/material.dart';

/// Familia con serifa del sistema (Noto Serif en Android). Se usa en títulos y
/// en el texto del diario para dar sensación de libro.
const String kSerifFamily = 'serif';

/// Temas claro y oscuro inspirados en la papelería japonesa:
/// papel washi cálido, tinta sumi y un único acento bermellón (shu).
class AppTheme {
  AppTheme._();

  static const ColorScheme _lightScheme = ColorScheme(
    brightness: Brightness.light,
    primary: Color(0xFFB04A3C),
    onPrimary: Color(0xFFFFFFFF),
    primaryContainer: Color(0xFFF1D9D2),
    onPrimaryContainer: Color(0xFF4A1B14),
    secondary: Color(0xFF6B705C),
    onSecondary: Color(0xFFFFFFFF),
    secondaryContainer: Color(0xFFE3E4D6),
    onSecondaryContainer: Color(0xFF262A1D),
    error: Color(0xFFB3261E),
    onError: Color(0xFFFFFFFF),
    surface: Color(0xFFF4EFE6),
    onSurface: Color(0xFF2B2926),
    onSurfaceVariant: Color(0xFF6E685D),
    outline: Color(0xFF8A8478),
    outlineVariant: Color(0xFFD9D0BF),
    shadow: Color(0xFF000000),
    scrim: Color(0xFF000000),
    inverseSurface: Color(0xFF2B2926),
    onInverseSurface: Color(0xFFF4EFE6),
    inversePrimary: Color(0xFFE8A99E),
    surfaceContainerLowest: Color(0xFFFFFDF8),
    surfaceContainerLow: Color(0xFFFBF8F1),
    surfaceContainer: Color(0xFFF0EADD),
    surfaceContainerHigh: Color(0xFFEAE3D4),
    surfaceContainerHighest: Color(0xFFE4DCCB),
  );

  static const ColorScheme _darkScheme = ColorScheme(
    brightness: Brightness.dark,
    primary: Color(0xFFE08C7E),
    onPrimary: Color(0xFF3F140D),
    primaryContainer: Color(0xFF5C2A21),
    onPrimaryContainer: Color(0xFFF7DDD7),
    secondary: Color(0xFFB7BCA3),
    onSecondary: Color(0xFF2B2F1F),
    secondaryContainer: Color(0xFF42463A),
    onSecondaryContainer: Color(0xFFE3E4D6),
    error: Color(0xFFF2B8B5),
    onError: Color(0xFF601410),
    surface: Color(0xFF1B1A18),
    onSurface: Color(0xFFE9E3D6),
    onSurfaceVariant: Color(0xFFA8A194),
    outline: Color(0xFF7A7467),
    outlineVariant: Color(0xFF3A372F),
    shadow: Color(0xFF000000),
    scrim: Color(0xFF000000),
    inverseSurface: Color(0xFFE9E3D6),
    onInverseSurface: Color(0xFF2B2926),
    inversePrimary: Color(0xFFB04A3C),
    surfaceContainerLowest: Color(0xFF141311),
    surfaceContainerLow: Color(0xFF242220),
    surfaceContainer: Color(0xFF2B2926),
    surfaceContainerHigh: Color(0xFF34312C),
    surfaceContainerHighest: Color(0xFF3E3A34),
  );

  static ThemeData light() => _build(_lightScheme);

  static ThemeData dark() => _build(_darkScheme);

  static ThemeData _build(ColorScheme scheme) {
    final ThemeData base = ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
    );

    final TextTheme text = base.textTheme.apply(
      bodyColor: scheme.onSurface,
      displayColor: scheme.onSurface,
    );

    final TextTheme textTheme = text.copyWith(
      displayLarge: text.displayLarge?.copyWith(fontFamily: kSerifFamily),
      displayMedium: text.displayMedium?.copyWith(fontFamily: kSerifFamily),
      displaySmall: text.displaySmall?.copyWith(fontFamily: kSerifFamily),
      headlineLarge: text.headlineLarge?.copyWith(fontFamily: kSerifFamily),
      headlineMedium: text.headlineMedium?.copyWith(
        fontFamily: kSerifFamily,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.4,
      ),
      headlineSmall: text.headlineSmall?.copyWith(fontFamily: kSerifFamily),
      titleLarge: text.titleLarge?.copyWith(
        fontFamily: kSerifFamily,
        fontWeight: FontWeight.w400,
      ),
    );

    return base.copyWith(
      textTheme: textTheme,
      // Desde Flutter 3.35 ThemeData exige AppBarThemeData (no AppBarTheme).
      appBarTheme: AppBarThemeData(
        backgroundColor: scheme.surface,
        foregroundColor: scheme.onSurface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          fontFamily: kSerifFamily,
          fontSize: 20,
          fontWeight: FontWeight.w400,
          letterSpacing: 3,
          color: scheme.onSurface,
        ),
      ),
      dividerTheme: DividerThemeData(
        color: scheme.outlineVariant,
        thickness: 1,
        space: 1,
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: scheme.primary,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: scheme.inverseSurface,
        contentTextStyle: TextStyle(color: scheme.onInverseSurface),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      ),
      listTileTheme: ListTileThemeData(
        iconColor: scheme.onSurfaceVariant,
        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      ),
    );
  }
}
