import 'package:flutter/widgets.dart';

/// Idiomas de la app. El español es el de origen; el inglés se elige en Ajustes.
enum AppLanguage {
  es('es', 'Español'),
  en('en', 'English');

  const AppLanguage(this.code, this.nativeName);

  /// Código de dos letras: es también el que se guarda en los ajustes.
  final String code;

  /// Nombre del idioma escrito en ese mismo idioma.
  final String nativeName;

  Locale get locale => Locale(code);

  /// Idioma guardado con ese código; cualquier otro valor da español.
  static AppLanguage fromCode(String? code) {
    for (final AppLanguage language in AppLanguage.values) {
      if (language.code == code) {
        return language;
      }
    }
    return AppLanguage.es;
  }
}

/// Idioma en uso, para el código que no tiene un `BuildContext` a mano
/// (avisos, mensajes de error de los proveedores, nombres de archivo...).
///
/// Lo actualiza `SettingsProvider` al cargar los ajustes y al cambiar de idioma.
class AppLocale {
  AppLocale._();

  static AppLanguage current = AppLanguage.es;

  static bool get isEnglish => current == AppLanguage.en;
}

/// Devuelve [en] si la app está en inglés y [es] en cualquier otro caso.
///
/// Para textos que se dibujan en pantalla conviene `context.tr`, que además
/// hace que el widget se redibuje al cambiar de idioma.
String tr(String es, String en) => AppLocale.isEnglish ? en : es;

/// Reparte el idioma elegido por todo el árbol de widgets.
///
/// Se pone encima del `Navigator` (en el `builder` de `MaterialApp`), así que
/// lo ven todas las pantallas y los diálogos.
class LanguageScope extends InheritedWidget {
  const LanguageScope({
    super.key,
    required this.language,
    required super.child,
  });

  final AppLanguage language;

  /// Idioma del contexto. Fuera de un [LanguageScope] (por ejemplo en una
  /// prueba de un widget suelto) se usa [AppLocale.current].
  static AppLanguage of(BuildContext context) {
    final LanguageScope? scope =
        context.dependOnInheritedWidgetOfExactType<LanguageScope>();
    return scope?.language ?? AppLocale.current;
  }

  @override
  bool updateShouldNotify(LanguageScope oldWidget) =>
      language != oldWidget.language;
}

extension TrContext on BuildContext {
  /// Texto en el idioma de la app: [es] en español y [en] en inglés.
  String tr(String es, String en) =>
      LanguageScope.of(this) == AppLanguage.en ? en : es;
}
