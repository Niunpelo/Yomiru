/// Límites de fotos y notas de voz por día.
class AttachmentLimits {
  AttachmentLimits._();

  /// Fotos por día y año.
  static const int maxImagesPerDay = 10;

  /// Notas de voz por día y año.
  static const int maxVoiceNotesPerDay = 5;

  /// Duración máxima de una nota de voz. La grabación se detiene sola al llegar.
  static const int maxVoiceSeconds = 300;

  /// Lado máximo, en píxeles, al que se reducen las fotos al adjuntarlas.
  static const double imageMaxSide = 1600;

  /// Calidad JPEG (0-100) con la que se guardan las fotos.
  static const int imageQuality = 80;
}
