import '../l10n/tr.dart';
import 'attachment_model.dart';
import 'capsule_model.dart';
import 'entry_model.dart';

/// Todo lo que se guarda en una copia de seguridad: las entradas del diario,
/// las cápsulas y los datos de las fotos y notas de voz.
///
/// Los archivos de las fotos y notas de voz van aparte, dentro del archivo de
/// copia; aquí solo están las filas de la base de datos.
class BackupSnapshot {
  const BackupSnapshot({
    required this.entries,
    required this.capsules,
    required this.attachments,
    this.appVersion = '',
    this.createdAt,
  });

  /// Versión del formato. Sube si algún día cambia lo que contiene la copia.
  static const int formatVersion = 1;

  final List<Entry> entries;
  final List<Capsule> capsules;
  final List<Attachment> attachments;

  /// Versión de Gonen que hizo la copia (solo informativa).
  final String appVersion;

  /// Momento en que se hizo la copia.
  final DateTime? createdAt;

  /// Convierte la copia a un mapa listo para `jsonEncode`.
  Map<String, Object?> toJson() {
    return <String, Object?>{
      'format': formatVersion,
      'app_version': appVersion,
      'created_at': createdAt?.millisecondsSinceEpoch,
      'entries': <Map<String, Object?>>[
        for (final Entry entry in entries) entry.toMap(),
      ],
      'capsules': <Map<String, Object?>>[
        for (final Capsule capsule in capsules) capsule.toMap(),
      ],
      'attachments': <Map<String, Object?>>[
        for (final Attachment attachment in attachments) attachment.toMap(),
      ],
    };
  }

  /// Crea la copia a partir del resultado de `jsonDecode`.
  /// Lanza [FormatException] si el contenido no es válido.
  factory BackupSnapshot.fromJson(Object? json) {
    if (json is! Map) {
      throw FormatException(_invalidFormat());
    }
    final int format = (json['format'] as num?)?.toInt() ?? 0;
    if (format < 1) {
      throw FormatException(_invalidFormat());
    }
    if (format > formatVersion) {
      throw FormatException(
        tr(
          'Esta copia es de una versión más nueva de Gonen. Actualiza la app para restaurarla.',
          'This backup comes from a newer version of Gonen. Update the app to restore it.',
        ),
      );
    }

    try {
      final int? createdMs = (json['created_at'] as num?)?.toInt();
      return BackupSnapshot(
        appVersion: (json['app_version'] as String?) ?? '',
        createdAt: createdMs == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(createdMs),
        entries: <Entry>[
          for (final Map<String, Object?> map in _maps(json['entries']))
            Entry.fromMap(map),
        ],
        capsules: <Capsule>[
          for (final Map<String, Object?> map in _maps(json['capsules']))
            Capsule.fromMap(map),
        ],
        attachments: <Attachment>[
          for (final Map<String, Object?> map in _maps(json['attachments']))
            Attachment.fromMap(map),
        ],
      );
    } on FormatException {
      rethrow;
    } catch (error) {
      throw FormatException(
        tr(
          'Los datos de la copia no son válidos ($error).',
          'The backup data is not valid ($error).',
        ),
      );
    }
  }

  static String _invalidFormat() => tr(
        'El archivo de copia no tiene un formato válido.',
        'The backup file is not in a valid format.',
      );

  static List<Map<String, Object?>> _maps(Object? value) {
    if (value == null) {
      return const <Map<String, Object?>>[];
    }
    if (value is! List) {
      throw FormatException(_invalidFormat());
    }
    final List<Map<String, Object?>> maps = <Map<String, Object?>>[];
    for (final Object? item in value) {
      if (item is! Map) {
        throw FormatException(_invalidFormat());
      }
      maps.add(Map<String, Object?>.from(item));
    }
    return maps;
  }
}

/// Qué se añadió al restaurar una copia.
class BackupMergeResult {
  const BackupMergeResult({
    this.entriesAdded = 0,
    this.entriesKept = 0,
    this.capsulesAdded = 0,
    this.attachmentsAdded = 0,
  });

  /// Entradas que no estaban en este móvil y se han añadido.
  final int entriesAdded;

  /// Entradas del mismo día que ya existían con otro texto: se conserva la de
  /// este móvil y no se toca.
  final int entriesKept;

  /// Cápsulas que se han añadido.
  final int capsulesAdded;

  /// Fotos y notas de voz que se han añadido.
  final int attachmentsAdded;

  /// Verdadero si la restauración no ha cambiado nada.
  bool get isEmpty =>
      entriesAdded == 0 && capsulesAdded == 0 && attachmentsAdded == 0;
}
