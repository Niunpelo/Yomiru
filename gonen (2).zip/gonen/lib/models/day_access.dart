/// Qué se puede hacer con la tarjeta del año actual para el día seleccionado.
enum DayAccess {
  /// Es hoy: se puede escribir hasta las 23:59.
  editable,

  /// El día ya terminó: se puede leer, pero no editar.
  ended,

  /// El día aún no ha llegado: todavía no se puede escribir.
  notYet,

  /// El día no existe en ese año (29 de febrero en un año no bisiesto).
  missing,
}

/// Calcula el acceso a [date] en el instante [now].
///
/// Solo cuenta el día del calendario: a las 23:59:59 sigue siendo editable y a
/// las 00:00:00 del día siguiente pasa a ser de solo lectura.
DayAccess dayAccessFor(DateTime? date, DateTime now) {
  if (date == null) {
    return DayAccess.missing;
  }
  final DateTime day = DateTime(date.year, date.month, date.day);
  final DateTime today = DateTime(now.year, now.month, now.day);
  if (day.isAtSameMomentAs(today)) {
    return DayAccess.editable;
  }
  return day.isBefore(today) ? DayAccess.ended : DayAccess.notYet;
}
