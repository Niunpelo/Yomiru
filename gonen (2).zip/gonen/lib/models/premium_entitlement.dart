/// Tipo de compra premium.
enum PremiumPlan {
  /// Sin premium.
  none,

  /// Suscripción anual.
  yearly,

  /// Pago único: no caduca.
  lifetime,
}

/// Derecho a usar las funciones premium, tal y como lo confirmó Google Play
/// por última vez.
///
/// Google Play solo dice qué compras están activas en cada consulta. Por eso la
/// suscripción anual se da por buena durante [subscriptionGrace] desde la última
/// vez que Play la confirmó (la app lo consulta cada vez que se abre). Así no se
/// pierde el premium por pasar unos días sin conexión, y una suscripción que
/// caduca deja de valer pasado ese margen.
class PremiumEntitlement {
  const PremiumEntitlement({required this.plan, this.verifiedAt});

  /// Sin derecho premium.
  static const PremiumEntitlement none =
      PremiumEntitlement(plan: PremiumPlan.none);

  /// Margen sin confirmación de Play durante el que la suscripción sigue valiendo.
  static const Duration subscriptionGrace = Duration(days: 7);

  final PremiumPlan plan;

  /// Última vez que Google Play confirmó la compra.
  final DateTime? verifiedAt;

  /// Verdadero si en el instante [now] se pueden usar las funciones premium.
  bool isActiveAt(DateTime now) {
    switch (plan) {
      case PremiumPlan.none:
        return false;
      case PremiumPlan.lifetime:
        return true;
      case PremiumPlan.yearly:
        final DateTime? verified = verifiedAt;
        if (verified == null) {
          return false;
        }
        return !now.isAfter(verified.add(subscriptionGrace));
    }
  }
}
