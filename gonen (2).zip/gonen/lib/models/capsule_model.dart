import 'package:flutter/foundation.dart';

/// Estado de una cápsula del tiempo.
enum CapsuleStatus {
  /// Todavía no ha llegado el día de apertura: no se puede leer.
  sealed,

  /// Ya ha llegado el día de apertura, pero aún no se ha abierto.
  ready,

  /// Ya se abrió y se puede releer.
  opened,
}

/// Mensaje escrito hoy para leerlo en un día del futuro.
@immutable
class Capsule {
  const Capsule({
    this.id,
    required this.title,
    required this.content,
    required this.createdAt,
    required this.openDate,
    this.openedAt,
    this.sender,
    this.recipient,
    this.uid,
  });

  /// Identificador autoincremental de SQLite. Es null mientras no se ha guardado.
  final int? id;

  /// Título opcional. Se ve aunque la cápsula esté sellada.
  final String title;

  /// Mensaje. No se enseña hasta que llega el día de apertura.
  final String content;

  /// Momento en que se escribió y selló.
  final DateTime createdAt;

  /// Día a partir del cual se puede abrir (solo cuenta la fecha, a las 00:00).
  final DateTime openDate;

  /// Momento en que se abrió por primera vez, o null si aún no se ha abierto.
  final DateTime? openedAt;

  /// Quién la escribió, cuando no es una cápsula solo para uno mismo:
  /// * en una cápsula recibida, el nombre de quien la envió;
  /// * en una cápsula enviada, el nombre propio que se puso al enviarla.
  final String? sender;

  /// Para quién es, en una cápsula que se envió a otra persona (puede ser un
  /// texto vacío si no se puso nombre). Es null en el resto.
  final String? recipient;

  /// Identificador único de una cápsula enviada o recibida. Sirve para no
  /// guardar dos veces la misma cápsula si el archivo llega más de una vez.
  final String? uid;

  /// Verdadero si se creó para enviarla a otra persona.
  bool get isSent => recipient != null;

  /// Verdadero si la ha enviado otra persona.
  bool get isReceived => recipient == null && sender != null;

  /// Quita la hora de [date].
  static DateTime dateOnly(DateTime date) =>
      DateTime(date.year, date.month, date.day);

  /// Convierte una fecha en el texto "AAAA-MM-DD".
  static String dateKey(DateTime date) {
    final String yyyy = date.year.toString().padLeft(4, '0');
    final String mm = date.month.toString().padLeft(2, '0');
    final String dd = date.day.toString().padLeft(2, '0');
    return '$yyyy-$mm-$dd';
  }

  /// Convierte el texto "AAAA-MM-DD" en una fecha.
  static DateTime parseDateKey(String key) {
    final List<String> parts = key.split('-');
    return DateTime(
      int.parse(parts[0]),
      int.parse(parts[1]),
      int.parse(parts[2]),
    );
  }

  /// Estado de la cápsula en el instante [now].
  CapsuleStatus statusOn(DateTime now) {
    if (openedAt != null) {
      return CapsuleStatus.opened;
    }
    return dateOnly(now).isBefore(openDate)
        ? CapsuleStatus.sealed
        : CapsuleStatus.ready;
  }

  /// Días de calendario que faltan para poder abrirla (0 si ya se puede).
  ///
  /// Se calcula con fechas UTC para que los cambios de hora no desajusten la cuenta.
  int daysUntilOpen(DateTime now) {
    final DateTime from = DateTime.utc(now.year, now.month, now.day);
    final DateTime to = DateTime.utc(openDate.year, openDate.month, openDate.day);
    final int days = to.difference(from).inDays;
    return days < 0 ? 0 : days;
  }

  Capsule copyWith({int? id, DateTime? openedAt}) {
    return Capsule(
      id: id ?? this.id,
      title: title,
      content: content,
      createdAt: createdAt,
      openDate: openDate,
      openedAt: openedAt ?? this.openedAt,
      sender: sender,
      recipient: recipient,
      uid: uid,
    );
  }

  /// Convierte la cápsula al formato de columnas de SQLite.
  Map<String, Object?> toMap() {
    return <String, Object?>{
      'id': ?id,
      'title': title,
      'content': content,
      'created_at': createdAt.millisecondsSinceEpoch,
      'open_date': dateKey(openDate),
      'opened_at': openedAt?.millisecondsSinceEpoch,
      'sender': sender,
      'recipient': recipient,
      'uid': uid,
    };
  }

  /// Crea una cápsula a partir de una fila de SQLite.
  factory Capsule.fromMap(Map<String, Object?> map) {
    final int? openedMs = map['opened_at'] as int?;
    return Capsule(
      id: map['id'] as int?,
      title: (map['title'] as String?) ?? '',
      content: (map['content'] as String?) ?? '',
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at']! as int),
      openDate: parseDateKey(map['open_date']! as String),
      openedAt:
          openedMs == null ? null : DateTime.fromMillisecondsSinceEpoch(openedMs),
      sender: map['sender'] as String?,
      recipient: map['recipient'] as String?,
      uid: map['uid'] as String?,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is Capsule &&
        other.id == id &&
        other.title == title &&
        other.content == content &&
        other.createdAt == createdAt &&
        other.openDate == openDate &&
        other.openedAt == openedAt &&
        other.sender == sender &&
        other.recipient == recipient &&
        other.uid == uid;
  }

  @override
  int get hashCode => Object.hash(
        id,
        title,
        content,
        createdAt,
        openDate,
        openedAt,
        sender,
        recipient,
        uid,
      );

  @override
  String toString() => 'Capsule(id: $id, abre el ${dateKey(openDate)})';
}
