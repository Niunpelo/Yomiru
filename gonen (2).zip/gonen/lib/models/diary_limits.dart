/// Límites del ajuste "años anteriores que se muestran".
class DiaryLimits {
  DiaryLimits._();

  /// Solo se muestra la tarjeta del año actual.
  static const int minYearsBack = 0;

  /// Máximo de años anteriores que se pueden mostrar.
  static const int maxYearsBack = 20;

  /// Por defecto: el año actual más 4 anteriores (5 tarjetas).
  static const int defaultYearsBack = 4;

  /// Ajusta [value] al rango permitido.
  static int clampYearsBack(int value) {
    if (value < minYearsBack) {
      return minYearsBack;
    }
    if (value > maxYearsBack) {
      return maxYearsBack;
    }
    return value;
  }
}
