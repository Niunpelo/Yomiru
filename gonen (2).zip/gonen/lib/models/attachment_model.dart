import 'package:flutter/foundation.dart';

/// Tipo de archivo que se adjunta a un día del diario o a una cápsula.
enum AttachmentType { image, audio }

/// Foto o nota de voz adjunta a un día concreto de un año, o a una cápsula
/// del tiempo.
///
/// El archivo vive en el almacenamiento privado de la app; aquí solo se guarda
/// su ruta relativa, para que la base de datos siga valiendo aunque cambie la
/// carpeta de la app (por ejemplo, al restaurar una copia).
///
/// * Adjunto de un día: [dayOfYear] ("MM-DD") y [year] indican el día, y
///   [capsuleId] es null.
/// * Adjunto de una cápsula: [capsuleId] indica la cápsula y [dayOfYear] y
///   [year] no se usan (vacío y 0).
@immutable
class Attachment {
  const Attachment({
    this.id,
    required this.dayOfYear,
    required this.year,
    required this.type,
    required this.relativePath,
    this.durationMs,
    required this.createdAt,
    this.capsuleId,
  });

  /// Adjunto de una cápsula del tiempo. Mientras la cápsula no se ha guardado,
  /// [capsuleId] puede ser null.
  const Attachment.forCapsule({
    this.id,
    this.capsuleId,
    required this.type,
    required this.relativePath,
    this.durationMs,
    required this.createdAt,
  })  : dayOfYear = '',
        year = 0;

  /// Identificador autoincremental de SQLite. Es null mientras no se ha guardado.
  final int? id;

  /// Día del año en formato "MM-DD". Vacío en los adjuntos de cápsulas.
  final String dayOfYear;

  /// Año del día. Es 0 en los adjuntos de cápsulas.
  final int year;

  final AttachmentType type;

  /// Ruta del archivo relativa a la carpeta de adjuntos de la app.
  final String relativePath;

  /// Duración en milisegundos (solo notas de voz).
  final int? durationMs;

  final DateTime createdAt;

  /// Cápsula a la que pertenece, o null si es un adjunto de un día del diario.
  final int? capsuleId;

  /// Verdadero si el adjunto pertenece a una cápsula del tiempo.
  bool get isForCapsule => dayOfYear.isEmpty && year == 0;

  Attachment copyWith({int? id, int? capsuleId}) {
    return Attachment(
      id: id ?? this.id,
      dayOfYear: dayOfYear,
      year: year,
      type: type,
      relativePath: relativePath,
      durationMs: durationMs,
      createdAt: createdAt,
      capsuleId: capsuleId ?? this.capsuleId,
    );
  }

  /// Convierte el adjunto al formato de columnas de SQLite.
  Map<String, Object?> toMap() {
    return <String, Object?>{
      'id': ?id,
      'day_of_year': dayOfYear,
      'year': year,
      'type': type.name,
      'file_path': relativePath,
      'duration_ms': durationMs,
      'created_at': createdAt.millisecondsSinceEpoch,
      'capsule_id': capsuleId,
    };
  }

  /// Crea un adjunto a partir de una fila de SQLite.
  factory Attachment.fromMap(Map<String, Object?> map) {
    final String typeName = (map['type'] as String?) ?? '';
    return Attachment(
      id: map['id'] as int?,
      dayOfYear: (map['day_of_year'] as String?) ?? '',
      year: (map['year'] as int?) ?? 0,
      type: AttachmentType.values.firstWhere(
        (AttachmentType candidate) => candidate.name == typeName,
        orElse: () => AttachmentType.image,
      ),
      relativePath: map['file_path']! as String,
      durationMs: map['duration_ms'] as int?,
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at']! as int),
      capsuleId: map['capsule_id'] as int?,
    );
  }

  @override
  bool operator ==(Object other) {
    return other is Attachment &&
        other.id == id &&
        other.dayOfYear == dayOfYear &&
        other.year == year &&
        other.type == type &&
        other.relativePath == relativePath &&
        other.durationMs == durationMs &&
        other.createdAt == createdAt &&
        other.capsuleId == capsuleId;
  }

  @override
  int get hashCode => Object.hash(
        id,
        dayOfYear,
        year,
        type,
        relativePath,
        durationMs,
        createdAt,
        capsuleId,
      );

  @override
  String toString() => isForCapsule
      ? 'Attachment(${type.name}, cápsula $capsuleId)'
      : 'Attachment(${type.name}, $year-$dayOfYear)';
}
