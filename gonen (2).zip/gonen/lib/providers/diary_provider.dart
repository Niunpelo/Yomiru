import 'dart:async';

import 'package:flutter/foundation.dart';

import '../database/database_helper.dart';
import '../models/attachment_limits.dart';
import '../models/attachment_model.dart';
import '../models/day_access.dart';
import '../models/diary_limits.dart';
import '../models/entry_model.dart';
import '../services/attachment_service.dart';

/// Estado del guardado automático del texto del año actual.
enum SaveStatus { idle, unsaved, saving, saved, error }

/// Gestiona el día seleccionado, las entradas de los últimos años y el guardado.
///
/// Reglas de edición:
/// * Solo se puede escribir en la tarjeta del año actual y solo si el día
///   seleccionado es hoy. Al llegar la medianoche (pasadas las 23:59) esa
///   tarjeta pasa a ser de solo lectura.
/// * Los años anteriores nunca se pueden editar.
class DiaryProvider extends ChangeNotifier {
  DiaryProvider({
    DatabaseHelper? databaseHelper,
    AttachmentService? attachmentService,
    int yearsBack = DiaryLimits.defaultYearsBack,
    DateTime Function()? clock,
  })  : _db = databaseHelper ?? DatabaseHelper.instance,
        _files = attachmentService ?? AttachmentService.instance,
        _clock = clock ?? DateTime.now,
        _yearsBack = DiaryLimits.clampYearsBack(yearsBack),
        _shownYearsBack = DiaryLimits.clampYearsBack(yearsBack) {
    final DateTime now = _clock();
    _targetCursor = _cursorFor(now);
    _cursor = _targetCursor;
    _entryYear = now.year;
  }

  /// Año bisiesto usado como calendario de referencia. Con él existen los 366
  /// días posibles, incluido el 29 de febrero, y se puede navegar de forma
  /// circular sin depender del año actual.
  static const int _referenceYear = 2000;

  static const Duration _autosaveDelay = Duration(milliseconds: 900);

  /// Margen tras la medianoche para asegurarse de que el reloj ya marca el día nuevo.
  static const Duration _midnightMargin = Duration(milliseconds: 100);

  final DatabaseHelper _db;
  final AttachmentService _files;
  final DateTime Function() _clock;

  /// Cuántos años anteriores se piden en el ajuste.
  int _yearsBack;

  /// Cuántos años anteriores tienen cargados las tarjetas que se ven ahora.
  /// Cambia solo cuando termina la carga, para que nunca haya tarjetas sin datos.
  int _shownYearsBack;

  /// Día que se está mostrando (fecha UTC dentro del año de referencia).
  late DateTime _cursor;

  /// Día al que se quiere llegar; se actualiza al instante para que pulsar
  /// varias veces seguidas ">" avance un día por pulsación aunque la carga
  /// del día anterior no haya terminado.
  late DateTime _targetCursor;

  late int _entryYear;
  Map<int, Entry> _entries = const <int, Entry>{};
  Map<int, List<Attachment>> _attachments = const <int, List<Attachment>>{};
  bool _isReady = false;
  bool _followingToday = true;
  String? _errorMessage;
  SaveStatus _saveStatus = SaveStatus.idle;

  int _loadToken = 0;
  Timer? _autosaveTimer;
  Timer? _midnightTimer;
  String? _pendingText;
  String? _pendingDayKey;
  int? _pendingYear;
  Future<void> _saveQueue = Future<void>.value();
  bool _disposed = false;

  // ---------------------------------------------------------------------------
  // Lectura del estado
  // ---------------------------------------------------------------------------

  /// Falso hasta que se han cargado las entradas por primera vez.
  bool get isReady => _isReady;

  /// Mensaje de error si no se pudo abrir el diario.
  String? get errorMessage => _errorMessage;

  /// Mes seleccionado (1-12).
  int get month => _cursor.month;

  /// Día del mes seleccionado (1-31).
  int get day => _cursor.day;

  /// Clave "MM-DD" del día seleccionado.
  String get dayKey => Entry.dayKeyFor(_cursor);

  /// Fecha de referencia (año bisiesto) para mostrar el nombre del día y del mes,
  /// incluso cuando el día seleccionado no existe en el año actual.
  DateTime get referenceDate =>
      DateTime(_referenceYear, _cursor.month, _cursor.day);

  /// Año en el que se escribe: el año actual en el momento de cargar el día.
  int get entryYear => _entryYear;

  /// Años anteriores que se han elegido en los ajustes.
  int get yearsBack => _yearsBack;

  /// Cuántas tarjetas se muestran por día (el año actual y los anteriores).
  int get yearsToShow => _shownYearsBack + 1;

  /// Años que se muestran, del más reciente al más antiguo.
  List<int> get years =>
      List<int>.generate(yearsToShow, (int index) => _entryYear - index);

  /// El día seleccionado dentro del año actual, o null si ese año no lo tiene
  /// (el 29 de febrero en un año no bisiesto).
  DateTime? get selectedDate => _dateInYear(_entryYear);

  /// Qué se puede hacer ahora mismo con la tarjeta del año actual.
  DayAccess get access => dayAccessFor(selectedDate, _clock());

  /// Verdadero si se puede escribir en la tarjeta del año actual.
  bool get canWriteCurrentYear => access == DayAccess.editable;

  /// Verdadero si el día seleccionado es el de hoy.
  bool get isToday => dayKey == Entry.dayKeyFor(_clock());

  /// Indica si el día seleccionado existe en [year].
  bool dayExistsIn(int year) => _dateInYear(year) != null;

  /// Entrada guardada de un año concreto para el día seleccionado.
  Entry? entryFor(int year) => _entries[year];

  /// Entrada del año actual para el día seleccionado.
  Entry? get currentEntry => _entries[_entryYear];

  /// Fotos y notas de voz de un año concreto para el día seleccionado.
  List<Attachment> attachmentsFor(int year) =>
      _attachments[year] ?? const <Attachment>[];

  /// Cuántos adjuntos de [type] tiene el día de hoy (año actual).
  int attachmentCount(AttachmentType type) => attachmentsFor(_entryYear)
      .where((Attachment attachment) => attachment.type == type)
      .length;

  /// Máximo de adjuntos de [type] por día.
  static int attachmentLimit(AttachmentType type) =>
      type == AttachmentType.image
          ? AttachmentLimits.maxImagesPerDay
          : AttachmentLimits.maxVoiceNotesPerDay;

  SaveStatus get saveStatus => _saveStatus;

  DateTime? _dateInYear(int year) {
    final DateTime candidate = DateTime(year, month, day);
    return candidate.month == month ? candidate : null;
  }

  // ---------------------------------------------------------------------------
  // Ajuste: años anteriores
  // ---------------------------------------------------------------------------

  /// Aplica el número de años anteriores elegido en los ajustes.
  ///
  /// Se llama desde un proveedor en medio de la construcción de la interfaz, así
  /// que no notifica de inmediato: la recarga es asíncrona y notifica al terminar.
  /// Las entradas de los años que dejan de verse no se borran.
  void applyYearsBack(int value) {
    final int next = DiaryLimits.clampYearsBack(value);
    if (next == _yearsBack) {
      return;
    }
    _yearsBack = next;
    if (_isReady) {
      unawaited(_showDay(_targetCursor));
    }
  }

  // ---------------------------------------------------------------------------
  // Navegación entre días
  // ---------------------------------------------------------------------------

  /// Carga el día de hoy y arranca el aviso de medianoche. Se llama una vez al
  /// abrir la pantalla principal.
  Future<void> initialize() async {
    _scheduleMidnightTick();
    await _showDay(_cursorFor(_clock()));
  }

  /// Vuelve a intentar la carga tras un error.
  Future<void> retry() => _showDay(_targetCursor);

  /// Vuelve a leer el día que se está viendo (por ejemplo, tras restaurar una
  /// copia de seguridad que ha añadido entradas).
  Future<void> reload() => _showDay(_targetCursor);

  Future<void> goToToday() => _showDay(_cursorFor(_clock()));

  Future<void> goToPreviousDay() => _showDay(_shift(_targetCursor, -1));

  Future<void> goToNextDay() => _showDay(_shift(_targetCursor, 1));

  /// Salta al día y mes de [date] (el año de [date] se ignora).
  Future<void> goToDate(DateTime date) => _showDay(_cursorFor(date));

  /// Se llama al volver a la app: si ha cambiado el día (o el año) mientras
  /// estaba en segundo plano, actualiza lo que se muestra y bloquea lo que ya
  /// no se puede editar.
  Future<void> refreshIfNeeded() async {
    if (!_isReady) {
      return;
    }
    // Los temporizadores pueden retrasarse con la app en segundo plano.
    _scheduleMidnightTick();

    final DateTime now = _clock();
    final bool dayChanged = Entry.dayKeyFor(now) != dayKey;
    if (_followingToday && (dayChanged || now.year != _entryYear)) {
      await goToToday();
    } else if (now.year != _entryYear) {
      await _showDay(_targetCursor);
    } else {
      // El día no ha cambiado de vista, pero puede haber terminado: se vuelve
      // a evaluar si la tarjeta se puede editar.
      _notify();
    }
  }

  DateTime _cursorFor(DateTime date) =>
      DateTime.utc(_referenceYear, date.month, date.day);

  DateTime _shift(DateTime from, int delta) {
    final DateTime start = DateTime.utc(_referenceYear, 1, 1);
    final int index = from.difference(start).inDays;
    // En Dart el resto con divisor positivo nunca es negativo.
    final int next = (index + delta) % 366;
    return start.add(Duration(days: next));
  }

  Future<void> _showDay(DateTime cursor) async {
    _targetCursor = cursor;
    // Antes de cambiar de día se guarda lo que haya a medias en el día actual.
    await flushPendingSave();

    final int token = ++_loadToken;
    final DateTime now = _clock();
    final int year = now.year;
    final int yearsBack = _yearsBack;
    final String key = Entry.dayKeyFor(cursor);

    try {
      final List<Entry> rows = await _db.getEntriesForDay(
        key,
        fromYear: year - yearsBack,
        toYear: year,
      );
      final List<Attachment> attachmentRows = await _db.getAttachmentsForDay(
        key,
        fromYear: year - yearsBack,
        toYear: year,
      );
      if (token != _loadToken || _disposed) {
        return;
      }
      _cursor = cursor;
      _entryYear = year;
      _shownYearsBack = yearsBack;
      _entries = <int, Entry>{for (final Entry entry in rows) entry.year: entry};
      _attachments = _groupByYear(attachmentRows);
      _followingToday = key == Entry.dayKeyFor(_clock());
      _saveStatus = SaveStatus.idle;
      _errorMessage = null;
      _isReady = true;
      _notify();
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al cargar las entradas: $error\n$stackTrace');
      if (token != _loadToken || _disposed) {
        return;
      }
      if (_isReady) {
        // Se sigue viendo el día anterior: la navegación parte de él, no del
        // día que falló.
        _targetCursor = _cursor;
      }
      _errorMessage = 'No se pudo abrir el diario.';
      _notify();
    }
  }

  // ---------------------------------------------------------------------------
  // Medianoche: fin del plazo para editar
  // ---------------------------------------------------------------------------

  void _scheduleMidnightTick() {
    _midnightTimer?.cancel();
    if (_disposed) {
      return;
    }
    final DateTime now = _clock();
    final DateTime nextMidnight = DateTime(now.year, now.month, now.day + 1);
    _midnightTimer = Timer(
      nextMidnight.difference(now) + _midnightMargin,
      () => unawaited(_onMidnight()),
    );
  }

  Future<void> _onMidnight() async {
    if (_disposed) {
      return;
    }
    // Lo que se escribió antes de las 00:00 se guarda; después la tarjeta pasa
    // a ser de solo lectura al notificar.
    await flushPendingSave();
    _scheduleMidnightTick();
    if (_isReady && _clock().year != _entryYear) {
      // Cambio de año con la app abierta: se recargan las tarjetas con el año nuevo.
      unawaited(_showDay(_targetCursor));
    }
    _notify();
  }

  // ---------------------------------------------------------------------------
  // Guardado
  // ---------------------------------------------------------------------------

  /// Se llama cada vez que el usuario cambia el texto del año actual.
  /// Guarda automáticamente cuando deja de escribir unos instantes.
  void onContentChanged(String text) {
    if (!canWriteCurrentYear) {
      return;
    }
    // Se anotan el día y el año ahora, no al guardar, para que el texto vaya
    // siempre a la entrada correcta aunque el usuario cambie de día enseguida.
    _pendingText = text;
    _pendingDayKey = dayKey;
    _pendingYear = _entryYear;

    _autosaveTimer?.cancel();
    _autosaveTimer = Timer(_autosaveDelay, () {
      unawaited(flushPendingSave());
    });

    if (_saveStatus != SaveStatus.unsaved) {
      _saveStatus = SaveStatus.unsaved;
      _notify();
    }
  }

  /// Guarda ahora mismo el texto indicado (botón "Guardar").
  Future<void> saveNow(String text) {
    if (!canWriteCurrentYear) {
      return Future<void>.value();
    }
    _pendingText = text;
    _pendingDayKey = dayKey;
    _pendingYear = _entryYear;
    return flushPendingSave();
  }

  /// Escribe en la base de datos lo que esté pendiente. Las llamadas se
  /// ejecutan una detrás de otra para que nunca se pisen entre sí.
  Future<void> flushPendingSave() {
    _autosaveTimer?.cancel();
    _autosaveTimer = null;
    // catchError evita que un fallo inesperado deje la cola rota para siempre.
    _saveQueue =
        _saveQueue.catchError((Object _) {}).then((_) => _writePending());
    return _saveQueue;
  }

  Future<void> _writePending() async {
    final String? text = _pendingText;
    final String? key = _pendingDayKey;
    final int? year = _pendingYear;
    if (text == null || key == null || year == null) {
      return;
    }
    _pendingText = null;
    _pendingDayKey = null;
    _pendingYear = null;

    _saveStatus = SaveStatus.saving;
    _notify();

    try {
      final Entry? saved = await _db.saveEntry(
        dayOfYear: key,
        year: year,
        content: text,
      );
      if (key == dayKey && year == _entryYear) {
        final Map<int, Entry> next = Map<int, Entry>.of(_entries);
        if (saved == null) {
          next.remove(year);
        } else {
          next[year] = saved;
        }
        _entries = next;
      }
      _saveStatus =
          _pendingText == null ? SaveStatus.saved : SaveStatus.unsaved;
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al guardar: $error\n$stackTrace');
      // Se conserva el texto para reintentar en el siguiente guardado.
      _pendingText ??= text;
      _pendingDayKey ??= key;
      _pendingYear ??= year;
      _saveStatus = SaveStatus.error;
    }
    _notify();
  }

  // ---------------------------------------------------------------------------
  // Fotos y notas de voz
  // ---------------------------------------------------------------------------

  static Map<int, List<Attachment>> _groupByYear(List<Attachment> rows) {
    final Map<int, List<Attachment>> grouped = <int, List<Attachment>>{};
    for (final Attachment attachment in rows) {
      (grouped[attachment.year] ??= <Attachment>[]).add(attachment);
    }
    return grouped;
  }

  /// Motivo por el que no se puede añadir un adjunto ahora mismo, o null si se puede.
  ///
  /// Se aplican las mismas reglas que al texto: solo el propio día, hasta las
  /// 23:59. [dayKey] y [year] son los del día en el que se empezó a adjuntar.
  String? _attachmentBlocker(AttachmentType type, String dayKey, int year) {
    if (!canWriteCurrentYear || dayKey != this.dayKey || year != _entryYear) {
      return 'Este día ya terminó (23:59): no se pueden añadir más archivos.';
    }
    if (attachmentCount(type) >= attachmentLimit(type)) {
      return type == AttachmentType.image
          ? 'Ya tienes ${AttachmentLimits.maxImagesPerDay} fotos en este día.'
          : 'Ya tienes ${AttachmentLimits.maxVoiceNotesPerDay} notas de voz en '
              'este día.';
    }
    return null;
  }

  /// Añade una foto: la copia al almacenamiento de la app y la registra.
  /// Devuelve un mensaje de error o null si todo ha ido bien.
  Future<String?> addImage({
    required String sourcePath,
    required String dayKey,
    required int year,
  }) async {
    final String? blocker =
        _attachmentBlocker(AttachmentType.image, dayKey, year);
    if (blocker != null) {
      return blocker;
    }

    final String relativePath = _files.newRelativePath(
      dayKey: dayKey,
      year: year,
      extension: 'jpg',
    );
    try {
      await _files.copyInto(relativePath, sourcePath);
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al copiar la foto: $error\n$stackTrace');
      await _files.delete(relativePath);
      return 'No se pudo guardar la foto.';
    }
    return _registerAttachment(
      type: AttachmentType.image,
      relativePath: relativePath,
      dayKey: dayKey,
      year: year,
    );
  }

  /// Registra una nota de voz que ya está grabada en [relativePath].
  /// Si no se puede añadir, borra el archivo. Devuelve un error o null.
  Future<String?> addVoiceNote({
    required String relativePath,
    required int durationMs,
    required String dayKey,
    required int year,
  }) async {
    final String? blocker =
        _attachmentBlocker(AttachmentType.audio, dayKey, year);
    if (blocker != null) {
      await _files.delete(relativePath);
      return blocker;
    }
    return _registerAttachment(
      type: AttachmentType.audio,
      relativePath: relativePath,
      dayKey: dayKey,
      year: year,
      durationMs: durationMs,
    );
  }

  Future<String?> _registerAttachment({
    required AttachmentType type,
    required String relativePath,
    required String dayKey,
    required int year,
    int? durationMs,
  }) async {
    try {
      final Attachment saved = await _db.insertAttachment(
        Attachment(
          dayOfYear: dayKey,
          year: year,
          type: type,
          relativePath: relativePath,
          durationMs: durationMs,
          createdAt: _clock(),
        ),
      );
      if (dayKey == this.dayKey) {
        final Map<int, List<Attachment>> next =
            Map<int, List<Attachment>>.of(_attachments);
        next[year] = <Attachment>[...?next[year], saved];
        _attachments = next;
        _notify();
      }
      return null;
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al guardar el adjunto: $error\n$stackTrace');
      await _files.delete(relativePath);
      return 'No se pudo guardar el archivo.';
    }
  }

  /// Borra un adjunto. Solo se puede mientras el día sea editable (hoy, hasta
  /// las 23:59). Devuelve un mensaje de error o null.
  Future<String?> deleteAttachment(Attachment attachment) async {
    final int? id = attachment.id;
    if (id == null) {
      return null;
    }
    if (!canWriteCurrentYear ||
        attachment.year != _entryYear ||
        attachment.dayOfYear != dayKey) {
      return 'Este día ya terminó (23:59): ya no se puede borrar.';
    }

    try {
      await _db.deleteAttachment(id);
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al borrar el adjunto: $error\n$stackTrace');
      return 'No se pudo borrar el archivo.';
    }
    await _files.delete(attachment.relativePath);

    final Map<int, List<Attachment>> next =
        Map<int, List<Attachment>>.of(_attachments);
    next[attachment.year] = <Attachment>[
      for (final Attachment item in next[attachment.year] ?? <Attachment>[])
        if (item.id != id) item,
    ];
    _attachments = next;
    _notify();
    return null;
  }

  void _notify() {
    if (!_disposed) {
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _autosaveTimer?.cancel();
    _midnightTimer?.cancel();
    super.dispose();
  }
}
