import 'dart:math' as math;

import '../models/entry_model.dart';

/// Convierte [text] a minúsculas y sin tildes para comparar al buscar
/// ("Canción" y "cancion" coinciden). La "ñ" se respeta: "año" no es "ano".
///
/// El resultado tiene exactamente la misma longitud que [text], así que una
/// posición encontrada en el texto normalizado vale también en el original.
String normalizeForSearch(String text) {
  final StringBuffer buffer = StringBuffer();
  for (final int unit in text.codeUnits) {
    final String? folded = _fold[unit];
    if (folded != null) {
      buffer.write(folded);
      continue;
    }
    final String lower = String.fromCharCode(unit).toLowerCase();
    // Unas pocas letras ocupan más al pasar a minúscula: se dejan como están
    // para no desplazar las posiciones.
    buffer.write(lower.length == 1 ? lower : String.fromCharCode(unit));
  }
  return buffer.toString();
}

const String _accented = 'áàäâãéèëêíìïîóòöôõúùüûçÁÀÄÂÃÉÈËÊÍÌÏÎÓÒÖÔÕÚÙÜÛÇ';
const String _plain = 'aaaaaeeeeiiiiooooouuuucaaaaaeeeeiiiiooooouuuuc';

final Map<int, String> _fold = <int, String>{
  for (int i = 0; i < _accented.length; i++) _accented.codeUnitAt(i): _plain[i],
  // La "Ñ" mayúscula pasa a "ñ" para que la búsqueda no distinga mayúsculas.
  'Ñ'.codeUnitAt(0): 'ñ',
};

/// Una entrada del diario que contiene lo buscado.
class SearchHit {
  const SearchHit({
    required this.entry,
    required this.date,
    required this.matchStart,
    required this.matchLength,
  });

  final Entry entry;

  /// Día completo de la entrada (con su año).
  final DateTime date;

  /// Posición en `entry.content` de la primera palabra encontrada.
  final int matchStart;
  final int matchLength;
}

/// Resultado de una búsqueda: las coincidencias que se muestran y cuántas hay
/// en total.
class SearchResults {
  const SearchResults({required this.hits, required this.total});

  static const SearchResults empty = SearchResults(hits: <SearchHit>[], total: 0);

  final List<SearchHit> hits;
  final int total;
}

class _Indexed {
  const _Indexed(this.entry, this.date, this.normalized);

  final Entry entry;
  final DateTime date;
  final String normalized;
}

/// Entradas del diario preparadas para buscar rápido: el texto se normaliza una
/// sola vez, no en cada letra que se escribe.
class SearchIndex {
  SearchIndex(List<Entry> entries) : _items = _build(entries);

  /// Mínimo de letras para empezar a buscar.
  static const int minQueryLength = 2;

  final List<_Indexed> _items;

  static List<_Indexed> _build(List<Entry> entries) {
    final List<_Indexed> items = <_Indexed>[];
    for (final Entry entry in entries) {
      if (entry.isBlank || entry.dayOfYear.length != 5) {
        continue;
      }
      final int? month = int.tryParse(entry.dayOfYear.substring(0, 2));
      final int? day = int.tryParse(entry.dayOfYear.substring(3, 5));
      if (month == null || day == null) {
        continue;
      }
      final DateTime date = DateTime(entry.year, month, day);
      if (date.month != month) {
        continue;
      }
      items.add(_Indexed(entry, date, normalizeForSearch(entry.content)));
    }
    // Lo más reciente primero.
    items.sort((_Indexed a, _Indexed b) => b.date.compareTo(a.date));
    return items;
  }

  /// Número de entradas con texto en las que se puede buscar.
  int get length => _items.length;

  /// Busca las entradas que contienen todas las palabras de [query] (sin
  /// importar mayúsculas ni tildes). Devuelve como mucho [limit] coincidencias.
  SearchResults search(String query, {int limit = 200}) {
    final List<String> words = normalizeForSearch(query.trim())
        .split(RegExp(r'\s+'))
        .where((String word) => word.isNotEmpty)
        .toList();
    if (words.isEmpty || query.trim().length < minQueryLength) {
      return SearchResults.empty;
    }

    final List<SearchHit> hits = <SearchHit>[];
    int total = 0;
    for (final _Indexed item in _items) {
      int firstWordAt = -1;
      bool all = true;
      for (final String word in words) {
        final int at = item.normalized.indexOf(word);
        if (at < 0) {
          all = false;
          break;
        }
        if (firstWordAt < 0) {
          firstWordAt = at;
        }
      }
      if (!all) {
        continue;
      }
      total++;
      if (hits.length < limit) {
        hits.add(
          SearchHit(
            entry: item.entry,
            date: item.date,
            matchStart: firstWordAt,
            matchLength: words.first.length,
          ),
        );
      }
    }
    return SearchResults(hits: hits, total: total);
  }
}

/// Fragmento de texto alrededor de una coincidencia, dividido en tres partes
/// para poder resaltar la del medio.
class Snippet {
  const Snippet({required this.before, required this.match, required this.after});

  final String before;
  final String match;
  final String after;
}

/// Recorta [content] a unos [context] caracteres a cada lado de la
/// coincidencia, con los saltos de línea convertidos en espacios.
Snippet buildSnippet(
  String content,
  int start,
  int length, {
  int context = 45,
}) {
  final int safeStart = math.min(math.max(start, 0), content.length);
  final int safeEnd = math.min(safeStart + math.max(length, 0), content.length);

  int from = math.max(0, safeStart - context);
  int to = math.min(content.length, safeEnd + context);
  // No cortar un carácter formado por dos unidades (emojis).
  if (from > 0 && _isLowSurrogate(content.codeUnitAt(from))) {
    from++;
  }
  if (to < content.length && _isHighSurrogate(content.codeUnitAt(to - 1))) {
    to--;
  }

  String clean(String text) => text.replaceAll(RegExp(r'\s+'), ' ');

  return Snippet(
    before: '${from > 0 ? '…' : ''}${clean(content.substring(from, safeStart))}',
    match: clean(content.substring(safeStart, safeEnd)),
    after: '${clean(content.substring(safeEnd, to))}${to < content.length ? '…' : ''}',
  );
}

bool _isHighSurrogate(int unit) => unit >= 0xD800 && unit <= 0xDBFF;
bool _isLowSurrogate(int unit) => unit >= 0xDC00 && unit <= 0xDFFF;
