import 'dart:math';

/// Baraja de frases que se reparten al azar sin repetir ninguna hasta que se
/// han visto todas, y sin que la última de una vuelta sea la primera de la
/// siguiente. Así el dado no devuelve la misma idea dos veces seguidas.
class PromptDeck {
  PromptDeck(List<String> prompts, {Random? random})
      : _all = List<String>.unmodifiable(prompts),
        _random = random ?? Random();

  final List<String> _all;
  final Random _random;

  /// Frases que aún no han salido en la vuelta actual.
  final List<String> _bag = <String>[];

  String? _last;

  /// Cuántas frases tiene la baraja.
  int get length => _all.length;

  /// La siguiente frase, o un texto vacío si la baraja no tiene ninguna.
  String next() {
    if (_all.isEmpty) {
      return '';
    }
    if (_bag.isEmpty) {
      _bag
        ..addAll(_all)
        ..shuffle(_random);
      // La frase que va a salir ahora es la última de la lista: si coincide
      // con la anterior, se cambia de sitio con otra.
      if (_bag.length > 1 && _bag.last == _last) {
        final String repeated = _bag.removeLast();
        _bag.insert(0, repeated);
      }
    }
    final String value = _bag.removeLast();
    _last = value;
    return value;
  }
}
