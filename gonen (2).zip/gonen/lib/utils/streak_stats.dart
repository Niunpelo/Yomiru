/// Rachas de escritura: cuántos días seguidos se ha escrito en el diario.
class StreakStats {
  const StreakStats({
    required this.current,
    required this.best,
    required this.totalDays,
  });

  /// Días seguidos hasta hoy. Si hoy todavía no se ha escrito pero ayer sí, la
  /// racha sigue viva (aún queda el día de hoy para mantenerla).
  final int current;

  /// La racha más larga de todos los tiempos.
  final int best;

  /// Cuántos días distintos tienen algo escrito (o una foto o nota de voz).
  final int totalDays;

  static const StreakStats empty = StreakStats(current: 0, best: 0, totalDays: 0);

  /// Calcula las rachas de [days] (solo importa la fecha, no la hora) viendo el
  /// calendario desde [today].
  static StreakStats compute(Set<DateTime> days, DateTime today) {
    if (days.isEmpty) {
      return empty;
    }

    // Cada día pasa a ser un número entero (días desde 1970): dos días
    // seguidos siempre se llevan 1, aunque haya cambio de hora entre ellos.
    final Set<int> numbers = <int>{for (final DateTime day in days) _number(day)};
    final List<int> sorted = numbers.toList()..sort();

    int best = 1;
    int run = 1;
    for (int i = 1; i < sorted.length; i++) {
      run = sorted[i] == sorted[i - 1] + 1 ? run + 1 : 1;
      if (run > best) {
        best = run;
      }
    }

    final int todayNumber = _number(today);
    int cursor;
    if (numbers.contains(todayNumber)) {
      cursor = todayNumber;
    } else if (numbers.contains(todayNumber - 1)) {
      cursor = todayNumber - 1;
    } else {
      return StreakStats(current: 0, best: best, totalDays: numbers.length);
    }
    int current = 0;
    while (numbers.contains(cursor)) {
      current++;
      cursor--;
    }

    return StreakStats(current: current, best: best, totalDays: numbers.length);
  }

  static int _number(DateTime date) =>
      DateTime.utc(date.year, date.month, date.day).millisecondsSinceEpoch ~/
      Duration.millisecondsPerDay;
}
