import 'package:intl/intl.dart';

import '../l10n/tr.dart';

/// Pone en mayúscula la primera letra.
String capitalize(String text) {
  if (text.isEmpty) {
    return text;
  }
  return text[0].toUpperCase() + text.substring(1);
}

/// Nombre del mes en el idioma de la app, por ejemplo "Marzo" o "March".
String monthLabel(DateTime date) {
  return capitalize(DateFormat.MMMM(AppLocale.current.code).format(date));
}

/// Texto del día y el mes, por ejemplo "15 de Marzo" o "March 15".
String dayMonthLabel(DateTime date) {
  final String month = monthLabel(date);
  if (AppLocale.isEnglish) {
    return '$month ${date.day}';
  }
  return '${date.day} de $month';
}

/// Nombre del día de la semana, por ejemplo "Domingo" o "Sunday".
String weekdayLabel(DateTime date) {
  return capitalize(DateFormat.EEEE(AppLocale.current.code).format(date));
}

/// Fecha completa, por ejemplo "Viernes, 15 de Marzo de 2027" o
/// "Friday, March 15, 2027".
String fullDateLabel(DateTime date) {
  if (AppLocale.isEnglish) {
    return '${weekdayLabel(date)}, ${dayMonthLabel(date)}, ${date.year}';
  }
  return '${weekdayLabel(date)}, ${dayMonthLabel(date)} de ${date.year}';
}

/// Mes y año, por ejemplo "Marzo 2027" o "March 2027" (cabecera del calendario).
String monthYearLabel(DateTime date) {
  return capitalize(DateFormat.yMMMM(AppLocale.current.code).format(date));
}

/// Posición del día en su año (el 1 de enero es el 1).
int dayOfYear(DateTime date) {
  final DateTime day = DateTime.utc(date.year, date.month, date.day);
  return day.difference(DateTime.utc(date.year, 1, 1)).inDays + 1;
}

/// Cuántos días tiene [year]: 366 si es bisiesto y 365 si no.
int daysInYear(int year) {
  final bool leap = (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
  return leap ? 366 : 365;
}

/// Tiempo que falta para abrir una cápsula, por ejemplo "Faltan 12 días".
String remainingDaysLabel(int days) {
  if (days <= 0) {
    return tr('Ya se puede abrir', 'Ready to open');
  }
  if (days == 1) {
    return tr('Se abre mañana', 'Opens tomorrow');
  }
  return tr('Faltan $days días', '$days days to go');
}
