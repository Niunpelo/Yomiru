import 'package:intl/intl.dart';

/// Pone en mayúscula la primera letra.
String capitalize(String text) {
  if (text.isEmpty) {
    return text;
  }
  return text[0].toUpperCase() + text.substring(1);
}

/// Texto del día y el mes, por ejemplo "15 de Marzo".
String dayMonthLabel(DateTime date) {
  final String month = DateFormat.MMMM('es').format(date);
  return '${date.day} de ${capitalize(month)}';
}

/// Nombre del día de la semana, por ejemplo "Domingo".
String weekdayLabel(DateTime date) {
  return capitalize(DateFormat.EEEE('es').format(date));
}

/// Fecha completa, por ejemplo "Viernes, 15 de Marzo de 2027".
String fullDateLabel(DateTime date) {
  return '${weekdayLabel(date)}, ${dayMonthLabel(date)} de ${date.year}';
}

/// Tiempo que falta para abrir una cápsula, por ejemplo "Faltan 12 días".
String remainingDaysLabel(int days) {
  if (days <= 0) {
    return 'Ya se puede abrir';
  }
  if (days == 1) {
    return 'Se abre mañana';
  }
  return 'Faltan $days días';
}
