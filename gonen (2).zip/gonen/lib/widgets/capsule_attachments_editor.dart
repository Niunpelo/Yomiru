import 'dart:async';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../models/attachment_limits.dart';
import '../models/attachment_model.dart';
import '../providers/premium_provider.dart';
import '../screens/premium_screen.dart';
import '../services/attachment_service.dart';
import 'attachment_action_bar.dart';
import 'attachments_section.dart';
import 'voice_recorder_sheet.dart';

/// Zona de la pantalla "Nueva cápsula" donde se añaden fotos y notas de voz.
///
/// Las fotos y notas se guardan ya en el almacenamiento de la app, pero
/// [attachments] solo vive en la pantalla hasta que se sella la cápsula. Sin
/// Gonen Premium los botones llevan un candado y abren la pantalla de compra.
class CapsuleAttachmentsEditor extends StatelessWidget {
  const CapsuleAttachmentsEditor({
    super.key,
    required this.attachments,
    required this.enabled,
    required this.onAdded,
    required this.onRemoved,
  });

  /// Lo que ya se ha añadido a la cápsula que se está escribiendo.
  final List<Attachment> attachments;

  /// Falso mientras se sella la cápsula: no se puede añadir ni quitar nada.
  final bool enabled;

  final ValueChanged<Attachment> onAdded;
  final Future<void> Function(Attachment attachment) onRemoved;

  int _count(AttachmentType type) =>
      attachments.where((Attachment item) => item.type == type).length;

  void _showMessage(ScaffoldMessengerState messenger, String text) {
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  /// Comprueba premium y límites. Devuelve false (avisando) si no se puede
  /// añadir ahora mismo.
  Future<bool> _canAdd(BuildContext context, AttachmentType type) async {
    if (!enabled) {
      return false;
    }
    final PremiumProvider premium = context.read<PremiumProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);

    if (!premium.isPremium) {
      await Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (BuildContext context) => const PremiumScreen(),
        ),
      );
      return false;
    }

    final bool isImage = type == AttachmentType.image;
    final int limit = isImage
        ? AttachmentLimits.maxImagesPerDay
        : AttachmentLimits.maxVoiceNotesPerDay;
    if (_count(type) >= limit) {
      _showMessage(
        messenger,
        isImage
            ? 'Ya tienes $limit fotos en esta cápsula.'
            : 'Ya tienes $limit notas de voz en esta cápsula.',
      );
      return false;
    }
    return true;
  }

  Future<void> _pickImage(BuildContext context, ImageSource source) async {
    if (!await _canAdd(context, AttachmentType.image)) {
      return;
    }
    if (!context.mounted) {
      return;
    }
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);

    XFile? picked;
    try {
      picked = await pickPhoto(source);
    } catch (error) {
      debugPrint('Gonen: no se pudo abrir la cámara o la galería: $error');
      _showMessage(
        messenger,
        source == ImageSource.camera
            ? 'No se pudo abrir la cámara.'
            : 'No se pudo abrir la galería.',
      );
      return;
    }
    if (picked == null) {
      return;
    }

    final AttachmentService files = AttachmentService.instance;
    final String relativePath = files.newCapsuleRelativePath(extension: 'jpg');
    try {
      await files.copyInto(relativePath, picked.path);
    } catch (error) {
      debugPrint('Gonen: no se pudo guardar la foto de la cápsula: $error');
      await files.delete(relativePath);
      _showMessage(messenger, 'No se pudo guardar la foto.');
      return;
    }

    onAdded(
      Attachment.forCapsule(
        type: AttachmentType.image,
        relativePath: relativePath,
        createdAt: DateTime.now(),
      ),
    );
  }

  Future<void> _recordVoice(BuildContext context) async {
    if (!await _canAdd(context, AttachmentType.audio)) {
      return;
    }
    if (!context.mounted) {
      return;
    }

    final RecordedVoice? voice = await showModalBottomSheet<RecordedVoice>(
      context: context,
      isDismissible: false,
      enableDrag: false,
      builder: (BuildContext sheetContext) =>
          const VoiceRecorderSheet.forCapsule(),
    );
    if (voice == null) {
      return;
    }

    onAdded(
      Attachment.forCapsule(
        type: AttachmentType.audio,
        relativePath: voice.relativePath,
        durationMs: voice.durationMs,
        createdAt: DateTime.now(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool premium = context
        .select<PremiumProvider, bool>((PremiumProvider p) => p.isPremium);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        AttachmentButtons(
          premium: premium,
          onCamera: () => unawaited(_pickImage(context, ImageSource.camera)),
          onGallery: () => unawaited(_pickImage(context, ImageSource.gallery)),
          onVoice: () => unawaited(_recordVoice(context)),
        ),
        if (attachments.isNotEmpty) ...<Widget>[
          const SizedBox(height: 12),
          AttachmentList(
            attachments: attachments,
            onDelete: enabled ? onRemoved : null,
          ),
        ],
      ],
    );
  }
}
