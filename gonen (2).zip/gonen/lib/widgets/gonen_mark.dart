import 'package:flutter/material.dart';

/// El logo de Gonen: cinco anillos de árbol, uno por año, que se difuminan
/// hacia fuera. Es el mismo dibujo que el icono de la app.
///
/// Se pinta sobre un fondo [background] (bermellón por defecto del tema) con
/// los anillos en [foreground]. Las medidas son las del logo de 512 px.
class GonenMark extends StatelessWidget {
  const GonenMark({
    super.key,
    this.size = 52,
    this.background,
    this.foreground,
    this.radius,
  });

  final double size;

  /// Color del fondo; por defecto, el color de acento del tema.
  final Color? background;

  /// Color de los anillos; por defecto, el color de texto sobre el acento.
  final Color? foreground;

  /// Radio de las esquinas; por defecto, un 22 % del lado (como el icono).
  final double? radius;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return ExcludeSemantics(
      child: SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: GonenMarkPainter(
            background: background ?? scheme.primary,
            foreground: foreground ?? scheme.onPrimary,
            radiusFraction: radius == null ? 0.22 : radius! / size,
          ),
        ),
      ),
    );
  }
}

/// Dibuja el logo en un cuadrado del tamaño que se le dé.
class GonenMarkPainter extends CustomPainter {
  const GonenMarkPainter({
    required this.background,
    required this.foreground,
    this.radiusFraction = 0.22,
  });

  final Color background;
  final Color foreground;

  /// Radio de las esquinas como fracción del lado.
  final double radiusFraction;

  /// Centro del punto y los cuatro anillos, medidos sobre 512.
  static const double _dot = 30;
  static const List<double> _ringRadii = <double>[64, 98, 130, 160];
  static const List<double> _ringOpacity = <double>[0.9, 0.7, 0.5, 0.35];
  static const double _ringWidth = 14;

  @override
  void paint(Canvas canvas, Size size) {
    final double side = size.shortestSide;
    final double unit = side / 512;
    final Offset center = Offset(size.width / 2, size.height / 2);

    final RRect box = RRect.fromRectAndRadius(
      Offset.zero & size,
      Radius.circular(side * radiusFraction),
    );
    canvas.drawRRect(box, Paint()..color = background);

    canvas.drawCircle(center, _dot * unit, Paint()..color = foreground);
    for (int i = 0; i < _ringRadii.length; i++) {
      final Paint ring = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = _ringWidth * unit
        ..color = foreground.withValues(alpha: _ringOpacity[i]);
      canvas.drawCircle(center, _ringRadii[i] * unit, ring);
    }
  }

  @override
  bool shouldRepaint(GonenMarkPainter oldDelegate) =>
      oldDelegate.background != background ||
      oldDelegate.foreground != foreground ||
      oldDelegate.radiusFraction != radiusFraction;
}
