import 'package:flutter/material.dart';

import '../l10n/tr.dart';
import '../utils/date_labels.dart';

/// Pregunta si se sella la cápsula. Devuelve true solo si el usuario confirma.
///
/// Con [forOther] avisa de que después se elegirá cómo enviar el archivo.
Future<bool> confirmSealCapsule(
  BuildContext context,
  DateTime openDate, {
  bool forOther = false,
}) {
  return _confirm(
    context,
    title: forOther
        ? context.tr('¿Sellar y enviar la cápsula?', 'Seal and send the capsule?')
        : context.tr('¿Sellar la cápsula?', 'Seal the capsule?'),
    message: forOther
        ? context.tr(
            'Nadie podrá leerla hasta el ${fullDateLabel(openDate)}, tampoco tú. '
                'Después elegirás cómo enviar el archivo (WhatsApp, correo...). '
                'Te quedas una copia, que se abrirá ese mismo día.',
            'No one will be able to read it until ${fullDateLabel(openDate)}, '
                'not even you. Then you will choose how to send the file '
                '(WhatsApp, email...). You keep a copy, which will open on '
                'that same day.',
          )
        : context.tr(
            'No podrás leerla hasta el ${fullDateLabel(openDate)}. '
                'Hasta entonces su contenido quedará oculto.',
            'You will not be able to read it until ${fullDateLabel(openDate)}. '
                'Until then its content will stay hidden.',
          ),
    cancelLabel: context.tr('Revisar', 'Review'),
    confirmLabel: forOther
        ? context.tr('Sellar y enviar', 'Seal and send')
        : context.tr('Sellar', 'Seal'),
  );
}

/// Pregunta si se borra la cápsula. Devuelve true solo si el usuario confirma.
Future<bool> confirmDeleteCapsule(BuildContext context) {
  return _confirm(
    context,
    title: context.tr('¿Borrar la cápsula?', 'Delete the capsule?'),
    message: context.tr(
      'Se borrará para siempre, con su mensaje y sus fotos y notas de '
          'voz. Esta acción no se puede deshacer.',
      'It will be deleted forever, with its message and its photos and voice '
          'notes. This cannot be undone.',
    ),
    cancelLabel: context.tr('Cancelar', 'Cancel'),
    confirmLabel: context.tr('Borrar', 'Delete'),
    destructive: true,
  );
}

/// Pregunta si se borra una foto o una nota de voz del día.
Future<bool> confirmDeleteAttachment(BuildContext context) {
  return _confirm(
    context,
    title: context.tr('¿Borrar este archivo?', 'Delete this file?'),
    message: context.tr(
      'Se borrará para siempre. Esta acción no se puede deshacer.',
      'It will be deleted forever. This cannot be undone.',
    ),
    cancelLabel: context.tr('Cancelar', 'Cancel'),
    confirmLabel: context.tr('Borrar', 'Delete'),
    destructive: true,
  );
}

/// Pregunta si se descarta lo escrito al salir sin sellar.
Future<bool> confirmDiscardCapsule(BuildContext context) {
  return _confirm(
    context,
    title: context.tr('¿Descartar la cápsula?', 'Discard the capsule?'),
    message: context.tr(
      'Lo que has escrito se perderá.',
      'What you have written will be lost.',
    ),
    cancelLabel: context.tr('Seguir escribiendo', 'Keep writing'),
    confirmLabel: context.tr('Descartar', 'Discard'),
    destructive: true,
  );
}

/// Pregunta si se restaura una copia de seguridad.
Future<bool> confirmRestoreBackup(BuildContext context) {
  return _confirm(
    context,
    title: context.tr('¿Restaurar una copia?', 'Restore a backup?'),
    message: context.tr(
      'Se añadirá a este móvil lo que falte de la copia. No se borra ni '
          'se cambia nada de lo que ya tienes: si un día ya tiene texto aquí, '
          'se queda como está.',
      'Whatever is missing from the backup will be added to this phone. '
          'Nothing you already have is deleted or changed: if a day already '
          'has text here, it stays as it is.',
    ),
    cancelLabel: context.tr('Cancelar', 'Cancel'),
    confirmLabel: context.tr('Elegir copia', 'Choose backup'),
  );
}

Future<bool> _confirm(
  BuildContext context, {
  required String title,
  required String message,
  required String cancelLabel,
  required String confirmLabel,
  bool destructive = false,
}) async {
  final bool? result = await showDialog<bool>(
    context: context,
    builder: (BuildContext dialogContext) {
      final ColorScheme scheme = Theme.of(dialogContext).colorScheme;
      return AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(cancelLabel),
          ),
          FilledButton(
            style: destructive
                ? FilledButton.styleFrom(
                    backgroundColor: scheme.error,
                    foregroundColor: scheme.onError,
                  )
                : null,
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(confirmLabel),
          ),
        ],
      );
    },
  );
  return result ?? false;
}
