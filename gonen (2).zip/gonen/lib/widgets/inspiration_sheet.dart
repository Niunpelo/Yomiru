import 'package:flutter/material.dart';

import '../data/writing_prompts.dart';
import '../l10n/tr.dart';
import '../theme/app_theme.dart';
import '../utils/prompt_deck.dart';

/// Hoja inferior con una idea para empezar a escribir (el dado).
///
/// * «Otra idea» tira el dado de nuevo.
/// * «Escribir sobre esto» cierra la hoja devolviendo la frase, para que la
///   tarjeta del día la ponga en el texto y se pueda contestar debajo.
/// * «Cerrar» (o deslizar la hoja) cierra sin devolver nada.
class InspirationSheet extends StatefulWidget {
  const InspirationSheet({super.key, this.deck});

  /// Baraja de la que salen las frases. Solo se cambia en las pruebas.
  final PromptDeck? deck;

  @override
  State<InspirationSheet> createState() => _InspirationSheetState();
}

class _InspirationSheetState extends State<InspirationSheet> {
  late final PromptDeck _deck = widget.deck ?? sharedPromptDeck();
  late String _prompt = _deck.next();

  void _roll() => setState(() => _prompt = _deck.next());

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    // Con scroll por si la pantalla es baja o la letra muy grande.
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(Icons.casino_outlined, color: scheme.primary, size: 20),
                const SizedBox(width: 8),
                Text(
                  context.tr('UNA IDEA PARA ESCRIBIR', 'AN IDEA TO WRITE ABOUT'),
                  style: theme.textTheme.labelMedium?.copyWith(
                    color: scheme.primary,
                    letterSpacing: 1.6,
                  ),
                ),
              ],
            ),
            ConstrainedBox(
              constraints: const BoxConstraints(minHeight: 100),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 250),
                    child: Text(
                      _prompt,
                      key: ValueKey<String>(_prompt),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: context.appStyle.bodyFamily,
                        fontSize: 22,
                        height: 1.5,
                        color: scheme.onSurface,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            FilledButton.icon(
              onPressed: () => Navigator.of(context).pop(_prompt),
              icon: const Icon(Icons.edit_outlined),
              label: Text(context.tr('Escribir sobre esto', 'Write about this')),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _roll,
              icon: const Icon(Icons.casino_outlined),
              label: Text(context.tr('Otra idea', 'Another idea')),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(context.tr('Cerrar', 'Close')),
            ),
          ],
        ),
      ),
    );
  }
}
