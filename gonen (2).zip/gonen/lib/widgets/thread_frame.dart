import 'package:flutter/material.dart';

/// Marco de una tarjeta del estilo «Hilo rojo»: deja un margen a la izquierda
/// por donde baja el hilo y dibuja en él el nudo de la tarjeta.
///
/// El hilo atraviesa también el hueco de debajo ([gap]), así que las tarjetas
/// de la lista no llevan separador: el espacio lo pone este widget.
class ThreadFrame extends StatelessWidget {
  const ThreadFrame({
    super.key,
    required this.child,
    required this.isFirst,
    required this.isLast,
    required this.isCurrent,
    this.gap = 14,
  });

  /// Ancho del margen del hilo.
  static const double gutter = 30;

  final Widget child;

  /// Es la primera tarjeta: el hilo empieza en su nudo.
  final bool isFirst;

  /// Es la última tarjeta: el hilo termina en su nudo.
  final bool isLast;

  /// Es la tarjeta del año actual: su nudo es mayor y está relleno.
  final bool isCurrent;

  /// Espacio entre esta tarjeta y la siguiente.
  final double gap;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return Stack(
      children: <Widget>[
        Positioned(
          left: 0,
          top: 0,
          bottom: 0,
          width: gutter,
          child: ExcludeSemantics(
            child: CustomPaint(
              painter: ThreadPainter(
                thread: scheme.primary,
                paper: scheme.surface,
                isFirst: isFirst,
                isLast: isLast,
                isCurrent: isCurrent,
              ),
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.only(left: gutter, bottom: isLast ? 0 : gap),
          child: child,
        ),
      ],
    );
  }
}

/// Dibuja el trozo de hilo y el nudo de una tarjeta.
class ThreadPainter extends CustomPainter {
  const ThreadPainter({
    required this.thread,
    required this.paper,
    required this.isFirst,
    required this.isLast,
    required this.isCurrent,
  });

  final Color thread;
  final Color paper;
  final bool isFirst;
  final bool isLast;
  final bool isCurrent;

  /// Posición del hilo y del nudo dentro del margen.
  static const double _x = 12;
  static const double _knotY = 26;

  @override
  void paint(Canvas canvas, Size size) {
    final double top = isFirst ? _knotY : 0;
    final double bottom = isLast ? _knotY : size.height;
    canvas.drawLine(
      Offset(_x, top),
      Offset(_x, bottom),
      Paint()
        ..color = thread.withValues(alpha: 0.6)
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round,
    );

    const Offset knot = Offset(_x, _knotY);
    if (isCurrent) {
      canvas.drawCircle(knot, 11, Paint()..color = paper);
      canvas.drawCircle(knot, 7, Paint()..color = thread);
    } else {
      canvas.drawCircle(knot, 8, Paint()..color = paper);
      canvas.drawCircle(
        knot,
        4,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = thread,
      );
    }
  }

  @override
  bool shouldRepaint(ThreadPainter oldDelegate) =>
      oldDelegate.thread != thread ||
      oldDelegate.paper != paper ||
      oldDelegate.isFirst != isFirst ||
      oldDelegate.isLast != isLast ||
      oldDelegate.isCurrent != isCurrent;
}
