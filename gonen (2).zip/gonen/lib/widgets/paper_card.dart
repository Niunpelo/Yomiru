import 'package:flutter/material.dart';

/// Hoja de papel con borde fino sobre la que se escribe o se lee cada año.
class PaperCard extends StatelessWidget {
  const PaperCard({
    super.key,
    required this.child,
    this.emphasized = false,
    this.onTap,
  });

  final Widget child;

  /// Resalta el borde con el color de acento (tarjeta del año actual).
  final bool emphasized;

  /// Si se indica, la tarjeta es pulsable y muestra el efecto de tinta.
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return SizedBox(
      width: double.infinity,
      child: Material(
        color: scheme.surfaceContainerLow,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(6),
          side: BorderSide(
            color: emphasized
                ? scheme.primary.withValues(alpha: 0.55)
                : scheme.outlineVariant,
          ),
        ),
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 14),
            child: child,
          ),
        ),
      ),
    );
  }
}
