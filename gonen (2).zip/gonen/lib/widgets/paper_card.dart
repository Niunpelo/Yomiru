import 'package:flutter/material.dart';

import '../theme/app_style.dart';

/// Hoja de papel con borde fino sobre la que se escribe o se lee cada año.
///
/// En los estilos editoriales las esquinas son rectas y el borde es una línea
/// de tinta. Con [ruled] (solo en esos estilos) la tarjeta se convierte en una
/// sección sin caja, separada de la siguiente por una línea.
class PaperCard extends StatelessWidget {
  const PaperCard({
    super.key,
    required this.child,
    this.emphasized = false,
    this.ruled = false,
    this.onTap,
  });

  final Widget child;

  /// Resalta el borde con el color de acento (tarjeta del año actual).
  final bool emphasized;

  /// En los estilos editoriales, dibuja una sección con una línea debajo en
  /// lugar de una caja. En los demás estilos no cambia nada.
  final bool ruled;

  /// Si se indica, la tarjeta es pulsable y muestra el efecto de tinta.
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final AppStyle style = context.appStyle;

    if (ruled && style.isEditorial) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(0, 14, 0, 18),
        decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: scheme.outlineVariant)),
        ),
        child: child,
      );
    }

    final BorderSide side;
    if (style.isEditorial) {
      side = emphasized
          ? BorderSide(color: scheme.primary, width: 2)
          : BorderSide(color: scheme.outlineVariant);
    } else {
      side = BorderSide(
        color: emphasized
            ? scheme.primary.withValues(alpha: 0.55)
            : scheme.outlineVariant,
      );
    }

    return SizedBox(
      width: double.infinity,
      child: Material(
        color: scheme.surfaceContainerLow,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(style.cornerRadius),
          side: side,
        ),
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 14),
            child: child,
          ),
        ),
      ),
    );
  }
}
