import 'dart:async';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

import '../models/attachment_model.dart';
import '../screens/image_viewer_screen.dart';
import '../services/attachment_service.dart';
import '../utils/duration_label.dart';
import 'capsule_dialogs.dart';

/// Fotos (miniaturas) y notas de voz (reproductor) de un día.
///
/// Si se indica [onDelete], cada archivo muestra un botón para borrarlo; solo
/// se debe indicar mientras el día es editable (hoy, hasta las 23:59).
class AttachmentList extends StatelessWidget {
  const AttachmentList({
    super.key,
    required this.attachments,
    this.onDelete,
  });

  final List<Attachment> attachments;
  final Future<void> Function(Attachment attachment)? onDelete;

  @override
  Widget build(BuildContext context) {
    final List<Attachment> images = attachments
        .where((Attachment item) => item.type == AttachmentType.image)
        .toList();
    final List<Attachment> notes = attachments
        .where((Attachment item) => item.type == AttachmentType.audio)
        .toList();

    if (images.isEmpty && notes.isEmpty) {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        if (images.isNotEmpty)
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              for (int index = 0; index < images.length; index++)
                _ImageThumb(
                  key: ValueKey<String>(images[index].relativePath),
                  images: images,
                  index: index,
                  onDelete: onDelete,
                ),
            ],
          ),
        if (images.isNotEmpty && notes.isNotEmpty) const SizedBox(height: 12),
        for (final Attachment note in notes)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: AudioNoteTile(
              key: ValueKey<String>(note.relativePath),
              attachment: note,
              onDelete: onDelete,
            ),
          ),
      ],
    );
  }
}

class _ImageThumb extends StatelessWidget {
  const _ImageThumb({
    super.key,
    required this.images,
    required this.index,
    this.onDelete,
  });

  final List<Attachment> images;
  final int index;
  final Future<void> Function(Attachment attachment)? onDelete;

  void _openViewer(BuildContext context) {
    final List<File> files = <File>[
      for (final Attachment image in images)
        AttachmentService.instance.fileFor(image.relativePath),
    ];
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) =>
            ImageViewerScreen(files: files, initialIndex: index),
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context) async {
    final Future<void> Function(Attachment attachment)? handler = onDelete;
    if (handler == null) {
      return;
    }
    final bool confirmed = await confirmDeleteAttachment(context);
    if (confirmed) {
      await handler(images[index]);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final File file =
        AttachmentService.instance.fileFor(images[index].relativePath);

    return SizedBox(
      width: 96,
      height: 96,
      child: Stack(
        children: <Widget>[
          Positioned.fill(
            child: Semantics(
              button: true,
              label: 'Foto ${index + 1}',
              child: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: GestureDetector(
                  onTap: () => _openViewer(context),
                  child: ColoredBox(
                    color: scheme.surfaceContainerHighest,
                    child: Image.file(
                      file,
                      fit: BoxFit.cover,
                      cacheWidth: 288,
                      errorBuilder: (
                        BuildContext context,
                        Object error,
                        StackTrace? stackTrace,
                      ) {
                        return Icon(
                          Icons.broken_image_outlined,
                          color: scheme.onSurfaceVariant,
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
          ),
          if (onDelete != null)
            Positioned(
              top: 4,
              right: 4,
              child: Tooltip(
                message: 'Borrar foto',
                child: GestureDetector(
                  onTap: () => unawaited(_confirmDelete(context)),
                  child: Container(
                    width: 28,
                    height: 28,
                    decoration: const BoxDecoration(
                      color: Colors.black54,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.close_rounded,
                      size: 16,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Reproductor de una nota de voz: botón de play/pausa, progreso y duración.
class AudioNoteTile extends StatefulWidget {
  const AudioNoteTile({
    super.key,
    required this.attachment,
    this.onDelete,
  });

  final Attachment attachment;
  final Future<void> Function(Attachment attachment)? onDelete;

  @override
  State<AudioNoteTile> createState() => _AudioNoteTileState();
}

class _AudioNoteTileState extends State<AudioNoteTile> {
  /// Solo suena una nota a la vez.
  static _AudioNoteTileState? _active;

  AudioPlayer? _player;
  final List<StreamSubscription<dynamic>> _subscriptions =
      <StreamSubscription<dynamic>>[];

  PlayerState _state = PlayerState.stopped;
  Duration _position = Duration.zero;
  late Duration _total =
      Duration(milliseconds: widget.attachment.durationMs ?? 0);

  @override
  void dispose() {
    for (final StreamSubscription<dynamic> subscription in _subscriptions) {
      unawaited(subscription.cancel());
    }
    if (identical(_active, this)) {
      _active = null;
    }
    final AudioPlayer? player = _player;
    if (player != null) {
      unawaited(player.dispose());
    }
    super.dispose();
  }

  AudioPlayer _ensurePlayer() {
    final AudioPlayer? existing = _player;
    if (existing != null) {
      return existing;
    }

    final AudioPlayer player = AudioPlayer();
    _subscriptions
      ..add(player.onPlayerStateChanged.listen((PlayerState state) {
        if (mounted) {
          setState(() => _state = state);
        }
      }))
      ..add(player.onPositionChanged.listen((Duration position) {
        if (mounted) {
          setState(() => _position = position);
        }
      }))
      ..add(player.onDurationChanged.listen((Duration duration) {
        if (mounted && duration > Duration.zero) {
          setState(() => _total = duration);
        }
      }))
      ..add(player.onPlayerComplete.listen((_) {
        if (mounted) {
          setState(() {
            _position = Duration.zero;
            _state = PlayerState.stopped;
          });
        }
      }));
    _player = player;
    return player;
  }

  Future<void> _toggle() async {
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    try {
      if (_state == PlayerState.playing) {
        await _player?.pause();
        return;
      }

      final _AudioNoteTileState? other = _active;
      if (other != null && !identical(other, this)) {
        await other._stop();
      }
      _active = this;

      final AudioPlayer player = _ensurePlayer();
      if (_state == PlayerState.paused) {
        await player.resume();
      } else {
        final File file =
            AttachmentService.instance.fileFor(widget.attachment.relativePath);
        await player.play(DeviceFileSource(file.path));
      }
    } catch (error) {
      debugPrint('Gonen: no se pudo reproducir la nota de voz: $error');
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(
          const SnackBar(content: Text('No se pudo reproducir la nota de voz.')),
        );
    }
  }

  Future<void> _stop() async {
    await _player?.stop();
    if (mounted) {
      setState(() => _position = Duration.zero);
    }
  }

  Future<void> _confirmDelete() async {
    final Future<void> Function(Attachment attachment)? handler =
        widget.onDelete;
    if (handler == null) {
      return;
    }
    final bool confirmed = await confirmDeleteAttachment(context);
    if (!confirmed) {
      return;
    }
    await _player?.stop();
    await handler(widget.attachment);
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final bool playing = _state == PlayerState.playing;
    final double progress = _total.inMilliseconds > 0
        ? (_position.inMilliseconds / _total.inMilliseconds)
            .clamp(0.0, 1.0)
            .toDouble()
        : 0.0;

    return Container(
      padding: const EdgeInsets.fromLTRB(8, 6, 8, 6),
      decoration: BoxDecoration(
        color: scheme.surfaceContainer,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Row(
        children: <Widget>[
          IconButton.filledTonal(
            onPressed: () => unawaited(_toggle()),
            tooltip: playing ? 'Pausar' : 'Reproducir',
            icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Nota de voz',
                  style: theme.textTheme.labelMedium?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 6),
                LinearProgressIndicator(value: progress, minHeight: 4),
                const SizedBox(height: 4),
                Text(
                  '${formatDuration(_position)} / ${formatDuration(_total)}',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          if (widget.onDelete != null)
            IconButton(
              onPressed: () => unawaited(_confirmDelete()),
              tooltip: 'Borrar nota de voz',
              icon: const Icon(Icons.delete_outline_rounded),
            ),
        ],
      ),
    );
  }
}
