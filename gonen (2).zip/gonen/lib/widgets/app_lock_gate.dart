import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/settings_provider.dart';
import '../screens/lock_screen.dart';
import '../services/biometric_service.dart';
import '../services/external_activity_guard.dart';

/// Envuelve toda la app y la tapa con [LockScreen] cuando el bloqueo
/// biométrico está activo:
///
/// * al abrir la app,
/// * cada vez que la app pasa a segundo plano (se vuelve a pedir al regresar),
/// * mientras la app no está en primer plano, para que la vista previa del
///   selector de apps no enseñe el diario.
///
/// El contenido sigue montado debajo (dentro de un `Stack`), así que no se
/// pierde el texto ni la posición de la pantalla al bloquear y desbloquear.
class AppLockGate extends StatefulWidget {
  const AppLockGate({super.key, required this.child});

  final Widget child;

  @override
  State<AppLockGate> createState() => _AppLockGateState();
}

class _AppLockGateState extends State<AppLockGate> with WidgetsBindingObserver {
  late final SettingsProvider _settings;
  late final BiometricService _biometric;

  bool _locked = false;
  bool _covered = false;
  bool _wasInBackground = false;
  bool _authenticating = false;
  bool _deviceUnavailable = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _settings = context.read<SettingsProvider>();
    _biometric = context.read<BiometricService>();
    _settings.addListener(_onSettingsChanged);

    _locked = _settings.biometricEnabled;
    if (_locked) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _tryUnlock());
    }
  }

  @override
  void dispose() {
    _settings.removeListener(_onSettingsChanged);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _onSettingsChanged() {
    if (!mounted) {
      return;
    }
    if (!_settings.biometricEnabled && (_locked || _covered)) {
      setState(() {
        _locked = false;
        _covered = false;
        _deviceUnavailable = false;
      });
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!_settings.biometricEnabled) {
      _wasInBackground = false;
      return;
    }

    switch (state) {
      case AppLifecycleState.inactive:
      case AppLifecycleState.hidden:
        if (!_covered) {
          setState(() => _covered = true);
        }
      case AppLifecycleState.paused:
        // El diálogo biométrico no pasa por aquí (la app solo queda "inactiva"),
        // pero por si acaso no se bloquea la app mientras se está autenticando.
        // Tampoco cuando la propia app ha abierto la cámara, la galería o la
        // compra de Google Play: al volver no debe pedir la huella otra vez.
        if (!_biometric.isAuthenticating && !ExternalActivityGuard.isActive) {
          _wasInBackground = true;
          FocusManager.instance.primaryFocus?.unfocus();
          setState(() {
            _locked = true;
            _covered = true;
          });
        }
      case AppLifecycleState.resumed:
        setState(() => _covered = false);
        // Solo se vuelve a pedir la identidad si se vuelve desde segundo plano.
        // Así, cancelar el diálogo no lo reabre una y otra vez.
        if (_wasInBackground) {
          _wasInBackground = false;
          if (_locked) {
            _tryUnlock();
          }
        }
      case AppLifecycleState.detached:
        break;
    }
  }

  Future<void> _tryUnlock() async {
    if (_authenticating || !mounted) {
      return;
    }
    setState(() => _authenticating = true);

    final bool verified = await _biometric.authenticate(
      reason: 'Desbloquea tu diario Gonen',
    );
    final bool unavailable = verified ? false : !(await _biometric.isAvailable());

    if (!mounted) {
      return;
    }
    setState(() {
      _authenticating = false;
      _deviceUnavailable = unavailable;
      if (verified) {
        _locked = false;
        _covered = false;
      }
    });
  }

  Future<void> _disableLock() async {
    await _settings.disableBiometricWithoutPrompt();
    if (!mounted) {
      return;
    }
    setState(() {
      _locked = false;
      _covered = false;
      _deviceUnavailable = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool showLock = _settings.biometricEnabled && (_locked || _covered);

    return Stack(
      fit: StackFit.expand,
      children: <Widget>[
        ExcludeSemantics(excluding: showLock, child: widget.child),
        if (showLock)
          Positioned.fill(
            child: LockScreen(
              busy: _authenticating,
              deviceUnavailable: _deviceUnavailable,
              onUnlock: _tryUnlock,
              onDisableLock: _disableLock,
            ),
          ),
      ],
    );
  }
}
