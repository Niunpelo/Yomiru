import 'dart:async';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../models/attachment_limits.dart';
import '../models/attachment_model.dart';
import '../providers/diary_provider.dart';
import '../providers/premium_provider.dart';
import '../screens/premium_screen.dart';
import '../services/external_activity_guard.dart';
import 'voice_recorder_sheet.dart';

/// Botones para añadir una foto (cámara o galería) o una nota de voz al día de hoy.
///
/// Sin Gonen Premium los botones llevan un candado y, al pulsarlos, abren la
/// pantalla de compra. Con premium solo funcionan mientras el día es editable
/// (hasta las 23:59), igual que el texto.
class AttachmentActionBar extends StatelessWidget {
  const AttachmentActionBar({super.key});

  void _showMessage(ScaffoldMessengerState messenger, String text) {
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _openPremium(BuildContext context) {
    return Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => const PremiumScreen(),
      ),
    );
  }

  /// Comprueba premium, día editable y límite. Devuelve false (avisando al
  /// usuario) si no se puede añadir ahora mismo.
  Future<bool> _canAdd(BuildContext context, AttachmentType type) async {
    final PremiumProvider premium = context.read<PremiumProvider>();
    final DiaryProvider diary = context.read<DiaryProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);

    if (!premium.isPremium) {
      await _openPremium(context);
      return false;
    }
    if (!diary.canWriteCurrentYear) {
      _showMessage(
        messenger,
        'Este día ya terminó (23:59): no se pueden añadir más archivos.',
      );
      return false;
    }
    if (diary.attachmentCount(type) >= DiaryProvider.attachmentLimit(type)) {
      _showMessage(
        messenger,
        type == AttachmentType.image
            ? 'Ya tienes ${AttachmentLimits.maxImagesPerDay} fotos en este día.'
            : 'Ya tienes ${AttachmentLimits.maxVoiceNotesPerDay} notas de voz '
                'en este día.',
      );
      return false;
    }
    return true;
  }

  Future<void> _pickImage(BuildContext context, ImageSource source) async {
    if (!await _canAdd(context, AttachmentType.image)) {
      return;
    }
    if (!context.mounted) {
      return;
    }

    final DiaryProvider diary = context.read<DiaryProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    // El día y el año se anotan ahora, antes de salir a la cámara o a la galería.
    final String dayKey = diary.dayKey;
    final int year = diary.entryYear;

    XFile? picked;
    try {
      picked = await pickPhoto(source);
    } catch (error) {
      debugPrint('Gonen: no se pudo abrir la cámara o la galería: $error');
      _showMessage(
        messenger,
        source == ImageSource.camera
            ? 'No se pudo abrir la cámara.'
            : 'No se pudo abrir la galería.',
      );
      return;
    }

    if (picked == null) {
      return;
    }
    final String? error = await diary.addImage(
      sourcePath: picked.path,
      dayKey: dayKey,
      year: year,
    );
    if (error != null) {
      _showMessage(messenger, error);
    }
  }

  Future<void> _recordVoice(BuildContext context) async {
    if (!await _canAdd(context, AttachmentType.audio)) {
      return;
    }
    if (!context.mounted) {
      return;
    }

    final DiaryProvider diary = context.read<DiaryProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final String dayKey = diary.dayKey;
    final int year = diary.entryYear;

    final RecordedVoice? voice = await showModalBottomSheet<RecordedVoice>(
      context: context,
      isDismissible: false,
      enableDrag: false,
      builder: (BuildContext sheetContext) =>
          VoiceRecorderSheet(dayKey: dayKey, year: year),
    );
    if (voice == null) {
      return;
    }

    final String? error = await diary.addVoiceNote(
      relativePath: voice.relativePath,
      durationMs: voice.durationMs,
      dayKey: dayKey,
      year: year,
    );
    if (error != null) {
      _showMessage(messenger, error);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool premium = context
        .select<PremiumProvider, bool>((PremiumProvider p) => p.isPremium);

    return AttachmentButtons(
      premium: premium,
      onCamera: () => unawaited(_pickImage(context, ImageSource.camera)),
      onGallery: () => unawaited(_pickImage(context, ImageSource.gallery)),
      onVoice: () => unawaited(_recordVoice(context)),
    );
  }
}

/// Abre la cámara o la galería y devuelve la foto elegida (ya reducida), o
/// null si se cancela. Lanza una excepción si no se puede abrir.
///
/// La cámara y la galería sacan a la app a segundo plano: mientras tanto no se
/// vuelve a pedir la huella al regresar.
Future<XFile?> pickPhoto(ImageSource source) async {
  try {
    ExternalActivityGuard.allowFor(const Duration(minutes: 5));
    return await ImagePicker().pickImage(
      source: source,
      maxWidth: AttachmentLimits.imageMaxSide,
      maxHeight: AttachmentLimits.imageMaxSide,
      imageQuality: AttachmentLimits.imageQuality,
    );
  } finally {
    ExternalActivityGuard.clear();
  }
}

/// Fila con los tres botones: foto, galería y voz. Sin [premium] llevan un
/// candado y debajo se explica por qué.
class AttachmentButtons extends StatelessWidget {
  const AttachmentButtons({
    super.key,
    required this.premium,
    required this.onCamera,
    required this.onGallery,
    required this.onVoice,
  });

  final bool premium;
  final VoidCallback onCamera;
  final VoidCallback onGallery;
  final VoidCallback onVoice;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: <Widget>[
            _ActionButton(
              icon: Icons.photo_camera_outlined,
              label: 'Foto',
              locked: !premium,
              onPressed: onCamera,
            ),
            _ActionButton(
              icon: Icons.photo_library_outlined,
              label: 'Galería',
              locked: !premium,
              onPressed: onGallery,
            ),
            _ActionButton(
              icon: Icons.mic_none_rounded,
              label: 'Voz',
              locked: !premium,
              onPressed: onVoice,
            ),
          ],
        ),
        if (!premium)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              'Fotos y notas de voz con Gonen Premium',
              style: theme.textTheme.labelSmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
      ],
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({
    required this.icon,
    required this.label,
    required this.locked,
    required this.onPressed,
  });

  final IconData icon;
  final String label;
  final bool locked;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      avatar: Icon(locked ? Icons.lock_outline_rounded : icon, size: 18),
      label: Text(label),
      onPressed: onPressed,
    );
  }
}
