import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_info.dart';
import '../providers/capsules_provider.dart';
import '../providers/premium_provider.dart';
import '../theme/app_theme.dart';

/// Menú desplegable de la esquina superior izquierda.
///
/// Para añadir una opción nueva basta con sumar otro `ListTile` en [build] y su
/// callback correspondiente.
class AppDrawer extends StatelessWidget {
  const AppDrawer({
    super.key,
    required this.onOpenCalendar,
    required this.onOpenSearch,
    required this.onOpenCapsules,
    required this.onOpenBackup,
    required this.onOpenPremium,
    required this.onOpenSettings,
  });

  final VoidCallback onOpenCalendar;
  final VoidCallback onOpenSearch;
  final VoidCallback onOpenCapsules;
  final VoidCallback onOpenBackup;
  final VoidCallback onOpenPremium;
  final VoidCallback onOpenSettings;

  /// Cierra el menú y ejecuta [action].
  void _go(BuildContext context, VoidCallback action) {
    Navigator.of(context).pop();
    action();
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final int readyCount = context
        .select<CapsulesProvider, int>((CapsulesProvider p) => p.readyCount);
    final bool premium = context
        .select<PremiumProvider, bool>((PremiumProvider p) => p.isPremium);

    return Drawer(
      backgroundColor: scheme.surface,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const _DrawerHeader(),
            const Divider(),
            // Desplazable, para que con pantallas bajas o letra grande ninguna
            // opción quede fuera de alcance.
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const SizedBox(height: 8),
                    ListTile(
                      leading: const Icon(Icons.menu_book_outlined),
                      title: const Text('Diario'),
                      selected: true,
                      selectedColor: scheme.primary,
                      onTap: () => Navigator.of(context).pop(),
                    ),
                    ListTile(
                      leading: const Icon(Icons.calendar_month_outlined),
                      title: const Text('Calendario'),
                      subtitle: const Text('Tus días escritos y tu racha'),
                      onTap: () => _go(context, onOpenCalendar),
                    ),
                    ListTile(
                      leading: const Icon(Icons.search_rounded),
                      title: const Text('Buscar'),
                      subtitle: const Text('Encuentra cualquier recuerdo'),
                      onTap: () => _go(context, onOpenSearch),
                    ),
                    ListTile(
                      leading: const Icon(Icons.hourglass_empty_rounded),
                      title: const Text('Cápsulas del tiempo'),
                      subtitle: const Text('Mensajes para leer en el futuro'),
                      trailing:
                          readyCount > 0 ? _CountPill(count: readyCount) : null,
                      onTap: () => _go(context, onOpenCapsules),
                    ),
                    ListTile(
                      leading: const Icon(Icons.cloud_upload_outlined),
                      title: const Text('Copia de seguridad'),
                      subtitle: const Text('Guarda y recupera tu diario'),
                      onTap: () => _go(context, onOpenBackup),
                    ),
                    ListTile(
                      leading: const Icon(Icons.star_outline_rounded),
                      title: const Text('Gonen Premium'),
                      subtitle: Text(
                        premium
                            ? 'Activo'
                            : 'Fotos, notas de voz y copias de seguridad',
                      ),
                      trailing: premium
                          ? Icon(
                              Icons.check_circle_outline_rounded,
                              color: scheme.primary,
                            )
                          : null,
                      onTap: () => _go(context, onOpenPremium),
                    ),
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 20),
                      child: Divider(),
                    ),
                    ListTile(
                      leading: const Icon(Icons.settings_outlined),
                      title: const Text('Ajustes'),
                      onTap: () => _go(context, onOpenSettings),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
              child: Text(
                'Gonen $kAppVersion',
                style: TextStyle(
                  fontFamily: kSerifFamily,
                  fontSize: 13,
                  letterSpacing: 2,
                  color: scheme.onSurfaceVariant,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DrawerHeader extends StatelessWidget {
  const _DrawerHeader();

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
      child: Row(
        children: <Widget>[
          // Sello rojo con el kanji 五 (cinco), como el de un hanko.
          Container(
            width: 52,
            height: 52,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: scheme.primary,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              '五',
              style: TextStyle(
                fontFamily: kSerifFamily,
                fontSize: 30,
                color: scheme.onPrimary,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Gonen',
                  style: TextStyle(
                    fontFamily: kSerifFamily,
                    fontSize: 26,
                    letterSpacing: 4,
                    color: scheme.onSurface,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Tu diario, año tras año',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CountPill extends StatelessWidget {
  const _CountPill({required this.count});

  final int count;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
      decoration: BoxDecoration(
        color: scheme.primary,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        '$count',
        style: TextStyle(
          color: scheme.onPrimary,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
