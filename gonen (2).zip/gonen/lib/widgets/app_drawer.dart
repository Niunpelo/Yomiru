import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_info.dart';
import '../l10n/tr.dart';
import '../providers/capsules_provider.dart';
import '../providers/premium_provider.dart';
import '../theme/app_style.dart';
import 'gonen_mark.dart';

/// Menú desplegable de la esquina superior izquierda.
///
/// Para añadir una opción nueva basta con sumar otro `ListTile` en [build] y su
/// callback correspondiente.
class AppDrawer extends StatelessWidget {
  const AppDrawer({
    super.key,
    required this.onOpenCalendar,
    required this.onOpenSearch,
    required this.onOpenCapsules,
    required this.onOpenBackup,
    required this.onOpenPremium,
    required this.onOpenSettings,
  });

  final VoidCallback onOpenCalendar;
  final VoidCallback onOpenSearch;
  final VoidCallback onOpenCapsules;
  final VoidCallback onOpenBackup;
  final VoidCallback onOpenPremium;
  final VoidCallback onOpenSettings;

  /// Cierra el menú y ejecuta [action].
  void _go(BuildContext context, VoidCallback action) {
    Navigator.of(context).pop();
    action();
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final int readyCount = context
        .select<CapsulesProvider, int>((CapsulesProvider p) => p.readyCount);
    final bool premium = context
        .select<PremiumProvider, bool>((PremiumProvider p) => p.isPremium);

    return Drawer(
      backgroundColor: scheme.surface,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const _DrawerHeader(),
            const Divider(),
            // Desplazable, para que con pantallas bajas o letra grande ninguna
            // opción quede fuera de alcance.
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const SizedBox(height: 8),
                    ListTile(
                      leading: const Icon(Icons.menu_book_outlined),
                      title: Text(context.tr('Diario', 'Diary')),
                      selected: true,
                      selectedColor: scheme.primary,
                      onTap: () => Navigator.of(context).pop(),
                    ),
                    ListTile(
                      leading: const Icon(Icons.calendar_month_outlined),
                      title: Text(context.tr('Calendario', 'Calendar')),
                      subtitle: Text(
                        context.tr(
                          'Tus días escritos y tu racha',
                          'Your written days and your streak',
                        ),
                      ),
                      onTap: () => _go(context, onOpenCalendar),
                    ),
                    ListTile(
                      leading: const Icon(Icons.search_rounded),
                      title: Text(context.tr('Buscar', 'Search')),
                      subtitle: Text(
                        context.tr(
                          'Encuentra cualquier recuerdo',
                          'Find any memory',
                        ),
                      ),
                      onTap: () => _go(context, onOpenSearch),
                    ),
                    ListTile(
                      leading: const Icon(Icons.hourglass_empty_rounded),
                      title: Text(context.tr('Cápsulas del tiempo', 'Time capsules')),
                      subtitle: Text(
                        context.tr(
                          'Mensajes para leer en el futuro',
                          'Messages to read in the future',
                        ),
                      ),
                      trailing:
                          readyCount > 0 ? _CountPill(count: readyCount) : null,
                      onTap: () => _go(context, onOpenCapsules),
                    ),
                    ListTile(
                      leading: const Icon(Icons.cloud_upload_outlined),
                      title: Text(context.tr('Copia de seguridad', 'Backup')),
                      subtitle: Text(
                        context.tr(
                          'Guarda y recupera tu diario',
                          'Save and restore your diary',
                        ),
                      ),
                      onTap: () => _go(context, onOpenBackup),
                    ),
                    ListTile(
                      leading: const Icon(Icons.star_outline_rounded),
                      title: const Text('Gonen Premium'),
                      subtitle: Text(
                        premium
                            ? (kPremiumTestBuild
                                ? context.tr('Activo (modo prueba)', 'Active (test mode)')
                                : context.tr('Activo', 'Active'))
                            : context.tr(
                                'Fotos, notas de voz y copias de seguridad',
                                'Photos, voice notes and backups',
                              ),
                      ),
                      trailing: premium
                          ? Icon(
                              Icons.check_circle_outline_rounded,
                              color: scheme.primary,
                            )
                          : null,
                      onTap: () => _go(context, onOpenPremium),
                    ),
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 20),
                      child: Divider(),
                    ),
                    ListTile(
                      leading: const Icon(Icons.settings_outlined),
                      title: Text(context.tr('Ajustes', 'Settings')),
                      onTap: () => _go(context, onOpenSettings),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
              child: Text(
                kVersionLabel,
                style: TextStyle(
                  fontFamily: context.appStyle.bodyFamily,
                  fontSize: 13,
                  letterSpacing: 2,
                  color: scheme.onSurfaceVariant,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DrawerHeader extends StatelessWidget {
  const _DrawerHeader();

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final AppStyle style = context.appStyle;

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
      child: Row(
        children: <Widget>[
          // El logo de la app: cinco anillos de árbol, uno por año.
          GonenMark(size: 52, radius: style.isEditorial ? 0 : 12),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Gonen',
                  style: TextStyle(
                    fontFamily: style.displayFamily,
                    fontWeight:
                        style.isEditorial ? FontWeight.w600 : FontWeight.w400,
                    fontSize: 26,
                    letterSpacing: style.isEditorial ? 1 : 4,
                    color: scheme.onSurface,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  context.tr('Tu diario, año tras año', 'Your diary, year after year'),
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CountPill extends StatelessWidget {
  const _CountPill({required this.count});

  final int count;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
      decoration: BoxDecoration(
        color: scheme.primary,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        '$count',
        style: TextStyle(
          color: scheme.onPrimary,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
