import 'package:flutter/material.dart';

import '../l10n/tr.dart';
import '../models/capsule_model.dart';
import '../providers/capsules_provider.dart';
import '../utils/date_labels.dart';

/// Cuenta al usuario qué pasó al importar una cápsula.
///
/// Con [offerList] el diálogo ofrece un botón para ir a la lista de cápsulas
/// (para cuando se llega desde otra pantalla). Devuelve true solo si el
/// usuario pulsa ese botón.
Future<bool> showCapsuleImportResult(
  BuildContext context,
  CapsuleImportResult result, {
  required bool offerList,
}) async {
  final String title;
  final String message;
  final bool imported = result.status == CapsuleImportStatus.imported;

  switch (result.status) {
    case CapsuleImportStatus.imported:
      final Capsule capsule = result.capsule!;
      title = context.tr('Cápsula guardada', 'Capsule saved');
      message = _importedMessage(context, capsule);
    case CapsuleImportStatus.duplicate:
      title = context.tr('Ya la tenías', 'You already had it');
      message = context.tr(
        'Esta cápsula ya estaba guardada en este móvil. No se ha '
            'cambiado nada.',
        'This capsule was already saved on this phone. Nothing has been '
            'changed.',
      );
    case CapsuleImportStatus.invalid:
      title = context.tr('No se pudo guardar', 'Could not be saved');
      message = result.message ??
          context.tr(
            'Este archivo no es una cápsula de Gonen.',
            'This file is not a Gonen capsule.',
          );
    case CapsuleImportStatus.failed:
      title = context.tr('No se pudo guardar', 'Could not be saved');
      message = result.message ??
          context.tr(
            'No se pudo guardar la cápsula.',
            'The capsule could not be saved.',
          );
  }

  final bool? open = await showDialog<bool>(
    context: context,
    builder: (BuildContext dialogContext) {
      return AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(
              imported && offerList
                  ? dialogContext.tr('Cerrar', 'Close')
                  : dialogContext.tr('Entendido', 'Got it'),
            ),
          ),
          if (imported && offerList)
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: Text(dialogContext.tr('Ver cápsulas', 'See capsules')),
            ),
        ],
      );
    },
  );
  return open ?? false;
}

String _importedMessage(BuildContext context, Capsule capsule) {
  final String from = capsule.sender ?? context.tr('Alguien', 'Someone');
  final DateTime today = Capsule.dateOnly(DateTime.now());
  final String when = capsule.openDate.isAfter(today)
      ? context.tr(
          'Se podrá abrir el ${fullDateLabel(capsule.openDate)}. Te avisaremos '
              'ese día; hasta entonces su contenido queda oculto.',
          'It can be opened on ${fullDateLabel(capsule.openDate)}. We will let '
              'you know that day; until then its content stays hidden.',
        )
      : context.tr(
          'Ya se puede abrir: la encontrarás en tu lista de cápsulas.',
          'It can be opened now: you will find it in your list of capsules.',
        );
  return context.tr(
    '$from te ha dejado una cápsula del tiempo.\n\n$when',
    '$from has left you a time capsule.\n\n$when',
  );
}
