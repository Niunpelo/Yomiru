import 'package:flutter/material.dart';

import '../providers/capsules_provider.dart';
import '../theme/app_style.dart';

/// Aviso de que Gonen no puede comprobar qué día es de verdad (la fecha del
/// móvil es manual) y por eso no abre las cápsulas.
class ClockNotice extends StatelessWidget {
  const ClockNotice({super.key});

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: scheme.errorContainer,
        borderRadius: BorderRadius.circular(context.appStyle.cornerRadius),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(Icons.schedule_rounded, color: scheme.onErrorContainer),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              CapsulesProvider.clockUnverifiedMessage,
              style: TextStyle(color: scheme.onErrorContainer),
            ),
          ),
        ],
      ),
    );
  }
}
