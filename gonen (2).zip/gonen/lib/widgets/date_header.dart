import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Cabecera con el día seleccionado, flechas para cambiar de día y acceso
/// rápido a "hoy".
class DateHeader extends StatelessWidget {
  const DateHeader({
    super.key,
    required this.dayLabel,
    required this.subtitle,
    required this.isToday,
    required this.onPrevious,
    required this.onNext,
    required this.onToday,
    required this.onPickDate,
  });

  /// Texto principal, por ejemplo "15 de Marzo".
  final String dayLabel;

  /// Texto secundario, por ejemplo el día de la semana.
  final String subtitle;

  final bool isToday;
  final VoidCallback onPrevious;
  final VoidCallback onNext;
  final VoidCallback onToday;
  final VoidCallback onPickDate;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
      child: Row(
        children: <Widget>[
          IconButton(
            onPressed: onPrevious,
            icon: const Icon(Icons.chevron_left_rounded),
            iconSize: 32,
            tooltip: 'Día anterior',
          ),
          Expanded(
            child: InkWell(
              onTap: onPickDate,
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(
                      dayLabel,
                      textAlign: TextAlign.center,
                      style: theme.textTheme.headlineMedium,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      textAlign: TextAlign.center,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: scheme.onSurfaceVariant,
                        fontFamily: kSerifFamily,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    if (isToday)
                      Text(
                        '· Hoy ·',
                        style: theme.textTheme.labelMedium?.copyWith(
                          color: scheme.primary,
                          letterSpacing: 1.5,
                        ),
                      )
                    else
                      TextButton.icon(
                        onPressed: onToday,
                        icon: const Icon(Icons.today_outlined, size: 18),
                        label: const Text('Ir a hoy'),
                        style: TextButton.styleFrom(
                          visualDensity: VisualDensity.compact,
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
          IconButton(
            onPressed: onNext,
            icon: const Icon(Icons.chevron_right_rounded),
            iconSize: 32,
            tooltip: 'Día siguiente',
          ),
        ],
      ),
    );
  }
}
