import 'package:flutter/material.dart';

import '../l10n/tr.dart';
import '../theme/app_style.dart';
import '../utils/date_labels.dart' show monthLabel;

/// Cabecera con el día seleccionado, flechas para cambiar de día y acceso
/// rápido a "hoy".
///
/// En los estilos editoriales el número del día ocupa media cabecera, como la
/// portada de una revista.
class DateHeader extends StatelessWidget {
  const DateHeader({
    super.key,
    required this.date,
    required this.dayLabel,
    required this.subtitle,
    required this.isToday,
    required this.onPrevious,
    required this.onNext,
    required this.onToday,
    required this.onPickDate,
    this.yearDay,
    this.yearDays,
  });

  /// Fecha de referencia: de ella salen el número del día y el nombre del mes.
  final DateTime date;

  /// Texto principal, por ejemplo "15 de Marzo".
  final String dayLabel;

  /// Texto secundario, por ejemplo el día de la semana.
  final String subtitle;

  final bool isToday;
  final VoidCallback onPrevious;
  final VoidCallback onNext;
  final VoidCallback onToday;
  final VoidCallback onPickDate;

  /// Posición del día dentro del año (1-366), si se conoce.
  final int? yearDay;

  /// Días que tiene el año (365 o 366), si se conoce.
  final int? yearDays;

  @override
  Widget build(BuildContext context) {
    final AppStyle style = context.appStyle;
    if (style.isEditorial) {
      return _buildEditorial(context, style);
    }
    return _buildCentered(context, style);
  }

  // ---------------------------------------------------------------------------
  // Hilo rojo: fecha centrada
  // ---------------------------------------------------------------------------

  Widget _buildCentered(BuildContext context, AppStyle style) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final bool thread = style.hasThread;

    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
      child: Row(
        children: <Widget>[
          IconButton(
            onPressed: onPrevious,
            icon: const Icon(Icons.chevron_left_rounded),
            iconSize: 32,
            tooltip: context.tr('Día anterior', 'Previous day'),
          ),
          Expanded(
            child: InkWell(
              onTap: onPickDate,
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    // El hilo rojo lleva «HOY» sobre la fecha, a modo de sello.
                    if (thread && isToday)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: Text(
                          context.tr('HOY', 'TODAY'),
                          style: theme.textTheme.labelMedium?.copyWith(
                            color: scheme.primary,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 6,
                          ),
                        ),
                      ),
                    Text(
                      dayLabel,
                      textAlign: TextAlign.center,
                      style: theme.textTheme.headlineMedium,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      textAlign: TextAlign.center,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: scheme.onSurfaceVariant,
                        fontFamily: style.bodyFamily,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    if (isToday)
                      (thread
                          ? const SizedBox(height: 4)
                          : Text(
                              context.tr('· Hoy ·', '· Today ·'),
                              style: theme.textTheme.labelMedium?.copyWith(
                                color: scheme.primary,
                                letterSpacing: 1.5,
                              ),
                            ))
                    else
                      TextButton.icon(
                        onPressed: onToday,
                        icon: const Icon(Icons.today_outlined, size: 18),
                        label: Text(context.tr('Ir a hoy', 'Go to today')),
                        style: TextButton.styleFrom(
                          visualDensity: VisualDensity.compact,
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
          IconButton(
            onPressed: onNext,
            icon: const Icon(Icons.chevron_right_rounded),
            iconSize: 32,
            tooltip: context.tr('Día siguiente', 'Next day'),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Editorial japonesa: número enorme
  // ---------------------------------------------------------------------------

  Widget _buildEditorial(BuildContext context, AppStyle style) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    final TextStyle label = TextStyle(
      fontFamily: style.labelFamily,
      fontSize: 12,
      letterSpacing: 1,
      color: scheme.onSurface,
    );

    final String? progress = (yearDay == null || yearDays == null)
        ? null
        : '${context.tr('Día', 'Day')} $yearDay / $yearDays'.toUpperCase();

    final Widget info = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 130),
          child: Text(subtitle.toUpperCase(), style: label),
        ),
        const SizedBox(height: 4),
        if (isToday)
          Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: scheme.primary,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                context.tr('HOY', 'TODAY'),
                style: label.copyWith(
                  color: scheme.primary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          )
        else
          InkWell(
            onTap: onToday,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Text(
                context.tr('IR A HOY', 'GO TO TODAY'),
                style: label.copyWith(
                  color: scheme.primary,
                  fontWeight: FontWeight.w500,
                  decoration: TextDecoration.underline,
                  decorationColor: scheme.primary,
                ),
              ),
            ),
          ),
        if (progress != null) ...<Widget>[
          const SizedBox(height: 4),
          Text(
            progress,
            style: label.copyWith(
              fontSize: 10.5,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ],
      ],
    );

    // En la editorial japonesa el mes va en vertical, junto a una línea fina.
    final Widget verticalMonth = Container(
      padding: const EdgeInsets.only(left: 8),
      decoration: BoxDecoration(
        border: Border(left: BorderSide(color: scheme.primary)),
      ),
      child: RotatedBox(
        quarterTurns: 3,
        child: Text(
          monthLabel(date).toUpperCase(),
          style: label.copyWith(
            fontSize: 13,
            letterSpacing: 3,
            color: scheme.primary,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Container(
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(color: scheme.outlineVariant, width: 3),
          ),
        ),
        padding: const EdgeInsets.only(top: 8, bottom: 8),
        child: Row(
          children: <Widget>[
            IconButton(
              onPressed: onPrevious,
              icon: const Icon(Icons.chevron_left_rounded),
              iconSize: 28,
              tooltip: context.tr('Día anterior', 'Previous day'),
            ),
            Expanded(
              child: InkWell(
                onTap: onPickDate,
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        '${date.day}',
                        style: TextStyle(
                          fontFamily: style.displayFamily,
                          fontWeight: style.displayWeight,
                          fontSize: 100,
                          height: 0.95,
                          color: scheme.onSurface,
                        ),
                      ),
                      const SizedBox(width: 12),
                      info,
                      const SizedBox(width: 14),
                      verticalMonth,
                    ],
                  ),
                ),
              ),
            ),
            IconButton(
              onPressed: onNext,
              icon: const Icon(Icons.chevron_right_rounded),
              iconSize: 28,
              tooltip: context.tr('Día siguiente', 'Next day'),
            ),
          ],
        ),
      ),
    );
  }
}
