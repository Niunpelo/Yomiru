import '../l10n/tr.dart';
import '../utils/prompt_deck.dart';
import 'writing_prompts_en.dart';

/// Barajas compartidas por toda la app (una por idioma): así, mientras no se
/// cierre, el dado no repite frases aunque se abra desde días distintos.
final PromptDeck kSharedPromptDeckEs = PromptDeck(kWritingPrompts);
final PromptDeck kSharedPromptDeckEn = PromptDeck(kWritingPromptsEn);

/// La baraja del idioma en que está la app ahora mismo.
PromptDeck sharedPromptDeck() =>
    AppLocale.isEnglish ? kSharedPromptDeckEn : kSharedPromptDeckEs;

/// Frases y preguntas para inspirarse al escribir. Para añadir más basta con
/// sumar otra línea a la lista (que no esté repetida: lo comprueba una prueba).
const List<String> kWritingPrompts = <String>[
  // --- El día de hoy -------------------------------------------------------
  '¿Qué ha sido lo mejor de hoy?',
  '¿Qué te ha hecho sonreír hoy?',
  '¿Qué ha sido lo más difícil de hoy y cómo lo has llevado?',
  '¿Con qué ánimo te has despertado y con cuál te vas a dormir?',
  'Describe tu día en tres palabras y cuenta por qué las has elegido.',
  '¿Qué has aprendido hoy, aunque sea algo pequeño?',
  '¿Qué conversación de hoy se te va a quedar en la memoria?',
  '¿Qué has hecho hoy por primera vez?',
  '¿Qué ha salido distinto de lo que esperabas?',
  '¿A qué le has dedicado más tiempo hoy? ¿Ha valido la pena?',
  '¿Cuál ha sido el mejor momento del día y dónde estabas?',
  '¿Qué te ha preocupado hoy? ¿Sigue teniendo importancia?',
  '¿Qué has dejado de hacer hoy que te habría gustado hacer?',
  'Si hoy fuese un capítulo de un libro, ¿cómo se titularía?',
  '¿Qué cosa pequeña ha hecho que hoy mereciera la pena?',
  '¿Qué has hecho hoy solo para ti?',
  '¿Qué parte de tu rutina de hoy repetirías mañana?',

  // --- Gratitud ------------------------------------------------------------
  'Escribe tres cosas que hoy agradeces.',
  '¿A quién le agradeces algo hoy? ¿Se lo has dicho?',
  '¿Qué tienes ahora mismo que hace unos años deseabas?',
  '¿Qué comodidad cotidiana das por hecha y hoy quieres valorar?',
  '¿Quién te ha ayudado últimamente sin que se lo pidieras?',
  '¿Qué lugar de tu día a día te hace sentir en casa?',

  // --- Emociones -----------------------------------------------------------
  '¿Cómo te sientes ahora mismo? Descríbelo como si fuese el tiempo que hace.',
  '¿Qué emoción ha pesado más hoy? ¿Dónde la has notado en el cuerpo?',
  '¿Qué te hace falta ahora mismo?',
  '¿Qué has hecho hoy que te dé orgullo?',
  '¿Qué te ha enfadado y qué hay debajo de ese enfado?',
  '¿Qué te da miedo últimamente? ¿Qué le dirías a un amigo que sintiera lo mismo?',
  '¿Cuándo has sentido calma hoy?',
  '¿Qué necesitas soltar esta semana?',
  '¿Qué te da energía y qué te la quita últimamente?',
  'Escribe una carta corta a tu yo de esta mañana.',
  '¿Qué te gustaría perdonarte?',
  '¿Qué has sentido hoy que no le has contado a nadie?',

  // --- Personas ------------------------------------------------------------
  '¿Con quién has hablado hoy que te haya hecho bien?',
  '¿A quién echas de menos hoy? ¿Qué le dirías?',
  '¿Qué detalle de alguien cercano has notado hoy?',
  '¿Qué le dirías hoy a esa persona a la que no ves desde hace tiempo?',
  '¿Qué has aprendido de alguien esta semana?',
  '¿Quién te ha hecho reír últimamente y qué pasó?',
  '¿Qué cualidad de alguien cercano te gustaría tener?',
  '¿En quién has pensado hoy sin motivo aparente?',
  '¿Qué te gustaría que alguien supiera de ti y todavía no sabe?',

  // --- Sentidos y detalles -------------------------------------------------
  '¿Qué has oído hoy que quieras recordar?',
  'Describe un olor de hoy.',
  '¿Qué luz había hoy a la hora de comer?',
  '¿Qué sabor ha sido el protagonista de tu día?',
  'Describe el lugar donde estás ahora como si tuvieras que explicárselo a alguien dentro de diez años.',
  '¿Qué canción te ha acompañado hoy?',
  '¿Qué has visto hoy desde la ventana?',
  '¿Qué tiempo ha hecho hoy y cómo ha influido en ti?',
  'Fíjate en tres objetos a tu alrededor y cuenta qué historia tiene cada uno.',
  '¿Qué textura, sonido o color te ha llamado la atención hoy?',
  '¿Cómo ha sido el camino de hoy de un sitio a otro?',
  '¿Qué ropa llevas hoy y por qué la elegiste?',

  // --- Mirar atrás (este diario guarda los años anteriores) ------------------
  'Mira las tarjetas de otros años: ¿qué ha cambiado desde entonces?',
  '¿Qué le dirías hoy a quien eras en el primer año de este diario?',
  '¿Qué problema de hace un año ya no te preocupa?',
  '¿Qué recuerdo de hace años te ha venido hoy a la cabeza?',
  '¿Qué te sorprendería de tu vida actual si lo hubieras sabido hace cinco años?',
  '¿Qué hábito has ganado o perdido desde el año pasado?',
  '¿Qué sueño de hace tiempo sigue vivo?',
  '¿Qué decisión de hace años agradeces hoy?',
  '¿A qué lugar del pasado te gustaría volver y por qué?',
  '¿Cuál es tu recuerdo más antiguo? Cuéntalo con todos los detalles que alcances.',
  '¿Qué estabas haciendo en este mismo día hace un año?',

  // --- Mirar adelante --------------------------------------------------------
  '¿Qué te gustaría que dijera este mismo día dentro de un año?',
  '¿Qué quieres que tu yo del futuro recuerde de hoy?',
  '¿Qué pequeño paso puedes dar mañana hacia algo que te importa?',
  '¿Qué esperas con ilusión esta semana?',
  'Si pudieras pedir un deseo para el próximo año, ¿cuál sería?',
  '¿Qué te gustaría haber conseguido dentro de cinco años?',
  '¿Qué miedo quieres dejar atrás el año que viene?',
  '¿Cómo imaginas un día perfecto dentro de un año?',
  '¿Qué plan tienes para el fin de semana y qué esperas de él?',
  '¿Qué te gustaría empezar a hacer y todavía no has empezado?',

  // --- Reflexión -------------------------------------------------------------
  '¿Qué harías hoy si no tuvieras miedo a equivocarte?',
  '¿Qué creencia tuya ha cambiado últimamente?',
  '¿A qué le das importancia de verdad y no le dedicas tiempo?',
  '¿En qué has sido valiente hoy?',
  '¿Qué consejo te darías si fueras tu mejor amigo?',
  '¿Qué decisión estás aplazando y por qué?',
  '¿Qué parte de tu rutina te gustaría cambiar?',
  '¿Qué te gustaría hacer más veces?',
  '¿Qué estás aprendiendo de ti últimamente?',
  '¿Cuándo fue la última vez que perdiste la noción del tiempo?',
  '¿Qué significa para ti una buena vida?',
  '¿Qué cosas haces solo por costumbre?',
  '¿Qué límite has puesto, o te gustaría poner?',
  '¿Qué error reciente te ha enseñado algo?',
  '¿De qué te gustaría hablar más a menudo?',

  // --- Creatividad -----------------------------------------------------------
  'Cuenta hoy como si fuese una escena de película: ¿quién la dirige y qué música suena?',
  'Cuenta tu día desde el punto de vista de un objeto que te ha acompañado.',
  'Inventa un titular de periódico para el día de hoy.',
  'Si tu día fuese un color, ¿cuál sería y por qué?',
  'Resume tu día en seis frases.',
  'Cuéntale tu día a un niño de cinco años.',
  'Haz una lista de cinco cosas pequeñas que hoy te han gustado.',
  'Termina esta frase: «Hoy me he dado cuenta de que…»',
  'Termina esta frase: «Lo que más me ha costado hoy ha sido…»',
  'Termina esta frase: «Ojalá mañana…»',
  'Termina esta frase: «Hoy me ha hecho feliz…»',
  'Termina esta frase: «Por fin he entendido que…»',
  'Escribe una frase que quieras recordar de hoy, tuya o de otra persona.',
  'Escribe lo que le dirías a un desconocido que se cruzara contigo hoy.',

  // --- Cuerpo y descanso -----------------------------------------------------
  '¿Cómo has dormido y cómo se nota en tu día?',
  '¿Has cuidado hoy de tu cuerpo? ¿Cómo?',
  '¿Cuándo has parado a respirar hoy?',
  '¿Qué has comido hoy que te haya sentado especialmente bien?',

  // --- Trabajo, estudios y aficiones -----------------------------------------
  '¿Qué parte de tu trabajo o de tus estudios te ha gustado hoy?',
  '¿Qué tarea has terminado hoy y cómo te has sentido al acabarla?',
  '¿Qué libro, serie o película te ha hecho pensar últimamente?',
  '¿Qué has leído o escuchado hoy que te haya dado que pensar?',
  '¿Cuál es tu pequeño placer de esta semana?',
  '¿Qué sitio nuevo has descubierto últimamente?',
  '¿Cuándo fue la última vez que te reíste a carcajadas?',
];
