import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Pantalla que tapa el diario mientras está bloqueado.
///
/// No se apoya en ningún `Navigator` ni en tooltips, porque se dibuja por
/// encima de toda la app (ver `AppLockGate`).
class LockScreen extends StatelessWidget {
  const LockScreen({
    super.key,
    required this.busy,
    required this.deviceUnavailable,
    required this.onUnlock,
    required this.onDisableLock,
  });

  /// Verdadero mientras el diálogo del sistema está abierto.
  final bool busy;

  /// Verdadero si el dispositivo ya no puede autenticar al usuario.
  final bool deviceUnavailable;

  final VoidCallback onUnlock;
  final VoidCallback onDisableLock;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: scheme.surface,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Icon(Icons.lock_outline_rounded, size: 40, color: scheme.primary),
                const SizedBox(height: 24),
                Text(
                  'Gonen',
                  style: TextStyle(
                    fontFamily: kSerifFamily,
                    fontSize: 36,
                    fontWeight: FontWeight.w300,
                    letterSpacing: 6,
                    color: scheme.onSurface,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Tu diario está protegido',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: scheme.onSurfaceVariant,
                    fontFamily: kSerifFamily,
                  ),
                ),
                const SizedBox(height: 32),
                FilledButton.icon(
                  onPressed: busy ? null : onUnlock,
                  icon: const Icon(Icons.fingerprint_rounded),
                  label: const Text('Desbloquear'),
                ),
                if (deviceUnavailable) ...<Widget>[
                  const SizedBox(height: 24),
                  Text(
                    'Este dispositivo ya no tiene huella, rostro ni bloqueo de '
                    'pantalla configurados.',
                    textAlign: TextAlign.center,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: onDisableLock,
                    child: const Text('Desactivar el bloqueo'),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
