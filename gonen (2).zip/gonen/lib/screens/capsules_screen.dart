import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/tr.dart';
import '../models/capsule_model.dart';
import '../providers/capsules_provider.dart';
import '../services/file_transfer_service.dart';
import '../theme/app_theme.dart';
import '../utils/capsule_labels.dart';
import '../utils/date_labels.dart';
import '../widgets/capsule_import_dialog.dart';
import '../widgets/paper_card.dart';
import 'capsule_detail_screen.dart';
import 'new_capsule_screen.dart';

/// Lista de cápsulas del tiempo: listas para abrir, selladas y abiertas.
class CapsulesScreen extends StatelessWidget {
  const CapsulesScreen({super.key});

  Future<void> _newCapsule(BuildContext context) {
    return Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => const NewCapsuleScreen(),
      ),
    );
  }

  /// Elige un archivo de cápsula (`.gonencap`) y lo guarda en este móvil.
  Future<void> _import(BuildContext context) async {
    final CapsulesProvider capsules = context.read<CapsulesProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);

    File? picked;
    try {
      picked = await const FileTransferService().pickFile();
      if (picked == null) {
        return;
      }
      final CapsuleImportResult result = await capsules.importFile(picked);
      if (!context.mounted) {
        return;
      }
      await showCapsuleImportResult(context, result, offerList: false);
    } on FileTransferException catch (error) {
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(error.message)));
    } finally {
      if (picked != null) {
        try {
          if (await picked.exists()) {
            await picked.delete();
          }
        } catch (error) {
          debugPrint('Gonen: no se pudo borrar el archivo temporal: $error');
        }
      }
    }
  }

  Future<void> _openDetail(BuildContext context, Capsule capsule) {
    final int? id = capsule.id;
    if (id == null) {
      return Future<void>.value();
    }
    return Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => CapsuleDetailScreen(capsuleId: id),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final CapsulesProvider capsules = context.watch<CapsulesProvider>();
    final bool showButton = capsules.isLoaded && capsules.capsules.isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr('Cápsulas', 'Capsules')),
        actions: <Widget>[
          IconButton(
            onPressed: () => unawaited(_import(context)),
            icon: const Icon(Icons.file_download_outlined),
            tooltip: context.tr(
              'Importar una cápsula recibida',
              'Import a received capsule',
            ),
          ),
        ],
      ),
      floatingActionButton: showButton
          ? FloatingActionButton.extended(
              onPressed: () => unawaited(_newCapsule(context)),
              icon: const Icon(Icons.add_rounded),
              label: Text(context.tr('Nueva cápsula', 'New capsule')),
            )
          : null,
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: _buildBody(context, capsules),
          ),
        ),
      ),
    );
  }

  Widget _buildBody(BuildContext context, CapsulesProvider capsules) {
    final ThemeData theme = Theme.of(context);

    if (capsules.errorMessage != null && !capsules.isLoaded) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(capsules.errorMessage!, style: theme.textTheme.bodyLarge),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () => unawaited(capsules.load()),
              child: Text(context.tr('Reintentar', 'Try again')),
            ),
          ],
        ),
      );
    }

    if (!capsules.isLoaded) {
      return const Center(child: CircularProgressIndicator());
    }

    if (capsules.capsules.isEmpty) {
      return _EmptyState(
        onCreate: () => unawaited(_newCapsule(context)),
        onImport: () => unawaited(_import(context)),
      );
    }

    final List<Capsule> ready = capsules.readyCapsules;
    final List<Capsule> sealed = capsules.sealedCapsules;
    final List<Capsule> opened = capsules.openedCapsules;

    Widget tile(Capsule capsule) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: _CapsuleTile(
          capsule: capsule,
          status: capsules.statusOf(capsule),
          daysLeft: capsules.daysUntilOpen(capsule),
          hasAttachments: capsule.id != null &&
              capsules.attachmentsFor(capsule.id!).isNotEmpty,
          onTap: () => unawaited(_openDetail(context, capsule)),
        ),
      );
    }

    return ListView(
      // Margen inferior para que el botón flotante no tape la última tarjeta.
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
      children: <Widget>[
        if (ready.isNotEmpty) ...<Widget>[
          _SectionTitle(context.tr('Listas para abrir', 'Ready to open')),
          for (final Capsule capsule in ready) tile(capsule),
        ],
        if (sealed.isNotEmpty) ...<Widget>[
          _SectionTitle(context.tr('Selladas', 'Sealed')),
          for (final Capsule capsule in sealed) tile(capsule),
        ],
        if (opened.isNotEmpty) ...<Widget>[
          _SectionTitle(context.tr('Abiertas', 'Opened')),
          for (final Capsule capsule in opened) tile(capsule),
        ],
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 16, 4, 8),
      child: Text(
        text.toUpperCase(),
        style: theme.textTheme.labelMedium?.copyWith(
          color: theme.colorScheme.primary,
          letterSpacing: 1.6,
        ),
      ),
    );
  }
}

class _CapsuleTile extends StatelessWidget {
  const _CapsuleTile({
    required this.capsule,
    required this.status,
    required this.daysLeft,
    required this.hasAttachments,
    required this.onTap,
  });

  final Capsule capsule;
  final CapsuleStatus status;
  final int daysLeft;
  final bool hasAttachments;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    final IconData icon;
    final String detail;
    final String extra;
    switch (status) {
      case CapsuleStatus.sealed:
        icon = Icons.lock_outline_rounded;
        detail = context.tr(
          'Se abre el ${fullDateLabel(capsule.openDate)}',
          'Opens on ${fullDateLabel(capsule.openDate)}',
        );
        extra = remainingDaysLabel(daysLeft);
      case CapsuleStatus.ready:
        icon = Icons.mark_email_unread_outlined;
        detail = context.tr(
          'Lista desde el ${fullDateLabel(capsule.openDate)}',
          'Ready since ${fullDateLabel(capsule.openDate)}',
        );
        extra = context.tr('Toca para abrirla', 'Tap to open it');
      case CapsuleStatus.opened:
        icon = Icons.drafts_outlined;
        detail = context.tr(
          'Abierta el ${fullDateLabel(capsule.openedAt!)}',
          'Opened on ${fullDateLabel(capsule.openedAt!)}',
        );
        extra = context.tr(
          'Escrita el ${fullDateLabel(capsule.createdAt)}',
          'Written on ${fullDateLabel(capsule.createdAt)}',
        );
    }

    final bool highlighted = status == CapsuleStatus.ready;
    final String? peer = capsulePeerLabel(capsule);

    return PaperCard(
      emphasized: highlighted,
      onTap: onTap,
      child: Row(
        children: <Widget>[
          Icon(icon, color: highlighted ? scheme.primary : scheme.onSurfaceVariant),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  capsule.title.isEmpty
                      ? context.tr('Sin título', 'Untitled')
                      : capsule.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: context.appStyle.displayFamily,
                    fontSize: 18,
                    color: scheme.onSurface,
                  ),
                ),
                if (peer != null)
                  Text(
                    peer,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: scheme.primary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                const SizedBox(height: 4),
                Text(
                  detail,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
                Text(
                  extra,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: highlighted ? scheme.primary : scheme.onSurfaceVariant,
                    fontWeight: highlighted ? FontWeight.w600 : FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          if (hasAttachments) ...<Widget>[
            Icon(
              Icons.attach_file_rounded,
              size: 18,
              color: scheme.onSurfaceVariant,
            ),
            const SizedBox(width: 4),
          ],
          Icon(Icons.chevron_right_rounded, color: scheme.onSurfaceVariant),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.onCreate, required this.onImport});

  final VoidCallback onCreate;
  final VoidCallback onImport;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(Icons.hourglass_empty_rounded, size: 52, color: scheme.outline),
            const SizedBox(height: 20),
            Text(
              context.tr('Aún no hay cápsulas', 'No capsules yet'),
              style: theme.textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            Text(
              context.tr(
                'Escribe hoy un mensaje para tu yo del futuro. Quedará sellado '
                    'hasta el día que elijas y te avisaremos cuando llegue.',
                'Write a message today for your future self. It will stay sealed '
                    'until the day you choose and we will let you know when it '
                    'arrives.',
              ),
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: scheme.onSurfaceVariant,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: onCreate,
              icon: const Icon(Icons.add_rounded),
              label: Text(context.tr('Escribir una cápsula', 'Write a capsule')),
            ),
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: onImport,
              icon: const Icon(Icons.file_download_outlined),
              label: Text(
                context.tr(
                  'Importar una cápsula recibida',
                  'Import a received capsule',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
