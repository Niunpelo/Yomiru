import 'dart:async';

import 'package:flutter/material.dart';

import '../database/database_helper.dart';
import '../models/entry_model.dart';
import '../utils/date_labels.dart';
import '../utils/search_utils.dart';

/// Busca una palabra o frase en todo el diario. Al tocar un resultado se cierra
/// devolviendo su fecha, y la pantalla principal salta a ese día.
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key, this.loadEntries});

  /// Lee las entradas. Solo se cambia en las pruebas.
  final Future<List<Entry>> Function()? loadEntries;

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _controller = TextEditingController();

  SearchIndex? _index;
  bool _failed = false;
  SearchResults _results = SearchResults.empty;

  @override
  void initState() {
    super.initState();
    unawaited(_load());
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final List<Entry> entries =
          await (widget.loadEntries ?? DatabaseHelper.instance.getAllEntries)();
      if (!mounted) {
        return;
      }
      setState(() {
        _index = SearchIndex(entries);
        _results = _index!.search(_controller.text);
      });
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al preparar la búsqueda: $error\n$stackTrace');
      if (mounted) {
        setState(() => _failed = true);
      }
    }
  }

  void _onChanged(String text) {
    final SearchIndex? index = _index;
    if (index == null) {
      return;
    }
    setState(() => _results = index.search(text));
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final bool typed =
        _controller.text.trim().length >= SearchIndex.minQueryLength;

    Widget body;
    if (_failed) {
      body = Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text('No se pudo preparar la búsqueda.', style: theme.textTheme.bodyLarge),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () {
                setState(() => _failed = false);
                unawaited(_load());
              },
              child: const Text('Reintentar'),
            ),
          ],
        ),
      );
    } else if (_index == null) {
      body = const Center(child: CircularProgressIndicator());
    } else if (!typed) {
      body = _Message(
        icon: Icons.search_rounded,
        text: 'Escribe al menos ${SearchIndex.minQueryLength} letras para '
            'buscar en tus ${_index!.length} entradas.',
      );
    } else if (_results.total == 0) {
      body = const _Message(
        icon: Icons.search_off_rounded,
        text: 'No hay ninguna entrada con eso.',
      );
    } else {
      final int shown = _results.hits.length;
      body = ListView.separated(
        padding: const EdgeInsets.fromLTRB(8, 0, 8, 24),
        itemCount: _results.hits.length + 1,
        separatorBuilder: (BuildContext context, int index) =>
            const Divider(height: 1),
        itemBuilder: (BuildContext context, int index) {
          if (index == 0) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
              child: Text(
                _results.total == shown
                    ? (shown == 1 ? '1 resultado' : '$shown resultados')
                    : 'Mostrando los $shown más recientes de ${_results.total}',
                style: theme.textTheme.labelMedium?.copyWith(
                  color: scheme.onSurfaceVariant,
                ),
              ),
            );
          }
          final SearchHit hit = _results.hits[index - 1];
          return _ResultTile(
            hit: hit,
            onTap: () => Navigator.of(context).pop(hit.date),
          );
        },
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _controller,
          autofocus: true,
          textInputAction: TextInputAction.search,
          onChanged: _onChanged,
          decoration: const InputDecoration(
            hintText: 'Buscar en el diario',
            border: InputBorder.none,
          ),
          style: theme.textTheme.titleMedium,
        ),
        actions: <Widget>[
          if (_controller.text.isNotEmpty)
            IconButton(
              onPressed: () {
                _controller.clear();
                _onChanged('');
              },
              icon: const Icon(Icons.close_rounded),
              tooltip: 'Borrar',
            ),
        ],
      ),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: body,
          ),
        ),
      ),
    );
  }
}

class _Message extends StatelessWidget {
  const _Message({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 48, color: scheme.outline),
            const SizedBox(height: 16),
            Text(
              text,
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: scheme.onSurfaceVariant,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ResultTile extends StatelessWidget {
  const _ResultTile({required this.hit, required this.onTap});

  final SearchHit hit;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final Snippet snippet = buildSnippet(
      hit.entry.content,
      hit.matchStart,
      hit.matchLength,
    );
    final TextStyle? base = theme.textTheme.bodyMedium?.copyWith(
      color: scheme.onSurfaceVariant,
      height: 1.4,
    );

    return ListTile(
      onTap: onTap,
      title: Text(fullDateLabel(hit.date)),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Text.rich(
          TextSpan(
            style: base,
            children: <InlineSpan>[
              TextSpan(text: snippet.before),
              TextSpan(
                text: snippet.match,
                style: TextStyle(
                  color: scheme.primary,
                  fontWeight: FontWeight.w700,
                ),
              ),
              TextSpan(text: snippet.after),
            ],
          ),
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
        ),
      ),
    );
  }
}
