import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../database/database_helper.dart';
import '../utils/date_labels.dart';
import '../utils/streak_stats.dart';
import '../widgets/paper_card.dart';

/// Calendario con un sello rojo en cada día en el que se escribió algo, y las
/// rachas de escritura. Al tocar un día se cierra devolviendo su fecha, y la
/// pantalla principal salta a él.
class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key, this.loadDays, this.now});

  /// Lee los días escritos. Solo se cambia en las pruebas.
  final Future<Set<DateTime>> Function()? loadDays;

  /// Reloj. Solo se cambia en las pruebas.
  final DateTime Function()? now;

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  /// Cuántos años hacia atrás se puede navegar.
  static const int _yearsBackAllowed = 25;

  Set<DateTime>? _days;
  StreakStats _stats = StreakStats.empty;
  bool _failed = false;
  late DateTime _month;

  DateTime get _today {
    final DateTime now = (widget.now ?? DateTime.now)();
    return DateTime(now.year, now.month, now.day);
  }

  @override
  void initState() {
    super.initState();
    final DateTime today = _today;
    _month = DateTime(today.year, today.month);
    unawaited(_load());
  }

  Future<void> _load() async {
    try {
      final Set<DateTime> days =
          await (widget.loadDays ?? DatabaseHelper.instance.getWrittenDays)();
      if (!mounted) {
        return;
      }
      setState(() {
        _days = days;
        _stats = StreakStats.compute(days, _today);
      });
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al leer los días escritos: $error\n$stackTrace');
      if (mounted) {
        setState(() => _failed = true);
      }
    }
  }

  bool get _canGoNext {
    final DateTime today = _today;
    return _month.year < today.year ||
        (_month.year == today.year && _month.month < today.month);
  }

  bool get _canGoPrevious => _month.year > _today.year - _yearsBackAllowed;

  void _shiftMonth(int delta) {
    setState(() => _month = DateTime(_month.year, _month.month + delta));
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);

    Widget body;
    if (_failed) {
      body = Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text('No se pudo leer el calendario.', style: theme.textTheme.bodyLarge),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () {
                setState(() => _failed = false);
                unawaited(_load());
              },
              child: const Text('Reintentar'),
            ),
          ],
        ),
      );
    } else if (_days == null) {
      body = const Center(child: CircularProgressIndicator());
    } else {
      body = ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: <Widget>[
          _StatsRow(stats: _stats),
          const SizedBox(height: 16),
          PaperCard(
            child: Column(
              children: <Widget>[
                _MonthHeader(
                  month: _month,
                  onPrevious: _canGoPrevious ? () => _shiftMonth(-1) : null,
                  onNext: _canGoNext ? () => _shiftMonth(1) : null,
                ),
                const SizedBox(height: 8),
                _MonthGrid(
                  month: _month,
                  today: _today,
                  writtenDays: _days!,
                  onSelect: (DateTime date) => Navigator.of(context).pop(date),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Cada sello es un día en el que escribiste o guardaste una foto o '
            'una nota de voz. Toca un día para verlo en el diario.',
            textAlign: TextAlign.center,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
              height: 1.5,
            ),
          ),
        ],
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Calendario')),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: body,
          ),
        ),
      ),
    );
  }
}

class _StatsRow extends StatelessWidget {
  const _StatsRow({required this.stats});

  final StreakStats stats;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(child: _StatTile(value: stats.current, label: 'Racha actual')),
        const SizedBox(width: 10),
        Expanded(child: _StatTile(value: stats.best, label: 'Mejor racha')),
        const SizedBox(width: 10),
        Expanded(child: _StatTile(value: stats.totalDays, label: 'Días escritos')),
      ],
    );
  }
}

class _StatTile extends StatelessWidget {
  const _StatTile({required this.value, required this.label});

  final int value;
  final String label;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        children: <Widget>[
          Text(
            '$value',
            style: theme.textTheme.headlineSmall?.copyWith(color: scheme.primary),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            textAlign: TextAlign.center,
            style: theme.textTheme.labelSmall?.copyWith(
              color: scheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

class _MonthHeader extends StatelessWidget {
  const _MonthHeader({
    required this.month,
    required this.onPrevious,
    required this.onNext,
  });

  final DateTime month;
  final VoidCallback? onPrevious;
  final VoidCallback? onNext;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);

    return Row(
      children: <Widget>[
        IconButton(
          onPressed: onPrevious,
          icon: const Icon(Icons.chevron_left_rounded),
          tooltip: 'Mes anterior',
        ),
        Expanded(
          child: Text(
            capitalize(DateFormat.yMMMM('es').format(month)),
            textAlign: TextAlign.center,
            style: theme.textTheme.titleMedium,
          ),
        ),
        IconButton(
          onPressed: onNext,
          icon: const Icon(Icons.chevron_right_rounded),
          tooltip: 'Mes siguiente',
        ),
      ],
    );
  }
}

class _MonthGrid extends StatelessWidget {
  const _MonthGrid({
    required this.month,
    required this.today,
    required this.writtenDays,
    required this.onSelect,
  });

  static const List<String> _weekdays = <String>['L', 'M', 'X', 'J', 'V', 'S', 'D'];

  final DateTime month;
  final DateTime today;
  final Set<DateTime> writtenDays;
  final ValueChanged<DateTime> onSelect;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    // Lunes = 1 ... domingo = 7: los huecos antes del día 1.
    final int blanks = DateTime(month.year, month.month, 1).weekday - 1;
    final int daysInMonth = DateTime(month.year, month.month + 1, 0).day;

    final List<Widget> cells = <Widget>[
      for (final String letter in _weekdays)
        Center(
          child: Text(
            letter,
            style: theme.textTheme.labelMedium?.copyWith(
              color: scheme.onSurfaceVariant,
            ),
          ),
        ),
      for (int i = 0; i < blanks; i++) const SizedBox.shrink(),
      for (int day = 1; day <= daysInMonth; day++)
        _DayCell(
          date: DateTime(month.year, month.month, day),
          today: today,
          written: writtenDays.contains(DateTime(month.year, month.month, day)),
          onSelect: onSelect,
        ),
    ];

    return GridView.count(
      crossAxisCount: 7,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 4,
      crossAxisSpacing: 4,
      children: cells,
    );
  }
}

class _DayCell extends StatelessWidget {
  const _DayCell({
    required this.date,
    required this.today,
    required this.written,
    required this.onSelect,
  });

  final DateTime date;
  final DateTime today;
  final bool written;
  final ValueChanged<DateTime> onSelect;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    final bool future = date.isAfter(today);
    final bool isToday = date == today;

    final Color textColor;
    if (written) {
      textColor = scheme.onPrimary;
    } else if (future) {
      textColor = scheme.onSurfaceVariant.withValues(alpha: 0.4);
    } else {
      textColor = scheme.onSurface;
    }

    return Semantics(
      button: !future,
      label: '${dayMonthLabel(date)}${written ? ', con entrada' : ''}',
      excludeSemantics: true,
      child: InkWell(
        onTap: future ? null : () => onSelect(date),
        borderRadius: BorderRadius.circular(6),
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            // El sello: un cuadrado rojo como el de un hanko.
            color: written ? scheme.primary : null,
            borderRadius: BorderRadius.circular(6),
            border: isToday
                ? Border.all(color: scheme.primary, width: 1.6)
                : null,
          ),
          child: Text(
            '${date.day}',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: textColor,
              fontWeight: written || isToday ? FontWeight.w600 : FontWeight.w400,
            ),
          ),
        ),
      ),
    );
  }
}
