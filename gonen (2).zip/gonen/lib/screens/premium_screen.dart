import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/attachment_limits.dart';
import '../models/premium_entitlement.dart';
import '../providers/premium_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/paper_card.dart';

/// Pantalla de Gonen Premium: qué incluye y cómo comprarlo (suscripción anual
/// o pago único).
class PremiumScreen extends StatelessWidget {
  const PremiumScreen({super.key});

  /// Precios orientativos que se enseñan si Google Play no los ha devuelto.
  static const String _fallbackYearlyPrice = '9,99 €';
  static const String _fallbackLifetimePrice = '14,99 €';

  Future<void> _buy(BuildContext context, PremiumPlan plan) async {
    final PremiumProvider premium = context.read<PremiumProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final String? error = await premium.purchase(plan);
    if (error != null) {
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(error)));
    }
  }

  Future<void> _restore(BuildContext context) async {
    final PremiumProvider premium = context.read<PremiumProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final String? error = await premium.restorePurchases();
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(
            error ??
                'Buscando tus compras en Google Play. Si tienes alguna activa, '
                    'se recuperará en unos segundos.',
          ),
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    final PremiumProvider premium = context.watch<PremiumProvider>();
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final PremiumPlan plan = premium.plan;
    final bool storeReady = premium.storeAvailable && premium.productsLoaded;

    return Scaffold(
      appBar: AppBar(title: const Text('Premium')),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
              children: <Widget>[
                Icon(Icons.star_outline_rounded, size: 52, color: scheme.primary),
                const SizedBox(height: 12),
                Text(
                  'Gonen Premium',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.headlineMedium,
                ),
                const SizedBox(height: 8),
                Text(
                  'Guarda también cómo se veía y cómo sonaba tu día.',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 24),
                const _Benefit(
                  icon: Icons.photo_camera_outlined,
                  text: 'Fotos: hasta ${AttachmentLimits.maxImagesPerDay} por día, '
                      'desde la cámara o la galería.',
                ),
                const _Benefit(
                  icon: Icons.mic_none_rounded,
                  text: 'Notas de voz: hasta ${AttachmentLimits.maxVoiceNotesPerDay} '
                      'por día, de hasta ${AttachmentLimits.maxVoiceSeconds ~/ 60} '
                      'minutos cada una.',
                ),
                const _Benefit(
                  icon: Icons.schedule_rounded,
                  text: 'Se añaden el propio día, hasta las 23:59, igual que el '
                      'texto.',
                ),
                const _Benefit(
                  icon: Icons.visibility_outlined,
                  text: 'Lo que guardes podrás verlo y escucharlo siempre, '
                      'aunque dejes de ser premium.',
                ),
                const SizedBox(height: 16),
                if (premium.message != null) ...<Widget>[
                  _MessageCard(
                    message: premium.message!,
                    onClose: premium.clearMessage,
                  ),
                  const SizedBox(height: 16),
                ],
                if (premium.isTestUnlock) ...<Widget>[
                  const _InfoCard(
                    icon: Icons.science_outlined,
                    text: 'Compilación de prueba: el premium está desbloqueado '
                        'sin pagar. No es una versión para publicar.',
                  ),
                  const SizedBox(height: 16),
                ],
                if (plan != PremiumPlan.none)
                  _ActiveCard(plan: plan)
                else ...<Widget>[
                  if (!storeReady) ...<Widget>[
                    const _InfoCard(
                      icon: Icons.info_outline_rounded,
                      text: 'Las compras solo están disponibles en la versión de '
                          'Gonen instalada desde Google Play. Aquí todavía no se '
                          'pueden hacer.',
                    ),
                    const SizedBox(height: 16),
                  ],
                  _PlanCard(
                    title: 'Anual',
                    price: premium.yearlyPrice ?? _fallbackYearlyPrice,
                    priceNote: 'al año',
                    detail: 'Se renueva cada año hasta que la canceles en Google '
                        'Play.',
                    buttonLabel: 'Suscribirme',
                    emphasized: true,
                    onPressed: premium.isBusy || !premium.yearlyAvailable
                        ? null
                        : () => unawaited(_buy(context, PremiumPlan.yearly)),
                  ),
                  const SizedBox(height: 12),
                  _PlanCard(
                    title: 'De por vida',
                    price: premium.lifetimePrice ?? _fallbackLifetimePrice,
                    priceNote: 'pago único',
                    detail: 'Se paga una sola vez y no caduca.',
                    buttonLabel: 'Comprar',
                    emphasized: false,
                    onPressed: premium.isBusy || !premium.lifetimeAvailable
                        ? null
                        : () => unawaited(_buy(context, PremiumPlan.lifetime)),
                  ),
                ],
                const SizedBox(height: 12),
                Center(
                  child: TextButton(
                    onPressed: () => unawaited(_restore(context)),
                    child: const Text('Restaurar compras'),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Los pagos los gestiona Google Play. Puedes cancelar la '
                  'suscripción cuando quieras en Google Play > Pagos y '
                  'suscripciones > Suscripciones.',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Benefit extends StatelessWidget {
  const _Benefit({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(icon, size: 22, color: theme.colorScheme.primary),
          const SizedBox(width: 14),
          Expanded(child: Text(text, style: theme.textTheme.bodyMedium)),
        ],
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  const _PlanCard({
    required this.title,
    required this.price,
    required this.priceNote,
    required this.detail,
    required this.buttonLabel,
    required this.emphasized,
    required this.onPressed,
  });

  final String title;
  final String price;
  final String priceNote;
  final String detail;
  final String buttonLabel;
  final bool emphasized;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return PaperCard(
      emphasized: emphasized,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Text(
                title,
                style: TextStyle(
                  fontFamily: kSerifFamily,
                  fontSize: 22,
                  color: scheme.onSurface,
                ),
              ),
              const Spacer(),
              Text(
                price,
                style: TextStyle(
                  fontFamily: kSerifFamily,
                  fontSize: 26,
                  color: scheme.primary,
                ),
              ),
              const SizedBox(width: 6),
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(
                  priceNote,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            detail,
            style: theme.textTheme.bodySmall?.copyWith(
              color: scheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: emphasized
                ? FilledButton(onPressed: onPressed, child: Text(buttonLabel))
                : OutlinedButton(onPressed: onPressed, child: Text(buttonLabel)),
          ),
        ],
      ),
    );
  }
}

class _ActiveCard extends StatelessWidget {
  const _ActiveCard({required this.plan});

  final PremiumPlan plan;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final String detail = plan == PremiumPlan.lifetime
        ? 'Pago único: no caduca.'
        : 'Suscripción anual. Se gestiona en Google Play > Pagos y '
            'suscripciones > Suscripciones.';

    return PaperCard(
      emphasized: true,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(Icons.check_circle_outline_rounded, color: scheme.primary),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text('Gonen Premium activo', style: theme.textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  detail,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return PaperCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(icon, color: theme.colorScheme.onSurfaceVariant),
          const SizedBox(width: 14),
          Expanded(child: Text(text, style: theme.textTheme.bodyMedium)),
        ],
      ),
    );
  }
}

class _MessageCard extends StatelessWidget {
  const _MessageCard({required this.message, required this.onClose});

  final String message;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return PaperCard(
      emphasized: true,
      child: Row(
        children: <Widget>[
          Expanded(child: Text(message, style: theme.textTheme.bodyMedium)),
          IconButton(
            onPressed: onClose,
            icon: const Icon(Icons.close_rounded),
            tooltip: 'Cerrar aviso',
          ),
        ],
      ),
    );
  }
}
