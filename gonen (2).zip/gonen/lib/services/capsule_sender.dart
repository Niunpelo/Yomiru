import 'package:flutter/foundation.dart';

import '../l10n/tr.dart';
import '../models/attachment_model.dart';
import '../models/capsule_model.dart';
import 'capsule_share_service.dart';
import 'file_transfer_service.dart';

/// Cómo ha terminado el envío de una cápsula.
enum CapsuleSendResult {
  /// Se abrió el menú de compartir de Android con el archivo.
  shared,

  /// No se pudo abrir el menú de compartir y el archivo se guardó donde el
  /// usuario quiso, para que lo envíe él.
  saved,

  /// El usuario canceló al elegir dónde guardar el archivo.
  cancelled,
}

/// Error al preparar o enviar una cápsula, con un mensaje en el idioma de la app.
class CapsuleSendException implements Exception {
  const CapsuleSendException(this.message);

  final String message;

  @override
  String toString() => message;
}

/// Prepara el archivo de una cápsula y lo ofrece para enviar.
///
/// Primero abre el menú de compartir de Android (WhatsApp, correo...). Si no
/// se puede, guarda el archivo con el selector de documentos para que el
/// usuario lo envíe a mano.
class CapsuleSender {
  CapsuleSender({
    CapsuleShareService? shareService,
    FileTransferService? transfer,
  })  : _share = shareService ?? CapsuleShareService(),
        _transfer = transfer ?? const FileTransferService();

  final CapsuleShareService _share;
  final FileTransferService _transfer;

  Future<CapsuleSendResult> send(
    Capsule capsule,
    List<Attachment> attachments,
  ) async {
    final CapsulePackage package;
    try {
      package = await _share.build(capsule: capsule, attachments: attachments);
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al preparar la cápsula: $error\n$stackTrace');
      throw CapsuleSendException(
        tr(
          'No se pudo preparar el archivo de la cápsula.',
          'The capsule file could not be prepared.',
        ),
      );
    }

    try {
      await _transfer.shareFile(
        path: package.file.path,
        text: package.message,
        subject: tr(
          'Una cápsula del tiempo para ti',
          'A time capsule for you',
        ),
      );
      // El archivo se queda en la carpeta temporal: la otra app lo lee después
      // de que esta función termine.
      return CapsuleSendResult.shared;
    } on FileTransferException catch (error) {
      debugPrint('Gonen: no se pudo compartir, se guarda el archivo: $error');
    }

    try {
      final bool saved = await _transfer.saveFile(
        sourcePath: package.file.path,
        suggestedName: package.fileName,
      );
      return saved ? CapsuleSendResult.saved : CapsuleSendResult.cancelled;
    } on FileTransferException catch (error) {
      throw CapsuleSendException(error.message);
    }
  }
}
