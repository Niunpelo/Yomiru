import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Hasta qué punto se puede fiar Gonen de la fecha del móvil.
enum ClockTrust {
  /// La fecha es fiable: es automática (la pone la red) o coincide con el
  /// contador interno de Android.
  ok,

  /// La fecha del móvil se ha cambiado a mano. Gonen usa la que calcula con el
  /// contador interno de Android, que el usuario no puede tocar.
  adjusted,

  /// No hay forma de saber qué día es de verdad: la fecha es manual y Gonen no
  /// tiene un punto de referencia anterior. No se abre ninguna cápsula hasta
  /// que se activen la fecha y la hora automáticas.
  unverifiable,
}

/// Lo que Android cuenta del reloj y el usuario no puede cambiar a mano.
@immutable
class ClockSnapshot {
  const ClockSnapshot({
    required this.elapsedMs,
    required this.bootCount,
    required this.autoTime,
  });

  /// Milisegundos desde que arrancó el móvil (también cuenta el reposo). Solo
  /// avanza y no depende de la fecha.
  final int elapsedMs;

  /// Cuántas veces ha arrancado el móvil, o -1 si Android no lo dice.
  final int bootCount;

  /// «Fecha y hora automáticas» está activado: la fecha la pone la red y no se
  /// puede cambiar desde los ajustes.
  final bool autoTime;
}

/// Último momento en que Gonen supo qué hora era de verdad.
@immutable
class ClockAnchor {
  const ClockAnchor({
    required this.trustedMs,
    required this.elapsedMs,
    required this.bootCount,
  });

  /// La fecha real en ese momento (milisegundos desde 1970).
  final int trustedMs;

  /// El contador desde el arranque en ese momento.
  final int elapsedMs;

  /// El número de arranques en ese momento.
  final int bootCount;
}

/// Resultado de mirar el reloj.
@immutable
class ClockReading {
  const ClockReading({
    required this.wall,
    required this.now,
    required this.trust,
  });

  /// Lo que marca el reloj del móvil.
  final DateTime wall;

  /// La fecha y hora que Gonen da por buenas.
  final DateTime now;

  final ClockTrust trust;
}

/// Calcula la fecha de verdad aunque se cambie la del móvil, para que no se
/// pueda abrir una cápsula antes de tiempo adelantando el reloj.
///
/// Se apoya en dos cosas que el usuario no puede cambiar a mano:
///
/// * Si «Fecha y hora automáticas» está activado, la fecha la pone la red y no
///   se puede cambiar desde los ajustes: se usa tal cual y se guarda como
///   punto de referencia (fecha real + contador de Android desde el arranque).
/// * Si está desactivado (fecha manual), la fecha del móvil puede estar
///   cambiada. Mientras no se reinicie el móvil, la fecha real es la del
///   último punto de referencia más el tiempo que ha contado Android desde
///   entonces. Si se reinicia, el contador vuelve a cero y ya no hay forma de
///   saberlo: no se abre nada hasta activar la fecha automática.
///
/// Si no se puede leer el contador (por ejemplo, en las pruebas o fuera de
/// Android), se usa el reloj del móvil sin más: es mejor no bloquear las
/// cápsulas de nadie por un fallo de esta comprobación.
///
/// No puede frenar a quien tenga acceso a los archivos del móvil o lo tenga
/// manipulado (root): las cápsulas se guardan en la base de datos local.
class TrustedClock {
  TrustedClock({
    DateTime Function()? wallClock,
    Future<ClockSnapshot?> Function()? probe,
  })  : _wallClock = wallClock ?? DateTime.now,
        _probe = probe ?? _platformProbe;

  static const MethodChannel _channel = MethodChannel('gonen/files');

  static const String _trustedKey = 'clock_anchor_trusted_ms';
  static const String _elapsedKey = 'clock_anchor_elapsed_ms';
  static const String _bootKey = 'clock_anchor_boot_count';

  /// Diferencia máxima entre el reloj del móvil y el contador de Android para
  /// dar la fecha por buena (las correcciones de la red son de segundos).
  static const Duration tolerance = Duration(minutes: 3);

  final DateTime Function() _wallClock;
  final Future<ClockSnapshot?> Function() _probe;

  /// Mira el reloj, aplica las reglas y guarda el nuevo punto de referencia.
  /// Nunca lanza excepciones.
  Future<ClockReading> read() async {
    final DateTime wall = _wallClock();
    try {
      final ClockSnapshot? snapshot = await _probe();
      if (snapshot == null) {
        return ClockReading(wall: wall, now: wall, trust: ClockTrust.ok);
      }
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final ({ClockReading reading, ClockAnchor? anchor}) result = evaluate(
        wall: wall,
        snapshot: snapshot,
        anchor: _loadAnchor(prefs),
      );
      final ClockAnchor? next = result.anchor;
      if (next != null) {
        await prefs.setInt(_trustedKey, next.trustedMs);
        await prefs.setInt(_elapsedKey, next.elapsedMs);
        await prefs.setInt(_bootKey, next.bootCount);
      }
      return result.reading;
    } catch (error) {
      debugPrint('Gonen: no se pudo comprobar la fecha del móvil: $error');
      return ClockReading(wall: wall, now: wall, trust: ClockTrust.ok);
    }
  }

  /// Las reglas, sin tocar el móvil: con lo que marca el reloj ([wall]), lo que
  /// cuenta Android ([snapshot]) y el último punto de referencia ([anchor]),
  /// dice qué fecha dar por buena y cuál es el nuevo punto de referencia (null
  /// si no hay que guardar ninguno).
  @visibleForTesting
  static ({ClockReading reading, ClockAnchor? anchor}) evaluate({
    required DateTime wall,
    required ClockSnapshot snapshot,
    required ClockAnchor? anchor,
  }) {
    // Fecha automática: la pone la red y no se puede cambiar a mano.
    if (snapshot.autoTime) {
      return (
        reading: ClockReading(wall: wall, now: wall, trust: ClockTrust.ok),
        anchor: ClockAnchor(
          trustedMs: wall.millisecondsSinceEpoch,
          elapsedMs: snapshot.elapsedMs,
          bootCount: snapshot.bootCount,
        ),
      );
    }

    // Fecha manual, pero sin reiniciar desde el último punto de referencia.
    final bool sameBoot = anchor != null &&
        anchor.bootCount == snapshot.bootCount &&
        snapshot.elapsedMs >= anchor.elapsedMs;
    if (anchor != null && sameBoot) {
      final DateTime counted = DateTime.fromMillisecondsSinceEpoch(
        anchor.trustedMs + (snapshot.elapsedMs - anchor.elapsedMs),
      );
      final bool agrees = wall.difference(counted).abs() <= tolerance;
      // Si coinciden, manda el reloj (así el error del contador no se
      // acumula); si no, la fecha del móvil está cambiada y manda el contador.
      final DateTime trusted = agrees ? wall : counted;
      return (
        reading: ClockReading(
          wall: wall,
          now: trusted,
          trust: agrees ? ClockTrust.ok : ClockTrust.adjusted,
        ),
        anchor: ClockAnchor(
          trustedMs: trusted.millisecondsSinceEpoch,
          elapsedMs: snapshot.elapsedMs,
          bootCount: snapshot.bootCount,
        ),
      );
    }

    // Fecha manual y ningún punto de referencia fiable: no hay forma de saber
    // qué día es. No se guarda nada, para no fiarse de una fecha sin comprobar.
    return (
      reading: ClockReading(wall: wall, now: wall, trust: ClockTrust.unverifiable),
      anchor: null,
    );
  }

  static ClockAnchor? _loadAnchor(SharedPreferences prefs) {
    final int? trusted = prefs.getInt(_trustedKey);
    final int? elapsed = prefs.getInt(_elapsedKey);
    final int? boot = prefs.getInt(_bootKey);
    if (trusted == null || elapsed == null || boot == null) {
      return null;
    }
    return ClockAnchor(trustedMs: trusted, elapsedMs: elapsed, bootCount: boot);
  }

  /// Pregunta a Android (canal `gonen/files`, ver `tool/patch_android.py`).
  static Future<ClockSnapshot?> _platformProbe() async {
    try {
      final Map<Object?, Object?>? info =
          await _channel.invokeMapMethod<Object?, Object?>('clockInfo');
      if (info == null) {
        return null;
      }
      final Object? elapsed = info['elapsed'];
      final Object? boot = info['boot'];
      final Object? auto = info['auto'];
      if (elapsed is! int) {
        return null;
      }
      return ClockSnapshot(
        elapsedMs: elapsed,
        bootCount: boot is int ? boot : -1,
        autoTime: auto is bool ? auto : true,
      );
    } on MissingPluginException {
      return null;
    } on PlatformException {
      return null;
    }
  }
}
