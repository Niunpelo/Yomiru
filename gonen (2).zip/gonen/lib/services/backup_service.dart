import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../app_info.dart';
import '../database/database_helper.dart';
import '../l10n/tr.dart';
import '../models/attachment_model.dart';
import '../models/backup_snapshot.dart';
import '../models/capsule_model.dart';
import '../models/entry_model.dart';
import 'attachment_service.dart';
import 'backup_archive.dart';
import 'capsule_cipher.dart';

/// Resultado de crear una copia de seguridad.
class BackupCreateResult {
  const BackupCreateResult({
    required this.file,
    required this.fileName,
    required this.sizeBytes,
    required this.entries,
    required this.capsules,
    required this.photos,
    required this.voiceNotes,
    required this.missingFiles,
  });

  /// Archivo temporal con la copia, listo para que el usuario lo guarde donde quiera.
  final File file;

  /// Nombre sugerido, por ejemplo `gonen-copia-2026-11-05.gonen`.
  final String fileName;

  final int sizeBytes;
  final int entries;
  final int capsules;
  final int photos;
  final int voiceNotes;

  /// Fotos o notas de voz que figuraban en la base de datos pero ya no existían
  /// como archivo, y por tanto no están en la copia.
  final int missingFiles;
}

/// Resultado de restaurar una copia de seguridad.
class BackupRestoreResult {
  const BackupRestoreResult({
    required this.merge,
    required this.filesRestored,
    required this.attachmentsWithoutFile,
  });

  /// Qué se añadió a la base de datos.
  final BackupMergeResult merge;

  /// Archivos de fotos y notas de voz copiados a este móvil.
  final int filesRestored;

  /// Adjuntos de la copia que se descartaron porque su archivo no venía en ella.
  final int attachmentsWithoutFile;
}

/// Crea y restaura copias de seguridad en un archivo `.gonen`.
///
/// * Crear la copia vuelca todo (texto, cápsulas, fotos y notas de voz) a un
///   archivo temporal; después la pantalla se lo entrega al usuario para que
///   lo guarde donde quiera.
/// * Restaurar **nunca borra ni sobrescribe** lo que ya hay en el móvil: solo
///   añade lo que falta.
class BackupService {
  BackupService({
    DatabaseHelper? databaseHelper,
    AttachmentService? attachmentService,
    DateTime Function()? clock,
    Future<Directory> Function()? temporaryDirectory,
  })  : _db = databaseHelper ?? DatabaseHelper.instance,
        _files = attachmentService ?? AttachmentService.instance,
        _clock = clock ?? DateTime.now,
        _temporaryDirectory = temporaryDirectory ?? getTemporaryDirectory;

  /// Extensión de los archivos de copia.
  static const String fileExtension = 'gonen';

  static const String _lastBackupKey = 'last_backup_ms';

  /// Día del año válido: "MM-DD" con mes 01-12 y día 01-31.
  static final RegExp _dayKeyPattern =
      RegExp(r'^(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])$');

  final DatabaseHelper _db;
  final AttachmentService _files;
  final DateTime Function() _clock;
  final Future<Directory> Function() _temporaryDirectory;

  /// Nombre de archivo sugerido para una copia hecha en [date].
  static String suggestedFileName(DateTime date) =>
      '${tr('gonen-copia', 'gonen-backup')}-${Capsule.dateKey(date)}.$fileExtension';

  // ---------------------------------------------------------------------------
  // Fecha de la última copia
  // ---------------------------------------------------------------------------

  /// Cuándo se guardó la última copia desde este móvil, o null si nunca.
  Future<DateTime?> lastBackupAt() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final int? millis = prefs.getInt(_lastBackupKey);
      return millis == null ? null : DateTime.fromMillisecondsSinceEpoch(millis);
    } catch (error) {
      debugPrint('Gonen: no se pudo leer la fecha de la última copia: $error');
      return null;
    }
  }

  /// Anota que la copia se ha guardado ahora.
  Future<void> markBackupDone() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_lastBackupKey, _clock().millisecondsSinceEpoch);
    } catch (error) {
      debugPrint('Gonen: no se pudo anotar la fecha de la copia: $error');
    }
  }

  // ---------------------------------------------------------------------------
  // Crear
  // ---------------------------------------------------------------------------

  /// Crea la copia en un archivo temporal. El llamador debe borrarlo con
  /// [discard] cuando ya lo haya entregado.
  Future<BackupCreateResult> create() async {
    final List<Entry> entries = <Entry>[
      for (final Entry entry in await _db.getAllEntries())
        if (!entry.isBlank) entry,
    ];
    final List<Capsule> capsules = await _db.getCapsules();

    // Solo entran los adjuntos cuyo archivo existe de verdad.
    final List<Attachment> included = <Attachment>[];
    final Set<String> seen = <String>{};
    int missing = 0;
    for (final Attachment attachment in await _db.getAllAttachments()) {
      final String path = attachment.relativePath;
      if (!BackupArchive.isSafeAttachmentPath(path) || !await _files.exists(path)) {
        missing++;
      } else if (seen.add(path)) {
        included.add(attachment);
      }
    }

    final DateTime now = _clock();
    final BackupSnapshot snapshot = BackupSnapshot(
      entries: entries,
      capsules: capsules,
      attachments: included,
      appVersion: kAppVersion,
      createdAt: now,
    );

    final Directory temp = await _temporaryDirectory();
    final String fileName = suggestedFileName(now);
    final File file = File(p.join(temp.path, fileName));

    final BackupArchiveWriter writer = await BackupArchiveWriter.create(file);
    try {
      await writer.addBytes(
        BackupArchive.dataEntry,
        utf8.encode(jsonEncode(snapshot.toJson())),
      );
      for (final Attachment attachment in included) {
        await writer.addFile(
          '${BackupArchive.filesPrefix}${attachment.relativePath}',
          _files.fileFor(attachment.relativePath),
        );
      }
      await writer.close();
    } catch (_) {
      await writer.abort();
      await _deleteQuietly(file);
      rethrow;
    }

    return BackupCreateResult(
      file: file,
      fileName: fileName,
      sizeBytes: await file.length(),
      entries: entries.length,
      capsules: capsules.length,
      photos: included
          .where((Attachment item) => item.type == AttachmentType.image)
          .length,
      voiceNotes: included
          .where((Attachment item) => item.type == AttachmentType.audio)
          .length,
      missingFiles: missing,
    );
  }

  /// Borra el archivo temporal de una copia ya entregada. Nunca lanza.
  Future<void> discard(File file) => _deleteQuietly(file);

  // ---------------------------------------------------------------------------
  // Restaurar
  // ---------------------------------------------------------------------------

  /// Añade a este móvil lo que haya en la copia [source] y todavía no esté.
  ///
  /// Lanza [FormatException] (con un mensaje en el idioma de la app) si el archivo no es
  /// una copia de Gonen o está dañado. Si algo falla a medias, los archivos que
  /// ya se habían copiado se borran y la base de datos no cambia.
  Future<BackupRestoreResult> restore(File source) async {
    await _rejectCapsuleFile(source);
    final BackupArchiveReader reader = await BackupArchiveReader.open(source);
    final List<String> extracted = <String>[];
    try {
      final BackupEntryHeader? first = await reader.next();
      if (first == null || first.name != BackupArchive.dataEntry) {
        throw FormatException(
          tr(
            'La copia de seguridad está incompleta o dañada.',
            'The backup is incomplete or damaged.',
          ),
        );
      }
      final BackupSnapshot snapshot = _sanitize(
        BackupSnapshot.fromJson(
          jsonDecode(utf8.decode(await reader.readEntryBytes())),
        ),
      );

      final Set<String> wanted = <String>{
        for (final Attachment attachment in snapshot.attachments)
          attachment.relativePath,
      };

      int filesRestored = 0;
      while (true) {
        final BackupEntryHeader? header = await reader.next();
        if (header == null) {
          break;
        }
        if (!header.name.startsWith(BackupArchive.filesPrefix)) {
          continue;
        }
        final String relativePath =
            header.name.substring(BackupArchive.filesPrefix.length);
        if (!BackupArchive.isSafeAttachmentPath(relativePath) ||
            !wanted.contains(relativePath)) {
          continue;
        }
        if (await _files.exists(relativePath)) {
          continue;
        }

        final File target = await _files.prepareFile(relativePath);
        final File partial = File('${target.path}.part');
        try {
          await reader.copyEntryTo(partial);
          await partial.rename(target.path);
        } catch (_) {
          await _deleteQuietly(partial);
          rethrow;
        }
        extracted.add(relativePath);
        filesRestored++;
      }

      // Solo se registran los adjuntos cuyo archivo está ya en este móvil.
      final List<Attachment> usable = <Attachment>[];
      for (final Attachment attachment in snapshot.attachments) {
        if (await _files.exists(attachment.relativePath)) {
          usable.add(attachment);
        }
      }

      final BackupMergeResult merge = await _db.mergeSnapshot(
        BackupSnapshot(
          entries: snapshot.entries,
          capsules: snapshot.capsules,
          attachments: usable,
        ),
      );
      return BackupRestoreResult(
        merge: merge,
        filesRestored: filesRestored,
        attachmentsWithoutFile: snapshot.attachments.length - usable.length,
      );
    } catch (_) {
      for (final String relativePath in extracted) {
        await _files.delete(relativePath);
      }
      rethrow;
    } finally {
      await reader.close();
    }
  }

  /// Si el archivo es una cápsula recibida (y no una copia de seguridad), lo
  /// dice con un mensaje claro en lugar de «no es una copia».
  Future<void> _rejectCapsuleFile(File source) async {
    final RandomAccessFile input = await source.open();
    try {
      final List<int> head = await input.read(CapsuleCipher.magic.length);
      if (head.length == CapsuleCipher.magic.length) {
        bool same = true;
        for (int i = 0; i < head.length; i++) {
          if (head[i] != CapsuleCipher.magic[i]) {
            same = false;
            break;
          }
        }
        if (same) {
          throw FormatException(
            tr(
              'Este archivo es una cápsula, no una copia de seguridad. '
                  'Impórtala desde el menú, en «Cápsulas».',
              'This file is a capsule, not a backup. Import it from the menu, '
                  'under “Capsules”.',
            ),
          );
        }
      }
    } finally {
      await input.close();
    }
  }

  /// Quita de [snapshot] todo lo que no tenga el aspecto de datos de Gonen
  /// (días imposibles, rutas raras), por si el archivo está manipulado.
  BackupSnapshot _sanitize(BackupSnapshot snapshot) {
    bool validDay(String key, int year) =>
        _dayKeyPattern.hasMatch(key) && year >= 1900 && year <= 9999;

    return BackupSnapshot(
      appVersion: snapshot.appVersion,
      createdAt: snapshot.createdAt,
      entries: <Entry>[
        for (final Entry entry in snapshot.entries)
          if (validDay(entry.dayOfYear, entry.year)) entry,
      ],
      capsules: snapshot.capsules,
      attachments: <Attachment>[
        for (final Attachment attachment in snapshot.attachments)
          if (BackupArchive.isSafeAttachmentPath(attachment.relativePath) &&
              (attachment.capsuleId != null ||
                  validDay(attachment.dayOfYear, attachment.year)))
            attachment,
      ],
    );
  }

  Future<void> _deleteQuietly(File file) async {
    try {
      if (await file.exists()) {
        await file.delete();
      }
    } catch (error) {
      debugPrint('Gonen: no se pudo borrar ${file.path}: $error');
    }
  }
}
