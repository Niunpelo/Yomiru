import 'dart:typed_data';

/// Clave con la que Gonen cifra y descifra las cápsulas que se envían a otras
/// personas.
///
/// Es la misma en todas las copias de la app, y por eso la app de quien recibe
/// puede abrir lo que cerró la de quien envía sin ningún servidor. Eso también
/// significa que **no es un secreto de verdad**: quien desmonte el APK puede
/// sacarla. Sirve para que el archivo no se lea a simple vista (ni con un editor
/// de texto, ni mirando su contenido), no para frenar a un experto.
///
/// Cambiarla deja ilegibles las cápsulas enviadas con la clave anterior, así que
/// no se toca una vez publicada la app.
final Uint8List kCapsuleAppKey = Uint8List.fromList(<int>[
  0xad, 0x69, 0xae, 0xa3, 0xe9, 0x64, 0x21, 0x0e,
  0x18, 0xeb, 0xaf, 0xac, 0x68, 0x24, 0x75, 0xf9,
  0xcf, 0x1f, 0xa0, 0xf6, 0x35, 0xfa, 0x8e, 0x80,
  0xc0, 0x1d, 0x79, 0xa3, 0x23, 0x16, 0x73, 0x92,
]);
