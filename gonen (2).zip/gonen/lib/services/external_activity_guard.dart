/// Avisa al bloqueo biométrico de que la app va a abrir a propósito otra
/// pantalla del sistema (cámara, galería, compra de Google Play).
///
/// Al hacerlo, la app pasa a segundo plano y, sin este aviso, al volver pediría
/// la huella otra vez. El permiso caduca solo, así que un fallo no puede dejar
/// el bloqueo desactivado indefinidamente.
class ExternalActivityGuard {
  ExternalActivityGuard._();

  static DateTime _until = DateTime.fromMillisecondsSinceEpoch(0);

  /// Verdadero mientras la app espera a que vuelva una pantalla del sistema.
  static bool get isActive => DateTime.now().isBefore(_until);

  /// Permite pasar a segundo plano sin bloquear durante [duration].
  static void allowFor(Duration duration) {
    _until = DateTime.now().add(duration);
  }

  /// Quita el permiso en cuanto la pantalla del sistema ha devuelto el control.
  static void clear() {
    _until = DateTime.fromMillisecondsSinceEpoch(0);
  }
}
