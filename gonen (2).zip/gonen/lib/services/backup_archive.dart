import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

/// Formato del archivo de copia de seguridad de Gonen (extensión `.gonen`).
///
/// Es un contenedor sencillo, sin compresión ni cifrado:
///
/// ```text
/// "GONENBK1"                              8 bytes de identificación
/// repetido, una vez por cada entrada:
///   2 bytes   longitud del nombre (0 = fin del archivo)
///   n bytes   nombre en UTF-8
///   8 bytes   longitud de los datos
///   m bytes   datos
/// ```
///
/// La primera entrada es siempre `data.json` (el texto del diario, las cápsulas
/// y los datos de los adjuntos). Las siguientes son `files/<ruta>`: las fotos y
/// notas de voz. Todos los números van en big-endian.
class BackupArchive {
  BackupArchive._();

  /// Identificación del formato y su versión.
  static final Uint8List magic = Uint8List.fromList(utf8.encode('GONENBK1'));

  /// Nombre de la primera entrada, con los datos en JSON.
  static const String dataEntry = 'data.json';

  /// Prefijo del nombre de las entradas que son fotos o notas de voz.
  static const String filesPrefix = 'files/';

  /// Rutas que Gonen crea para sus adjuntos: `AAAA/MM-DD/<número>.jpg|m4a`
  /// (de un día) o `capsules/<número>.jpg|m4a` (de una cápsula).
  ///
  /// Al restaurar solo se aceptan rutas así de estrictas, para que un archivo
  /// manipulado no pueda escribir fuera de la carpeta de adjuntos.
  static final RegExp _safePath = RegExp(
    r'^(?:\d{4}/\d{2}-\d{2}|capsules)/\d+\.(?:jpg|m4a)$',
  );

  /// Verdadero si [relativePath] tiene la forma de una ruta de adjunto de Gonen.
  static bool isSafeAttachmentPath(String relativePath) =>
      _safePath.hasMatch(relativePath);
}

/// Cabecera de una entrada del archivo: su nombre y cuántos bytes de datos tiene.
class BackupEntryHeader {
  const BackupEntryHeader({required this.name, required this.length});

  final String name;
  final int length;
}

/// Escribe un archivo de copia de seguridad entrada a entrada.
class BackupArchiveWriter {
  BackupArchiveWriter._(this._out);

  static const int _chunkSize = 64 * 1024;

  final RandomAccessFile _out;
  bool _closed = false;

  /// Crea [file] (sustituyéndolo si existe) y escribe la identificación.
  static Future<BackupArchiveWriter> create(File file) async {
    final RandomAccessFile out = await file.open(mode: FileMode.write);
    try {
      await out.writeFrom(BackupArchive.magic);
    } catch (_) {
      await out.close();
      rethrow;
    }
    return BackupArchiveWriter._(out);
  }

  Future<void> _writeHeader(String name, int length) async {
    final List<int> nameBytes = utf8.encode(name);
    if (nameBytes.isEmpty || nameBytes.length > 0xFFFF) {
      throw ArgumentError.value(name, 'name', 'Nombre de entrada no válido');
    }
    final int n = nameBytes.length;
    final Uint8List header = Uint8List(2 + n + 8);
    final ByteData view = ByteData.sublistView(header);
    view.setUint16(0, n, Endian.big);
    header.setRange(2, 2 + n, nameBytes);
    view.setUint32(2 + n, length ~/ 0x100000000, Endian.big);
    view.setUint32(2 + n + 4, length % 0x100000000, Endian.big);
    await _out.writeFrom(header);
  }

  /// Añade una entrada con los bytes de [bytes].
  Future<void> addBytes(String name, List<int> bytes) async {
    await _writeHeader(name, bytes.length);
    await _out.writeFrom(bytes);
  }

  /// Añade una entrada con el contenido de [source], copiado por trozos para
  /// no cargar el archivo entero en memoria.
  Future<void> addFile(String name, File source) async {
    final RandomAccessFile input = await source.open();
    try {
      final int length = await input.length();
      await _writeHeader(name, length);
      int remaining = length;
      while (remaining > 0) {
        final int wanted = remaining < _chunkSize ? remaining : _chunkSize;
        final Uint8List chunk = await input.read(wanted);
        if (chunk.isEmpty) {
          throw FileSystemException(
            'El archivo cambió mientras se copiaba',
            source.path,
          );
        }
        await _out.writeFrom(chunk);
        remaining -= chunk.length;
      }
    } finally {
      await input.close();
    }
  }

  /// Escribe la marca de fin y cierra el archivo.
  Future<void> close() async {
    if (_closed) {
      return;
    }
    _closed = true;
    try {
      await _out.writeFrom(const <int>[0, 0]);
      await _out.flush();
    } finally {
      await _out.close();
    }
  }

  /// Cierra el archivo sin marca de fin (la copia queda incompleta y hay que
  /// borrarla). Nunca lanza.
  Future<void> abort() async {
    if (_closed) {
      return;
    }
    _closed = true;
    try {
      await _out.close();
    } catch (_) {
      // Ya se está abortando: no hay nada más que hacer.
    }
  }
}

/// Lee un archivo de copia de seguridad entrada a entrada.
///
/// Todos los errores de contenido (archivo que no es de Gonen, cortado o
/// dañado) se lanzan como [FormatException] con un mensaje en español.
class BackupArchiveReader {
  BackupArchiveReader._(this._file, this._length);

  static const int _chunkSize = 64 * 1024;

  /// Tamaño máximo que se admite para una entrada que se lee entera en memoria.
  static const int maxInMemoryBytes = 64 * 1024 * 1024;

  final RandomAccessFile _file;
  final int _length;

  /// Bytes de datos de la entrada actual que aún no se han leído.
  int _remaining = 0;

  /// Abre [file] y comprueba que es una copia de seguridad de Gonen.
  static Future<BackupArchiveReader> open(File file) async {
    final RandomAccessFile raf = await file.open();
    try {
      final BackupArchiveReader reader =
          BackupArchiveReader._(raf, await raf.length());
      final Uint8List head = await reader._readExact(
        BackupArchive.magic.length,
        notGonen: true,
      );
      for (int i = 0; i < head.length; i++) {
        if (head[i] != BackupArchive.magic[i]) {
          throw const FormatException(_notGonenMessage);
        }
      }
      return reader;
    } catch (_) {
      await raf.close();
      rethrow;
    }
  }

  static const String _notGonenMessage =
      'Este archivo no es una copia de seguridad de Gonen.';
  static const String _incompleteMessage =
      'La copia de seguridad está incompleta o dañada.';

  /// Lee exactamente [count] bytes o lanza [FormatException].
  Future<Uint8List> _readExact(int count, {bool notGonen = false}) async {
    if (count == 0) {
      return Uint8List(0);
    }
    final Uint8List bytes = await _file.read(count);
    if (bytes.length != count) {
      throw FormatException(notGonen ? _notGonenMessage : _incompleteMessage);
    }
    return bytes;
  }

  /// Pasa a la siguiente entrada (saltándose lo que quedara sin leer de la
  /// actual). Devuelve null al llegar al final del archivo.
  Future<BackupEntryHeader?> next() async {
    if (_remaining > 0) {
      final int target = await _file.position() + _remaining;
      if (target > _length) {
        throw const FormatException(_incompleteMessage);
      }
      await _file.setPosition(target);
      _remaining = 0;
    }

    final Uint8List nameLengthBytes = await _readExact(2);
    final int nameLength =
        ByteData.sublistView(nameLengthBytes).getUint16(0, Endian.big);
    if (nameLength == 0) {
      return null;
    }

    final Uint8List nameBytes = await _readExact(nameLength);
    final String name = utf8.decode(nameBytes);

    final Uint8List lengthBytes = await _readExact(8);
    final ByteData lengthView = ByteData.sublistView(lengthBytes);
    final int length = lengthView.getUint32(0, Endian.big) * 0x100000000 +
        lengthView.getUint32(4, Endian.big);

    final int position = await _file.position();
    if (length > _length - position) {
      throw const FormatException(_incompleteMessage);
    }
    _remaining = length;
    return BackupEntryHeader(name: name, length: length);
  }

  /// Lee entera la entrada actual en memoria (solo para entradas pequeñas).
  Future<Uint8List> readEntryBytes() async {
    if (_remaining > maxInMemoryBytes) {
      throw const FormatException(_incompleteMessage);
    }
    final Uint8List bytes = await _readExact(_remaining);
    _remaining = 0;
    return bytes;
  }

  /// Copia la entrada actual a [target], por trozos.
  Future<void> copyEntryTo(File target) async {
    final RandomAccessFile out = await target.open(mode: FileMode.write);
    try {
      while (_remaining > 0) {
        final int wanted = _remaining < _chunkSize ? _remaining : _chunkSize;
        final Uint8List chunk = await _readExact(wanted);
        await out.writeFrom(chunk);
        _remaining -= wanted;
      }
    } finally {
      await out.close();
    }
  }

  Future<void> close() => _file.close();
}
