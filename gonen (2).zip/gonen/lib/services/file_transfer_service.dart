import 'dart:io';

import 'package:flutter/services.dart';

import 'external_activity_guard.dart';

/// Error al hablar con el selector de archivos del sistema.
class FileTransferException implements Exception {
  const FileTransferException(this.message);

  final String message;

  @override
  String toString() => message;
}

/// Guarda y elige archivos con las pantallas del sistema de Android (el
/// selector de documentos), sin necesitar ningún permiso de almacenamiento.
///
/// El código nativo está en `MainActivity.kt` (lo escribe `tool/patch_android.py`)
/// y responde al canal `gonen/files`.
class FileTransferService {
  const FileTransferService();

  static const MethodChannel _channel = MethodChannel('gonen/files');

  /// Tiempo máximo que se espera a que el usuario elija dónde guardar o qué abrir.
  static const Duration _waitForUser = Duration(minutes: 10);

  /// Pide al usuario dónde guardar [sourcePath] y lo copia allí con el nombre
  /// [suggestedName]. Devuelve false si el usuario cancela.
  Future<bool> saveFile({
    required String sourcePath,
    required String suggestedName,
  }) async {
    try {
      // La pantalla del sistema saca a la app a segundo plano: que al volver
      // no pida la huella otra vez.
      ExternalActivityGuard.allowFor(_waitForUser);
      final bool? saved = await _channel.invokeMethod<bool>(
        'saveFile',
        <String, Object?>{
          'sourcePath': sourcePath,
          'suggestedName': suggestedName,
        },
      );
      return saved ?? false;
    } on PlatformException catch (error) {
      throw FileTransferException(
        error.message ?? 'No se pudo guardar el archivo.',
      );
    } on MissingPluginException {
      throw const FileTransferException(
        'Esta versión de la app no puede guardar archivos.',
      );
    } finally {
      ExternalActivityGuard.clear();
    }
  }

  /// Pide al usuario que elija un archivo y devuelve una copia suya dentro de
  /// la carpeta temporal de la app, o null si cancela.
  Future<File?> pickFile() async {
    try {
      ExternalActivityGuard.allowFor(_waitForUser);
      final String? path = await _channel.invokeMethod<String>('pickFile');
      if (path == null || path.isEmpty) {
        return null;
      }
      return File(path);
    } on PlatformException catch (error) {
      throw FileTransferException(
        error.message ?? 'No se pudo abrir el archivo.',
      );
    } on MissingPluginException {
      throw const FileTransferException(
        'Esta versión de la app no puede abrir archivos.',
      );
    } finally {
      ExternalActivityGuard.clear();
    }
  }
}
