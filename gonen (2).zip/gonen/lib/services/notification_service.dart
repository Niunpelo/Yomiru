import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart' show TimeOfDay;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

import '../l10n/tr.dart';

/// Programa el recordatorio diario para escribir en el diario.
class NotificationService {
  NotificationService._();

  /// Instancia única compartida por toda la aplicación.
  static final NotificationService instance = NotificationService._();

  static const int dailyReminderId = 1001;

  /// Las cápsulas usan identificadores de aviso a partir de este número, para
  /// no chocar nunca con el recordatorio diario.
  static const int capsuleIdOffset = 100000;

  /// Hora del día (en punto) a la que avisa una cápsula del tiempo.
  static const int capsuleReminderHour = 9;

  static const String _capsuleChannelId = 'gonen_capsules';
  static String get _capsuleChannelName =>
      tr('Cápsulas del tiempo', 'Time capsules');
  static String get _capsuleChannelDescription => tr(
        'Aviso cuando llega el día de abrir una cápsula del tiempo',
        'Notice when the day to open a time capsule arrives',
      );

  static const String _channelId = 'gonen_daily_reminder';
  static String get _channelName => tr('Recordatorio diario', 'Daily reminder');
  static String get _channelDescription => tr(
        'Aviso diario para escribir en tu diario Gonen',
        'Daily notice to write in your Gonen diary',
      );

  /// Icono blanco y transparente (drawable) que añade tool/patch_android.py.
  static const String _androidIcon = 'ic_stat_gonen';

  static NotificationDetails get _notificationDetails => NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          _channelName,
          channelDescription: _channelDescription,
          importance: Importance.defaultImportance,
          priority: Priority.defaultPriority,
        ),
      );

  static NotificationDetails get _capsuleNotificationDetails =>
      NotificationDetails(
        android: AndroidNotificationDetails(
          _capsuleChannelId,
          _capsuleChannelName,
          channelDescription: _capsuleChannelDescription,
          importance: Importance.defaultImportance,
          priority: Priority.defaultPriority,
        ),
      );

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  Future<void>? _initializing;

  /// Prepara el plugin y la zona horaria local. Se puede llamar varias veces,
  /// también a la vez: todas las llamadas esperan a la misma inicialización.
  Future<void> initialize() => _initializing ??= _runInitialize();

  Future<void> _runInitialize() async {
    try {
      tz_data.initializeTimeZones();
      await _configureLocalTimezone();

      const AndroidInitializationSettings androidSettings =
          AndroidInitializationSettings(_androidIcon);
      const InitializationSettings settings =
          InitializationSettings(android: androidSettings);
      await _plugin.initialize(settings: settings);
    } catch (_) {
      // Si falla, la próxima llamada vuelve a intentarlo.
      _initializing = null;
      rethrow;
    }
  }

  Future<void> _configureLocalTimezone() async {
    try {
      final info = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(info.identifier));
    } catch (error) {
      debugPrint('Gonen: zona horaria no disponible, uso el desfase: $error');
      tz.setLocalLocation(_locationFromCurrentOffset());
    }
  }

  /// Plan B: busca una zona de la base de datos con el mismo desfase horario
  /// que el dispositivo en este momento.
  tz.Location _locationFromCurrentOffset() {
    final DateTime now = DateTime.now();
    final int offsetMs = now.timeZoneOffset.inMilliseconds;
    final int nowMs = now.millisecondsSinceEpoch;
    for (final tz.Location location in tz.timeZoneDatabase.locations.values) {
      if (location.timeZone(nowMs).offset == offsetMs) {
        return location;
      }
    }
    return tz.UTC;
  }

  /// Pide permiso para mostrar notificaciones (obligatorio desde Android 13).
  Future<bool> requestPermission() async {
    await initialize();
    final AndroidFlutterLocalNotificationsPlugin? android =
        _plugin.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
    if (android == null) {
      return true;
    }
    final bool? granted = await android.requestNotificationsPermission();
    return granted ?? true;
  }

  /// Programa (o reprograma) el aviso diario a la hora indicada.
  ///
  /// Usa un aviso "inexacto" para no necesitar el permiso de alarmas exactas:
  /// Android puede retrasarlo unos minutos para ahorrar batería.
  Future<void> scheduleDailyReminder(TimeOfDay time) async {
    await initialize();
    await _plugin.cancel(id: dailyReminderId);

    await _plugin.zonedSchedule(
      id: dailyReminderId,
      title: 'Gonen',
      body: tr(
        '¿Qué ha pasado hoy? Escribe tu entrada del diario.',
        'What happened today? Write your diary entry.',
      ),
      scheduledDate: _nextInstanceOf(time),
      notificationDetails: _notificationDetails,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  /// Quita el aviso diario.
  Future<void> cancelDailyReminder() async {
    await initialize();
    await _plugin.cancel(id: dailyReminderId);
  }

  /// Programa el aviso de una cápsula para las 09:00 de su día de apertura.
  ///
  /// El texto no menciona el título, el contenido ni quién la envió para no
  /// enseñarlos en la pantalla de bloqueo. Con [received] avisa de una cápsula
  /// que ha dejado otra persona. Devuelve false si esa hora ya ha pasado.
  Future<bool> scheduleCapsuleOpening({
    required int capsuleId,
    required DateTime openDate,
    bool received = false,
  }) async {
    await initialize();
    final tz.TZDateTime scheduled = tz.TZDateTime(
      tz.local,
      openDate.year,
      openDate.month,
      openDate.day,
      capsuleReminderHour,
    );
    if (!scheduled.isAfter(tz.TZDateTime.now(tz.local))) {
      return false;
    }

    await _plugin.zonedSchedule(
      id: capsuleIdOffset + capsuleId,
      title: tr('Gonen · Cápsula del tiempo', 'Gonen · Time capsule'),
      body: received
          ? tr(
              'Hoy puedes abrir una cápsula que te han dejado.',
              'Today you can open a capsule that someone left for you.',
            )
          : tr(
              'Hoy puedes abrir una cápsula que escribiste hace tiempo.',
              'Today you can open a capsule you wrote a while ago.',
            ),
      scheduledDate: scheduled,
      notificationDetails: _capsuleNotificationDetails,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
    );
    return true;
  }

  /// Quita el aviso de una cápsula (al abrirla o borrarla).
  Future<void> cancelCapsuleOpening(int capsuleId) async {
    await initialize();
    await _plugin.cancel(id: capsuleIdOffset + capsuleId);
  }

  /// Próxima vez que el reloj marcará [time]: hoy si aún no ha pasado, si no mañana.
  tz.TZDateTime _nextInstanceOf(TimeOfDay time) {
    final tz.TZDateTime now = tz.TZDateTime.now(tz.local);
    tz.TZDateTime scheduled = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      time.hour,
      time.minute,
    );
    if (!scheduled.isAfter(now)) {
      // Se construye con day + 1 (y no sumando 24 h) para respetar el cambio de hora.
      scheduled = tz.TZDateTime(
        tz.local,
        now.year,
        now.month,
        now.day + 1,
        time.hour,
        time.minute,
      );
    }
    return scheduled;
  }
}
