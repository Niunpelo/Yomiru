import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../l10n/tr.dart';
import '../models/attachment_limits.dart';
import '../models/attachment_model.dart';
import '../models/capsule_model.dart';
import '../utils/date_labels.dart';
import 'attachment_service.dart';
import 'backup_archive.dart';
import 'capsule_cipher.dart';

/// Archivo de cápsula listo para enviar.
class CapsulePackage {
  const CapsulePackage({
    required this.file,
    required this.fileName,
    required this.message,
  });

  /// Archivo cifrado, en la carpeta temporal de la app.
  final File file;

  /// Nombre sugerido para el archivo.
  final String fileName;

  /// Texto amable que acompaña al archivo cuando se envía.
  final String message;
}

/// Cápsula leída de un archivo recibido, lista para guardarse en la base de
/// datos. Sus fotos y notas de voz ya están copiadas a la carpeta de la app.
class ReceivedCapsule {
  const ReceivedCapsule({required this.capsule, required this.attachments});

  final Capsule capsule;
  final List<Attachment> attachments;
}

/// Prepara las cápsulas para enviarlas a otras personas y lee las que llegan.
///
/// El archivo (`.gonencap`) es un contenedor con el mensaje y los datos de la
/// cápsula (`capsule.json`) más sus fotos y notas de voz, todo cifrado entero
/// con [CapsuleCipher]. Fuera del cifrado solo se ve la identificación del
/// formato: ni el título, ni la fecha, ni quién la envía.
class CapsuleShareService {
  CapsuleShareService({
    AttachmentService? attachmentService,
    CapsuleCipher? cipher,
    Future<Directory> Function()? temporaryDirectory,
  })  : _filesOverride = attachmentService,
        _cipherOverride = cipher,
        _temporaryDirectory = temporaryDirectory ?? getTemporaryDirectory;

  /// Extensión de los archivos de cápsula.
  static const String fileExtension = 'gonencap';

  /// Nombre de la primera entrada del contenedor, con los datos en JSON.
  static const String metaEntry = 'capsule.json';

  /// Versión del contenido. Sube si algún día cambia lo que lleva la cápsula.
  static const int formatVersion = 1;

  static const int maxTitleLength = 60;
  static const int maxSenderLength = 40;

  /// Carpeta, dentro de la temporal, donde se dejan los archivos para enviar.
  static const String _sendFolder = 'envios';

  static const String _senderNameKey = 'share_sender_name';
  static String get _damaged => CapsuleCipher.damagedMessage;
  static String get _backupInstead => tr(
        'Este archivo es una copia de seguridad, no una cápsula. Restáurala '
            'desde el menú, en «Copia de seguridad».',
        'This file is a backup, not a capsule. Restore it from the menu, '
            'under “Backup”.',
      );

  final AttachmentService? _filesOverride;
  final CapsuleCipher? _cipherOverride;
  final Future<Directory> Function() _temporaryDirectory;

  AttachmentService get _files => _filesOverride ?? AttachmentService.instance;

  CapsuleCipher get _cipher => _cipherOverride ?? _sharedCipher;

  static final CapsuleCipher _sharedCipher = CapsuleCipher();

  // ---------------------------------------------------------------------------
  // Textos
  // ---------------------------------------------------------------------------

  /// Nombre sugerido para el archivo de [capsule].
  ///
  /// Es lo primero (y a veces lo único, porque WhatsApp descarta el texto que
  /// acompaña a un archivo de tipo desconocido) que ve quien lo recibe en el
  /// chat, así que dice qué es y con qué se abre:
  /// «Cápsula del tiempo de Ana (ábrela con Gonen).gonencap».
  static String suggestedFileName(Capsule capsule) {
    final String sender = _fileSafe(capsule.sender ?? '');
    if (AppLocale.isEnglish) {
      final String from = sender.isEmpty ? '' : ' from $sender';
      return 'Time capsule$from (open it with Gonen).$fileExtension';
    }
    final String who = sender.isEmpty ? '' : ' de $sender';
    return 'Cápsula del tiempo$who (ábrela con Gonen).$fileExtension';
  }

  /// Quita de [text] lo que no puede ir en un nombre de archivo (barras,
  /// comillas, dos puntos, caracteres de control...) y junta los espacios.
  static String _fileSafe(String text) {
    return text
        .replaceAll(RegExp(r'[\x00-\x1F\x7F\\/:*?"<>|]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  /// Carpeta propia de cada cápsula dentro de la de envíos. Así dos cápsulas
  /// de la misma persona (que tienen el mismo nombre de archivo) no se pisan.
  /// Solo deja letras y números: el identificador viene de la base de datos
  /// y nunca debe poder salirse de la carpeta temporal.
  static String _sendSubfolder(String uid) {
    final String safe = uid.replaceAll(RegExp(r'[^A-Za-z0-9]'), '');
    if (safe.isEmpty) {
      return 'x';
    }
    return safe.length > 12 ? safe.substring(0, 12) : safe;
  }

  /// Texto que acompaña al archivo al enviarlo. No dice nada del contenido.
  static String shareMessage(Capsule capsule) {
    final String sender = capsule.sender ?? tr('Alguien', 'Someone');
    return tr(
      '$sender te ha dejado una cápsula del tiempo en Gonen. '
          'Se podrá abrir el ${fullDateLabel(capsule.openDate)}.\n\n'
          'Ábrela con la app Gonen y la cápsula se guardará sola; te avisará '
          'el día de apertura. Si no se abre, entra en Gonen → Cápsulas → '
          'Importar.',
      '$sender has left you a time capsule in Gonen. '
          'It can be opened on ${fullDateLabel(capsule.openDate)}.\n\n'
          'Open it with the Gonen app and the capsule will be saved by itself; '
          'you will get a notice on the opening day. If it does not open, go '
          'to Gonen → Capsules → Import.',
    );
  }

  // ---------------------------------------------------------------------------
  // Tu nombre
  // ---------------------------------------------------------------------------

  /// Nombre que el usuario puso la última vez al enviar una cápsula, o un
  /// texto vacío.
  Future<String> loadSenderName() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      return prefs.getString(_senderNameKey) ?? '';
    } catch (error) {
      debugPrint('Gonen: no se pudo leer el nombre para enviar: $error');
      return '';
    }
  }

  /// Recuerda [name] para la próxima vez.
  Future<void> saveSenderName(String name) async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString(_senderNameKey, name.trim());
    } catch (error) {
      debugPrint('Gonen: no se pudo guardar el nombre para enviar: $error');
    }
  }

  // ---------------------------------------------------------------------------
  // Preparar para enviar
  // ---------------------------------------------------------------------------

  /// Crea el archivo cifrado de [capsule] con sus [attachments]. La cápsula
  /// tiene que ser de las que se envían (con `uid` y `sender`).
  ///
  /// El archivo queda en la carpeta temporal: Android lo borra solo cuando
  /// necesita sitio, y aquí se borran los de más de un día.
  Future<CapsulePackage> build({
    required Capsule capsule,
    required List<Attachment> attachments,
  }) async {
    final String? uid = capsule.uid;
    final String? sender = capsule.sender;
    if (uid == null || uid.isEmpty || sender == null || sender.trim().isEmpty) {
      throw ArgumentError('The capsule is not ready to be sent.');
    }

    final List<Attachment> included = <Attachment>[];
    final Set<String> seen = <String>{};
    for (final Attachment attachment in attachments) {
      final String path = attachment.relativePath;
      if (_isCapsuleFilePath(path) &&
          seen.add(path) &&
          await _files.exists(path)) {
        included.add(attachment);
      }
    }

    final Map<String, Object?> meta = <String, Object?>{
      'format': formatVersion,
      'uid': uid,
      'sender': sender.trim(),
      'title': capsule.title,
      'content': capsule.content,
      'created_at': capsule.createdAt.millisecondsSinceEpoch,
      'open_date': Capsule.dateKey(capsule.openDate),
      'attachments': <Map<String, Object?>>[
        for (final Attachment attachment in included)
          <String, Object?>{
            'type': attachment.type == AttachmentType.image ? 'image' : 'audio',
            'path': attachment.relativePath,
            'duration_ms': attachment.durationMs,
            'created_at': attachment.createdAt.millisecondsSinceEpoch,
          },
      ],
    };

    final Directory temp = await _temporaryDirectory();
    await _deleteOldPackages(temp);

    final String stamp = '${DateTime.now().microsecondsSinceEpoch}';
    final File plain = File(p.join(temp.path, 'enviar-$stamp.tmp'));
    final String fileName = suggestedFileName(capsule);
    final Directory folder = Directory(
      p.join(temp.path, _sendFolder, _sendSubfolder(uid)),
    );
    await folder.create(recursive: true);
    final File output = File(p.join(folder.path, fileName));

    final BackupArchiveWriter writer = await BackupArchiveWriter.create(plain);
    try {
      await writer.addBytes(metaEntry, utf8.encode(jsonEncode(meta)));
      for (final Attachment attachment in included) {
        await writer.addFile(
          '${BackupArchive.filesPrefix}${attachment.relativePath}',
          _files.fileFor(attachment.relativePath),
        );
      }
      await writer.close();
      await _cipher.encryptFile(plain, output);
    } catch (_) {
      await writer.abort();
      await _deleteQuietly(output);
      rethrow;
    } finally {
      await _deleteQuietly(plain);
    }

    return CapsulePackage(
      file: output,
      fileName: fileName,
      message: shareMessage(capsule),
    );
  }

  // ---------------------------------------------------------------------------
  // Leer una cápsula recibida
  // ---------------------------------------------------------------------------

  /// Descifra [file] y copia sus fotos y notas de voz a la carpeta de la app.
  ///
  /// * Devuelve null si [alreadyHave] dice que esa cápsula ya está guardada
  ///   (en ese caso no se copia ningún archivo).
  /// * Lanza [FormatException] (con un mensaje en español) si el archivo no es
  ///   una cápsula de Gonen, está dañado o es de una versión más nueva.
  ///
  /// Si algo falla a medias, los archivos que ya se habían copiado se borran.
  Future<ReceivedCapsule?> read(
    File file, {
    Future<bool> Function(String uid)? alreadyHave,
  }) async {
    await _rejectBackupFile(file);

    final Directory temp = await _temporaryDirectory();
    final File plain = File(
      p.join(temp.path, 'recibida-${DateTime.now().microsecondsSinceEpoch}.tmp'),
    );
    final List<String> copied = <String>[];
    BackupArchiveReader? reader;
    try {
      await _cipher.decryptFile(file, plain);

      reader = await BackupArchiveReader.open(plain);
      final BackupEntryHeader? first = await reader.next();
      if (first == null || first.name != metaEntry) {
        throw FormatException(_damaged);
      }
      final _Meta meta = _parseMeta(await reader.readEntryBytes());

      if (alreadyHave != null && await alreadyHave(meta.uid)) {
        return null;
      }

      final Map<String, _MetaFile> wanted = <String, _MetaFile>{
        for (final _MetaFile item in meta.files) item.path: item,
      };
      final Map<String, Attachment> restored = <String, Attachment>{};

      while (true) {
        final BackupEntryHeader? header = await reader.next();
        if (header == null) {
          break;
        }
        if (!header.name.startsWith(BackupArchive.filesPrefix)) {
          continue;
        }
        final String sourcePath =
            header.name.substring(BackupArchive.filesPrefix.length);
        final _MetaFile? item = wanted[sourcePath];
        if (item == null || restored.containsKey(sourcePath)) {
          continue;
        }

        final String newPath = await _freshPath(item.extension);
        final File target = await _files.prepareFile(newPath);
        final File partial = File('${target.path}.part');
        try {
          await reader.copyEntryTo(partial);
          await partial.rename(target.path);
        } catch (_) {
          await _deleteQuietly(partial);
          rethrow;
        }
        copied.add(newPath);
        restored[sourcePath] = Attachment.forCapsule(
          type: item.type,
          relativePath: newPath,
          durationMs: item.durationMs,
          createdAt: item.createdAt,
        );
      }

      final List<Attachment> attachments = <Attachment>[
        for (final _MetaFile item in meta.files)
          if (restored[item.path] != null) restored[item.path]!,
      ];
      final ReceivedCapsule received = ReceivedCapsule(
        capsule: Capsule(
          title: meta.title,
          content: meta.content,
          createdAt: meta.createdAt,
          openDate: meta.openDate,
          sender: meta.sender,
          uid: meta.uid,
        ),
        attachments: attachments,
      );
      // A partir de aquí los archivos ya son de quien llamó.
      copied.clear();
      return received;
    } catch (_) {
      for (final String path in copied) {
        await _files.delete(path);
      }
      rethrow;
    } finally {
      await reader?.close();
      await _deleteQuietly(plain);
    }
  }

  /// Interpreta los datos de la cápsula. Todo lo que no cuadra es un archivo
  /// dañado o manipulado.
  _Meta _parseMeta(Uint8List bytes) {
    final Object? decoded;
    try {
      decoded = jsonDecode(utf8.decode(bytes));
    } on FormatException {
      throw FormatException(_damaged);
    }
    if (decoded is! Map) {
      throw FormatException(_damaged);
    }

    final int format = (decoded['format'] as num?)?.toInt() ?? 0;
    if (format < 1) {
      throw FormatException(_damaged);
    }
    if (format > formatVersion) {
      throw FormatException(
        tr(
          'Esta cápsula es de una versión más nueva de Gonen. Actualiza la app '
              'para guardarla.',
          'This capsule comes from a newer version of Gonen. Update the app to '
              'save it.',
        ),
      );
    }

    final Object? uidValue = decoded['uid'];
    final Object? contentValue = decoded['content'];
    final Object? openValue = decoded['open_date'];
    if (uidValue is! String ||
        uidValue.isEmpty ||
        uidValue.length > 64 ||
        contentValue is! String ||
        contentValue.trim().isEmpty ||
        openValue is! String) {
      throw FormatException(_damaged);
    }

    final DateTime openDate;
    try {
      openDate = Capsule.parseDateKey(openValue);
    } on FormatException {
      throw FormatException(_damaged);
    } on RangeError {
      throw FormatException(_damaged);
    }
    if (Capsule.dateKey(openDate) != openValue) {
      throw FormatException(_damaged);
    }

    final String title = _clip(decoded['title'], maxTitleLength);
    final String senderText = _clip(decoded['sender'], maxSenderLength).trim();
    final int? createdMs = (decoded['created_at'] as num?)?.toInt();

    final List<_MetaFile> files = <_MetaFile>[];
    final Set<String> seen = <String>{};
    int images = 0;
    int voiceNotes = 0;
    final Object? rawFiles = decoded['attachments'];
    if (rawFiles is List) {
      for (final Object? raw in rawFiles) {
        if (raw is! Map) {
          continue;
        }
        final Object? path = raw['path'];
        final Object? type = raw['type'];
        if (path is! String ||
            !_isCapsuleFilePath(path) ||
            !seen.add(path)) {
          continue;
        }
        final bool isImage = type == 'image' && path.endsWith('.jpg');
        final bool isAudio = type == 'audio' && path.endsWith('.m4a');
        if (isImage && images < AttachmentLimits.maxImagesPerDay) {
          images++;
        } else if (isAudio && voiceNotes < AttachmentLimits.maxVoiceNotesPerDay) {
          voiceNotes++;
        } else {
          continue;
        }
        final int? fileCreatedMs = (raw['created_at'] as num?)?.toInt();
        files.add(
          _MetaFile(
            path: path,
            type: isImage ? AttachmentType.image : AttachmentType.audio,
            durationMs: (raw['duration_ms'] as num?)?.toInt(),
            createdAt: DateTime.fromMillisecondsSinceEpoch(
              fileCreatedMs ?? createdMs ?? 0,
            ),
          ),
        );
      }
    }

    return _Meta(
      uid: uidValue,
      sender: senderText.isEmpty ? 'Alguien' : senderText,
      title: title.trim(),
      content: contentValue.trim(),
      createdAt: DateTime.fromMillisecondsSinceEpoch(createdMs ?? 0),
      openDate: openDate,
      files: files,
    );
  }

  static String _clip(Object? value, int maxLength) {
    if (value is! String) {
      return '';
    }
    return value.length > maxLength ? value.substring(0, maxLength) : value;
  }

  /// Rutas que Gonen da a los archivos de una cápsula: `capsules/<n>.jpg|m4a`.
  static bool _isCapsuleFilePath(String path) =>
      path.startsWith('capsules/') && BackupArchive.isSafeAttachmentPath(path);

  /// Si el archivo es una copia de seguridad (y no una cápsula), lo dice con un
  /// mensaje claro en lugar de un «no es una cápsula» genérico.
  Future<void> _rejectBackupFile(File file) async {
    final RandomAccessFile input = await file.open();
    try {
      final List<int> head = await input.read(BackupArchive.magic.length);
      if (head.length == BackupArchive.magic.length) {
        bool same = true;
        for (int i = 0; i < head.length; i++) {
          if (head[i] != BackupArchive.magic[i]) {
            same = false;
            break;
          }
        }
        if (same) {
          throw FormatException(_backupInstead);
        }
      }
    } finally {
      await input.close();
    }
  }

  Future<String> _freshPath(String extension) async {
    String path = _files.newCapsuleRelativePath(extension: extension);
    while (await _files.exists(path)) {
      path = _files.newCapsuleRelativePath(extension: extension);
    }
    return path;
  }

  /// Borra los archivos de cápsula y temporales de más de un día.
  Future<void> _deleteOldPackages(Directory temp) async {
    try {
      final DateTime limit = DateTime.now().subtract(const Duration(days: 1));
      await for (final FileSystemEntity entity in temp.list()) {
        final String name = p.basename(entity.path);
        if (entity is Directory) {
          if (name == _sendFolder) {
            await _deleteOldSends(entity, limit);
          }
          continue;
        }
        if (entity is! File) {
          continue;
        }
        // «capsula-gonen-» es como se llamaban los archivos antes de la 1.5.1.
        final bool ours = name.startsWith('capsula-gonen-') ||
            name.startsWith('enviar-') ||
            name.startsWith('recibida-') ||
            name == 'incoming.$fileExtension';
        if (ours && (await entity.lastModified()).isBefore(limit)) {
          await _deleteQuietly(entity);
        }
      }
    } catch (error) {
      debugPrint('Gonen: no se pudieron limpiar los archivos antiguos: $error');
    }
  }

  /// Borra, dentro de la carpeta de envíos, los archivos de más de un día y
  /// las subcarpetas que se quedan vacías.
  Future<void> _deleteOldSends(Directory folder, DateTime limit) async {
    await for (final FileSystemEntity entity in folder.list()) {
      if (entity is! Directory) {
        continue;
      }
      await for (final FileSystemEntity file in entity.list()) {
        if (file is File && (await file.lastModified()).isBefore(limit)) {
          await _deleteQuietly(file);
        }
      }
      if (await entity.list().isEmpty) {
        await entity.delete();
      }
    }
  }

  Future<void> _deleteQuietly(File file) async {
    try {
      if (await file.exists()) {
        await file.delete();
      }
    } catch (error) {
      debugPrint('Gonen: no se pudo borrar ${file.path}: $error');
    }
  }
}

/// Datos de una cápsula recibida, ya revisados.
class _Meta {
  const _Meta({
    required this.uid,
    required this.sender,
    required this.title,
    required this.content,
    required this.createdAt,
    required this.openDate,
    required this.files,
  });

  final String uid;
  final String sender;
  final String title;
  final String content;
  final DateTime createdAt;
  final DateTime openDate;
  final List<_MetaFile> files;
}

/// Foto o nota de voz que declara una cápsula recibida.
class _MetaFile {
  const _MetaFile({
    required this.path,
    required this.type,
    required this.durationMs,
    required this.createdAt,
  });

  final String path;
  final AttachmentType type;
  final int? durationMs;
  final DateTime createdAt;

  String get extension => type == AttachmentType.image ? 'jpg' : 'm4a';
}
