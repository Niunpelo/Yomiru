import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';

import '../l10n/tr.dart';
import 'capsule_secret.dart';

/// Cifra y descifra archivos con la clave de la app (HMAC-SHA256).
///
/// El formato del archivo cifrado es:
///
/// ```text
/// "GONENCP1"   8 bytes de identificación
/// nonce       16 bytes al azar, distintos en cada archivo
/// longitud     8 bytes (big-endian) con el tamaño de los datos cifrados
/// datos        la misma cantidad de bytes que el original
/// firma       32 bytes para saber si alguien tocó el archivo o se dañó
/// ```
///
/// * **Cifrado**: cada byte se mezcla (XOR) con una tira de números
///   imprevisibles. Esa tira sale de repetir HMAC-SHA256 con la clave, el
///   nonce y un contador (bloques de 32 bytes).
/// * **Firma**: se calcula con otra clave derivada de la primera y cubre la
///   cabecera y todos los datos cifrados, en trozos de 64 KB encadenados. Si
///   falta un byte, sobra uno o alguno cambió, la firma no cuadra.
///
/// Los archivos se procesan por trozos para no cargar en memoria las fotos y
/// notas de voz.
class CapsuleCipher {
  /// Con [masterKey] se puede usar otra clave (por ejemplo, en las pruebas); y
  /// con [random], un generador de nonces conocido.
  CapsuleCipher({List<int>? masterKey, Random? random})
      : this._(masterKey ?? kCapsuleAppKey, random ?? Random.secure());

  CapsuleCipher._(List<int> master, this._random)
      : _encKey = _derive(master, 'gonen-capsule-enc-v1'),
        _macKey = _derive(master, 'gonen-capsule-mac-v1');

  /// Identificación del formato y su versión.
  static final Uint8List magic = Uint8List.fromList(utf8.encode('GONENCP1'));

  static const int nonceLength = 16;
  static const int tagLength = 32;

  /// Bytes de la cabecera: identificación, nonce y longitud.
  static const int headerLength = 8 + nonceLength + 8;

  static const int _chunkSize = 64 * 1024;
  static const int _blockSize = 32;

  static String get notCapsuleMessage => tr(
        'Este archivo no es una cápsula de Gonen.',
        'This file is not a Gonen capsule.',
      );

  static String get damagedMessage => tr(
        'La cápsula está incompleta o dañada.',
        'The capsule is incomplete or damaged.',
      );

  final Random _random;
  final List<int> _encKey;
  final List<int> _macKey;

  static List<int> _derive(List<int> master, String label) {
    return Hmac(sha256, master).convert(utf8.encode(label)).bytes;
  }

  /// Cifra [plain] y escribe el resultado en [output] (que se sustituye si
  /// existe).
  Future<void> encryptFile(File plain, File output) async {
    final Uint8List nonce = Uint8List(nonceLength);
    for (int i = 0; i < nonceLength; i++) {
      nonce[i] = _random.nextInt(256);
    }

    final RandomAccessFile input = await plain.open();
    RandomAccessFile? out;
    try {
      final int length = await input.length();

      final Uint8List header = Uint8List(headerLength);
      header.setRange(0, magic.length, magic);
      header.setRange(magic.length, magic.length + nonceLength, nonce);
      final ByteData view = ByteData.sublistView(header);
      view.setUint32(magic.length + nonceLength, length ~/ 0x100000000);
      view.setUint32(magic.length + nonceLength + 4, length % 0x100000000);

      out = await output.open(mode: FileMode.write);
      await out.writeFrom(header);
      List<int> tag = _firstTag(header);

      int offset = 0;
      while (offset < length) {
        final int wanted = min(_chunkSize, length - offset);
        final Uint8List chunk = await _readFully(input, wanted);
        if (chunk.length != wanted) {
          throw FileSystemException(
            tr(
              'El archivo cambió mientras se cifraba',
              'The file changed while it was being encrypted',
            ),
            plain.path,
          );
        }
        _applyKeystream(chunk, nonce, offset);
        tag = _nextTag(tag, chunk);
        await out.writeFrom(chunk);
        offset += wanted;
      }

      await out.writeFrom(tag);
      await out.flush();
    } finally {
      await input.close();
      await out?.close();
    }
  }

  /// Descifra [encrypted] y escribe el resultado en [output].
  ///
  /// Lanza [FormatException] (con un mensaje en español) si el archivo no es
  /// una cápsula de Gonen, está incompleto o la firma no cuadra. En ese caso
  /// [output] se borra: nunca queda texto sin comprobar.
  Future<void> decryptFile(File encrypted, File output) async {
    final RandomAccessFile input = await encrypted.open();
    RandomAccessFile? out;
    bool ok = false;
    try {
      final int fileLength = await input.length();

      final Uint8List header = await _readFully(input, headerLength);
      if (header.length != headerLength || !_startsWithMagic(header)) {
        throw FormatException(notCapsuleMessage);
      }
      final Uint8List nonce = Uint8List.fromList(
        header.sublist(magic.length, magic.length + nonceLength),
      );
      final ByteData view = ByteData.sublistView(header);
      final int length =
          view.getUint32(magic.length + nonceLength) * 0x100000000 +
              view.getUint32(magic.length + nonceLength + 4);
      if (length < 0 || headerLength + length + tagLength != fileLength) {
        throw FormatException(damagedMessage);
      }

      out = await output.open(mode: FileMode.write);
      List<int> tag = _firstTag(header);

      int offset = 0;
      while (offset < length) {
        final int wanted = min(_chunkSize, length - offset);
        final Uint8List chunk = await _readFully(input, wanted);
        if (chunk.length != wanted) {
          throw FormatException(damagedMessage);
        }
        // La firma se calcula sobre los datos cifrados, antes de descifrarlos.
        tag = _nextTag(tag, chunk);
        _applyKeystream(chunk, nonce, offset);
        await out.writeFrom(chunk);
        offset += wanted;
      }

      final Uint8List stored = await _readFully(input, tagLength);
      if (stored.length != tagLength || !_sameBytes(stored, tag)) {
        throw FormatException(damagedMessage);
      }
      await out.flush();
      ok = true;
    } finally {
      await input.close();
      await out?.close();
      if (!ok) {
        try {
          if (await output.exists()) {
            await output.delete();
          }
        } catch (_) {
          // Ya se está fallando: no hay nada más que hacer con este archivo.
        }
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Piezas internas
  // ---------------------------------------------------------------------------

  bool _startsWithMagic(Uint8List header) {
    for (int i = 0; i < magic.length; i++) {
      if (header[i] != magic[i]) {
        return false;
      }
    }
    return true;
  }

  /// Firma de la cabecera: el primer eslabón de la cadena.
  List<int> _firstTag(Uint8List header) {
    return Hmac(sha256, _macKey).convert(header).bytes;
  }

  /// Siguiente eslabón: la firma anterior más el trozo de datos cifrados.
  List<int> _nextTag(List<int> previous, Uint8List chunk) {
    final Uint8List data = Uint8List(previous.length + chunk.length);
    data.setRange(0, previous.length, previous);
    data.setRange(previous.length, data.length, chunk);
    return Hmac(sha256, _macKey).convert(data).bytes;
  }

  /// Mezcla (XOR) [data] con la tira de números que corresponde a las
  /// posiciones [streamOffset] en adelante. Descifrar es lo mismo que cifrar.
  void _applyKeystream(Uint8List data, Uint8List nonce, int streamOffset) {
    final Hmac prf = Hmac(sha256, _encKey);
    final Uint8List counterInput = Uint8List(nonceLength + 8);
    counterInput.setRange(0, nonceLength, nonce);
    final ByteData counterView = ByteData.sublistView(counterInput);

    int i = 0;
    while (i < data.length) {
      final int position = streamOffset + i;
      final int block = position ~/ _blockSize;
      final int inBlock = position % _blockSize;

      counterView.setUint32(nonceLength, block ~/ 0x100000000);
      counterView.setUint32(nonceLength + 4, block % 0x100000000);
      final List<int> keystream = prf.convert(counterInput).bytes;

      final int count = min(_blockSize - inBlock, data.length - i);
      for (int j = 0; j < count; j++) {
        data[i + j] ^= keystream[inBlock + j];
      }
      i += count;
    }
  }

  /// Lee [count] bytes, o los que queden si el archivo se acaba antes.
  Future<Uint8List> _readFully(RandomAccessFile file, int count) async {
    final BytesBuilder builder = BytesBuilder(copy: false);
    int remaining = count;
    while (remaining > 0) {
      final Uint8List part = await file.read(remaining);
      if (part.isEmpty) {
        break;
      }
      builder.add(part);
      remaining -= part.length;
    }
    return builder.takeBytes();
  }

  /// Compara dos listas en un tiempo que no depende de dónde difieren.
  bool _sameBytes(List<int> a, List<int> b) {
    if (a.length != b.length) {
      return false;
    }
    int difference = 0;
    for (int i = 0; i < a.length; i++) {
      difference |= a[i] ^ b[i];
    }
    return difference == 0;
  }
}
