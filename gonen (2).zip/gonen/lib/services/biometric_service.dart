import 'package:flutter/foundation.dart';
import 'package:local_auth/local_auth.dart';

/// Envoltorio sencillo sobre `local_auth` (huella, rostro o PIN del dispositivo).
class BiometricService {
  BiometricService({LocalAuthentication? auth})
      : _auth = auth ?? LocalAuthentication();

  final LocalAuthentication _auth;
  bool _isAuthenticating = false;

  /// Verdadero mientras hay un diálogo de autenticación abierto.
  ///
  /// El bloqueo de la app lo usa para no bloquearse a sí mismo cuando Android
  /// notifica que la app ha pasado a segundo plano por culpa del propio diálogo.
  bool get isAuthenticating => _isAuthenticating;

  /// Verdadero si el dispositivo puede autenticar al usuario, ya sea con
  /// biometría o con el PIN, patrón o contraseña de la pantalla de bloqueo.
  Future<bool> isAvailable() async {
    try {
      return await _auth.isDeviceSupported();
    } catch (error) {
      debugPrint('Gonen: no se pudo comprobar la autenticación: $error');
      return false;
    }
  }

  /// Muestra el diálogo del sistema. Devuelve true solo si el usuario se identifica.
  Future<bool> authenticate({required String reason}) async {
    if (_isAuthenticating) {
      return false;
    }
    _isAuthenticating = true;
    try {
      return await _auth.authenticate(
        localizedReason: reason,
        persistAcrossBackgrounding: true,
      );
    } catch (error) {
      // En local_auth 3 los fallos (cancelar, demasiados intentos, sin
      // credenciales...) llegan como excepciones. Para la app todos significan
      // lo mismo: no se ha podido verificar al usuario.
      debugPrint('Gonen: autenticación no completada: $error');
      return false;
    } finally {
      _isAuthenticating = false;
    }
  }
}
