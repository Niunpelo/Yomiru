import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/models/attachment_model.dart';

Attachment _attachment({
  int? id,
  AttachmentType type = AttachmentType.image,
  int? durationMs,
}) {
  return Attachment(
    id: id,
    dayOfYear: '03-15',
    year: 2026,
    type: type,
    relativePath: '2026/03-15/1700000000000000.jpg',
    durationMs: durationMs,
    createdAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
  );
}

void main() {
  group('Attachment', () {
    test('toMap y fromMap son operaciones inversas (foto)', () {
      final Attachment original = _attachment(id: 7);

      expect(Attachment.fromMap(original.toMap()), original);
    });

    test('toMap y fromMap conservan la duración de una nota de voz', () {
      final Attachment original = _attachment(
        id: 9,
        type: AttachmentType.audio,
        durationMs: 42000,
      );

      final Attachment restored = Attachment.fromMap(original.toMap());

      expect(restored, original);
      expect(restored.durationMs, 42000);
      expect(restored.type, AttachmentType.audio);
    });

    test('toMap no incluye el id mientras no se ha guardado', () {
      final Map<String, Object?> map = _attachment().toMap();

      expect(map.containsKey('id'), isFalse);
      expect(map['type'], 'image');
      expect(map['day_of_year'], '03-15');
      expect(map['file_path'], '2026/03-15/1700000000000000.jpg');
    });

    test('un tipo desconocido en la base de datos se trata como foto', () {
      final Map<String, Object?> map = _attachment(id: 1).toMap();
      map['type'] = 'video';

      expect(Attachment.fromMap(map).type, AttachmentType.image);
    });

    test('copyWith asigna el id sin tocar el resto', () {
      final Attachment saved = _attachment().copyWith(id: 12);

      expect(saved.id, 12);
      expect(saved.relativePath, _attachment().relativePath);
      expect(saved.year, 2026);
    });
  });
}
