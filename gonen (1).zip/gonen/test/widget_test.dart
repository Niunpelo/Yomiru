// Sustituye a la prueba de ejemplo que genera `flutter create` (hace referencia
// a una clase `MyApp` que Gonen no tiene y por eso siempre fallaba).
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/providers/capsules_provider.dart';
import 'package:gonen/providers/premium_provider.dart';
import 'package:gonen/widgets/app_drawer.dart';
import 'package:provider/provider.dart';

void main() {
  testWidgets('el menú lateral incluye Gonen Premium', (
    WidgetTester tester,
  ) async {
    final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<CapsulesProvider>(
            create: (_) => CapsulesProvider(),
          ),
          ChangeNotifierProvider<PremiumProvider>(
            create: (_) => PremiumProvider(),
          ),
        ],
        child: MaterialApp(
          home: Scaffold(
            key: scaffoldKey,
            drawer: AppDrawer(
              onOpenCapsules: () {},
              onOpenPremium: () {},
              onOpenSettings: () {},
            ),
            body: const SizedBox.shrink(),
          ),
        ),
      ),
    );

    scaffoldKey.currentState!.openDrawer();
    await tester.pumpAndSettle();

    expect(find.text('Diario'), findsOneWidget);
    expect(find.text('Cápsulas del tiempo'), findsOneWidget);
    expect(find.text('Gonen Premium'), findsOneWidget);
    expect(find.text('Ajustes'), findsOneWidget);
  });
}
