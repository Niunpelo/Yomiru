# Gonen

Diario de varios años con estética editorial japonesa. El nombre viene de 五年 (*gonen*, «cinco años»). Cada día muestra, en una misma pantalla, lo que escribiste ese mismo día en años anteriores, y además puedes dejar mensajes para tu yo del futuro en **cápsulas del tiempo**.

- **Diario**: una tarjeta por año. Solo se escribe en el año actual y **solo el propio día, hasta las 23:59**; a las 00:00 la entrada queda en solo lectura (se puede leer y copiar, no editar). Los años anteriores son siempre de solo lectura.
- **Años visibles**: en *Ajustes → Diario* eliges cuántos años anteriores salen en el inicio (de 0 a 5; por defecto 4, es decir, 5 tarjetas; con 5 salen 6). Reducirlo solo oculta tarjetas: nada se borra.
- **Gonen Premium**: desbloquea adjuntar **fotos** (cámara o galería) y **notas de voz** al día y a las cápsulas, y **crear copias de seguridad**. Cuesta **9,99 €/año** (suscripción) o **24,99 € de por vida** (pago único). Ver la sección «Premium y pagos».
- **Dado de ideas** (gratis): en la tarjeta de hoy, el icono del dado 🎲 (a la derecha de los iconos de foto, galería y voz; los cuatro son solo iconos, con su nombre como ayuda al mantenerlos pulsados) abre una hoja con una idea para empezar a escribir, sacada de un banco de más de cien preguntas y frases (el día, gratitud, emociones, personas, sentidos, mirar atrás y adelante, reflexión y creatividad). «Otra idea» tira el dado de nuevo sin repetir hasta que han salido todas; «Escribir sobre esto» pone la frase en el texto para contestar debajo.
- **Calendario** (gratis): cada día en el que escribiste, o guardaste una foto o una nota de voz, aparece con un sello rojo. Arriba salen tu **racha actual**, tu **mejor racha** y el total de **días escritos**. Tocar un día salta a él en el diario.
- **Buscar** (gratis): busca una palabra o frase en todo el diario, sin importar mayúsculas ni tildes («cancion» encuentra «canción»; la ñ sí se distingue). Tocar un resultado salta a ese día.
- **Copia de seguridad**: *crear* una copia es Premium; *restaurarla* es gratis. Ver «Copias de seguridad».
- **Menú lateral** (icono ☰ arriba a la izquierda): Diario, Calendario, Buscar, Cápsulas del tiempo, Copia de seguridad, Gonen Premium y Ajustes. Un punto sobre el icono avisa de que hay cápsulas listas para abrir.
- **Cápsulas del tiempo**: escribes un mensaje (con título opcional), eliges el día de apertura y queda sellado. Con Premium puedes añadirle **fotos y notas de voz**, que quedan selladas con el mensaje. No se puede leer hasta ese día; ese día, a las 09:00, llega un aviso. Tras abrirla se puede releer. **Adelantar la fecha del móvil no sirve para abrirla antes**: ver «Fecha de las cápsulas». Se pueden borrar en cualquier momento.
- **Cápsulas para otras personas** (enviar = Premium, recibir = gratis): al escribir una cápsula, el interruptor *Es para otra persona* la sella y abre el menú de compartir de Android (WhatsApp, correo, Bluetooth...) con un archivo `.gonencap` y un texto amable. Tú te quedas una copia; la otra persona, al tocar el archivo, la ve guardarse sola en Gonen y recibe un aviso a las 09:00 del día de apertura. Ver la sección «Cápsulas para otras personas».
- **Datos**: SQLite local (`sqflite`). Entradas por `día "MM-DD"` + `año`; cápsulas y adjuntos en sus propias tablas. Las fotos y notas de voz son archivos en el almacenamiento privado de la app.
- **Estado**: `provider`.
- **Privacidad**: bloqueo con huella, rostro o PIN del dispositivo (`local_auth`).
- **Recordatorio**: notificación diaria a la hora elegida (`flutter_local_notifications`).
- **Apariencia** (*Ajustes → Apariencia*): dos estilos a elegir (Editorial japonesa, el predeterminado, e Hilo rojo), cada uno en claro y oscuro (o el del sistema). Ver «Estilos y logo».
- **Idioma** (*Ajustes → Idioma*): español (por defecto) o inglés. Ver «Idioma».

## Conseguir el APK con GitHub (sin instalar nada)

### Método A: repositorio con los archivos sueltos

1. Crea un repositorio nuevo en GitHub (vacío, sin README).
2. Descomprime este ZIP y sube **todo el contenido**, incluida la carpeta oculta `.github`:
   ```bash
   cd gonen
   git init
   git add .
   git commit -m "Gonen"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/gonen.git
   git push -u origin main
   ```
   Si subes los archivos arrastrándolos en la web de GitHub, comprueba que `.github/workflows/build-apk.yml` ha llegado: sin ese archivo no se compila nada.
3. Abre la pestaña **Actions**. El workflow **Build APK** se lanza solo con cada `push` (también a mano con *Run workflow*).
4. Cuando termine (unos 5-10 minutos), entra en la ejecución y descarga el artefacto **gonen-apk** al final de la página. Es un ZIP que contiene `app-release.apk`.
5. Copia el APK al móvil e instálalo (Android te pedirá permitir instalar apps de este origen).

### Método B: subir solo el ZIP

Si GitHub no te deja subir las carpetas, sube `gonen.zip` tal cual a la raíz del repositorio y crea `.github/workflows/build-apk.yml` desde la web de GitHub con el workflow que descomprime el ZIP y compila dentro de `proyecto/gonen`. El resto es igual que en el método A.

Si subes una etiqueta que empiece por `v` (por ejemplo `v1.6.1`), el APK además se publica en *Releases*.

### Comprobar que se ha compilado la versión nueva

Cada ejecución indica qué versión ha compilado, en dos sitios:

- En la página de la ejecución, en **Annotations**, aparece un aviso azul: *«Compilando Gonen 1.6.1 desde 'gonen.zip'. Premium incluido: si»*.
- Cada ejecución sube **dos** artefactos con la versión en el nombre: `gonen-apk-v1.6.1` (el normal) y `gonen-apk-PRUEBA-premium-v1.6.1` (el de prueba con Premium).

Si pone una versión antigua (o *Premium incluido: NO*), el ZIP que hay en el repositorio no es el nuevo. En el método B el workflow elige el ZIP con la **versión más alta** de la raíz del repositorio, así que da igual que el móvil haya renombrado el archivo nuevo (por ejemplo a `gonen (1).zip`): basta con que esté subido en la raíz. Tras instalar, la versión también sale abajo en el menú lateral (el APK de prueba añade «· PRUEBA»).

**Cada ZIP nuevo debe llevar una versión mayor que el anterior** (el número de `version:` en `pubspec.yaml`). Si dos ZIP de la raíz tienen la misma versión, el workflow no puede saber cuál es el nuevo y puede compilar el viejo: el APK sale «sin cambios» aunque hayas subido el código nuevo. Además, cada compilación de GitHub se firma con una clave de depuración temporal distinta: si Android dice «App no instalada», desinstala la anterior antes (se borran sus datos, así que haz antes una copia de seguridad) o instala el APK de PRUEBA para poder crearla.

### Si la compilación falla o hay errores en el código

En la página de la ejecución, en **Annotations**, el paso *Análisis estático* deja un aviso azul con el número de errores y hasta 15 avisos rojos con cada error (fichero, línea y motivo). Si algo no compila, haz una captura de esa zona: es lo que hace falta para arreglarlo. El análisis nunca detiene la compilación por sí solo: es el paso *Compilar el APK* el que falla si hay un error real.

### Qué hace el workflow

El proyecto no incluye la carpeta `android/`: el workflow la genera con `flutter create` con Flutter 3.38 (la versión está fijada en el workflow para que la compilación no cambie sola) y después ejecuta `tool/patch_android.py`, que deja listo lo que exigen los plugins (desugaring, `FlutterFragmentActivity`, permisos, receptores de notificaciones, temas AppCompat e iconos), el canal nativo para guardar y abrir copias de seguridad (y leer el contador de arranque que usan las cápsulas) y las reglas de la copia automática de Android. Así no hace falta guardar en el repositorio los archivos de Android generados.

El APK se firma con la clave de depuración de Flutter: sirve para instalarlo y usarlo, pero no para subirlo a Google Play. Para Play Store tendrás que configurar tu propia clave de firma.

### Probar Premium sin pagar

Los pagos solo funcionan en una app instalada desde Google Play, así que en el APK normal de GitHub no se puede comprar nada. Por eso **cada ejecución genera dos APK**:

| Artefacto | Para qué sirve |
|-----------|----------------|
| `gonen-apk-v1.6.1` | El APK normal, con los pagos reales. |
| `gonen-apk-PRUEBA-premium-v1.6.1` | Trae **Premium desbloqueado sin pagar**: sirve para probar fotos, notas de voz (también en cápsulas) y copias de seguridad. |

Descarga el de PRUEBA al final de la página de la ejecución. En ese APK el menú lateral pone «Gonen 1.6.1 · PRUEBA» y «Gonen Premium · Activo (modo prueba)», y la pantalla Premium lo avisa. **No debe publicarse ni compartirse nunca.**

Aviso de firma: cada ejecución de GitHub firma con una clave de depuración distinta. Los dos APK de la **misma** ejecución se pueden instalar uno encima de otro, pero un APK de otra ejecución no se instala encima: hay que **desinstalar la app antes** (se pierden sus datos locales; haz antes una copia de seguridad si te importan).

## Premium y pagos

| Plan | Precio | Tipo en Google Play | ID del producto |
|------|--------|---------------------|-----------------|
| Anual | 9,99 €/año | Suscripción | `gonen_premium_yearly` |
| De por vida | 24,99 € | Producto de pago único (no consumible) | `gonen_premium_lifetime` |

Qué desbloquea: hasta 5 fotos y 2 notas de voz (máx. 5 min cada una) por día y por cápsula, y crear copias de seguridad. Ver el contenido ya guardado y **restaurar** una copia es siempre gratis, incluso si el premium caduca.

### Publicar con pagos reales

1. Crea una cuenta de **Google Play Console** (pago único de 25 USD) y una app nueva con el identificador `com.gonen.gonen` (el que genera `flutter create --org com.gonen --project-name gonen`).
2. Configura una **clave de firma propia** y compila un **AAB firmado** (`flutter build appbundle --release`). El APK de depuración no sirve para Play.
3. Sube el AAB a una pista de **pruebas internas** (los productos no aparecen hasta que hay una versión subida).
4. En *Monetizar → Productos*:
   - *Suscripciones*: crea `gonen_premium_yearly` con un plan base **anual** de 9,99 € (renovación automática).
   - *Productos integrados*: crea `gonen_premium_lifetime` de 24,99 €.
   - Los ID tienen que coincidir exactamente con los de la tabla (`lib/providers/premium_provider.dart`).
5. En *Configuración → Pruebas de licencia* añade tu cuenta de Google como **tester**: así puedes comprar sin que te cobren.
6. Rellena la **política de privacidad** y el formulario de **seguridad de los datos**. La app usa el micrófono (permiso `RECORD_AUDIO`) y la cámara a través del selector del sistema; todo se guarda solo en el dispositivo.

### Limitaciones a tener en cuenta

- **Sin servidor**: la compra la confirma Google Play en el propio móvil y la app guarda el resultado en local. No hay verificación en un servidor propio, así que alguien con un móvil modificado podría saltarse el pago. Para un diario personal es un riesgo asumible; si algún día importa, hay que añadir un servidor que valide los recibos.
- **Suscripción anual**: la app consulta a Play cada vez que se abre. Si no logra confirmarla durante más de 7 días (por ejemplo, sin conexión), el premium se pausa hasta la próxima confirmación. El pago de por vida no caduca.
- **Restaurar compras**: en la pantalla Premium hay un botón para recuperar la compra tras reinstalar o cambiar de móvil.
- **Caducidad y cancelaciones**: si cancelas la suscripción, sigue activa hasta que acabe el periodo pagado. Cuando caduca, la app puede tardar hasta 7 días en bloquear las funciones premium.
- **Reembolsos**: un reembolso del pago de por vida **no** se detecta (sin servidor, la app no se entera). Si alguna vez hace falta, se puede añadir una consulta del estado de la compra.

## Copias de seguridad

*Menú ☰ → Copia de seguridad.* La copia es **un único archivo `.gonen`** con todo el diario, las cápsulas, las fotos y las notas de voz. Al pulsar *Crear copia*, Android te deja elegir dónde guardarlo (Google Drive, la memoria del móvil, otra app...). No pasa por ningún servidor de Gonen y no hace falta ningún permiso de almacenamiento.

- **Crear** (Premium): guarda todo lo que hay en ese momento. Si una foto o nota de voz figuraba en la base de datos pero su archivo ya no existe, no entra en la copia y se avisa.
- **Restaurar** (gratis): elige un archivo `.gonen`. **Nunca borra ni sobrescribe nada**: solo añade lo que falta. Si un día ya tiene un texto distinto en el móvil, se queda el del móvil (la pantalla te dice cuántos días se han respetado así). Las cápsulas y los archivos que ya estaban no se duplican. Restaurar dos veces la misma copia no cambia nada la segunda vez.
- **Sin cifrar**: el archivo es legible por quien lo tenga. Guárdalo en un lugar privado.
- **Archivo dañado o cortado**: se detecta y se rechaza sin tocar nada de lo que ya tienes.
- **Copia automática de Android** (además de la anterior): si el móvil tiene activada la copia de Google, Android guarda también la base de datos (los textos) y la restaura al reinstalar desde Google Play o al configurar un móvil nuevo. Las fotos y las notas de voz se excluyen de esa copia (`res/xml/gonen_backup_rules.xml`) porque Google solo admite 25 MB por app y, si se pasa, **no guarda nada**. Al pasar datos de móvil a móvil con cable o Bluetooth sí viajan completos. Para tener también las fotos y las notas de voz, usa la copia en archivo.
- **Cambio de firma**: un APK firmado con otra clave no se puede instalar encima del anterior; hay que desinstalarlo y se pierden los datos locales. Haz una copia antes (la firma de depuración de GitHub puede cambiar entre ejecuciones; con tu propia clave para Google Play esto no pasa).

## Cápsulas para otras personas

*Menú ☰ → Cápsulas → Nueva cápsula → «Es para otra persona».* Pon tu nombre (el que verá la otra persona) y, si quieres, para quién es (solo lo ves tú). Al sellar, Gonen prepara un archivo **`.gonencap`** y abre el menú de compartir con este texto:

> Ana te ha dejado una cápsula del tiempo en Gonen. Se podrá abrir el viernes, 9 de mayo de 2031. Ábrela con la app Gonen y la cápsula se guardará sola; te avisará el día de apertura. Si no se abre, entra en Gonen → Cápsulas → Importar.

- **Sin servidores**: el archivo viaja por el canal que elijas; no pasa por ningún servidor de Gonen. El texto no dice nada del contenido.
- **Cómo se ve en el chat**: el archivo se llama *«Cápsula del tiempo de Ana (ábrela con Gonen).gonencap»*, para que quien lo recibe sepa qué es y con qué se abre sin fiarse de nada más. WhatsApp muestra los archivos de tipo desconocido con el icono genérico «BIN» (eso no se puede cambiar desde la app) y suele descartar el texto que acompaña a un archivo así; en correo y otras apps el texto sí llega. Un aspecto más cuidado (tarjeta con vista previa) solo es posible con un enlace, y para eso haría falta un servidor.
- **Quien envía** necesita Premium. Se queda una copia en su lista («Para Lucía»), que se abre el mismo día. Desde la cápsula, el botón *Enviar el archivo otra vez* repite el envío. Si el menú de compartir no se puede abrir, Gonen guarda el archivo donde elijas para que lo mandes tú.
- **Quien recibe** no necesita Premium. Hay dos caminos: tocar el archivo en WhatsApp/correo/gestor de archivos y elegir *Gonen* (la cápsula se guarda sola y la app lo cuenta), o entrar en *Cápsulas → icono de importar* y elegir el archivo. Mientras no llega el día, solo se ve de quién es y cuándo se abre. Si el mismo archivo llega dos veces, no se duplica.
- **Fotos y notas de voz** viajan dentro del mismo archivo (máx. 5 fotos y 2 notas de voz).
- **Qué protege el cifrado**: todo el contenido (título, mensaje, fecha, nombre y archivos) va cifrado con HMAC-SHA256 y firmado; si el archivo se toca o se corta, la app lo rechaza. Con un editor de texto o descomprimiéndolo no se ve nada.
- **Qué NO protege**: la clave está dentro de la app (es la misma en todos los móviles, así la otra app puede abrirla sin servidor). Quien desmonte el APK puede sacarla, y quien cambie la fecha del móvil puede abrirla antes. Es un candado para que no se lea a simple vista, no una caja fuerte. Si el repositorio es público, la clave (`lib/services/capsule_secret.dart`) también lo es.
- **Android**: `tool/patch_android.py` añade el menú de compartir y la recogida de archivos al `MainActivity.kt`, un `FileProvider` propio (`GonenFileProvider`) y el filtro que hace que Gonen aparezca al abrir un archivo. Como WhatsApp y otras apps presentan estos archivos como «genéricos» (`application/octet-stream`), Gonen también aparecerá en la lista «Abrir con» de otros archivos desconocidos. Si al tocar el archivo no ofrece Gonen, usa *Importar*.

## Estilos y logo

*Ajustes → Apariencia → Estilo* ofrece dos estilos. La elección se guarda y se aplica al instante (la pantalla de inicio cambia de forma, no solo de colores):

| Estilo | Cómo es |
| --- | --- |
| **Editorial japonesa** (el predeterminado) | Como una revista sobre papel washi: número del día en Noto Serif extranegrita, mes en vertical junto a una línea bermellón, sello con punto, etiquetas en mayúsculas con letra de máquina de escribir (IBM Plex Mono), esquinas rectas y líneas finas de tinta. **Sin ninguna letra japonesa**: solo el aire. |
| **Hilo rojo** | Papel washi cálido, tinta sumi, acento bermellón y tarjetas con borde fino, unidas por un hilo bermellón vertical que baja por la izquierda y ata las tarjetas de los años con un nudo en cada una; la de hoy lleva el nudo relleno y un «HOY» sobre la fecha. |

Antes había otros dos estilos (Papelería japonesa y Editorial, la de revista con acento naranja). Se quitaron del todo: quien los tenía elegidos pasa automáticamente a la Editorial japonesa.

Los estilos viven en `lib/theme/app_style.dart` (el enum `AppStyle`, que decide fuentes, esquinas y forma de la pantalla; el primer valor es el predeterminado) y `lib/theme/app_theme.dart` (paletas y componentes). Los widgets preguntan el estilo con `context.appStyle`. Para añadir otro estilo: un valor nuevo en `AppStyle`, su paleta en `AppTheme.schemeFor` y, si cambia la forma de la lista, su rama en `home_screen.dart`.

**Fuentes.** La editorial japonesa lleva sus tipografías dentro del APK (`assets/fonts/`, unos 200 KB en total, solo alfabeto latino) para no necesitar internet. Son **SIL Open Font License 1.1** (IBM Plex Mono y Noto Serif); cada licencia está en `assets/fonts/OFL-*.txt`. `tool/make_fonts.py` documenta cómo se generaron a partir del repositorio `google/fonts`.

**Logo «Anillos».** Cinco anillos de un tronco —los años, de dentro afuera— en papel claro sobre bermellón; los anillos se van apagando hacia fuera. Se usa en el icono del lanzador (adaptativo, con capa monocroma para los iconos temáticos de Android 13), en el icono de las notificaciones, en el menú lateral y en `store/icon-512.png` (ficha de Google Play). `tool/patch_android.py` escribe los iconos vectoriales y copia los PNG de `tool/icons/` (Android 7.x) al proyecto generado.

## Idioma

*Ajustes → Idioma* cambia toda la app entre **Español** (por defecto) e **English**. Es un ajuste propio de la app: no depende del idioma del móvil.

- Los textos van en el propio código con `tr('español', 'english')` (o `context.tr(...)` en pantallas) en `lib/l10n/tr.dart`. Quien llame a `tr` fuera de un widget lee el idioma de `AppLocale.current`, que `SettingsProvider` actualiza al cargar y al cambiar.
- Fechas y calendario del sistema (selector de día) usan `flutter_localizations` con `es` y `en`.
- Las frases del dado de ideas tienen su versión inglesa en `lib/data/writing_prompts_en.dart`, en el mismo orden; una prueba comprueba que ambas listas tienen la misma longitud. Si añades una frase, añade las dos.
- El archivo de una cápsula enviada se llama «Cápsula del tiempo de Ana (ábrela con Gonen).gonencap» o «Time capsule from Ana (open it with Gonen).gonencap» según el idioma de quien la envía. El **contenido** de las cápsulas y del diario no se traduce nunca: es lo que escribiste.
- Los avisos ya programados (cápsulas) conservan el idioma con el que se crearon hasta que la app los vuelva a programar (al abrirla). El recordatorio diario se reprograma en el acto al cambiar de idioma.

## Compilar en tu ordenador

Requisitos: Flutter 3.38.1 o superior (Dart 3.10+), Java 17 y Python 3. El script `tool/patch_android.py` está pensado para la plantilla de Android de Flutter 3.38; con versiones mucho más nuevas puede necesitar ajustes.

```bash
flutter create --platforms=android --org com.gonen --project-name gonen .
python3 tool/patch_android.py
flutter pub get
flutter run                      # en un móvil o emulador
flutter build apk --release      # build/app/outputs/flutter-apk/app-release.apk
flutter test                     # pruebas de modelos, reglas de edición, estilos, idioma y menú lateral
```

## Estructura

```
lib/
  main.dart                       Arranque, proveedores, tema y localización
  app_info.dart                   Versión mostrada en la app
  models/
    entry_model.dart              Entry (id, dayOfYear, year, content, updatedAt)
    capsule_model.dart            Capsule y estados: sellada / lista / abierta
    day_access.dart               Regla de las 23:59: editable / terminado / aún no / no existe
    diary_limits.dart             Límites del ajuste «años anteriores»
    attachment_model.dart         Attachment: foto o nota de voz de un día o de una cápsula
    backup_snapshot.dart          Contenido de una copia (JSON) y resultado de restaurarla
    attachment_limits.dart        Máximos por día y calidad de las fotos
    premium_entitlement.dart      Plan (anual / de por vida) y margen de 7 días de la suscripción
  database/database_helper.dart   SQLite v5: entradas, cápsulas y adjuntos (migraciones v1 → … → v5), días escritos y mezcla de copias
  providers/
    diary_provider.dart           Día seleccionado, navegación, guardado automático, bloqueo a medianoche
    capsules_provider.dart        Crear, abrir, borrar e importar cápsulas; avisos
    settings_provider.dart        Años visibles, bloqueo biométrico, recordatorio, tema, estilo e idioma
    premium_provider.dart         Compras con Google Play (in_app_purchase) y estado premium
  services/
    biometric_service.dart        local_auth
    notification_service.dart     Aviso diario y avisos de cápsulas
    capsule_cipher.dart           Cifrado y firma de los archivos de cápsula (HMAC-SHA256)
    capsule_secret.dart           Clave de la app para las cápsulas enviadas
    capsule_share_service.dart    Preparar y leer archivos .gonencap
    capsule_sender.dart           Enviar: menú de compartir o guardar el archivo
    attachment_service.dart       Carpeta privada de fotos y notas de voz
    backup_archive.dart           Formato del archivo .gonen (escritura y lectura por trozos)
    backup_service.dart           Crear y restaurar copias de seguridad
    file_transfer_service.dart    Guardar/abrir archivos con el selector de Android (canal gonen/files)
    external_activity_guard.dart  Evita volver a bloquear la app al volver de la cámara o del pago
    trusted_clock.dart            Fecha de verdad aunque se cambie la del móvil (canal gonen/files, método clockInfo)
  screens/
    home_screen.dart              Menú lateral, cabecera con fecha y tarjetas por año
    capsules_screen.dart          Lista de cápsulas
    new_capsule_screen.dart       Escribir y sellar una cápsula
    capsule_detail_screen.dart    Cuenta atrás / abrir / leer
    calendar_screen.dart          Calendario con sellos y rachas
    search_screen.dart            Búsqueda en todo el diario
    backup_screen.dart            Crear y restaurar copias de seguridad
    premium_screen.dart           Planes, precios, restaurar compras
    image_viewer_screen.dart      Foto a pantalla completa con zoom
    settings_screen.dart          Ajustes
    lock_screen.dart              Pantalla de bloqueo
  widgets/                        Menú, tarjetas, diálogos, cabecera de fecha, bloqueo global,
                                  adjuntos (lista, barra de acciones, grabadora de voz),
                                  hilo rojo (thread_frame), logo (gonen_mark) y aviso de fecha
                                  sin comprobar (clock_notice)
  data/writing_prompts.dart       Banco de frases y preguntas del dado de ideas (español)
  data/writing_prompts_en.dart    Las mismas frases en inglés, en el mismo orden
  l10n/tr.dart                    Idioma de la app: tr(), context.tr(), LanguageScope
  utils/                          Textos de fechas, duración, rachas (streak_stats), búsqueda (search_utils) y baraja del dado (prompt_deck)
  theme/app_style.dart            Los dos estilos (AppStyle) y context.appStyle
  theme/app_theme.dart            Paletas y componentes de cada estilo, claro y oscuro
assets/fonts/                     Tipografías de la editorial japonesa (OFL)
tool/patch_android.py             Adapta el proyecto Android generado (iconos, compartir archivos...)
tool/icons/                       PNG del icono para Android 7.x
tool/make_fonts.py                Cómo se generaron las fuentes
store/icon-512.png                Icono de 512 px para la ficha de Google Play
.github/workflows/build-apk.yml   Compila el APK en GitHub Actions
```

## Detalles de comportamiento

- **Guardado**: el texto se guarda solo tras unos instantes sin teclear (0,9 s), al cambiar de día, al abrir otra pantalla y al pasar la app a segundo plano. El botón de la tarjeta (tick + texto) dice **Guardar** solo cuando hay cambios sin guardar; mientras guarda dice *Guardando…* y, cuando todo está en la base de datos, **Guardado** y queda apagado hasta que cambies algo. Si el guardado falla, el mismo botón se pone en rojo y vuelve a decir *Guardar*. El aviso «Puedes editar hasta las 23:59» de al lado no cambia nunca. Si dejas una entrada vacía, se borra y ese año vuelve a mostrar «Sin entrada este año».
- **Regla de las 23:59**: solo se puede escribir en el día de hoy. Lo escrito antes de las 00:00 se guarda; a las 00:00 la tarjeta pasa a solo lectura aunque tengas la app abierta. Los días pasados del año actual se pueden leer pero no editar, y los días futuros no se pueden escribir todavía («Este día aún no ha llegado»). Un día que no escribiste no se puede rellenar después.
- **Fotos y notas de voz**: se añaden desde la tarjeta del año actual, solo con Premium y solo el propio día hasta las 23:59 (igual que el texto). Después quedan en solo lectura: se pueden ver y escuchar, no añadir ni borrar. Una grabación tiene que guardarse antes de las 00:00: si la terminas pasada la medianoche, se descarta (el día ya está cerrado). Cada nota se corta sola a los 5 minutos. Los archivos se guardan en la carpeta privada de la app (las fotos se reducen a 1600 px y calidad 80) y no aparecen en la galería del móvil.
- **29 de febrero**: existe como día navegable. En años no bisiestos la tarjeta lo indica en lugar de dejar escribir.
- **Cambio de día**: si la app estaba en segundo plano y pasa la medianoche, al volver muestra el nuevo día (solo si estabas viendo «hoy»). Con la app abierta a medianoche, la tarjeta se bloquea pero la pantalla no salta sola: pulsa «Hoy».
- **Cápsulas**: el aviso se programa a las 09:00 del día de apertura y no muestra el título ni el contenido en la pantalla de bloqueo. Si deniegas el permiso de notificaciones, la cápsula se guarda igualmente, pero no habrá aviso. El «sellado» es una regla de la app, no cifrado: el texto está en la base de datos local, así que quien tenga acceso a los archivos del móvil (root) puede leerla. Cambiar la fecha del teléfono **no** la abre: ver el punto siguiente.
- **Fecha de las cápsulas** (`lib/services/trusted_clock.dart`): una cápsula solo se abre si Gonen está seguro de qué día es de verdad. Sin internet y sin permisos nuevos, se apoya en el contador de Android desde el arranque (`SystemClock.elapsedRealtime`: solo avanza, también con el móvil en reposo, y no depende de la fecha) y en un **punto de referencia** que Gonen guarda: «a esta fecha real, el contador marcaba tanto».
  - **Mismo arranque que el punto de referencia** (lo normal): la fecha real es la del punto de referencia más lo que ha contado Android desde entonces. Si el reloj del móvil coincide (margen de 3 minutos con la fecha manual y de 10 con la automática), se usa el reloj. Si no coincide, alguien ha cambiado la fecha: manda el contador, la cápsula sigue sellada y la cuenta atrás no se mueve. Esto vale **también con «Fecha y hora automáticas» activado**: sin internet se puede dejar una fecha falsa y volver a activar la automática, y el ajuste seguiría diciendo «automática». La única excepción es un reloj *atrasado* con la fecha automática: es la red corrigiéndolo hacia atrás, y atrasar nunca abre una cápsula antes.
  - **Sin punto de referencia o tras reiniciar el móvil** (el contador vuelve a cero; se detecta con el número de arranques `Settings.Global.BOOT_COUNT`): con la fecha automática se da por buena la del reloj y se guarda como punto de referencia; con la fecha manual no hay forma de saber qué día es, las cápsulas se quedan selladas y la pantalla pide activar «Fecha y hora automáticas». Tampoco se puede crear una cápsula nueva mientras tanto. Las cápsulas ya abiertas se pueden leer siempre.
  - Si Android no puede dar el contador en un móvil Android, **no se da la fecha por buena** (así la protección no se apaga en silencio). Fuera de Android (las pruebas) se usa el reloj del móvil.
  - La comprobación se hace al abrir la app, al volver a ella (las pantallas se actualizan después de comprobar, no antes), al crear una cápsula y justo antes de abrir una. Cuando alguien ha cambiado la fecha, la lista y la cápsula lo dicen: «La fecha del móvil no es la real. Gonen usa la fecha de verdad para tus cápsulas».
  - **Límites**: con el móvil sin internet, cambiar la fecha a mano, **reiniciar** y volver a activar la fecha automática engaña a Gonen hasta que el móvil se conecte y la red corrija el reloj (entonces lo detecta y la cápsula vuelve a quedar sellada); cerrarlo del todo exigiría consultar la hora en internet. Cambiar la **zona horaria** a mano puede adelantar el día como mucho un día. No protege frente a quien tenga acceso a los archivos del móvil (root). Los avisos de Android (`AlarmManager`) sí dependen del reloj del móvil: si se adelanta la fecha, el aviso de «ya se puede abrir» puede llegar antes de tiempo, pero la cápsula seguirá sellada al tocarlo. Al volver a la app se repasan los avisos de las cápsulas selladas con la fecha de verdad. Google Play admite este mecanismo: no usa permisos nuevos ni datos personales.
- **Recordatorio diario**: se programa como aviso «inexacto» (`inexactAllowWhileIdle`): suena aunque el móvil esté en reposo, pero Android decide el momento justo y puede retrasarlo unos minutos (más con el ahorro de batería). **No usa alarmas exactas a propósito**: el permiso `SCHEDULE_EXACT_ALARM` está reservado por Google Play a apps cuya función principal es una alarma o un calendario, y para un recordatorio de usuario Android recomienda las alarmas inexactas. Los avisos están configurados como los de un mensaje de WhatsApp: canal de importancia alta (salen como emergentes y encienden la pantalla), prioridad alta, sonido y vibración, categoría «recordatorio» y el icono tintado en bermellón. Los canales se crean al arrancar —Android no deja subir la importancia de un canal ya creado, por eso los antiguos se borran y se estrenan canales nuevos (`gonen_daily_reminder_v2`, `gonen_capsules_v2`)— y al arrancar y cada vez que vuelves a la app se comprueba que el recordatorio sigue programado (con la zona horaria del momento). **No se reprograma a ciegas**: reprogramar cancela la alarma que ya hay, y si Android estaba retrasando unos minutos un aviso «inexacto» y abrías la app justo entonces, el aviso de hoy se movía a mañana sin haber salido. Ahora solo se reprograma si cambió la hora, el idioma o la zona horaria, si Android ya no lo tiene programado o si pasaron más de 3 horas de su hora. Si Android no deja mostrar las notificaciones de Gonen (permiso denegado o avisos apagados en el sistema), Ajustes lo dice bajo la hora del recordatorio y explica dónde activarlas.
- **Versión release (R8)**: `flutter_local_notifications` guarda cada aviso programado como JSON con Gson y lo lee cuando Android dispara la alarma con la app cerrada. `tool/patch_android.py` escribe `android/app/proguard-rules.pro` y lo enlaza en el bloque `release` para que R8 no quite ni renombre lo que Gson necesita (si lo hiciera, el aviso programado no saldría nunca, aunque uno inmediato sí).
- **Si los avisos no llegan**: comprueba *Ajustes del móvil → Aplicaciones → Gonen → Notificaciones* (activadas, y el canal «Recordatorio diario» sin silenciar) y *Batería* (sin restricciones u «optimizada», nunca «restringida»). Algunos fabricantes (Xiaomi, Huawei, Oppo, Samsung...) cierran las apps que llevan tiempo sin abrirse y con ellas se pierden los avisos programados; en esos móviles conviene permitir el inicio automático o dejar la batería de Gonen sin restricciones.
- **Bloqueo**: se pide al abrir la app y cada vez que vuelve de segundo plano; se intenta tapar la vista previa del selector de apps (Android no siempre lo permite). Si el dispositivo se queda sin huella ni bloqueo de pantalla, la pantalla de bloqueo ofrece desactivarlo para que el diario no quede inaccesible.
- **Rachas**: cuenta días seguidos en los que hay texto o alguna foto o nota de voz. Si hoy todavía no has escrito pero ayer sí, la racha sigue viva (te queda el día de hoy para mantenerla). Las fotos y notas de las cápsulas no cuentan; los 29 de febrero de años no bisiestos tampoco existen.
- **Cápsulas con fotos y notas de voz**: se añaden al escribir la cápsula (solo Premium); mientras está sellada solo se ve cuántas lleva, y al abrirla se ven y se oyen. Si sales sin sellar, los archivos se borran. Al borrar una cápsula se borran también sus archivos.
- **Copia automática de Android**: ver «Copias de seguridad». Si no quieres que Android guarde ni siquiera el texto, cambia `android:allowBackup` a `"false"` en `tool/patch_android.py`.
