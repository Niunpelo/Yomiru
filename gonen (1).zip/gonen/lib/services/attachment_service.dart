import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Guarda y localiza los archivos (fotos y notas de voz) en el almacenamiento
/// privado de la app. Ninguno sale del dispositivo.
///
/// Estructura: `attachments/AAAA/MM-DD/<marca de tiempo>.<extensión>`.
class AttachmentService {
  AttachmentService._();

  /// Instancia única compartida por toda la aplicación.
  static final AttachmentService instance = AttachmentService._();

  Directory? _root;

  /// Localiza (y crea si hace falta) la carpeta de adjuntos. Se llama al arrancar.
  Future<void> initialize() async {
    if (_root != null) {
      return;
    }
    final Directory documents = await getApplicationDocumentsDirectory();
    final Directory root = Directory(p.join(documents.path, 'attachments'));
    await root.create(recursive: true);
    _root = root;
  }

  Directory get _requireRoot {
    final Directory? root = _root;
    if (root == null) {
      throw StateError('AttachmentService.initialize() no se ha llamado.');
    }
    return root;
  }

  /// Archivo correspondiente a una ruta relativa guardada en la base de datos.
  File fileFor(String relativePath) =>
      File(p.join(_requireRoot.path, relativePath));

  /// Ruta relativa nueva y única para un archivo de un día concreto.
  String newRelativePath({
    required String dayKey,
    required int year,
    required String extension,
  }) {
    final int stamp = DateTime.now().microsecondsSinceEpoch;
    return p.join('$year', dayKey, '$stamp.$extension');
  }

  /// Archivo de [relativePath] con su carpeta ya creada, listo para escribir.
  Future<File> prepareFile(String relativePath) async {
    final File file = fileFor(relativePath);
    await file.parent.create(recursive: true);
    return file;
  }

  /// Copia [sourcePath] (por ejemplo, la foto recién hecha) a [relativePath].
  Future<void> copyInto(String relativePath, String sourcePath) async {
    final File target = await prepareFile(relativePath);
    await File(sourcePath).copy(target.path);
  }

  /// Borra el archivo si existe. Nunca lanza: un archivo que no se puede borrar
  /// no debe impedir quitar el adjunto de la base de datos.
  Future<void> delete(String relativePath) async {
    try {
      final File file = fileFor(relativePath);
      if (await file.exists()) {
        await file.delete();
      }
    } catch (error) {
      debugPrint('Gonen: no se pudo borrar el archivo $relativePath: $error');
    }
  }
}
