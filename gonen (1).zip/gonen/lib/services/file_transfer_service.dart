import 'dart:io';

import 'package:flutter/services.dart';

import 'external_activity_guard.dart';

/// Error al hablar con el selector de archivos del sistema.
class FileTransferException implements Exception {
  const FileTransferException(this.message);

  final String message;

  @override
  String toString() => message;
}

/// Guarda y elige archivos con las pantallas del sistema de Android (el
/// selector de documentos), sin necesitar ningún permiso de almacenamiento.
///
/// El código nativo está en `MainActivity.kt` (lo escribe `tool/patch_android.py`)
/// y responde al canal `gonen/files`.
class FileTransferService {
  const FileTransferService();

  static const MethodChannel _channel = MethodChannel('gonen/files');

  /// Tiempo máximo que se espera a que el usuario elija dónde guardar o qué abrir.
  static const Duration _waitForUser = Duration(minutes: 10);

  /// Pide al usuario dónde guardar [sourcePath] y lo copia allí con el nombre
  /// [suggestedName]. Devuelve false si el usuario cancela.
  Future<bool> saveFile({
    required String sourcePath,
    required String suggestedName,
  }) async {
    try {
      // La pantalla del sistema saca a la app a segundo plano: que al volver
      // no pida la huella otra vez.
      ExternalActivityGuard.allowFor(_waitForUser);
      final bool? saved = await _channel.invokeMethod<bool>(
        'saveFile',
        <String, Object?>{
          'sourcePath': sourcePath,
          'suggestedName': suggestedName,
        },
      );
      return saved ?? false;
    } on PlatformException catch (error) {
      throw FileTransferException(
        error.message ?? 'No se pudo guardar el archivo.',
      );
    } on MissingPluginException {
      throw const FileTransferException(
        'Esta versión de la app no puede guardar archivos.',
      );
    } finally {
      ExternalActivityGuard.clear();
    }
  }

  /// Abre el menú de compartir de Android con el archivo [path] y el [text]
  /// que lo acompaña (WhatsApp, correo, Bluetooth...). Termina en cuanto se
  /// abre el menú; no se sabe si el usuario llegó a enviarlo.
  Future<void> shareFile({
    required String path,
    required String text,
    String? subject,
  }) async {
    try {
      // El menú de compartir saca a la app a segundo plano. No se quita el
      // permiso al terminar la llamada (el cambio ocurre después), sino que
      // caduca solo.
      ExternalActivityGuard.allowFor(const Duration(seconds: 30));
      await _channel.invokeMethod<bool>(
        'shareFile',
        <String, Object?>{'path': path, 'text': text, 'subject': subject},
      );
    } on PlatformException catch (error) {
      ExternalActivityGuard.clear();
      throw FileTransferException(
        error.message ?? 'No se pudo abrir el menú de compartir.',
      );
    } on MissingPluginException {
      ExternalActivityGuard.clear();
      throw const FileTransferException(
        'Esta versión de la app no puede compartir archivos.',
      );
    }
  }

  /// Archivo que otra app ha mandado abrir con Gonen («Abrir con...»), si lo
  /// hay. Devuelve una copia suya dentro de la carpeta temporal de la app. Solo
  /// se entrega una vez: la siguiente llamada devuelve null.
  Future<File?> takeIncomingFile() async {
    try {
      final String? path = await _channel.invokeMethod<String>('takeIncomingFile');
      if (path == null || path.isEmpty) {
        return null;
      }
      return File(path);
    } on PlatformException catch (error) {
      throw FileTransferException(
        error.message ?? 'No se pudo leer el archivo recibido.',
      );
    } on MissingPluginException {
      return null;
    }
  }

  /// Pide al usuario que elija un archivo y devuelve una copia suya dentro de
  /// la carpeta temporal de la app, o null si cancela.
  Future<File?> pickFile() async {
    try {
      ExternalActivityGuard.allowFor(_waitForUser);
      final String? path = await _channel.invokeMethod<String>('pickFile');
      if (path == null || path.isEmpty) {
        return null;
      }
      return File(path);
    } on PlatformException catch (error) {
      throw FileTransferException(
        error.message ?? 'No se pudo abrir el archivo.',
      );
    } on MissingPluginException {
      throw const FileTransferException(
        'Esta versión de la app no puede abrir archivos.',
      );
    } finally {
      ExternalActivityGuard.clear();
    }
  }
}
