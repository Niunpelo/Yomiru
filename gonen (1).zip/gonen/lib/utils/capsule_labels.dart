import '../models/capsule_model.dart';

/// «Para Lucía» (cápsula enviada), «De Ana» (cápsula recibida), o null si es
/// una cápsula normal, solo para uno mismo.
String? capsulePeerLabel(Capsule capsule) {
  final String? recipient = capsule.recipient;
  if (recipient != null) {
    final String name = recipient.trim();
    return name.isEmpty ? 'Para otra persona' : 'Para $name';
  }
  final String? sender = capsule.sender;
  if (sender != null) {
    return 'De $sender';
  }
  return null;
}
