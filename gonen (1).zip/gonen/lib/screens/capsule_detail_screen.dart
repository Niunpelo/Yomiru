import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/attachment_model.dart';
import '../models/capsule_model.dart';
import '../providers/capsules_provider.dart';
import '../providers/premium_provider.dart';
import '../services/capsule_sender.dart';
import '../theme/app_theme.dart';
import '../utils/capsule_labels.dart';
import '../utils/date_labels.dart';
import '../widgets/attachments_section.dart';
import '../widgets/capsule_dialogs.dart';
import '../widgets/paper_card.dart';
import 'premium_screen.dart';

/// Detalle de una cápsula. Según su estado enseña la cuenta atrás (sellada),
/// el botón para abrirla (lista) o el mensaje (abierta).
class CapsuleDetailScreen extends StatefulWidget {
  const CapsuleDetailScreen({super.key, required this.capsuleId});

  final int capsuleId;

  @override
  State<CapsuleDetailScreen> createState() => _CapsuleDetailScreenState();
}

class _CapsuleDetailScreenState extends State<CapsuleDetailScreen> {
  bool _busy = false;

  void _showMessage(ScaffoldMessengerState messenger, String text) {
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _open() async {
    if (_busy) {
      return;
    }
    final CapsulesProvider capsules = context.read<CapsulesProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);

    setState(() => _busy = true);
    final String? error = await capsules.open(widget.capsuleId);
    if (!mounted) {
      return;
    }
    setState(() => _busy = false);
    if (error != null) {
      _showMessage(messenger, error);
    }
  }

  /// Vuelve a preparar el archivo de una cápsula enviada y abre el menú de
  /// compartir (por si no se llegó a enviar, o hay que mandarla otra vez).
  Future<void> _resend() async {
    if (_busy) {
      return;
    }
    final CapsulesProvider capsules = context.read<CapsulesProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final Capsule? capsule = capsules.byId(widget.capsuleId);
    if (capsule == null) {
      return;
    }
    if (!context.read<PremiumProvider>().isPremium) {
      await Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (BuildContext context) => const PremiumScreen(),
        ),
      );
      return;
    }

    setState(() => _busy = true);
    String? note;
    try {
      final CapsuleSendResult sent = await CapsuleSender().send(
        capsule,
        capsules.attachmentsFor(widget.capsuleId),
      );
      switch (sent) {
        case CapsuleSendResult.shared:
          break;
        case CapsuleSendResult.saved:
          note = 'El archivo está guardado: envíaselo tú a la otra persona.';
        case CapsuleSendResult.cancelled:
          break;
      }
    } on CapsuleSendException catch (error) {
      note = error.message;
    } catch (error) {
      debugPrint('Gonen: error al enviar la cápsula: $error');
      note = 'No se pudo enviar el archivo de la cápsula.';
    }
    if (!mounted) {
      return;
    }
    setState(() => _busy = false);
    if (note != null) {
      _showMessage(messenger, note);
    }
  }

  Future<void> _delete() async {
    if (_busy) {
      return;
    }
    final CapsulesProvider capsules = context.read<CapsulesProvider>();
    final NavigatorState navigator = Navigator.of(context);
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);

    final bool confirmed = await confirmDeleteCapsule(context);
    if (!confirmed || !mounted) {
      return;
    }

    setState(() => _busy = true);
    final String? error = await capsules.delete(widget.capsuleId);
    if (!mounted) {
      return;
    }
    if (error != null) {
      setState(() => _busy = false);
      _showMessage(messenger, error);
      return;
    }
    navigator.pop();
  }

  @override
  Widget build(BuildContext context) {
    final CapsulesProvider capsules = context.watch<CapsulesProvider>();
    final Capsule? capsule = capsules.byId(widget.capsuleId);

    if (capsule == null) {
      // Ocurre un instante tras borrarla, justo antes de cerrar la pantalla.
      return Scaffold(appBar: AppBar(), body: const SizedBox.shrink());
    }

    final CapsuleStatus status = capsules.statusOf(capsule);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Cápsula'),
        actions: <Widget>[
          if (capsule.isSent)
            IconButton(
              onPressed: _busy ? null : () => unawaited(_resend()),
              icon: const Icon(Icons.send_outlined),
              tooltip: 'Enviar el archivo otra vez',
            ),
          IconButton(
            onPressed: _busy ? null : _delete,
            icon: const Icon(Icons.delete_outline_rounded),
            tooltip: 'Borrar cápsula',
          ),
        ],
      ),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
              children: switch (status) {
                CapsuleStatus.sealed => _sealedContent(
                    context,
                    capsule,
                    capsules.daysUntilOpen(capsule),
                    capsules.attachmentsFor(widget.capsuleId),
                  ),
                CapsuleStatus.ready => _readyContent(
                    context,
                    capsule,
                    capsules.attachmentsFor(widget.capsuleId),
                  ),
                CapsuleStatus.opened => _openedContent(
                    context,
                    capsule,
                    capsules.attachmentsFor(widget.capsuleId),
                  ),
              },
            ),
          ),
        ),
      ),
    );
  }

  String _titleOf(Capsule capsule) =>
      capsule.title.isEmpty ? 'Sin título' : capsule.title;

  /// «De Ana» o «Para Lucía» cuando la cápsula se envió o se recibió; si no,
  /// nada.
  List<Widget> _peerLine(
    BuildContext context,
    Capsule capsule, {
    TextAlign align = TextAlign.center,
  }) {
    final String? peer = capsulePeerLabel(capsule);
    if (peer == null) {
      return const <Widget>[];
    }
    final ThemeData theme = Theme.of(context);
    return <Widget>[
      const SizedBox(height: 6),
      Text(
        peer,
        textAlign: align,
        style: theme.textTheme.titleSmall?.copyWith(
          color: theme.colorScheme.primary,
        ),
      ),
    ];
  }

  /// "Incluye 2 fotos y 1 nota de voz", o null si no hay ninguna.
  String? _attachmentsSummary(List<Attachment> attachments) {
    final int images = attachments
        .where((Attachment item) => item.type == AttachmentType.image)
        .length;
    final int notes = attachments.length - images;
    final List<String> parts = <String>[
      if (images > 0) images == 1 ? '1 foto' : '$images fotos',
      if (notes > 0) notes == 1 ? '1 nota de voz' : '$notes notas de voz',
    ];
    return parts.isEmpty ? null : 'Incluye ${parts.join(' y ')}.';
  }

  List<Widget> _sealedContent(
    BuildContext context,
    Capsule capsule,
    int days,
    List<Attachment> attachments,
  ) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final String? summary = _attachmentsSummary(attachments);

    return <Widget>[
      const SizedBox(height: 16),
      Icon(Icons.lock_outline_rounded, size: 56, color: scheme.primary),
      const SizedBox(height: 16),
      Text(
        _titleOf(capsule),
        textAlign: TextAlign.center,
        style: theme.textTheme.headlineMedium,
      ),
      ..._peerLine(context, capsule),
      const SizedBox(height: 20),
      Text(
        'Se abrirá el',
        textAlign: TextAlign.center,
        style: theme.textTheme.labelLarge?.copyWith(
          color: scheme.onSurfaceVariant,
        ),
      ),
      const SizedBox(height: 4),
      Text(
        fullDateLabel(capsule.openDate),
        textAlign: TextAlign.center,
        style: theme.textTheme.titleLarge,
      ),
      const SizedBox(height: 8),
      Text(
        remainingDaysLabel(days),
        textAlign: TextAlign.center,
        style: theme.textTheme.titleMedium?.copyWith(color: scheme.primary),
      ),
      const SizedBox(height: 28),
      PaperCard(
        child: Text(
          summary == null
              ? 'El mensaje está sellado: no se puede leer hasta ese día.'
              : 'El mensaje está sellado: no se puede leer hasta ese día. '
                  '$summary',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: kSerifFamily,
            fontSize: 15,
            fontStyle: FontStyle.italic,
            color: scheme.onSurfaceVariant,
          ),
        ),
      ),
      if (capsule.isSent) ...<Widget>[
        const SizedBox(height: 12),
        Text(
          'Te quedas una copia. Con el botón de arriba puedes enviar el '
          'archivo otra vez.',
          textAlign: TextAlign.center,
          style: theme.textTheme.bodySmall?.copyWith(
            color: scheme.onSurfaceVariant,
          ),
        ),
      ],
      const SizedBox(height: 20),
      Text(
        'Escrita el ${fullDateLabel(capsule.createdAt)}',
        textAlign: TextAlign.center,
        style: theme.textTheme.bodySmall?.copyWith(
          color: scheme.onSurfaceVariant,
        ),
      ),
    ];
  }

  List<Widget> _readyContent(
    BuildContext context,
    Capsule capsule,
    List<Attachment> attachments,
  ) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final String? summary = _attachmentsSummary(attachments);

    return <Widget>[
      const SizedBox(height: 16),
      Icon(Icons.mark_email_unread_outlined, size: 56, color: scheme.primary),
      const SizedBox(height: 16),
      Text(
        _titleOf(capsule),
        textAlign: TextAlign.center,
        style: theme.textTheme.headlineMedium,
      ),
      ..._peerLine(context, capsule),
      const SizedBox(height: 16),
      Text(
        'Ya ha llegado el día. Puedes abrirla cuando quieras.',
        textAlign: TextAlign.center,
        style: theme.textTheme.bodyLarge?.copyWith(
          color: scheme.onSurfaceVariant,
        ),
      ),
      if (summary != null) ...<Widget>[
        const SizedBox(height: 6),
        Text(
          summary,
          textAlign: TextAlign.center,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: scheme.onSurfaceVariant,
          ),
        ),
      ],
      const SizedBox(height: 28),
      FilledButton.icon(
        onPressed: _busy ? null : () => unawaited(_open()),
        icon: const Icon(Icons.lock_open_rounded),
        label: const Text('Abrir cápsula'),
      ),
      const SizedBox(height: 20),
      Text(
        'Escrita el ${fullDateLabel(capsule.createdAt)}',
        textAlign: TextAlign.center,
        style: theme.textTheme.bodySmall?.copyWith(
          color: scheme.onSurfaceVariant,
        ),
      ),
    ];
  }

  List<Widget> _openedContent(
    BuildContext context,
    Capsule capsule,
    List<Attachment> attachments,
  ) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final TextStyle? metaStyle = theme.textTheme.bodySmall?.copyWith(
      color: scheme.onSurfaceVariant,
    );

    return <Widget>[
      Text(_titleOf(capsule), style: theme.textTheme.headlineSmall),
      ..._peerLine(context, capsule, align: TextAlign.start),
      const SizedBox(height: 16),
      PaperCard(
        emphasized: true,
        child: SelectableText(
          capsule.content,
          style: theme.textTheme.bodyLarge?.copyWith(
            fontFamily: kSerifFamily,
            fontSize: 17,
            height: 1.75,
          ),
        ),
      ),
      if (attachments.isNotEmpty) ...<Widget>[
        const SizedBox(height: 20),
        AttachmentList(attachments: attachments),
      ],
      const SizedBox(height: 20),
      Text('Escrita el ${fullDateLabel(capsule.createdAt)}', style: metaStyle),
      if (capsule.openedAt != null)
        Text('Abierta el ${fullDateLabel(capsule.openedAt!)}', style: metaStyle),
    ];
  }
}
