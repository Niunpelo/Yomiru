import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/attachment_model.dart';
import '../models/capsule_model.dart';
import '../providers/capsules_provider.dart';
import '../providers/premium_provider.dart';
import '../services/attachment_service.dart';
import '../services/capsule_sender.dart';
import '../services/capsule_share_service.dart';
import '../theme/app_theme.dart';
import '../utils/date_labels.dart';
import '../widgets/capsule_attachments_editor.dart';
import '../widgets/capsule_dialogs.dart';
import 'premium_screen.dart';

/// Formulario para escribir y sellar una cápsula del tiempo nueva.
class NewCapsuleScreen extends StatefulWidget {
  const NewCapsuleScreen({super.key});

  @override
  State<NewCapsuleScreen> createState() => _NewCapsuleScreenState();
}

class _NewCapsuleScreenState extends State<NewCapsuleScreen> {
  final TextEditingController _title = TextEditingController();
  final TextEditingController _message = TextEditingController();

  /// Nombre de quien envía y de quien recibe (solo si la cápsula es para otra
  /// persona).
  final TextEditingController _senderName = TextEditingController();
  final TextEditingController _recipientName = TextEditingController();

  final CapsuleShareService _shareService = CapsuleShareService();
  late final CapsuleSender _sender = CapsuleSender(shareService: _shareService);

  /// Verdadero si la cápsula es para enviarla a otra persona (Premium).
  bool _forOther = false;

  /// Fotos y notas de voz añadidas, todavía sin guardar en la cápsula.
  final List<Attachment> _attachments = <Attachment>[];

  DateTime? _openDate;
  bool _saving = false;

  /// Verdadero cuando ya se ha sellado: a partir de ahí se puede salir sin preguntar.
  bool _done = false;

  /// Verdadero solo si la cápsula se guardó: sus archivos ya no se pueden borrar.
  bool _sealed = false;

  bool get _hasDraft =>
      _title.text.trim().isNotEmpty ||
      _message.text.trim().isNotEmpty ||
      _attachments.isNotEmpty;

  bool get _canSeal =>
      !_saving &&
      _message.text.trim().isNotEmpty &&
      _openDate != null &&
      (!_forOther || _senderName.text.trim().isNotEmpty);

  @override
  void initState() {
    super.initState();
    _title.addListener(_onChanged);
    _message.addListener(_onChanged);
    _senderName.addListener(_onChanged);
    unawaited(_loadSenderName());
  }

  /// Rellena tu nombre con el que se usó la última vez que se envió una cápsula.
  Future<void> _loadSenderName() async {
    final String saved = await _shareService.loadSenderName();
    if (mounted && saved.isNotEmpty && _senderName.text.isEmpty) {
      _senderName.text = saved;
    }
  }

  Future<void> _toggleForOther(bool value) async {
    if (value && !context.read<PremiumProvider>().isPremium) {
      // Enviar cápsulas a otras personas es de Gonen Premium.
      await Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (BuildContext context) => const PremiumScreen(),
        ),
      );
      return;
    }
    if (mounted) {
      setState(() => _forOther = value);
    }
  }

  @override
  void dispose() {
    _title.dispose();
    _message.dispose();
    _senderName.dispose();
    _recipientName.dispose();
    if (!_sealed) {
      // Se salió sin sellar: las fotos y notas de voz no se quedan huérfanas.
      for (final Attachment attachment in _attachments) {
        unawaited(AttachmentService.instance.delete(attachment.relativePath));
      }
    }
    super.dispose();
  }

  void _addAttachment(Attachment attachment) {
    if (!mounted) {
      return;
    }
    setState(() => _attachments.add(attachment));
  }

  Future<void> _removeAttachment(Attachment attachment) async {
    await AttachmentService.instance.delete(attachment.relativePath);
    if (!mounted) {
      return;
    }
    setState(() => _attachments.remove(attachment));
  }

  void _onChanged() => setState(() {});

  /// Suma [months] meses a [from] sin pasarse de mes (31 de enero + 1 mes = 28/29 de febrero).
  DateTime _plusMonths(DateTime from, int months) {
    final int total = from.year * 12 + (from.month - 1) + months;
    final int year = total ~/ 12;
    final int month = total % 12 + 1;
    final int lastDay = DateTime(year, month + 1, 0).day;
    return DateTime(year, month, from.day > lastDay ? lastDay : from.day);
  }

  Future<void> _pickDate() async {
    final DateTime today = context.read<CapsulesProvider>().today;
    final DateTime tomorrow = DateTime(today.year, today.month, today.day + 1);
    // Si la pantalla se quedó abierta pasada la medianoche, la fecha elegida
    // antes puede haber quedado en el pasado: el calendario no la admitiría.
    DateTime initial = _openDate ?? _plusMonths(today, 12);
    if (initial.isBefore(tomorrow)) {
      initial = tomorrow;
    }

    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: tomorrow,
      lastDate: DateTime(today.year + 100, 12, 31),
      helpText: 'Elegir día de apertura',
    );
    if (picked != null && mounted) {
      setState(() => _openDate = Capsule.dateOnly(picked));
    }
  }

  Future<void> _seal() async {
    final DateTime? openDate = _openDate;
    if (openDate == null || !_canSeal) {
      return;
    }

    final bool forOther = _forOther;
    final bool confirmed =
        await confirmSealCapsule(context, openDate, forOther: forOther);
    if (!confirmed || !mounted) {
      return;
    }

    final CapsulesProvider capsules = context.read<CapsulesProvider>();
    final NavigatorState navigator = Navigator.of(context);
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);

    setState(() => _saving = true);
    final CapsuleCreateResult result = await capsules.create(
      title: _title.text,
      content: _message.text,
      openDate: openDate,
      attachments: List<Attachment>.of(_attachments),
      senderName: forOther ? _senderName.text : null,
      recipientName: _recipientName.text,
    );
    if (!mounted) {
      return;
    }

    if (!result.success) {
      setState(() => _saving = false);
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(result.errorMessage!)));
      return;
    }

    // La cápsula ya está guardada: sus archivos no se pueden borrar al salir.
    _sealed = true;

    String? sendNote;
    final Capsule? saved = result.capsule;
    if (forOther && saved != null) {
      await _shareService.saveSenderName(_senderName.text);
      sendNote = await _sendFile(saved, result.attachments);
      if (!mounted) {
        return;
      }
    }

    _done = true;
    navigator.pop();
    final String reminder = result.reminderScheduled
        ? 'Cápsula sellada. Te avisaremos el ${dayMonthLabel(openDate)}.'
        : 'Cápsula sellada. Sin notificaciones no recibirás el aviso '
            'del día de apertura.';
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(sendNote == null ? reminder : '$reminder $sendNote'),
        ),
      );
  }

  /// Prepara el archivo y abre el menú de compartir. Devuelve una frase para
  /// añadir al aviso final cuando hay algo que contar, o null si todo fue bien.
  Future<String?> _sendFile(Capsule capsule, List<Attachment> files) async {
    try {
      final CapsuleSendResult sent = await _sender.send(capsule, files);
      switch (sent) {
        case CapsuleSendResult.shared:
          return null;
        case CapsuleSendResult.saved:
          return 'El archivo está guardado: envíaselo tú a la otra persona.';
        case CapsuleSendResult.cancelled:
          return 'Aún no has enviado el archivo: pulsa Enviar en la cápsula.';
      }
    } on CapsuleSendException catch (error) {
      return '${error.message} Puedes enviarla desde la cápsula.';
    } catch (error) {
      debugPrint('Gonen: error al enviar la cápsula: $error');
      return 'No se pudo enviar el archivo. Puedes hacerlo desde la cápsula.';
    }
  }

  Future<void> _onPopBlocked() async {
    // Mientras se está sellando no se puede salir: la cápsula se guardaría igual.
    if (_saving) {
      return;
    }
    final bool discard = await confirmDiscardCapsule(context);
    if (discard && mounted) {
      setState(() => _done = true);
      Navigator.of(context).pop();
    }
  }

  /// Interruptor «Es para otra persona» y, si está activo, los nombres.
  List<Widget> _buildRecipientSection(ThemeData theme, ColorScheme scheme) {
    final bool premium = context
        .select<PremiumProvider, bool>((PremiumProvider p) => p.isPremium);

    return <Widget>[
      Text(
        'PARA QUIÉN ES',
        style: theme.textTheme.labelMedium?.copyWith(
          color: scheme.primary,
          letterSpacing: 1.6,
        ),
      ),
      const SizedBox(height: 4),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        value: _forOther,
        onChanged: _saving ? null : (bool value) => unawaited(_toggleForOther(value)),
        secondary: Icon(
          premium ? Icons.send_outlined : Icons.lock_outline_rounded,
        ),
        title: Text(
          premium ? 'Es para otra persona' : 'Es para otra persona (Premium)',
        ),
        subtitle: const Text(
          'Se crea un archivo para enviárselo por WhatsApp, correo...',
        ),
      ),
      if (_forOther) ...<Widget>[
        const SizedBox(height: 8),
        TextField(
          controller: _senderName,
          maxLength: CapsuleShareService.maxSenderLength,
          enabled: !_saving,
          textCapitalization: TextCapitalization.words,
          textInputAction: TextInputAction.next,
          decoration: const InputDecoration(
            labelText: 'Tu nombre',
            helperText: 'Es el que verá la otra persona.',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _recipientName,
          maxLength: CapsuleShareService.maxSenderLength,
          enabled: !_saving,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(
            labelText: 'Para (opcional)',
            helperText: 'Solo lo ves tú, para reconocerla en tu lista.',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'La otra persona necesita Gonen. El archivo va cifrado y la app no '
          'la deja abrir antes de la fecha, pero la clave está dentro de la '
          'app: alguien con muchos conocimientos podría saltarse ese candado. '
          'No metas nada de lo que dependa algo importante.',
          style: theme.textTheme.bodySmall?.copyWith(
            color: scheme.onSurfaceVariant,
            height: 1.5,
          ),
        ),
      ],
    ];
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final DateTime today = context.read<CapsulesProvider>().today;

    final List<({String label, DateTime date})> shortcuts =
        <({String label, DateTime date})>[
      (label: 'En 1 mes', date: _plusMonths(today, 1)),
      (label: 'En 6 meses', date: _plusMonths(today, 6)),
      (label: 'En 1 año', date: _plusMonths(today, 12)),
      (label: 'En 5 años', date: _plusMonths(today, 60)),
    ];

    return PopScope<Object?>(
      canPop: _done || (!_hasDraft && !_saving),
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) {
          unawaited(_onPopBlocked());
        }
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('Nueva cápsula')),
        body: SafeArea(
          child: Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 680),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
                keyboardDismissBehavior:
                    ScrollViewKeyboardDismissBehavior.onDrag,
                children: <Widget>[
                  Text(
                    'Escribe un mensaje para tu yo del futuro. Quedará sellado '
                    'y no podrás leerlo hasta el día que elijas.',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: scheme.onSurfaceVariant,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _title,
                    maxLength: 60,
                    textCapitalization: TextCapitalization.sentences,
                    textInputAction: TextInputAction.next,
                    decoration: const InputDecoration(
                      labelText: 'Título (opcional)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _message,
                    minLines: 8,
                    maxLines: null,
                    keyboardType: TextInputType.multiline,
                    textCapitalization: TextCapitalization.sentences,
                    style: theme.textTheme.bodyLarge?.copyWith(
                      fontFamily: kSerifFamily,
                      fontSize: 17,
                      height: 1.6,
                    ),
                    decoration: const InputDecoration(
                      labelText: 'Mensaje',
                      alignLabelWithHint: true,
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'FOTOS Y NOTAS DE VOZ',
                    style: theme.textTheme.labelMedium?.copyWith(
                      color: scheme.primary,
                      letterSpacing: 1.6,
                    ),
                  ),
                  const SizedBox(height: 8),
                  CapsuleAttachmentsEditor(
                    attachments: _attachments,
                    enabled: !_saving,
                    onAdded: _addAttachment,
                    onRemoved: _removeAttachment,
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'SE PODRÁ ABRIR EL',
                    style: theme.textTheme.labelMedium?.copyWith(
                      color: scheme.primary,
                      letterSpacing: 1.6,
                    ),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _saving ? null : _pickDate,
                    icon: const Icon(Icons.event_outlined),
                    label: Text(
                      _openDate == null
                          ? 'Elegir fecha'
                          : fullDateLabel(_openDate!),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: <Widget>[
                      for (final ({String label, DateTime date}) option
                          in shortcuts)
                        ChoiceChip(
                          label: Text(option.label),
                          selected: _openDate == option.date,
                          onSelected: _saving
                              ? null
                              : (bool selected) =>
                                  setState(() => _openDate = option.date),
                        ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  ..._buildRecipientSection(theme, scheme),
                  const SizedBox(height: 28),
                  FilledButton.icon(
                    onPressed: _canSeal ? () => unawaited(_seal()) : null,
                    icon: _saving
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Icon(
                            _forOther
                                ? Icons.send_outlined
                                : Icons.lock_outline_rounded,
                          ),
                    label: Text(
                      _forOther ? 'Sellar y enviar' : 'Sellar cápsula',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
