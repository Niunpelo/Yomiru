import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/capsule_model.dart';
import '../providers/capsules_provider.dart';
import '../theme/app_theme.dart';
import '../utils/date_labels.dart';
import '../widgets/paper_card.dart';
import 'capsule_detail_screen.dart';
import 'new_capsule_screen.dart';

/// Lista de cápsulas del tiempo: listas para abrir, selladas y abiertas.
class CapsulesScreen extends StatelessWidget {
  const CapsulesScreen({super.key});

  Future<void> _newCapsule(BuildContext context) {
    return Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => const NewCapsuleScreen(),
      ),
    );
  }

  Future<void> _openDetail(BuildContext context, Capsule capsule) {
    final int? id = capsule.id;
    if (id == null) {
      return Future<void>.value();
    }
    return Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => CapsuleDetailScreen(capsuleId: id),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final CapsulesProvider capsules = context.watch<CapsulesProvider>();
    final bool showButton = capsules.isLoaded && capsules.capsules.isNotEmpty;

    return Scaffold(
      appBar: AppBar(title: const Text('Cápsulas')),
      floatingActionButton: showButton
          ? FloatingActionButton.extended(
              onPressed: () => unawaited(_newCapsule(context)),
              icon: const Icon(Icons.add_rounded),
              label: const Text('Nueva cápsula'),
            )
          : null,
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: _buildBody(context, capsules),
          ),
        ),
      ),
    );
  }

  Widget _buildBody(BuildContext context, CapsulesProvider capsules) {
    final ThemeData theme = Theme.of(context);

    if (capsules.errorMessage != null && !capsules.isLoaded) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(capsules.errorMessage!, style: theme.textTheme.bodyLarge),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () => unawaited(capsules.load()),
              child: const Text('Reintentar'),
            ),
          ],
        ),
      );
    }

    if (!capsules.isLoaded) {
      return const Center(child: CircularProgressIndicator());
    }

    if (capsules.capsules.isEmpty) {
      return _EmptyState(onCreate: () => unawaited(_newCapsule(context)));
    }

    final List<Capsule> ready = capsules.readyCapsules;
    final List<Capsule> sealed = capsules.sealedCapsules;
    final List<Capsule> opened = capsules.openedCapsules;

    Widget tile(Capsule capsule) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: _CapsuleTile(
          capsule: capsule,
          status: capsules.statusOf(capsule),
          daysLeft: capsules.daysUntilOpen(capsule),
          onTap: () => unawaited(_openDetail(context, capsule)),
        ),
      );
    }

    return ListView(
      // Margen inferior para que el botón flotante no tape la última tarjeta.
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
      children: <Widget>[
        if (ready.isNotEmpty) ...<Widget>[
          const _SectionTitle('Listas para abrir'),
          for (final Capsule capsule in ready) tile(capsule),
        ],
        if (sealed.isNotEmpty) ...<Widget>[
          const _SectionTitle('Selladas'),
          for (final Capsule capsule in sealed) tile(capsule),
        ],
        if (opened.isNotEmpty) ...<Widget>[
          const _SectionTitle('Abiertas'),
          for (final Capsule capsule in opened) tile(capsule),
        ],
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 16, 4, 8),
      child: Text(
        text.toUpperCase(),
        style: theme.textTheme.labelMedium?.copyWith(
          color: theme.colorScheme.primary,
          letterSpacing: 1.6,
        ),
      ),
    );
  }
}

class _CapsuleTile extends StatelessWidget {
  const _CapsuleTile({
    required this.capsule,
    required this.status,
    required this.daysLeft,
    required this.onTap,
  });

  final Capsule capsule;
  final CapsuleStatus status;
  final int daysLeft;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    final IconData icon;
    final String detail;
    final String extra;
    switch (status) {
      case CapsuleStatus.sealed:
        icon = Icons.lock_outline_rounded;
        detail = 'Se abre el ${fullDateLabel(capsule.openDate)}';
        extra = remainingDaysLabel(daysLeft);
      case CapsuleStatus.ready:
        icon = Icons.mark_email_unread_outlined;
        detail = 'Lista desde el ${fullDateLabel(capsule.openDate)}';
        extra = 'Toca para abrirla';
      case CapsuleStatus.opened:
        icon = Icons.drafts_outlined;
        detail = 'Abierta el ${fullDateLabel(capsule.openedAt!)}';
        extra = 'Escrita el ${fullDateLabel(capsule.createdAt)}';
    }

    final bool highlighted = status == CapsuleStatus.ready;

    return PaperCard(
      emphasized: highlighted,
      onTap: onTap,
      child: Row(
        children: <Widget>[
          Icon(icon, color: highlighted ? scheme.primary : scheme.onSurfaceVariant),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  capsule.title.isEmpty ? 'Sin título' : capsule.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: kSerifFamily,
                    fontSize: 18,
                    color: scheme.onSurface,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  detail,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
                Text(
                  extra,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: highlighted ? scheme.primary : scheme.onSurfaceVariant,
                    fontWeight: highlighted ? FontWeight.w600 : FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Icon(Icons.chevron_right_rounded, color: scheme.onSurfaceVariant),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.onCreate});

  final VoidCallback onCreate;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(Icons.hourglass_empty_rounded, size: 52, color: scheme.outline),
            const SizedBox(height: 20),
            Text(
              'Aún no hay cápsulas',
              style: theme.textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            Text(
              'Escribe hoy un mensaje para tu yo del futuro. Quedará sellado '
              'hasta el día que elijas y te avisaremos cuando llegue.',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: scheme.onSurfaceVariant,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: onCreate,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Escribir una cápsula'),
            ),
          ],
        ),
      ),
    );
  }
}
