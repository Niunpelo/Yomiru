import 'package:flutter/material.dart';

import '../models/capsule_model.dart';
import '../providers/capsules_provider.dart';
import '../utils/date_labels.dart';

/// Cuenta al usuario qué pasó al importar una cápsula.
///
/// Con [offerList] el diálogo ofrece un botón para ir a la lista de cápsulas
/// (para cuando se llega desde otra pantalla). Devuelve true solo si el
/// usuario pulsa ese botón.
Future<bool> showCapsuleImportResult(
  BuildContext context,
  CapsuleImportResult result, {
  required bool offerList,
}) async {
  final String title;
  final String message;
  final bool imported = result.status == CapsuleImportStatus.imported;

  switch (result.status) {
    case CapsuleImportStatus.imported:
      final Capsule capsule = result.capsule!;
      title = 'Cápsula guardada';
      message = _importedMessage(capsule);
    case CapsuleImportStatus.duplicate:
      title = 'Ya la tenías';
      message = 'Esta cápsula ya estaba guardada en este móvil. No se ha '
          'cambiado nada.';
    case CapsuleImportStatus.invalid:
      title = 'No se pudo guardar';
      message = result.message ?? 'Este archivo no es una cápsula de Gonen.';
    case CapsuleImportStatus.failed:
      title = 'No se pudo guardar';
      message = result.message ?? 'No se pudo guardar la cápsula.';
  }

  final bool? open = await showDialog<bool>(
    context: context,
    builder: (BuildContext dialogContext) {
      return AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(imported && offerList ? 'Cerrar' : 'Entendido'),
          ),
          if (imported && offerList)
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Ver cápsulas'),
            ),
        ],
      );
    },
  );
  return open ?? false;
}

String _importedMessage(Capsule capsule) {
  final String from = capsule.sender ?? 'Alguien';
  final DateTime today = Capsule.dateOnly(DateTime.now());
  final String when = capsule.openDate.isAfter(today)
      ? 'Se podrá abrir el ${fullDateLabel(capsule.openDate)}. Te avisaremos '
          'ese día; hasta entonces su contenido queda oculto.'
      : 'Ya se puede abrir: la encontrarás en tu lista de cápsulas.';
  return '$from te ha dejado una cápsula del tiempo.\n\n$when';
}
