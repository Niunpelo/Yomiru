import 'package:flutter/material.dart';

import '../utils/date_labels.dart';

/// Pregunta si se sella la cápsula. Devuelve true solo si el usuario confirma.
///
/// Con [forOther] avisa de que después se elegirá cómo enviar el archivo.
Future<bool> confirmSealCapsule(
  BuildContext context,
  DateTime openDate, {
  bool forOther = false,
}) {
  return _confirm(
    context,
    title: forOther ? '¿Sellar y enviar la cápsula?' : '¿Sellar la cápsula?',
    message: forOther
        ? 'Nadie podrá leerla hasta el ${fullDateLabel(openDate)}, tampoco tú. '
            'Después elegirás cómo enviar el archivo (WhatsApp, correo...). '
            'Te quedas una copia, que se abrirá ese mismo día.'
        : 'No podrás leerla hasta el ${fullDateLabel(openDate)}. '
            'Hasta entonces su contenido quedará oculto.',
    cancelLabel: 'Revisar',
    confirmLabel: forOther ? 'Sellar y enviar' : 'Sellar',
  );
}

/// Pregunta si se borra la cápsula. Devuelve true solo si el usuario confirma.
Future<bool> confirmDeleteCapsule(BuildContext context) {
  return _confirm(
    context,
    title: '¿Borrar la cápsula?',
    message: 'Se borrará para siempre, con su mensaje y sus fotos y notas de '
        'voz. Esta acción no se puede deshacer.',
    cancelLabel: 'Cancelar',
    confirmLabel: 'Borrar',
    destructive: true,
  );
}

/// Pregunta si se borra una foto o una nota de voz del día.
Future<bool> confirmDeleteAttachment(BuildContext context) {
  return _confirm(
    context,
    title: '¿Borrar este archivo?',
    message: 'Se borrará para siempre. Esta acción no se puede deshacer.',
    cancelLabel: 'Cancelar',
    confirmLabel: 'Borrar',
    destructive: true,
  );
}

/// Pregunta si se descarta lo escrito al salir sin sellar.
Future<bool> confirmDiscardCapsule(BuildContext context) {
  return _confirm(
    context,
    title: '¿Descartar la cápsula?',
    message: 'Lo que has escrito se perderá.',
    cancelLabel: 'Seguir escribiendo',
    confirmLabel: 'Descartar',
    destructive: true,
  );
}

/// Pregunta si se restaura una copia de seguridad.
Future<bool> confirmRestoreBackup(BuildContext context) {
  return _confirm(
    context,
    title: '¿Restaurar una copia?',
    message: 'Se añadirá a este móvil lo que falte de la copia. No se borra ni '
        'se cambia nada de lo que ya tienes: si un día ya tiene texto aquí, '
        'se queda como está.',
    cancelLabel: 'Cancelar',
    confirmLabel: 'Elegir copia',
  );
}

Future<bool> _confirm(
  BuildContext context, {
  required String title,
  required String message,
  required String cancelLabel,
  required String confirmLabel,
  bool destructive = false,
}) async {
  final bool? result = await showDialog<bool>(
    context: context,
    builder: (BuildContext dialogContext) {
      final ColorScheme scheme = Theme.of(dialogContext).colorScheme;
      return AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(cancelLabel),
          ),
          FilledButton(
            style: destructive
                ? FilledButton.styleFrom(
                    backgroundColor: scheme.error,
                    foregroundColor: scheme.onError,
                  )
                : null,
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(confirmLabel),
          ),
        ],
      );
    },
  );
  return result ?? false;
}
