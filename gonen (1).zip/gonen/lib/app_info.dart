/// Versión que se muestra en el menú y en los ajustes. Debe coincidir con `version` en pubspec.yaml.
const String kAppVersion = '1.2.0';
