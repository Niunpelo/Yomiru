import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';

import '../database/database_helper.dart';
import '../models/attachment_model.dart';
import '../models/capsule_model.dart';
import '../services/attachment_service.dart';
import '../services/capsule_share_service.dart';
import '../services/notification_service.dart';

/// Resultado de sellar una cápsula nueva.
class CapsuleCreateResult {
  const CapsuleCreateResult({
    this.errorMessage,
    this.reminderScheduled = false,
    this.capsule,
    this.attachments = const <Attachment>[],
  });

  /// Mensaje en español listo para mostrar, o null si todo ha ido bien.
  final String? errorMessage;

  /// Verdadero si se programó el aviso del día de apertura.
  final bool reminderScheduled;

  /// La cápsula ya guardada (con su identificador), si todo ha ido bien.
  final Capsule? capsule;

  /// Fotos y notas de voz de la cápsula guardada.
  final List<Attachment> attachments;

  bool get success => errorMessage == null;
}

/// Qué pasó al importar un archivo de cápsula.
enum CapsuleImportStatus {
  /// La cápsula se ha guardado.
  imported,

  /// Ya estaba guardada: no se ha hecho nada.
  duplicate,

  /// El archivo no es una cápsula de Gonen, está dañado o es de una versión
  /// más nueva.
  invalid,

  /// El archivo es correcto, pero no se pudo guardar.
  failed,
}

/// Resultado de importar un archivo de cápsula.
class CapsuleImportResult {
  const CapsuleImportResult(this.status, {this.capsule, this.message});

  final CapsuleImportStatus status;

  /// La cápsula guardada (solo si [status] es `imported`).
  final Capsule? capsule;

  /// Explicación en español para `invalid` y `failed`.
  final String? message;
}

/// Cápsulas del tiempo: mensajes que se escriben hoy y se leen en un día futuro.
class CapsulesProvider extends ChangeNotifier {
  CapsulesProvider({
    DatabaseHelper? databaseHelper,
    NotificationService? notificationService,
    CapsuleShareService? shareService,
    DateTime Function()? clock,
  })  : _db = databaseHelper ?? DatabaseHelper.instance,
        _notifications = notificationService ?? NotificationService.instance,
        _share = shareService ?? CapsuleShareService(),
        _clock = clock ?? DateTime.now;

  final DatabaseHelper _db;
  final NotificationService _notifications;
  final CapsuleShareService _share;
  final DateTime Function() _clock;

  List<Capsule> _capsules = const <Capsule>[];
  Map<int, List<Attachment>> _attachments = const <int, List<Attachment>>{};
  bool _isLoaded = false;
  String? _errorMessage;
  bool _disposed = false;

  /// Todas las cápsulas, ordenadas por fecha de apertura.
  List<Capsule> get capsules => _capsules;

  /// Falso hasta que se han leído las cápsulas por primera vez.
  bool get isLoaded => _isLoaded;

  /// Mensaje de error si no se pudieron leer las cápsulas.
  String? get errorMessage => _errorMessage;

  /// Ya ha llegado su día y todavía no se han abierto.
  List<Capsule> get readyCapsules => _withStatus(CapsuleStatus.ready);

  /// Todavía no ha llegado su día.
  List<Capsule> get sealedCapsules => _withStatus(CapsuleStatus.sealed);

  /// Ya abiertas, las más recientes primero.
  List<Capsule> get openedCapsules {
    final List<Capsule> opened = _withStatus(CapsuleStatus.opened);
    opened.sort(
      (Capsule a, Capsule b) => b.openedAt!.compareTo(a.openedAt!),
    );
    return opened;
  }

  /// Fotos y notas de voz de una cápsula (vacío si no tiene).
  List<Attachment> attachmentsFor(int capsuleId) =>
      _attachments[capsuleId] ?? const <Attachment>[];

  /// Cuántas cápsulas están listas para abrirse (para el aviso del menú).
  int get readyCount => readyCapsules.length;

  /// Estado de [capsule] ahora mismo.
  CapsuleStatus statusOf(Capsule capsule) => capsule.statusOn(_clock());

  /// Días que faltan para poder abrir [capsule].
  int daysUntilOpen(Capsule capsule) => capsule.daysUntilOpen(_clock());

  /// Hoy, sin hora. Lo usa la pantalla de creación para limitar el calendario.
  DateTime get today => Capsule.dateOnly(_clock());

  /// Busca una cápsula por su identificador.
  Capsule? byId(int id) {
    for (final Capsule capsule in _capsules) {
      if (capsule.id == id) {
        return capsule;
      }
    }
    return null;
  }

  List<Capsule> _withStatus(CapsuleStatus status) {
    final DateTime now = _clock();
    return _capsules
        .where((Capsule capsule) => capsule.statusOn(now) == status)
        .toList();
  }

  // ---------------------------------------------------------------------------
  // Carga
  // ---------------------------------------------------------------------------

  /// Lee las cápsulas de la base de datos y repasa los avisos pendientes.
  Future<void> load() async {
    try {
      final List<Capsule> capsules = await _db.getCapsules();
      final List<Attachment> files = await _db.getCapsuleAttachments();
      final Map<int, List<Attachment>> grouped = <int, List<Attachment>>{};
      for (final Attachment file in files) {
        final int? capsuleId = file.capsuleId;
        if (capsuleId != null) {
          grouped.putIfAbsent(capsuleId, () => <Attachment>[]).add(file);
        }
      }
      _capsules = capsules;
      _attachments = grouped;
      _errorMessage = null;
      _isLoaded = true;
      _notify();
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al leer las cápsulas: $error\n$stackTrace');
      _errorMessage = 'No se pudieron leer las cápsulas del tiempo.';
      _notify();
      return;
    }
    await _syncReminders();
  }

  /// Vuelve a evaluar el estado de cada cápsula con la hora actual. Se llama al
  /// volver a la app, por si ha llegado el día de abrir alguna.
  void refreshStatuses() => _notify();

  /// Reprograma el aviso de las cápsulas selladas. Es seguro repetirlo: el
  /// mismo identificador sustituye al aviso anterior, y así se recuperan los
  /// avisos si Android los ha perdido o ha cambiado la zona horaria.
  Future<void> _syncReminders() async {
    try {
      final DateTime now = _clock();
      for (final Capsule capsule in _capsules) {
        final int? id = capsule.id;
        if (id != null && capsule.statusOn(now) == CapsuleStatus.sealed) {
          await _notifications.scheduleCapsuleOpening(
            capsuleId: id,
            openDate: capsule.openDate,
            received: capsule.isReceived,
          );
        }
      }
    } catch (error) {
      debugPrint('Gonen: no se pudieron repasar los avisos de cápsulas: $error');
    }
  }

  // ---------------------------------------------------------------------------
  // Crear, abrir y borrar
  // ---------------------------------------------------------------------------

  /// Sella una cápsula nueva que se podrá abrir a partir de [openDate], con las
  /// fotos y notas de voz de [attachments] (cuyos archivos ya están guardados).
  ///
  /// Con [senderName] la cápsula es para otra persona: queda marcada como
  /// enviada, con un identificador único, y [recipientName] (opcional) dice
  /// para quién es. El archivo para enviar se prepara aparte, con
  /// `CapsuleSender`.
  Future<CapsuleCreateResult> create({
    required String title,
    required String content,
    required DateTime openDate,
    List<Attachment> attachments = const <Attachment>[],
    String? senderName,
    String recipientName = '',
  }) async {
    final String cleanTitle = title.trim();
    final String cleanContent = content.trim();
    if (cleanContent.isEmpty) {
      return const CapsuleCreateResult(
        errorMessage: 'Escribe el mensaje de la cápsula.',
      );
    }

    final bool forOther = senderName != null;
    final String cleanSender = (senderName ?? '').trim();
    if (forOther && cleanSender.isEmpty) {
      return const CapsuleCreateResult(
        errorMessage:
            'Escribe tu nombre para que la otra persona sepa quién la envía.',
      );
    }

    final DateTime now = _clock();
    final DateTime day = Capsule.dateOnly(openDate);
    if (!day.isAfter(Capsule.dateOnly(now))) {
      return const CapsuleCreateResult(
        errorMessage: 'La fecha de apertura debe ser posterior a hoy.',
      );
    }

    final Capsule saved;
    final List<Attachment> savedFiles;
    try {
      final ({Capsule capsule, List<Attachment> attachments}) result =
          await _db.insertCapsuleWithAttachments(
        Capsule(
          title: cleanTitle,
          content: cleanContent,
          createdAt: now,
          openDate: day,
          sender: forOther ? _clip(cleanSender) : null,
          recipient: forOther ? _clip(recipientName.trim()) : null,
          uid: forOther ? _newUid() : null,
        ),
        attachments,
      );
      saved = result.capsule;
      savedFiles = result.attachments;
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al guardar la cápsula: $error\n$stackTrace');
      return const CapsuleCreateResult(
        errorMessage: 'No se pudo guardar la cápsula.',
      );
    }

    _capsules = <Capsule>[..._capsules, saved]..sort(_byOpenDate);
    final int? savedId = saved.id;
    if (savedId != null && savedFiles.isNotEmpty) {
      _attachments = <int, List<Attachment>>{..._attachments, savedId: savedFiles};
    }
    _notify();

    bool reminderScheduled = false;
    try {
      final bool granted = await _notifications.requestPermission();
      if (granted && saved.id != null) {
        reminderScheduled = await _notifications.scheduleCapsuleOpening(
          capsuleId: saved.id!,
          openDate: day,
        );
      }
    } catch (error) {
      debugPrint('Gonen: no se pudo programar el aviso de la cápsula: $error');
    }
    return CapsuleCreateResult(
      reminderScheduled: reminderScheduled,
      capsule: saved,
      attachments: savedFiles,
    );
  }

  /// Guarda la cápsula que viene en [file] (un archivo `.gonencap` recibido).
  /// No borra [file]: lo hace quien lo pidió.
  Future<CapsuleImportResult> importFile(File file) async {
    final ReceivedCapsule? received;
    try {
      received = await _share.read(file, alreadyHave: _db.hasCapsuleUid);
    } on FormatException catch (error) {
      return CapsuleImportResult(
        CapsuleImportStatus.invalid,
        message: error.message,
      );
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al leer la cápsula recibida: $error\n$stackTrace');
      return const CapsuleImportResult(
        CapsuleImportStatus.failed,
        message: 'No se pudo leer el archivo de la cápsula.',
      );
    }
    if (received == null) {
      return const CapsuleImportResult(CapsuleImportStatus.duplicate);
    }

    final ({Capsule capsule, List<Attachment> attachments}) saved;
    try {
      saved = await _db.insertCapsuleWithAttachments(
        received.capsule,
        received.attachments,
      );
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al guardar la cápsula recibida: $error\n$stackTrace');
      for (final Attachment attachment in received.attachments) {
        await AttachmentService.instance.delete(attachment.relativePath);
      }
      return const CapsuleImportResult(
        CapsuleImportStatus.failed,
        message: 'No se pudo guardar la cápsula recibida.',
      );
    }

    try {
      // Sin permiso para notificar no habría aviso el día de apertura.
      await _notifications.requestPermission();
    } catch (error) {
      debugPrint('Gonen: no se pudo pedir permiso de notificaciones: $error');
    }
    // Recarga la lista y programa el aviso de la cápsula nueva.
    await load();
    return CapsuleImportResult(
      CapsuleImportStatus.imported,
      capsule: saved.capsule,
    );
  }

  /// Recorta un nombre a la longitud máxima que admite el archivo de cápsula.
  static String _clip(String text) {
    const int maxLength = CapsuleShareService.maxSenderLength;
    return text.length > maxLength ? text.substring(0, maxLength) : text;
  }

  /// Identificador único de 32 caracteres para una cápsula que se envía.
  static String _newUid() {
    final Random random = Random.secure();
    final StringBuffer buffer = StringBuffer();
    for (int i = 0; i < 16; i++) {
      buffer.write(random.nextInt(256).toRadixString(16).padLeft(2, '0'));
    }
    return buffer.toString();
  }

  /// Abre una cápsula cuyo día ya ha llegado y anota el momento. Si ya estaba
  /// abierta no hace nada. Devuelve un mensaje de error o null.
  Future<String?> open(int id) async {
    final Capsule? capsule = byId(id);
    if (capsule == null) {
      return 'No se encontró la cápsula.';
    }
    final CapsuleStatus status = capsule.statusOn(_clock());
    if (status == CapsuleStatus.opened) {
      return null;
    }
    if (status == CapsuleStatus.sealed) {
      return 'Todavía no ha llegado el día de abrir esta cápsula.';
    }

    final DateTime openedAt = _clock();
    try {
      await _db.markCapsuleOpened(id, openedAt);
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al abrir la cápsula: $error\n$stackTrace');
      return 'No se pudo abrir la cápsula.';
    }

    _capsules = <Capsule>[
      for (final Capsule item in _capsules)
        if (item.id == id) item.copyWith(openedAt: openedAt) else item,
    ];
    _notify();
    await _cancelReminder(id);
    return null;
  }

  /// Borra una cápsula (sellada, lista o abierta) con sus fotos y notas de voz.
  /// Devuelve un error o null.
  Future<String?> delete(int id) async {
    final List<Attachment> files = attachmentsFor(id);
    try {
      await _db.deleteCapsule(id);
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al borrar la cápsula: $error\n$stackTrace');
      return 'No se pudo borrar la cápsula.';
    }
    _capsules = <Capsule>[
      for (final Capsule item in _capsules)
        if (item.id != id) item,
    ];
    _attachments = <int, List<Attachment>>{
      for (final MapEntry<int, List<Attachment>> item in _attachments.entries)
        if (item.key != id) item.key: item.value,
    };
    _notify();
    for (final Attachment file in files) {
      await AttachmentService.instance.delete(file.relativePath);
    }
    await _cancelReminder(id);
    return null;
  }

  Future<void> _cancelReminder(int id) async {
    try {
      await _notifications.cancelCapsuleOpening(id);
    } catch (error) {
      debugPrint('Gonen: no se pudo quitar el aviso de la cápsula: $error');
    }
  }

  static int _byOpenDate(Capsule a, Capsule b) {
    final int byDate = a.openDate.compareTo(b.openDate);
    if (byDate != 0) {
      return byDate;
    }
    return (a.id ?? 0).compareTo(b.id ?? 0);
  }

  void _notify() {
    if (!_disposed) {
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
