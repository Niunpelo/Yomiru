# Gonen

Diario de varios años con estética de papelería japonesa. El nombre viene de 五年 (*gonen*, «cinco años»). Cada día muestra, en una misma pantalla, lo que escribiste ese mismo día en años anteriores, y además puedes dejar mensajes para tu yo del futuro en **cápsulas del tiempo**.

- **Diario**: una tarjeta por año. Solo se escribe en el año actual y **solo el propio día, hasta las 23:59**; a las 00:00 la entrada queda en solo lectura (se puede leer y copiar, no editar). Los años anteriores son siempre de solo lectura.
- **Años visibles**: en *Ajustes → Diario* eliges cuántos años anteriores salen en el inicio (de 0 a 20; por defecto 4, es decir, 5 tarjetas). Reducirlo solo oculta tarjetas: nada se borra.
- **Menú lateral** (icono ☰ arriba a la izquierda): Diario, Cápsulas del tiempo y Ajustes. Un punto sobre el icono avisa de que hay cápsulas listas para abrir.
- **Cápsulas del tiempo**: escribes un mensaje (con título opcional), eliges el día de apertura y queda sellado. No se puede leer hasta ese día; ese día, a las 09:00, llega un aviso. Tras abrirla se puede releer. Se pueden borrar en cualquier momento.
- **Datos**: SQLite local (`sqflite`). Entradas por `día "MM-DD"` + `año`; cápsulas en su propia tabla.
- **Estado**: `provider`.
- **Privacidad**: bloqueo con huella, rostro o PIN del dispositivo (`local_auth`).
- **Recordatorio**: notificación diaria a la hora elegida (`flutter_local_notifications`).
- **Tema**: claro y oscuro, interfaz en español.

## Conseguir el APK con GitHub (sin instalar nada)

### Método A: repositorio con los archivos sueltos

1. Crea un repositorio nuevo en GitHub (vacío, sin README).
2. Descomprime este ZIP y sube **todo el contenido**, incluida la carpeta oculta `.github`:
   ```bash
   cd gonen
   git init
   git add .
   git commit -m "Gonen"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/gonen.git
   git push -u origin main
   ```
   Si subes los archivos arrastrándolos en la web de GitHub, comprueba que `.github/workflows/build-apk.yml` ha llegado: sin ese archivo no se compila nada.
3. Abre la pestaña **Actions**. El workflow **Build APK** se lanza solo con cada `push` (también a mano con *Run workflow*).
4. Cuando termine (unos 5-10 minutos), entra en la ejecución y descarga el artefacto **gonen-apk** al final de la página. Es un ZIP que contiene `app-release.apk`.
5. Copia el APK al móvil e instálalo (Android te pedirá permitir instalar apps de este origen).

### Método B: subir solo el ZIP

Si GitHub no te deja subir las carpetas, sube `gonen.zip` tal cual a la raíz del repositorio y crea `.github/workflows/build-apk.yml` desde la web de GitHub con el workflow que descomprime el ZIP y compila dentro de `proyecto/gonen`. El resto es igual que en el método A.

Si subes una etiqueta que empiece por `v` (por ejemplo `v1.1.0`), el APK además se publica en *Releases*.

### Qué hace el workflow

El proyecto no incluye la carpeta `android/`: el workflow la genera con `flutter create` con Flutter 3.38 (la versión está fijada en el workflow para que la compilación no cambie sola) y después ejecuta `tool/patch_android.py`, que deja listo lo que exigen los plugins (desugaring, `FlutterFragmentActivity`, permisos, receptores de notificaciones, temas AppCompat e iconos). Así no hace falta guardar en el repositorio los archivos de Android generados.

El APK se firma con la clave de depuración de Flutter: sirve para instalarlo y usarlo, pero no para subirlo a Google Play. Para Play Store tendrás que configurar tu propia clave de firma.

## Compilar en tu ordenador

Requisitos: Flutter 3.38.1 o superior (Dart 3.10+), Java 17 y Python 3. El script `tool/patch_android.py` está pensado para la plantilla de Android de Flutter 3.38; con versiones mucho más nuevas puede necesitar ajustes.

```bash
flutter create --platforms=android --org com.gonen --project-name gonen .
python3 tool/patch_android.py
flutter pub get
flutter run                      # en un móvil o emulador
flutter build apk --release      # build/app/outputs/flutter-apk/app-release.apk
flutter test                     # pruebas de modelos y reglas de edición
```

## Estructura

```
lib/
  main.dart                       Arranque, proveedores, tema y localización
  app_info.dart                   Versión mostrada en la app
  models/
    entry_model.dart              Entry (id, dayOfYear, year, content, updatedAt)
    capsule_model.dart            Capsule y estados: sellada / lista / abierta
    day_access.dart               Regla de las 23:59: editable / terminado / aún no / no existe
    diary_limits.dart             Límites del ajuste «años anteriores»
  database/database_helper.dart   SQLite v2: entradas y cápsulas (migración v1 → v2)
  providers/
    diary_provider.dart           Día seleccionado, navegación, guardado automático, bloqueo a medianoche
    capsules_provider.dart        Crear, abrir y borrar cápsulas; avisos
    settings_provider.dart        Años visibles, bloqueo biométrico, recordatorio, tema
  services/
    biometric_service.dart        local_auth
    notification_service.dart     Aviso diario y avisos de cápsulas
  screens/
    home_screen.dart              Menú lateral, cabecera con fecha y tarjetas por año
    capsules_screen.dart          Lista de cápsulas
    new_capsule_screen.dart       Escribir y sellar una cápsula
    capsule_detail_screen.dart    Cuenta atrás / abrir / leer
    settings_screen.dart          Ajustes
    lock_screen.dart              Pantalla de bloqueo
  widgets/                        Menú, tarjetas, diálogos, cabecera de fecha, bloqueo global
  theme/app_theme.dart            Paleta washi/sumi/bermellón, claro y oscuro
tool/patch_android.py             Adapta el proyecto Android generado
.github/workflows/build-apk.yml   Compila el APK en GitHub Actions
```

## Detalles de comportamiento

- **Guardado**: el texto se guarda solo tras unos instantes sin teclear (0,9 s), al cambiar de día, al abrir otra pantalla y al pasar la app a segundo plano. También hay un botón **Guardar**. Si dejas una entrada vacía, se borra y ese año vuelve a mostrar «Sin entrada este año».
- **Regla de las 23:59**: solo se puede escribir en el día de hoy. Lo escrito antes de las 00:00 se guarda; a las 00:00 la tarjeta pasa a solo lectura aunque tengas la app abierta. Los días pasados del año actual se pueden leer pero no editar, y los días futuros no se pueden escribir todavía («Este día aún no ha llegado»). Un día que no escribiste no se puede rellenar después.
- **29 de febrero**: existe como día navegable. En años no bisiestos la tarjeta lo indica en lugar de dejar escribir.
- **Cambio de día**: si la app estaba en segundo plano y pasa la medianoche, al volver muestra el nuevo día (solo si estabas viendo «hoy»). Con la app abierta a medianoche, la tarjeta se bloquea pero la pantalla no salta sola: pulsa «Hoy».
- **Cápsulas**: el aviso se programa a las 09:00 del día de apertura y no muestra el título ni el contenido en la pantalla de bloqueo. Si deniegas el permiso de notificaciones, la cápsula se guarda igualmente, pero no habrá aviso. El «sellado» es una regla de la app, no cifrado: el texto está en la base de datos local, y cambiar la fecha del teléfono permitiría abrirla antes.
- **Recordatorio diario**: usa un aviso «inexacto» para no necesitar el permiso de alarmas exactas; Android puede retrasarlo unos minutos. Se reprograma al abrir la app.
- **Bloqueo**: se pide al abrir la app y cada vez que vuelve de segundo plano; se intenta tapar la vista previa del selector de apps (Android no siempre lo permite). Si el dispositivo se queda sin huella ni bloqueo de pantalla, la pantalla de bloqueo ofrece desactivarlo para que el diario no quede inaccesible.
- **Copias de seguridad**: la base de datos es un archivo local. Android puede incluirla en su copia automática a Google Drive; si no quieres eso, añade `android:allowBackup="false"` a `<application>` en el manifiesto.
