import 'package:flutter/material.dart';

import 'app_style.dart';

export 'app_style.dart';

/// Temas claro y oscuro de cada [AppStyle].
///
/// Los dos estilos comparten la paleta washi: papel cálido, tinta sumi y un
/// único acento bermellón (shu). La editorial japonesa añade líneas finas,
/// esquinas rectas y números enormes; el hilo rojo, tarjetas con un hilo.
class AppTheme {
  AppTheme._();

  // ---------------------------------------------------------------------------
  // Paleta washi (editorial japonesa e hilo rojo)
  // ---------------------------------------------------------------------------

  static const ColorScheme _washiLight = ColorScheme(
    brightness: Brightness.light,
    primary: Color(0xFFB04A3C),
    onPrimary: Color(0xFFFFFFFF),
    primaryContainer: Color(0xFFF1D9D2),
    onPrimaryContainer: Color(0xFF4A1B14),
    secondary: Color(0xFF6B705C),
    onSecondary: Color(0xFFFFFFFF),
    secondaryContainer: Color(0xFFE3E4D6),
    onSecondaryContainer: Color(0xFF262A1D),
    error: Color(0xFFB3261E),
    onError: Color(0xFFFFFFFF),
    surface: Color(0xFFF4EFE6),
    onSurface: Color(0xFF2B2926),
    onSurfaceVariant: Color(0xFF6E685D),
    outline: Color(0xFF8A8478),
    outlineVariant: Color(0xFFD9D0BF),
    shadow: Color(0xFF000000),
    scrim: Color(0xFF000000),
    inverseSurface: Color(0xFF2B2926),
    onInverseSurface: Color(0xFFF4EFE6),
    inversePrimary: Color(0xFFE8A99E),
    surfaceContainerLowest: Color(0xFFFFFDF8),
    surfaceContainerLow: Color(0xFFFBF8F1),
    surfaceContainer: Color(0xFFF0EADD),
    surfaceContainerHigh: Color(0xFFEAE3D4),
    surfaceContainerHighest: Color(0xFFE4DCCB),
  );

  static const ColorScheme _washiDark = ColorScheme(
    brightness: Brightness.dark,
    primary: Color(0xFFE08C7E),
    onPrimary: Color(0xFF3F140D),
    primaryContainer: Color(0xFF5C2A21),
    onPrimaryContainer: Color(0xFFF7DDD7),
    secondary: Color(0xFFB7BCA3),
    onSecondary: Color(0xFF2B2F1F),
    secondaryContainer: Color(0xFF42463A),
    onSecondaryContainer: Color(0xFFE3E4D6),
    error: Color(0xFFF2B8B5),
    onError: Color(0xFF601410),
    surface: Color(0xFF1B1A18),
    onSurface: Color(0xFFE9E3D6),
    onSurfaceVariant: Color(0xFFA8A194),
    outline: Color(0xFF7A7467),
    outlineVariant: Color(0xFF3A372F),
    shadow: Color(0xFF000000),
    scrim: Color(0xFF000000),
    inverseSurface: Color(0xFFE9E3D6),
    onInverseSurface: Color(0xFF2B2926),
    inversePrimary: Color(0xFFB04A3C),
    surfaceContainerLowest: Color(0xFF141311),
    surfaceContainerLow: Color(0xFF242220),
    surfaceContainer: Color(0xFF2B2926),
    surfaceContainerHigh: Color(0xFF34312C),
    surfaceContainerHighest: Color(0xFF3E3A34),
  );

  /// Editorial japonesa: la paleta washi con las líneas en tinta y sin tarjetas
  /// de otro color (el papel es el mismo en todas partes).
  static final ColorScheme _washiRuledLight = _washiLight.copyWith(
    outlineVariant: const Color(0xFF2B2926),
    surfaceContainerLow: const Color(0xFFF4EFE6),
  );

  static final ColorScheme _washiRuledDark = _washiDark.copyWith(
    outlineVariant: const Color(0xFFE9E3D6),
    surfaceContainerLow: const Color(0xFF1B1A18),
  );

  /// Colores de [style] con el brillo [brightness].
  static ColorScheme schemeFor(AppStyle style, Brightness brightness) {
    final bool dark = brightness == Brightness.dark;
    switch (style) {
      case AppStyle.hiloRojo:
        return dark ? _washiDark : _washiLight;
      case AppStyle.editorialJaponesa:
        return dark ? _washiRuledDark : _washiRuledLight;
    }
  }

  static ThemeData light([AppStyle style = AppStyle.defaultStyle]) =>
      _build(style, Brightness.light);

  static ThemeData dark([AppStyle style = AppStyle.defaultStyle]) =>
      _build(style, Brightness.dark);

  // ---------------------------------------------------------------------------
  // Construcción
  // ---------------------------------------------------------------------------

  static TextTheme _textTheme(
    TextTheme base,
    ColorScheme scheme,
    AppStyle style,
  ) {
    final TextTheme text = base.apply(
      bodyColor: scheme.onSurface,
      displayColor: scheme.onSurface,
    );

    if (!style.isEditorial) {
      final String serif = style.displayFamily;
      return text.copyWith(
        displayLarge: text.displayLarge?.copyWith(fontFamily: serif),
        displayMedium: text.displayMedium?.copyWith(fontFamily: serif),
        displaySmall: text.displaySmall?.copyWith(fontFamily: serif),
        headlineLarge: text.headlineLarge?.copyWith(fontFamily: serif),
        headlineMedium: text.headlineMedium?.copyWith(
          fontFamily: serif,
          fontWeight: FontWeight.w400,
          letterSpacing: 0.4,
        ),
        headlineSmall: text.headlineSmall?.copyWith(fontFamily: serif),
        titleLarge: text.titleLarge?.copyWith(
          fontFamily: serif,
          fontWeight: FontWeight.w400,
        ),
      );
    }

    final String display = style.displayFamily;
    final String body = style.bodyFamily;
    final String label = style.labelFamily ?? body;
    final FontWeight weight = style.displayWeight;
    return text.copyWith(
      displayLarge: text.displayLarge?.copyWith(
        fontFamily: display,
        fontWeight: weight,
      ),
      displayMedium: text.displayMedium?.copyWith(
        fontFamily: display,
        fontWeight: weight,
      ),
      displaySmall: text.displaySmall?.copyWith(
        fontFamily: display,
        fontWeight: weight,
      ),
      headlineLarge: text.headlineLarge?.copyWith(
        fontFamily: display,
        fontWeight: weight,
      ),
      headlineMedium: text.headlineMedium?.copyWith(
        fontFamily: display,
        fontWeight: weight,
        letterSpacing: 0,
      ),
      headlineSmall: text.headlineSmall?.copyWith(
        fontFamily: display,
        fontWeight: weight,
      ),
      titleLarge: text.titleLarge?.copyWith(
        fontFamily: display,
        fontWeight: weight,
      ),
      titleMedium: text.titleMedium?.copyWith(fontFamily: body),
      titleSmall: text.titleSmall?.copyWith(fontFamily: body),
      bodyLarge: text.bodyLarge?.copyWith(fontFamily: body),
      bodyMedium: text.bodyMedium?.copyWith(fontFamily: body),
      bodySmall: text.bodySmall?.copyWith(fontFamily: body),
      labelLarge: text.labelLarge?.copyWith(
        fontFamily: label,
        letterSpacing: 0.8,
      ),
      labelMedium: text.labelMedium?.copyWith(
        fontFamily: label,
        letterSpacing: 0.8,
      ),
      labelSmall: text.labelSmall?.copyWith(
        fontFamily: label,
        letterSpacing: 0.6,
      ),
    );
  }

  static ThemeData _build(AppStyle style, Brightness brightness) {
    final ColorScheme scheme = schemeFor(style, brightness);
    final ThemeData base = ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
    );

    final TextTheme textTheme = _textTheme(base.textTheme, scheme, style);
    final bool editorial = style.isEditorial;
    final RoundedRectangleBorder shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(style.cornerRadius),
    );
    final RoundedRectangleBorder outlinedShape = RoundedRectangleBorder(
      borderRadius: BorderRadius.zero,
      side: BorderSide(color: scheme.outlineVariant),
    );

    return base.copyWith(
      textTheme: textTheme,
      extensions: <ThemeExtension<dynamic>>[GonenStyleTheme(style)],
      // Desde Flutter 3.35 ThemeData exige AppBarThemeData (no AppBarTheme).
      appBarTheme: AppBarThemeData(
        backgroundColor: scheme.surface,
        foregroundColor: scheme.onSurface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        shape: editorial
            ? Border(bottom: BorderSide(color: scheme.outlineVariant))
            : null,
        titleTextStyle: TextStyle(
          fontFamily: style.displayFamily,
          fontSize: editorial ? 22 : 20,
          fontWeight: editorial ? FontWeight.w600 : FontWeight.w400,
          letterSpacing: editorial ? 0.5 : 3,
          color: scheme.onSurface,
        ),
      ),
      dividerTheme: DividerThemeData(
        color: scheme.outlineVariant,
        thickness: 1,
        space: 1,
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: scheme.primary,
          shape: shape,
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(shape: shape),
      ),
      chipTheme: editorial
          ? ChipThemeData(
              shape: shape,
              side: BorderSide(color: scheme.outlineVariant),
              backgroundColor: Colors.transparent,
              labelStyle: TextStyle(
                fontFamily: style.labelFamily,
                fontSize: 12,
                letterSpacing: 0.8,
                color: scheme.onSurface,
              ),
            )
          : null,
      segmentedButtonTheme: editorial
          ? SegmentedButtonThemeData(
              style: ButtonStyle(
                shape: WidgetStatePropertyAll<OutlinedBorder>(shape),
              ),
            )
          : null,
      dialogTheme: editorial ? DialogThemeData(shape: outlinedShape) : null,
      bottomSheetTheme:
          editorial ? BottomSheetThemeData(shape: outlinedShape) : null,
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: scheme.inverseSurface,
        contentTextStyle: TextStyle(color: scheme.onInverseSurface),
        shape: shape,
      ),
      listTileTheme: ListTileThemeData(
        iconColor: scheme.onSurfaceVariant,
        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      ),
    );
  }
}
