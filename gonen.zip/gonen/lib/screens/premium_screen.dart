import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/tr.dart';
import '../models/attachment_limits.dart';
import '../models/premium_entitlement.dart';
import '../providers/premium_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/paper_card.dart';

/// Pantalla de Gonen Premium: qué incluye y cómo comprarlo (suscripción anual
/// o pago único).
class PremiumScreen extends StatelessWidget {
  const PremiumScreen({super.key});

  /// Precios orientativos que se enseñan si Google Play no los ha devuelto.
  static String get _fallbackYearlyPrice => tr('4,99 €', '€4.99');
  static String get _fallbackLifetimePrice => tr('14,99 €', '€14.99');

  Future<void> _buy(BuildContext context, PremiumPlan plan) async {
    final PremiumProvider premium = context.read<PremiumProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final String? error = await premium.purchase(plan);
    if (error != null) {
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(error)));
    }
  }

  Future<void> _restore(BuildContext context) async {
    final PremiumProvider premium = context.read<PremiumProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final String? error = await premium.restorePurchases();
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(
            error ??
                tr(
                  'Buscando tus compras en Google Play. Si tienes alguna '
                      'activa, se recuperará en unos segundos.',
                  'Looking for your purchases on Google Play. If you have an '
                      'active one, it will be restored in a few seconds.',
                ),
          ),
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    final PremiumProvider premium = context.watch<PremiumProvider>();
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final PremiumPlan plan = premium.plan;
    final bool storeReady = premium.storeAvailable && premium.productsLoaded;

    return Scaffold(
      appBar: AppBar(title: const Text('Premium')),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
              children: <Widget>[
                Icon(Icons.star_outline_rounded, size: 52, color: scheme.primary),
                const SizedBox(height: 12),
                Text(
                  'Gonen Premium',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.headlineMedium,
                ),
                const SizedBox(height: 8),
                Text(
                  context.tr(
                    'Guarda también cómo se veía y cómo sonaba tu día.',
                    'Also keep how your day looked and sounded.',
                  ),
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 24),
                _Benefit(
                  icon: Icons.photo_camera_outlined,
                  text: context.tr(
                    'Fotos: hasta ${AttachmentLimits.maxImagesPerDay} por día, '
                        'desde la cámara o la galería.',
                    'Photos: up to ${AttachmentLimits.maxImagesPerDay} per '
                        'day, from the camera or the gallery.',
                  ),
                ),
                _Benefit(
                  icon: Icons.mic_none_rounded,
                  text: context.tr(
                    'Notas de voz: hasta ${AttachmentLimits.maxVoiceNotesPerDay} '
                        'por día, de hasta ${AttachmentLimits.maxVoiceSeconds ~/ 60} '
                        'minutos cada una.',
                    'Voice notes: up to ${AttachmentLimits.maxVoiceNotesPerDay} '
                        'per day, up to ${AttachmentLimits.maxVoiceSeconds ~/ 60} '
                        'minutes each.',
                  ),
                ),
                _Benefit(
                  icon: Icons.schedule_rounded,
                  text: context.tr(
                    'Se añaden el propio día, hasta las 23:59, igual que el '
                        'texto.',
                    'They are added on the day itself, until 23:59, just '
                        'like the text.',
                  ),
                ),
                _Benefit(
                  icon: Icons.visibility_outlined,
                  text: context.tr(
                    'Lo que guardes podrás verlo y escucharlo siempre, '
                        'aunque dejes de ser premium.',
                    'You will always be able to see and hear what you save, '
                        'even if you stop being premium.',
                  ),
                ),
                _Benefit(
                  icon: Icons.edit_note_rounded,
                  text: context.tr(
                    'Plantilla del día: las preguntas que elijas aparecen cada '
                        'día en tu tarjeta para que las desarrolles (en el menú '
                        '☰ → Plantilla del día).',
                    'Daily template: the questions you choose show up on your '
                        'card every day for you to expand on (in the ☰ menu → '
                        'Daily template).',
                  ),
                ),
                _Benefit(
                  icon: Icons.backup_outlined,
                  text: context.tr(
                    'Copia de seguridad automática en la carpeta que elijas, '
                        'cada cierto tiempo (hacer una copia a mano y '
                        'restaurarla es gratis).',
                    'Automatic backup to the folder you choose, every so often '
                        '(making a backup by hand and restoring it is free).',
                  ),
                ),
                _Benefit(
                  icon: Icons.send_outlined,
                  text: context.tr(
                    'Enviar cápsulas del tiempo a otras personas (recibirlas '
                        'es gratis).',
                    'Send time capsules to other people (receiving them is '
                        'free).',
                  ),
                ),
                const SizedBox(height: 16),
                if (premium.message != null) ...<Widget>[
                  _MessageCard(
                    message: premium.message!,
                    onClose: premium.clearMessage,
                  ),
                  const SizedBox(height: 16),
                ],
                if (premium.isTestUnlock) ...<Widget>[
                  _InfoCard(
                    icon: Icons.science_outlined,
                    text: context.tr(
                      'Compilación de prueba: el premium está desbloqueado '
                          'sin pagar. No es una versión para publicar.',
                      'Test build: premium is unlocked without paying. This '
                          'is not a version to publish.',
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
                if (plan != PremiumPlan.none)
                  _ActiveCard(plan: plan)
                else ...<Widget>[
                  if (!storeReady) ...<Widget>[
                    _InfoCard(
                      icon: Icons.info_outline_rounded,
                      text: context.tr(
                        'Las compras solo están disponibles en la versión de '
                            'Gonen instalada desde Google Play. Aquí todavía no se '
                            'pueden hacer.',
                        'Purchases are only available in the version of Gonen '
                            'installed from Google Play. They cannot be made '
                            'here yet.',
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                  _PlanCard(
                    title: context.tr('Anual', 'Yearly'),
                    price: premium.yearlyPrice ?? _fallbackYearlyPrice,
                    priceNote: context.tr('al año', 'per year'),
                    detail: context.tr(
                      'Se renueva cada año hasta que la canceles en Google '
                          'Play.',
                      'Renews every year until you cancel it on Google Play.',
                    ),
                    buttonLabel: context.tr('Suscribirme', 'Subscribe'),
                    emphasized: true,
                    onPressed: premium.isBusy || !premium.yearlyAvailable
                        ? null
                        : () => unawaited(_buy(context, PremiumPlan.yearly)),
                  ),
                  const SizedBox(height: 12),
                  _PlanCard(
                    title: context.tr('De por vida', 'Lifetime'),
                    price: premium.lifetimePrice ?? _fallbackLifetimePrice,
                    priceNote: context.tr('pago único', 'one-time payment'),
                    detail: context.tr(
                      'Se paga una sola vez y no caduca.',
                      'Paid once and never expires.',
                    ),
                    buttonLabel: context.tr('Comprar', 'Buy'),
                    emphasized: false,
                    onPressed: premium.isBusy || !premium.lifetimeAvailable
                        ? null
                        : () => unawaited(_buy(context, PremiumPlan.lifetime)),
                  ),
                ],
                const SizedBox(height: 12),
                Center(
                  child: TextButton(
                    onPressed: () => unawaited(_restore(context)),
                    child: Text(context.tr('Restaurar compras', 'Restore purchases')),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  context.tr(
                    'Los pagos los gestiona Google Play. Puedes cancelar la '
                        'suscripción cuando quieras en Google Play > Pagos y '
                        'suscripciones > Suscripciones.',
                    'Payments are handled by Google Play. You can cancel the '
                        'subscription whenever you want in Google Play > '
                        'Payments & subscriptions > Subscriptions.',
                  ),
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Benefit extends StatelessWidget {
  const _Benefit({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(icon, size: 22, color: theme.colorScheme.primary),
          const SizedBox(width: 14),
          Expanded(child: Text(text, style: theme.textTheme.bodyMedium)),
        ],
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  const _PlanCard({
    required this.title,
    required this.price,
    required this.priceNote,
    required this.detail,
    required this.buttonLabel,
    required this.emphasized,
    required this.onPressed,
  });

  final String title;
  final String price;
  final String priceNote;
  final String detail;
  final String buttonLabel;
  final bool emphasized;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return PaperCard(
      emphasized: emphasized,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Text(
                title,
                style: TextStyle(
                  fontFamily: context.appStyle.displayFamily,
                  fontWeight: context.appStyle.displayWeight,
                  fontSize: 22,
                  color: scheme.onSurface,
                ),
              ),
              const Spacer(),
              Text(
                price,
                style: TextStyle(
                  fontFamily: context.appStyle.displayFamily,
                  fontWeight: context.appStyle.displayWeight,
                  fontSize: 26,
                  color: scheme.primary,
                ),
              ),
              const SizedBox(width: 6),
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(
                  priceNote,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            detail,
            style: theme.textTheme.bodySmall?.copyWith(
              color: scheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: emphasized
                ? FilledButton(onPressed: onPressed, child: Text(buttonLabel))
                : OutlinedButton(onPressed: onPressed, child: Text(buttonLabel)),
          ),
        ],
      ),
    );
  }
}

class _ActiveCard extends StatelessWidget {
  const _ActiveCard({required this.plan});

  final PremiumPlan plan;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final String detail = plan == PremiumPlan.lifetime
        ? context.tr('Pago único: no caduca.', 'One-time payment: never expires.')
        : context.tr(
            'Suscripción anual. Se gestiona en Google Play > Pagos y '
                'suscripciones > Suscripciones.',
            'Yearly subscription. Managed in Google Play > Payments & '
                'subscriptions > Subscriptions.',
          );

    return PaperCard(
      emphasized: true,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(Icons.check_circle_outline_rounded, color: scheme.primary),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  context.tr('Gonen Premium activo', 'Gonen Premium active'),
                  style: theme.textTheme.titleMedium,
                ),
                const SizedBox(height: 4),
                Text(
                  detail,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return PaperCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(icon, color: theme.colorScheme.onSurfaceVariant),
          const SizedBox(width: 14),
          Expanded(child: Text(text, style: theme.textTheme.bodyMedium)),
        ],
      ),
    );
  }
}

class _MessageCard extends StatelessWidget {
  const _MessageCard({required this.message, required this.onClose});

  final String message;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return PaperCard(
      emphasized: true,
      child: Row(
        children: <Widget>[
          Expanded(child: Text(message, style: theme.textTheme.bodyMedium)),
          IconButton(
            onPressed: onClose,
            icon: const Icon(Icons.close_rounded),
            tooltip: context.tr('Cerrar aviso', 'Dismiss notice'),
          ),
        ],
      ),
    );
  }
}
