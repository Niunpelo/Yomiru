import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_info.dart';
import '../models/diary_limits.dart';
import '../providers/settings_provider.dart';
import '../theme/app_theme.dart';

/// Ajustes: años visibles en el inicio, bloqueo biométrico, recordatorio
/// diario y apariencia.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _busy = false;

  /// Valor del deslizador mientras se arrastra; se guarda al soltarlo.
  double? _yearsDraft;

  /// Ejecuta un cambio de ajustes y, si falla, enseña el motivo en un aviso.
  Future<void> _run(Future<String?> Function() action) async {
    if (_busy) {
      return;
    }
    setState(() => _busy = true);
    String? error;
    try {
      error = await action();
    } catch (exception) {
      debugPrint('Gonen: error al cambiar un ajuste: $exception');
      error = 'No se pudo completar el cambio.';
    }
    if (!mounted) {
      return;
    }
    setState(() => _busy = false);
    if (error != null) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(error)));
    }
  }

  Future<void> _pickReminderTime(SettingsProvider settings) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: settings.reminderTime,
      helpText: 'Hora del recordatorio',
      builder: (BuildContext context, Widget? child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
    if (picked == null) {
      return;
    }
    await _run(() => settings.setReminderTime(picked));
  }

  String _yearsBackDescription(int yearsBack) {
    if (yearsBack == 0) {
      return 'Solo se muestra el año actual.';
    }
    if (yearsBack == 1) {
      return 'El año actual y 1 año anterior.';
    }
    return 'El año actual y los $yearsBack años anteriores.';
  }

  @override
  Widget build(BuildContext context) {
    final SettingsProvider settings = context.watch<SettingsProvider>();
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final String timeText = MaterialLocalizations.of(context).formatTimeOfDay(
      settings.reminderTime,
      alwaysUse24HourFormat: true,
    );
    final int yearsBack = _yearsDraft?.round() ?? settings.yearsBack;

    return Scaffold(
      appBar: AppBar(title: const Text('Ajustes')),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: ListView(
              padding: const EdgeInsets.only(bottom: 32),
              children: <Widget>[
                const _SectionLabel('Diario'),
                ListTile(
                  leading: const Icon(Icons.history_rounded),
                  title: const Text('Años anteriores en el inicio'),
                  subtitle: Text(_yearsBackDescription(yearsBack)),
                  trailing: Text(
                    '$yearsBack',
                    style: theme.textTheme.titleLarge?.copyWith(
                      color: scheme.primary,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Slider(
                    value: yearsBack.toDouble(),
                    min: DiaryLimits.minYearsBack.toDouble(),
                    max: DiaryLimits.maxYearsBack.toDouble(),
                    divisions: DiaryLimits.maxYearsBack - DiaryLimits.minYearsBack,
                    label: '$yearsBack',
                    onChanged: (double value) =>
                        setState(() => _yearsDraft = value),
                    onChangeEnd: (double value) {
                      setState(() => _yearsDraft = null);
                      unawaited(settings.setYearsBack(value.round()));
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 4),
                  child: Text(
                    'Reducirlo solo oculta tarjetas: tus entradas antiguas no se '
                    'borran y vuelven a verse si lo aumentas.',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ),
                const ListTile(
                  leading: Icon(Icons.lock_outline_rounded),
                  title: Text('Edición del día'),
                  subtitle: Text(
                    'Cada entrada se puede escribir y editar hasta las 23:59 del '
                    'mismo día. Después queda en solo lectura.',
                  ),
                ),
                const Divider(height: 32),
                const _SectionLabel('Privacidad'),
                SwitchListTile(
                  secondary: const Icon(Icons.fingerprint_rounded),
                  title: const Text('Bloqueo biométrico'),
                  subtitle: const Text(
                    'Pide huella, rostro o el bloqueo de pantalla al abrir Gonen.',
                  ),
                  value: settings.biometricEnabled,
                  onChanged: _busy
                      ? null
                      : (bool value) =>
                          _run(() => settings.setBiometricEnabled(value)),
                ),
                const Divider(height: 32),
                const _SectionLabel('Recordatorio diario'),
                SwitchListTile(
                  secondary: const Icon(Icons.notifications_none_rounded),
                  title: const Text('Recordarme escribir'),
                  subtitle: const Text('Un aviso cada día a la hora elegida.'),
                  value: settings.reminderEnabled,
                  onChanged: _busy
                      ? null
                      : (bool value) =>
                          _run(() => settings.setReminderEnabled(value)),
                ),
                ListTile(
                  leading: const Icon(Icons.schedule_rounded),
                  title: const Text('Hora del recordatorio'),
                  subtitle: Text(
                    settings.reminderEnabled
                        ? 'Cada día a las $timeText'
                        : 'Se usará cuando actives el recordatorio',
                  ),
                  trailing: Text(
                    timeText,
                    style: theme.textTheme.titleLarge?.copyWith(
                      color: scheme.primary,
                    ),
                  ),
                  onTap: _busy ? null : () => _pickReminderTime(settings),
                ),
                const Divider(height: 32),
                const _SectionLabel('Apariencia'),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: SegmentedButton<ThemeMode>(
                    showSelectedIcon: false,
                    segments: const <ButtonSegment<ThemeMode>>[
                      ButtonSegment<ThemeMode>(
                        value: ThemeMode.system,
                        label: Text('Sistema'),
                        icon: Icon(Icons.brightness_auto_outlined),
                      ),
                      ButtonSegment<ThemeMode>(
                        value: ThemeMode.light,
                        label: Text('Claro'),
                        icon: Icon(Icons.light_mode_outlined),
                      ),
                      ButtonSegment<ThemeMode>(
                        value: ThemeMode.dark,
                        label: Text('Oscuro'),
                        icon: Icon(Icons.dark_mode_outlined),
                      ),
                    ],
                    selected: <ThemeMode>{settings.themeMode},
                    onSelectionChanged: (Set<ThemeMode> selection) {
                      settings.setThemeMode(selection.first);
                    },
                  ),
                ),
                const SizedBox(height: 40),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32),
                  child: Column(
                    children: <Widget>[
                      Text(
                        'Gonen $kAppVersion',
                        style: TextStyle(
                          fontFamily: kSerifFamily,
                          fontSize: 16,
                          letterSpacing: 2,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Tus entradas y cápsulas se guardan en una base de datos '
                        'local de este dispositivo, sin cuentas ni servidores.',
                        textAlign: TextAlign.center,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 4),
      child: Text(
        text.toUpperCase(),
        style: theme.textTheme.labelMedium?.copyWith(
          color: theme.colorScheme.primary,
          letterSpacing: 1.6,
        ),
      ),
    );
  }
}
