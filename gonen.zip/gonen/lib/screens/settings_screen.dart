import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_info.dart';
import '../l10n/tr.dart';
import '../models/diary_limits.dart';
import '../providers/settings_provider.dart';
import '../theme/app_theme.dart';

/// Ajustes: años visibles en el inicio, bloqueo biométrico, recordatorio
/// diario, apariencia (estilo y claro/oscuro) e idioma.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _busy = false;

  /// Valor del deslizador mientras se arrastra; se guarda al soltarlo.
  double? _yearsDraft;

  /// Ejecuta un cambio de ajustes y, si falla, enseña el motivo en un aviso.
  Future<void> _run(Future<String?> Function() action) async {
    if (_busy) {
      return;
    }
    setState(() => _busy = true);
    String? error;
    try {
      error = await action();
    } catch (exception) {
      debugPrint('Gonen: error al cambiar un ajuste: $exception');
      error = tr(
        'No se pudo completar el cambio.',
        'The change could not be completed.',
      );
    }
    if (!mounted) {
      return;
    }
    setState(() => _busy = false);
    if (error != null) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(error)));
    }
  }

  Future<void> _pickReminderTime(SettingsProvider settings) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: settings.reminderTime,
      helpText: tr('Hora del recordatorio', 'Reminder time'),
      builder: (BuildContext context, Widget? child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
    if (picked == null) {
      return;
    }
    await _run(() => settings.setReminderTime(picked));
  }

  String _yearsBackDescription(BuildContext context, int yearsBack) {
    if (yearsBack == 0) {
      return context.tr(
        'Solo se muestra el año actual.',
        'Only the current year is shown.',
      );
    }
    if (yearsBack == 1) {
      return context.tr(
        'El año actual y 1 año anterior.',
        'The current year and 1 previous year.',
      );
    }
    return context.tr(
      'El año actual y los $yearsBack años anteriores.',
      'The current year and the $yearsBack previous years.',
    );
  }

  @override
  Widget build(BuildContext context) {
    final SettingsProvider settings = context.watch<SettingsProvider>();
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final String timeText = MaterialLocalizations.of(context).formatTimeOfDay(
      settings.reminderTime,
      alwaysUse24HourFormat: true,
    );
    final int yearsBack = _yearsDraft?.round() ?? settings.yearsBack;

    return Scaffold(
      appBar: AppBar(title: Text(context.tr('Ajustes', 'Settings'))),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: ListView(
              padding: const EdgeInsets.only(bottom: 32),
              children: <Widget>[
                _SectionLabel(context.tr('Diario', 'Diary')),
                ListTile(
                  leading: const Icon(Icons.history_rounded),
                  title: Text(
                    context.tr(
                      'Años anteriores en el inicio',
                      'Previous years on the home screen',
                    ),
                  ),
                  subtitle: Text(_yearsBackDescription(context, yearsBack)),
                  trailing: Text(
                    '$yearsBack',
                    style: theme.textTheme.titleLarge?.copyWith(
                      color: scheme.primary,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Slider(
                    value: yearsBack.toDouble(),
                    min: DiaryLimits.minYearsBack.toDouble(),
                    max: DiaryLimits.maxYearsBack.toDouble(),
                    divisions: DiaryLimits.maxYearsBack - DiaryLimits.minYearsBack,
                    label: '$yearsBack',
                    onChanged: (double value) =>
                        setState(() => _yearsDraft = value),
                    onChangeEnd: (double value) {
                      setState(() => _yearsDraft = null);
                      unawaited(settings.setYearsBack(value.round()));
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 4),
                  child: Text(
                    context.tr(
                      'Reducirlo solo oculta tarjetas: tus entradas antiguas no se '
                          'borran y vuelven a verse si lo aumentas.',
                      'Lowering it only hides cards: your old entries are not '
                          'deleted and show up again if you raise it.',
                    ),
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.lock_outline_rounded),
                  title: Text(context.tr('Edición del día', 'Editing the day')),
                  subtitle: Text(
                    context.tr(
                      'Cada entrada se puede escribir y editar hasta las 23:59 del '
                          'mismo día. Después queda en solo lectura.',
                      'Each entry can be written and edited until 11:59 pm of the '
                          'same day. After that it becomes read-only.',
                    ),
                  ),
                ),
                const Divider(height: 32),
                _SectionLabel(context.tr('Privacidad', 'Privacy')),
                SwitchListTile(
                  secondary: const Icon(Icons.fingerprint_rounded),
                  title: Text(
                    context.tr('Bloqueo biométrico', 'Biometric lock'),
                  ),
                  subtitle: Text(
                    context.tr(
                      'Pide huella, rostro o el bloqueo de pantalla al abrir Gonen.',
                      'Asks for your fingerprint, face or screen lock when '
                          'opening Gonen.',
                    ),
                  ),
                  value: settings.biometricEnabled,
                  onChanged: _busy
                      ? null
                      : (bool value) =>
                          _run(() => settings.setBiometricEnabled(value)),
                ),
                const Divider(height: 32),
                _SectionLabel(context.tr('Recordatorio diario', 'Daily reminder')),
                SwitchListTile(
                  secondary: const Icon(Icons.notifications_none_rounded),
                  title: Text(
                    context.tr('Recordarme escribir', 'Remind me to write'),
                  ),
                  subtitle: Text(
                    context.tr(
                      'Un aviso cada día a la hora elegida.',
                      'A notification every day at the chosen time.',
                    ),
                  ),
                  value: settings.reminderEnabled,
                  onChanged: _busy
                      ? null
                      : (bool value) =>
                          _run(() => settings.setReminderEnabled(value)),
                ),
                ListTile(
                  leading: const Icon(Icons.schedule_rounded),
                  title: Text(
                    context.tr('Hora del recordatorio', 'Reminder time'),
                  ),
                  subtitle: Text(
                    settings.reminderEnabled
                        ? context.tr(
                            'Cada día a las $timeText',
                            'Every day at $timeText',
                          )
                        : context.tr(
                            'Se usará cuando actives el recordatorio',
                            'It will be used when you turn the reminder on',
                          ),
                  ),
                  trailing: Text(
                    timeText,
                    style: theme.textTheme.titleLarge?.copyWith(
                      color: scheme.primary,
                    ),
                  ),
                  onTap: _busy ? null : () => _pickReminderTime(settings),
                ),
                if (settings.notificationsBlocked)
                  ListTile(
                    leading: Icon(
                      Icons.notifications_off_outlined,
                      color: scheme.error,
                    ),
                    title: Text(
                      context.tr(
                        'Android no deja mostrar los avisos de Gonen',
                        'Android is not letting Gonen show notifications',
                      ),
                      style: TextStyle(color: scheme.error),
                    ),
                    subtitle: Text(
                      context.tr(
                        'Actívalos en los ajustes del sistema: Aplicaciones → '
                            'Gonen → Notificaciones. Al volver aquí se '
                            'comprueba solo.',
                        'Turn them on in the system settings: Apps → Gonen → '
                            'Notifications. This is checked again when you '
                            'come back.',
                      ),
                    ),
                  ),
                const Divider(height: 32),
                _SectionLabel(context.tr('Apariencia', 'Appearance')),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
                  child: Text(
                    context.tr('Estilo', 'Style'),
                    style: theme.textTheme.titleMedium,
                  ),
                ),
                _StylePicker(
                  selected: settings.style,
                  onSelected: (AppStyle style) =>
                      unawaited(settings.setStyle(style)),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
                  child: Text(
                    context.tr('Claro u oscuro', 'Light or dark'),
                    style: theme.textTheme.titleMedium,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: SegmentedButton<ThemeMode>(
                    showSelectedIcon: false,
                    // Sin iconos: con ellos «Sistema» no cabía en su tercio y la
                    // última letra caía a otra línea.
                    segments: <ButtonSegment<ThemeMode>>[
                      ButtonSegment<ThemeMode>(
                        value: ThemeMode.system,
                        label: _SegmentLabel(context.tr('Sistema', 'System')),
                      ),
                      ButtonSegment<ThemeMode>(
                        value: ThemeMode.light,
                        label: _SegmentLabel(context.tr('Claro', 'Light')),
                      ),
                      ButtonSegment<ThemeMode>(
                        value: ThemeMode.dark,
                        label: _SegmentLabel(context.tr('Oscuro', 'Dark')),
                      ),
                    ],
                    selected: <ThemeMode>{settings.themeMode},
                    onSelectionChanged: (Set<ThemeMode> selection) {
                      settings.setThemeMode(selection.first);
                    },
                  ),
                ),
                const Divider(height: 40),
                _SectionLabel(context.tr('Idioma', 'Language')),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
                  child: SegmentedButton<AppLanguage>(
                    showSelectedIcon: false,
                    segments: <ButtonSegment<AppLanguage>>[
                      for (final AppLanguage language in AppLanguage.values)
                        ButtonSegment<AppLanguage>(
                          value: language,
                          label: Text(language.nativeName),
                        ),
                    ],
                    selected: <AppLanguage>{settings.language},
                    onSelectionChanged: (Set<AppLanguage> selection) {
                      unawaited(settings.setLanguage(selection.first));
                    },
                  ),
                ),
                const SizedBox(height: 40),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32),
                  child: Column(
                    children: <Widget>[
                      Text(
                        kVersionLabel,
                        style: TextStyle(
                          fontFamily: context.appStyle.bodyFamily,
                          fontSize: 16,
                          letterSpacing: 2,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        context.tr(
                          'Tus entradas, cápsulas, fotos y notas de voz se guardan '
                              'solo en este dispositivo, sin cuentas ni servidores.',
                          'Your entries, capsules, photos and voice notes are '
                              'stored only on this device, with no accounts or '
                              'servers.',
                        ),
                        textAlign: TextAlign.center,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 4),
      child: Text(
        text.toUpperCase(),
        style: theme.textTheme.labelMedium?.copyWith(
          color: theme.colorScheme.primary,
          letterSpacing: 1.6,
        ),
      ),
    );
  }
}

/// Texto de un botón de un selector segmentado: siempre en una sola línea.
class _SegmentLabel extends StatelessWidget {
  const _SegmentLabel(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      maxLines: 1,
      softWrap: false,
      overflow: TextOverflow.ellipsis,
    );
  }
}

/// Los dos estilos, uno junto al otro, cada uno con una miniatura dibujada con
/// sus propios colores y tipografías.
class _StylePicker extends StatelessWidget {
  const _StylePicker({required this.selected, required this.onSelected});

  final AppStyle selected;
  final ValueChanged<AppStyle> onSelected;

  @override
  Widget build(BuildContext context) {
    const List<AppStyle> styles = AppStyle.values;

    Widget tile(AppStyle style) => Expanded(
          child: _StyleTile(
            style: style,
            selected: style == selected,
            onTap: () => onSelected(style),
          ),
        );

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          for (int i = 0; i < styles.length; i++) ...<Widget>[
            if (i > 0) const SizedBox(width: 12),
            tile(styles[i]),
          ],
        ],
      ),
    );
  }
}

class _StyleTile extends StatelessWidget {
  const _StyleTile({
    required this.style,
    required this.selected,
    required this.onTap,
  });

  final AppStyle style;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme current = theme.colorScheme;
    // La miniatura usa los colores del estilo con el brillo que se ve ahora.
    final ColorScheme mini = AppTheme.schemeFor(style, theme.brightness);
    final String name = style.label(context);

    return Semantics(
      button: true,
      selected: selected,
      label: name,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              height: 120,
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: mini.surface,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: selected ? current.primary : current.outlineVariant,
                  width: selected ? 2.5 : 1,
                ),
              ),
              child: ExcludeSemantics(
                child: _StyleMiniature(style: style, colors: mini),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    name,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
                    ),
                  ),
                ),
                if (selected)
                  Icon(Icons.check_circle_rounded, size: 18, color: current.primary),
              ],
            ),
            const SizedBox(height: 2),
            Text(
              style.description(context),
              style: theme.textTheme.bodySmall?.copyWith(
                color: current.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Dibujo en pequeño de la pantalla de inicio de un estilo.
class _StyleMiniature extends StatelessWidget {
  const _StyleMiniature({required this.style, required this.colors});

  final AppStyle style;
  final ColorScheme colors;

  Widget _line(double widthFactor, {Color? color, double height = 4}) {
    return FractionallySizedBox(
      widthFactor: widthFactor,
      child: Container(
        height: height,
        decoration: BoxDecoration(
          color: color ?? colors.onSurface.withValues(alpha: 0.28),
          borderRadius: BorderRadius.circular(2),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (style.isEditorial) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Text(
                '5',
                style: TextStyle(
                  fontFamily: style.displayFamily,
                  fontWeight: style.displayWeight,
                  fontSize: 46,
                  height: 1,
                  color: colors.onSurface,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    _line(0.8, color: colors.onSurface.withValues(alpha: 0.55)),
                    const SizedBox(height: 4),
                    _line(0.55),
                    const SizedBox(height: 4),
                    _line(0.4, color: colors.primary),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Container(height: 2, color: colors.outlineVariant),
          const SizedBox(height: 8),
          _line(0.9),
          const SizedBox(height: 4),
          _line(0.7),
          const SizedBox(height: 8),
          Container(height: 1, color: colors.outlineVariant),
        ],
      );
    }

    final Widget card = Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: colors.primary.withValues(alpha: 0.55)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            '2026',
            style: TextStyle(
              fontFamily: style.displayFamily,
              fontSize: 14,
              height: 1,
              color: colors.primary,
            ),
          ),
          const SizedBox(height: 6),
          _line(0.95),
          const SizedBox(height: 4),
          _line(0.6),
        ],
      ),
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Center(
          child: Text(
            '5',
            style: TextStyle(
              fontFamily: style.displayFamily,
              fontSize: 22,
              height: 1,
              color: colors.onSurface,
            ),
          ),
        ),
        const SizedBox(height: 8),
        if (style.hasThread)
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                width: 2,
                height: 56,
                margin: const EdgeInsets.only(left: 2, right: 8),
                color: colors.primary.withValues(alpha: 0.6),
              ),
              Expanded(child: card),
            ],
          )
        else
          card,
      ],
    );
  }
}
