import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/entry_model.dart';
import '../providers/capsules_provider.dart';
import '../providers/diary_provider.dart';
import '../utils/date_labels.dart';
import '../widgets/app_drawer.dart';
import '../widgets/date_header.dart';
import '../widgets/year_card.dart';
import 'capsules_screen.dart';
import 'settings_screen.dart';

/// Pantalla principal: el día seleccionado y una tarjeta por cada año.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        unawaited(context.read<DiaryProvider>().initialize());
        unawaited(context.read<CapsulesProvider>().load());
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final DiaryProvider diary = context.read<DiaryProvider>();
    switch (state) {
      case AppLifecycleState.inactive:
      case AppLifecycleState.hidden:
      case AppLifecycleState.paused:
      case AppLifecycleState.detached:
        // Si el sistema cierra la app en segundo plano, que no se pierda texto.
        unawaited(diary.flushPendingSave());
      case AppLifecycleState.resumed:
        // Si pasó la medianoche mientras tanto, se muestra el nuevo día, el
        // día anterior queda bloqueado y se repasan las cápsulas que ya se
        // pueden abrir.
        unawaited(diary.refreshIfNeeded());
        context.read<CapsulesProvider>().refreshStatuses();
    }
  }

  /// Guarda lo pendiente y abre [screen] encima de la pantalla principal.
  Future<void> _openScreen(Widget screen) async {
    final DiaryProvider diary = context.read<DiaryProvider>();
    await diary.flushPendingSave();
    if (!mounted) {
      return;
    }
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (BuildContext context) => screen),
    );
  }

  Future<void> _openSettings() => _openScreen(const SettingsScreen());

  Future<void> _openCapsules() => _openScreen(const CapsulesScreen());

  Future<void> _pickDate() async {
    final DiaryProvider diary = context.read<DiaryProvider>();
    final int year = diary.entryYear;
    final DateTime initial = diary.selectedDate ?? DateTime(year, 2, 28);

    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(year, 1, 1),
      lastDate: DateTime(year, 12, 31),
      helpText: 'Elegir día',
    );
    if (picked != null) {
      await diary.goToDate(picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    final DiaryProvider diary = context.watch<DiaryProvider>();
    final int readyCapsules = context
        .select<CapsulesProvider, int>((CapsulesProvider p) => p.readyCount);

    return Scaffold(
      drawer: AppDrawer(
        onOpenCapsules: () => unawaited(_openCapsules()),
        onOpenSettings: () => unawaited(_openSettings()),
      ),
      appBar: AppBar(
        title: const Text('Gonen'),
        leading: Builder(
          builder: (BuildContext innerContext) {
            return IconButton(
              onPressed: () => Scaffold.of(innerContext).openDrawer(),
              // Un punto avisa de que hay cápsulas listas para abrir.
              icon: Badge(
                isLabelVisible: readyCapsules > 0,
                child: const Icon(Icons.menu_rounded),
              ),
              tooltip: MaterialLocalizations.of(innerContext).openAppDrawerTooltip,
            );
          },
        ),
        actions: <Widget>[
          IconButton(
            onPressed: _openSettings,
            icon: const Icon(Icons.settings_outlined),
            tooltip: 'Ajustes',
          ),
        ],
      ),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: _buildBody(context, diary),
          ),
        ),
      ),
    );
  }

  Widget _buildBody(BuildContext context, DiaryProvider diary) {
    final ThemeData theme = Theme.of(context);

    if (diary.errorMessage != null && !diary.isReady) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(diary.errorMessage!, style: theme.textTheme.bodyLarge),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () => unawaited(diary.retry()),
              child: const Text('Reintentar'),
            ),
          ],
        ),
      );
    }

    if (!diary.isReady) {
      return const Center(child: CircularProgressIndicator());
    }

    final DateTime? selected = diary.selectedDate;
    final List<int> years = diary.years;

    return Column(
      children: <Widget>[
        DateHeader(
          dayLabel: dayMonthLabel(diary.referenceDate),
          subtitle: selected == null
              ? 'solo en años bisiestos'
              : weekdayLabel(selected),
          isToday: diary.isToday,
          onPrevious: () => unawaited(diary.goToPreviousDay()),
          onNext: () => unawaited(diary.goToNextDay()),
          onToday: () => unawaited(diary.goToToday()),
          onPickDate: _pickDate,
        ),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            itemCount: years.length,
            separatorBuilder: (BuildContext context, int index) =>
                const SizedBox(height: 14),
            itemBuilder: (BuildContext context, int index) {
              final int year = years[index];
              final DateTime? date = _dateIn(diary, year);

              if (year == diary.entryYear) {
                return CurrentYearCard(
                  key: ValueKey<String>('current-$year-${diary.dayKey}'),
                  year: year,
                  date: date,
                  access: diary.access,
                  text: diary.currentEntry?.content ?? '',
                );
              }

              final Entry? entry = diary.entryFor(year);
              return PastYearCard(
                key: ValueKey<String>('past-$year-${diary.dayKey}'),
                year: year,
                date: date,
                entry: entry,
              );
            },
          ),
        ),
      ],
    );
  }

  /// Fecha del día seleccionado dentro de [year], o null si no existe.
  DateTime? _dateIn(DiaryProvider diary, int year) {
    if (!diary.dayExistsIn(year)) {
      return null;
    }
    return DateTime(year, diary.month, diary.day);
  }
}
