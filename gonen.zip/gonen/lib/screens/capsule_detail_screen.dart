import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/tr.dart';
import '../models/attachment_model.dart';
import '../models/capsule_model.dart';
import '../providers/capsules_provider.dart';
import '../providers/premium_provider.dart';
import '../services/capsule_sender.dart';
import '../services/capsule_share_service.dart';
import '../theme/app_theme.dart';
import '../utils/capsule_labels.dart';
import '../utils/date_labels.dart';
import '../widgets/attachments_section.dart';
import '../widgets/capsule_dialogs.dart';
import '../widgets/clock_notice.dart';
import '../widgets/paper_card.dart';
import 'premium_screen.dart';

/// Detalle de una cápsula. Según su estado enseña la cuenta atrás (sellada),
/// el botón para abrirla (lista) o el mensaje (abierta).
class CapsuleDetailScreen extends StatefulWidget {
  const CapsuleDetailScreen({super.key, required this.capsuleId});

  final int capsuleId;

  @override
  State<CapsuleDetailScreen> createState() => _CapsuleDetailScreenState();
}

class _CapsuleDetailScreenState extends State<CapsuleDetailScreen> {
  bool _busy = false;

  void _showMessage(ScaffoldMessengerState messenger, String text) {
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _open() async {
    if (_busy) {
      return;
    }
    final CapsulesProvider capsules = context.read<CapsulesProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);

    setState(() => _busy = true);
    final String? error = await capsules.open(widget.capsuleId);
    if (!mounted) {
      return;
    }
    setState(() => _busy = false);
    if (error != null) {
      _showMessage(messenger, error);
    }
  }

  /// Vuelve a preparar el archivo de una cápsula enviada y abre el menú de
  /// compartir (por si no se llegó a enviar, o hay que mandarla otra vez).
  Future<void> _resend() async {
    if (_busy) {
      return;
    }
    final CapsulesProvider capsules = context.read<CapsulesProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final Capsule? capsule = capsules.byId(widget.capsuleId);
    if (capsule == null) {
      return;
    }
    if (!context.read<PremiumProvider>().isPremium) {
      await Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (BuildContext context) => const PremiumScreen(),
        ),
      );
      return;
    }

    setState(() => _busy = true);
    String? note;
    try {
      final CapsuleSendResult sent = await CapsuleSender().send(
        capsule,
        capsules.attachmentsFor(widget.capsuleId),
      );
      switch (sent) {
        case CapsuleSendResult.shared:
          break;
        case CapsuleSendResult.saved:
          note = tr(
            'El archivo está guardado: envíaselo tú a la otra persona.',
            'The file is saved: send it to the other person yourself.',
          );
        case CapsuleSendResult.cancelled:
          break;
      }
    } on CapsuleSendException catch (error) {
      note = error.message;
    } catch (error) {
      debugPrint('Gonen: error al enviar la cápsula: $error');
      note = tr(
        'No se pudo enviar el archivo de la cápsula.',
        'The capsule file could not be sent.',
      );
    }
    if (!mounted) {
      return;
    }
    setState(() => _busy = false);
    if (note != null) {
      _showMessage(messenger, note);
    }
  }

  Future<void> _delete() async {
    if (_busy) {
      return;
    }
    final CapsulesProvider capsules = context.read<CapsulesProvider>();
    final NavigatorState navigator = Navigator.of(context);
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);

    final bool confirmed = await confirmDeleteCapsule(context);
    if (!confirmed || !mounted) {
      return;
    }

    setState(() => _busy = true);
    final String? error = await capsules.delete(widget.capsuleId);
    if (!mounted) {
      return;
    }
    if (error != null) {
      setState(() => _busy = false);
      _showMessage(messenger, error);
      return;
    }
    navigator.pop();
  }

  @override
  Widget build(BuildContext context) {
    final CapsulesProvider capsules = context.watch<CapsulesProvider>();
    final Capsule? capsule = capsules.byId(widget.capsuleId);

    if (capsule == null) {
      // Ocurre un instante tras borrarla, justo antes de cerrar la pantalla.
      return Scaffold(appBar: AppBar(), body: const SizedBox.shrink());
    }

    final CapsuleStatus status = capsules.statusOf(capsule);
    // Su día ya ha llegado, pero no se puede comprobar la fecha del móvil.
    final bool held = capsules.isHeldByClock(capsule);

    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr('Cápsula', 'Capsule')),
        actions: <Widget>[
          if (capsule.isSent)
            IconButton(
              onPressed: _busy ? null : () => unawaited(_resend()),
              icon: const Icon(Icons.send_outlined),
              tooltip: context.tr('Enviar el archivo otra vez', 'Send the file again'),
            ),
          IconButton(
            onPressed: _busy ? null : _delete,
            icon: const Icon(Icons.delete_outline_rounded),
            tooltip: context.tr('Borrar cápsula', 'Delete capsule'),
          ),
        ],
      ),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
              children: <Widget>[
                if (held || capsules.clockAdjusted)
                  ClockNotice(adjusted: capsules.clockAdjusted),
                ...switch (status) {
                  CapsuleStatus.sealed => _sealedContent(
                      context,
                      capsule,
                      capsules.daysUntilOpen(capsule),
                      capsules.attachmentsFor(widget.capsuleId),
                      held: held,
                    ),
                  CapsuleStatus.ready => _readyContent(
                      context,
                      capsule,
                      capsules.attachmentsFor(widget.capsuleId),
                    ),
                  CapsuleStatus.opened => _openedContent(
                      context,
                      capsule,
                      capsules.attachmentsFor(widget.capsuleId),
                    ),
                },
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Título de la cápsula: una recibida con el título oculto lo esconde hasta
  /// que se abre.
  String _titleOf(Capsule capsule, {bool opened = false}) =>
      capsuleTitleLabel(capsule, opened: opened);

  /// «De Ana» o «Para Lucía» cuando la cápsula se envió o se recibió; si no,
  /// nada.
  List<Widget> _peerLine(
    BuildContext context,
    Capsule capsule, {
    TextAlign align = TextAlign.center,
  }) {
    final String? peer = capsulePeerLabel(capsule);
    if (peer == null) {
      return const <Widget>[];
    }
    final ThemeData theme = Theme.of(context);
    return <Widget>[
      const SizedBox(height: 6),
      Text(
        peer,
        textAlign: align,
        style: theme.textTheme.titleSmall?.copyWith(
          color: theme.colorScheme.primary,
        ),
      ),
    ];
  }

  /// "Incluye 2 fotos y 1 nota de voz", o null si no hay ninguna.
  String? _attachmentsSummary(List<Attachment> attachments) {
    final int images = attachments
        .where((Attachment item) => item.type == AttachmentType.image)
        .length;
    final int notes = attachments.length - images;
    final List<String> parts = <String>[
      if (images > 0)
        images == 1
            ? tr('1 foto', '1 photo')
            : tr('$images fotos', '$images photos'),
      if (notes > 0)
        notes == 1
            ? tr('1 nota de voz', '1 voice note')
            : tr('$notes notas de voz', '$notes voice notes'),
    ];
    if (parts.isEmpty) {
      return null;
    }
    final String joined = parts.join(tr(' y ', ' and '));
    return tr('Incluye $joined.', 'Includes $joined.');
  }

  List<Widget> _sealedContent(
    BuildContext context,
    Capsule capsule,
    int days,
    List<Attachment> attachments, {
    bool held = false,
  }) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final String? summary = _attachmentsSummary(attachments);

    return <Widget>[
      const SizedBox(height: 16),
      Icon(Icons.lock_outline_rounded, size: 56, color: scheme.primary),
      const SizedBox(height: 16),
      Text(
        _titleOf(capsule),
        textAlign: TextAlign.center,
        style: theme.textTheme.headlineMedium,
      ),
      ..._peerLine(context, capsule),
      const SizedBox(height: 20),
      Text(
        context.tr('Se abrirá el', 'It will open on'),
        textAlign: TextAlign.center,
        style: theme.textTheme.labelLarge?.copyWith(
          color: scheme.onSurfaceVariant,
        ),
      ),
      const SizedBox(height: 4),
      Text(
        fullDateLabel(capsule.openDate),
        textAlign: TextAlign.center,
        style: theme.textTheme.titleLarge,
      ),
      const SizedBox(height: 8),
      Text(
        held
            ? context.tr('Fecha del móvil sin comprobar', 'Phone date not verified')
            : remainingDaysLabel(days),
        textAlign: TextAlign.center,
        style: theme.textTheme.titleMedium?.copyWith(color: scheme.primary),
      ),
      const SizedBox(height: 28),
      PaperCard(
        child: Text(
          summary == null
              ? context.tr(
                  'El mensaje está sellado: no se puede leer hasta ese día.',
                  'The message is sealed: it cannot be read until that day.',
                )
              : context.tr(
                  'El mensaje está sellado: no se puede leer hasta ese día. '
                      '$summary',
                  'The message is sealed: it cannot be read until that day. '
                      '$summary',
                ),
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: context.appStyle.bodyFamily,
            fontSize: 15,
            fontStyle: FontStyle.italic,
            color: scheme.onSurfaceVariant,
          ),
        ),
      ),
      if (capsule.isSent) ...<Widget>[
        const SizedBox(height: 12),
        Text(
          context.tr(
            'Te quedas una copia. Con el botón de arriba puedes enviar el '
                'archivo otra vez. Quien lo reciba verá solo esto: '
                '${CapsuleShareService.shareMessage(capsule)}',
            'You keep a copy. With the button above you can send the file '
                'again. The person receiving it will only see this: '
                '${CapsuleShareService.shareMessage(capsule)}',
          ),
          textAlign: TextAlign.center,
          style: theme.textTheme.bodySmall?.copyWith(
            color: scheme.onSurfaceVariant,
          ),
        ),
      ],
      const SizedBox(height: 20),
      Text(
        context.tr(
          'Escrita el ${fullDateLabel(capsule.createdAt)}',
          'Written on ${fullDateLabel(capsule.createdAt)}',
        ),
        textAlign: TextAlign.center,
        style: theme.textTheme.bodySmall?.copyWith(
          color: scheme.onSurfaceVariant,
        ),
      ),
    ];
  }

  List<Widget> _readyContent(
    BuildContext context,
    Capsule capsule,
    List<Attachment> attachments,
  ) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final String? summary = _attachmentsSummary(attachments);

    return <Widget>[
      const SizedBox(height: 16),
      Icon(Icons.mark_email_unread_outlined, size: 56, color: scheme.primary),
      const SizedBox(height: 16),
      Text(
        _titleOf(capsule),
        textAlign: TextAlign.center,
        style: theme.textTheme.headlineMedium,
      ),
      ..._peerLine(context, capsule),
      const SizedBox(height: 16),
      Text(
        context.tr(
          'Ya ha llegado el día. Puedes abrirla cuando quieras.',
          'The day has arrived. You can open it whenever you like.',
        ),
        textAlign: TextAlign.center,
        style: theme.textTheme.bodyLarge?.copyWith(
          color: scheme.onSurfaceVariant,
        ),
      ),
      if (summary != null) ...<Widget>[
        const SizedBox(height: 6),
        Text(
          summary,
          textAlign: TextAlign.center,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: scheme.onSurfaceVariant,
          ),
        ),
      ],
      const SizedBox(height: 28),
      FilledButton.icon(
        onPressed: _busy ? null : () => unawaited(_open()),
        icon: const Icon(Icons.lock_open_rounded),
        label: Text(context.tr('Abrir cápsula', 'Open capsule')),
      ),
      const SizedBox(height: 20),
      Text(
        context.tr(
          'Escrita el ${fullDateLabel(capsule.createdAt)}',
          'Written on ${fullDateLabel(capsule.createdAt)}',
        ),
        textAlign: TextAlign.center,
        style: theme.textTheme.bodySmall?.copyWith(
          color: scheme.onSurfaceVariant,
        ),
      ),
    ];
  }

  List<Widget> _openedContent(
    BuildContext context,
    Capsule capsule,
    List<Attachment> attachments,
  ) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final TextStyle? metaStyle = theme.textTheme.bodySmall?.copyWith(
      color: scheme.onSurfaceVariant,
    );

    return <Widget>[
      Text(
        _titleOf(capsule, opened: true),
        style: theme.textTheme.headlineSmall,
      ),
      ..._peerLine(context, capsule, align: TextAlign.start),
      const SizedBox(height: 16),
      PaperCard(
        emphasized: true,
        child: SelectableText(
          capsule.content,
          style: theme.textTheme.bodyLarge?.copyWith(
            fontFamily: context.appStyle.bodyFamily,
            fontSize: 17,
            height: 1.75,
          ),
        ),
      ),
      if (attachments.isNotEmpty) ...<Widget>[
        const SizedBox(height: 20),
        AttachmentList(attachments: attachments),
      ],
      const SizedBox(height: 20),
      Text(
        context.tr(
          'Escrita el ${fullDateLabel(capsule.createdAt)}',
          'Written on ${fullDateLabel(capsule.createdAt)}',
        ),
        style: metaStyle,
      ),
      if (capsule.openedAt != null)
        Text(
          context.tr(
            'Abierta el ${fullDateLabel(capsule.openedAt!)}',
            'Opened on ${fullDateLabel(capsule.openedAt!)}',
          ),
          style: metaStyle,
        ),
    ];
  }
}
