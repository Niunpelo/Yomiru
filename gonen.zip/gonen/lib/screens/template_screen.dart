import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/tr.dart';
import '../models/day_template.dart';
import '../providers/settings_provider.dart';

/// Plantilla del día (Gonen Premium): el texto, normalmente unas preguntas, que
/// aparece ya escrito cada día en la tarjeta de hoy para que se desarrolle.
///
/// El texto se guarda con el botón y también al salir de la pantalla.
class TemplateScreen extends StatefulWidget {
  const TemplateScreen({super.key});

  @override
  State<TemplateScreen> createState() => _TemplateScreenState();
}

class _TemplateScreenState extends State<TemplateScreen> {
  late final SettingsProvider _settings;
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _settings = context.read<SettingsProvider>();
    _controller = TextEditingController(text: _settings.templateText);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// Guarda lo escrito. No usa el contexto: también se llama al salir.
  Future<void> _commit() => _settings.setTemplateText(_controller.text);

  Future<void> _saveWithMessage() async {
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    FocusScope.of(context).unfocus();
    await _commit();
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(content: Text(tr('Plantilla guardada.', 'Template saved.'))),
      );
  }

  /// Pone un ejemplo de tres preguntas en el campo (sin guardarlo aún).
  void _insertExample() {
    final String example = tr(
      '¿Cómo me siento hoy?\n\n'
          '¿Qué ha ido bien?\n\n'
          '¿Qué quiero recordar de este día?',
      'How do I feel today?\n\n'
          'What went well?\n\n'
          'What do I want to remember about this day?',
    );
    _controller.value = TextEditingValue(
      text: example,
      selection: TextSelection.collapsed(offset: example.length),
    );
  }

  @override
  Widget build(BuildContext context) {
    final SettingsProvider settings = context.watch<SettingsProvider>();
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final TextStyle? note = theme.textTheme.bodySmall?.copyWith(
      color: scheme.onSurfaceVariant,
    );

    return PopScope<Object?>(
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (didPop) {
          unawaited(_commit());
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(context.tr('Plantilla del día', 'Daily template')),
        ),
        body: SafeArea(
          child: Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 680),
              child: ListView(
                keyboardDismissBehavior:
                    ScrollViewKeyboardDismissBehavior.onDrag,
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
                children: <Widget>[
                  Text(
                    context.tr(
                      'Escribe aquí las preguntas, o el texto, con los que '
                          'quieres empezar cada día. Con la plantilla activa, '
                          'la tarjeta de hoy aparece con ese texto ya puesto '
                          'para que lo desarrolles.',
                      'Write here the questions, or the text, you want to '
                          'start each day with. With the template on, today\'s '
                          'card appears with that text already in place for '
                          'you to expand on.',
                    ),
                    style: theme.textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 8),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(
                      context.tr('Usar la plantilla', 'Use the template'),
                    ),
                    subtitle: Text(
                      context.tr(
                        'Cada día, en la tarjeta de hoy.',
                        'Every day, on today\'s card.',
                      ),
                    ),
                    value: settings.templateEnabled,
                    onChanged: (bool value) =>
                        unawaited(settings.setTemplateEnabled(value)),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _controller,
                    minLines: 6,
                    maxLines: 14,
                    maxLength: DayTemplate.maxLength,
                    keyboardType: TextInputType.multiline,
                    textCapitalization: TextCapitalization.sentences,
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      alignLabelWithHint: true,
                      labelText: context.tr('Tu plantilla', 'Your template'),
                      hintText: context.tr(
                        '¿Cómo me siento hoy?\n\n¿Qué ha ido bien?',
                        'How do I feel today?\n\nWhat went well?',
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 12,
                    runSpacing: 8,
                    children: <Widget>[
                      FilledButton(
                        onPressed: () => unawaited(_saveWithMessage()),
                        child: Text(context.tr('Guardar', 'Save')),
                      ),
                      OutlinedButton(
                        onPressed: _insertExample,
                        child: Text(
                          context.tr('Poner un ejemplo', 'Insert an example'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Text(
                    context.tr(
                      'Lo que escribas cada día se guarda en el diario como '
                          'siempre, con las preguntas incluidas: en las tarjetas '
                          'de otros años verás tus respuestas de ese mismo día, '
                          'una debajo de otra. Si un día no cambias nada, no se '
                          'guarda nada.',
                      'What you write each day is saved in the diary as usual, '
                          'questions included: on the cards of other years you '
                          'will see your answers for that same day, one below '
                          'the other. If you change nothing on a day, nothing '
                          'is saved.',
                    ),
                    style: note,
                  ),
                  const SizedBox(height: 10),
                  Text(
                    context.tr(
                      'Si dejas de ser premium, la plantilla deja de aparecer, '
                          'pero todo lo que ya escribiste se conserva.',
                      'If you stop being premium, the template stops showing up, '
                          'but everything you already wrote is kept.',
                    ),
                    style: note,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
