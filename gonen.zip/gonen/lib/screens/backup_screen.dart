import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/tr.dart';
import '../models/backup_snapshot.dart';
import '../providers/capsules_provider.dart';
import '../providers/diary_provider.dart';
import '../providers/premium_provider.dart';
import '../services/auto_backup_service.dart';
import '../services/backup_service.dart';
import '../services/file_transfer_service.dart';
import '../utils/date_labels.dart';
import '../widgets/capsule_dialogs.dart';
import '../widgets/paper_card.dart';
import 'premium_screen.dart';

/// Crear una copia de seguridad a mano y restaurarla (gratis), y programar una
/// copia automática en una carpeta (Gonen Premium).
///
/// La copia es un archivo `.gonen` que el usuario guarda donde quiera (Google
/// Drive, el propio móvil, un ordenador...). No viaja por ningún servidor de
/// Gonen.
class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  final BackupService _service = BackupService();
  final FileTransferService _transfer = const FileTransferService();

  final AutoBackupService _auto = AutoBackupService.instance;

  bool _busy = false;
  DateTime? _lastBackup;
  AutoBackupSettings _autoSettings = const AutoBackupSettings();

  @override
  void initState() {
    super.initState();
    unawaited(_loadLastBackup());
    unawaited(_loadAuto());
  }

  Future<void> _loadAuto() async {
    final AutoBackupSettings loaded = await _auto.load();
    if (mounted) {
      setState(() => _autoSettings = loaded);
    }
  }

  Future<void> _loadLastBackup() async {
    final DateTime? last = await _service.lastBackupAt();
    if (mounted) {
      setState(() => _lastBackup = last);
    }
  }

  void _showMessage(ScaffoldMessengerState messenger, String text) {
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  /// "12 entradas, 2 cápsulas, 5 fotos y 1 nota de voz".
  String _countsLabel({
    required int entries,
    required int capsules,
    required int photos,
    required int voiceNotes,
  }) {
    final List<String> parts = <String>[
      if (entries > 0)
        entries == 1
            ? tr('1 entrada', '1 entry')
            : tr('$entries entradas', '$entries entries'),
      if (capsules > 0)
        capsules == 1
            ? tr('1 cápsula', '1 capsule')
            : tr('$capsules cápsulas', '$capsules capsules'),
      if (photos > 0)
        photos == 1
            ? tr('1 foto', '1 photo')
            : tr('$photos fotos', '$photos photos'),
      if (voiceNotes > 0)
        voiceNotes == 1
            ? tr('1 nota de voz', '1 voice note')
            : tr('$voiceNotes notas de voz', '$voiceNotes voice notes'),
    ];
    return _joinParts(parts);
  }

  /// Une varias partes con comas y una "y" antes de la última.
  String _joinParts(List<String> parts) {
    if (parts.isEmpty) {
      return tr('nada', 'nothing');
    }
    if (parts.length == 1) {
      return parts.first;
    }
    final String and = tr('y', 'and');
    return '${parts.sublist(0, parts.length - 1).join(', ')} $and ${parts.last}';
  }

  // ---------------------------------------------------------------------------
  // Crear
  // ---------------------------------------------------------------------------

  Future<void> _create() async {
    if (_busy) {
      return;
    }
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    setState(() => _busy = true);
    BackupCreateResult? created;
    try {
      created = await _service.create();
      final bool saved = await _transfer.saveFile(
        sourcePath: created.file.path,
        suggestedName: created.fileName,
      );
      if (saved) {
        await _service.markBackupDone();
        await _loadLastBackup();
        final String counts = _countsLabel(
          entries: created.entries,
          capsules: created.capsules,
          photos: created.photos,
          voiceNotes: created.voiceNotes,
        );
        final String missing = created.missingFiles > 0
            ? tr(
                ' (${created.missingFiles} archivos no se encontraron y no '
                    'se incluyeron)',
                ' (${created.missingFiles} files were not found and were not '
                    'included)',
              )
            : '';
        _showMessage(
          messenger,
          tr('Copia guardada: $counts$missing.', 'Backup saved: $counts$missing.'),
        );
      }
    } on FileTransferException catch (error) {
      _showMessage(messenger, error.message);
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al crear la copia: $error\n$stackTrace');
      _showMessage(
        messenger,
        tr(
          'No se pudo crear la copia de seguridad.',
          'The backup could not be created.',
        ),
      );
    } finally {
      if (created != null) {
        await _service.discard(created.file);
      }
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Copia automática
  // ---------------------------------------------------------------------------

  Future<void> _openPremium() {
    return Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => const PremiumScreen(),
      ),
    );
  }

  /// Pide una carpeta y la guarda. Devuelve true si se eligió una.
  Future<bool> _chooseAutoFolder() async {
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    try {
      final BackupFolder? folder = await _transfer.pickFolder();
      if (folder == null) {
        return false;
      }
      await _auto.setFolder(folder);
      await _loadAuto();
      return true;
    } on FileTransferException catch (error) {
      _showMessage(messenger, error.message);
      return false;
    }
  }

  /// «Cambiar»: elige otra carpeta y, si la copia automática está activada,
  /// hace ya una copia en ella.
  Future<void> _changeAutoFolder() async {
    if (_busy) {
      return;
    }
    final bool chosen = await _chooseAutoFolder();
    if (chosen && mounted && _autoSettings.enabled) {
      await _runAutoNow();
    }
  }

  Future<void> _toggleAuto(bool enabled) async {
    if (_busy) {
      return;
    }
    if (!enabled) {
      await _auto.setEnabled(false);
      await _loadAuto();
      return;
    }
    // Activarla necesita una carpeta: se pide la primera vez.
    if (!_autoSettings.hasFolder && !await _chooseAutoFolder()) {
      return;
    }
    if (!mounted) {
      return;
    }
    await _auto.setEnabled(true);
    await _loadAuto();
    // Primera copia ya, para comprobar que funciona.
    await _runAutoNow();
  }

  Future<void> _setAutoInterval(int days) async {
    await _auto.setIntervalDays(days);
    await _loadAuto();
  }

  /// Hace la copia automática ahora mismo y cuenta cómo ha ido.
  Future<void> _runAutoNow() async {
    if (_busy) {
      return;
    }
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    setState(() => _busy = true);
    try {
      final AutoBackupResult result = await _auto.runNow();
      await _loadAuto();
      _showMessage(
        messenger,
        result.status == AutoBackupStatus.done
            ? tr('Copia automática guardada.', 'Automatic backup saved.')
            : (result.message ??
                tr(
                  'No se pudo hacer la copia.',
                  'The backup could not be made.',
                )),
      );
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  String _intervalLabel(int days) {
    switch (days) {
      case 1:
        return tr('Cada día', 'Every day');
      case 7:
        return tr('Cada semana', 'Every week');
      case 14:
        return tr('Cada 2 semanas', 'Every 2 weeks');
      case 30:
        return tr('Cada mes', 'Every month');
      default:
        return tr('Cada $days días', 'Every $days days');
    }
  }

  String _autoStatusText(AutoBackupSettings auto) {
    final String? error = auto.lastError;
    if (error != null) {
      return tr(
        'La última copia automática falló: $error',
        'The last automatic backup failed: $error',
      );
    }
    final DateTime? last = auto.lastSuccess;
    if (last == null) {
      return tr(
        'Todavía no se ha hecho ninguna copia automática.',
        'No automatic backup has been made yet.',
      );
    }
    return tr(
      'Última copia automática: ${fullDateLabel(last)}.',
      'Last automatic backup: ${fullDateLabel(last)}.',
    );
  }

  Widget _buildAutoBackupCard(
    ThemeData theme,
    TextStyle? bodyStyle, {
    required bool premium,
  }) {
    final ColorScheme scheme = theme.colorScheme;
    final AutoBackupSettings auto = _autoSettings;
    final String folderName = auto.folder?.name ?? '';

    return PaperCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            context.tr('COPIA AUTOMÁTICA', 'AUTOMATIC BACKUP'),
            style: _headingStyle(theme),
          ),
          const SizedBox(height: 8),
          Text(
            context.tr(
              'Gonen guarda una copia en la carpeta que elijas cada cierto '
                  'tiempo y la sustituye por la nueva: siempre hay un único '
                  'archivo, el más reciente.',
              'Gonen saves a backup in the folder you choose every so often '
                  'and replaces it with the new one: there is always a single '
                  'file, the most recent.',
            ),
            style: bodyStyle,
          ),
          const SizedBox(height: 12),
          if (!premium)
            FilledButton.icon(
              onPressed: _busy ? null : () => unawaited(_openPremium()),
              icon: const Icon(Icons.lock_outline_rounded),
              label: Text(
                context.tr('Activar (Premium)', 'Turn on (Premium)'),
              ),
            )
          else ...<Widget>[
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: auto.enabled,
              onChanged: _busy ? null : (bool value) => unawaited(_toggleAuto(value)),
              title: Text(
                context.tr('Copia automática', 'Automatic backup'),
              ),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.folder_outlined),
              title: Text(context.tr('Carpeta', 'Folder')),
              subtitle: Text(
                !auto.hasFolder
                    ? context.tr('Todavía no has elegido ninguna', 'None chosen yet')
                    : (folderName.isEmpty
                        ? context.tr('Carpeta elegida', 'Chosen folder')
                        : folderName),
              ),
              trailing: TextButton(
                onPressed: _busy ? null : () => unawaited(_changeAutoFolder()),
                child: Text(
                  auto.hasFolder
                      ? context.tr('Cambiar', 'Change')
                      : context.tr('Elegir', 'Choose'),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              context.tr('Cada cuánto', 'How often'),
              style: theme.textTheme.titleSmall,
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: <Widget>[
                for (final int days in AutoBackupService.intervalOptions)
                  ChoiceChip(
                    label: Text(_intervalLabel(days)),
                    selected: auto.intervalDays == days,
                    onSelected: _busy
                        ? null
                        : (bool _) => unawaited(_setAutoInterval(days)),
                  ),
              ],
            ),
            const SizedBox(height: 14),
            Text(
              _autoStatusText(auto),
              style: theme.textTheme.bodySmall?.copyWith(
                color: auto.lastError != null
                    ? scheme.error
                    : scheme.onSurfaceVariant,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: _busy || !auto.hasFolder
                  ? null
                  : () => unawaited(_runAutoNow()),
              icon: const Icon(Icons.backup_outlined),
              label: Text(context.tr('Hacer copia ahora', 'Back up now')),
            ),
            const SizedBox(height: 10),
            Text(
              context.tr(
                'Se hace al abrir Gonen o al volver a ella, cuando toca. Si no '
                    'abres la app, no se hace. El archivo se llama '
                    '${AutoBackupService.fileName}.',
                'It runs when you open Gonen or come back to it, when it is '
                    'due. If you do not open the app, it does not run. The '
                    'file is called ${AutoBackupService.fileName}.',
              ),
              style: theme.textTheme.bodySmall?.copyWith(
                color: scheme.onSurfaceVariant,
                height: 1.5,
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Restaurar
  // ---------------------------------------------------------------------------

  Future<void> _restore() async {
    if (_busy) {
      return;
    }
    final bool confirmed = await confirmRestoreBackup(context);
    if (!confirmed || !mounted) {
      return;
    }

    final DiaryProvider diary = context.read<DiaryProvider>();
    final CapsulesProvider capsules = context.read<CapsulesProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);

    setState(() => _busy = true);
    File? picked;
    try {
      picked = await _transfer.pickFile();
      if (picked == null) {
        return;
      }
      final BackupRestoreResult result = await _service.restore(picked);
      await diary.reload();
      await capsules.load();
      if (!mounted) {
        return;
      }
      await _showRestoreResult(result);
    } on FileTransferException catch (error) {
      _showMessage(messenger, error.message);
    } on FormatException catch (error) {
      _showMessage(messenger, error.message);
    } catch (error, stackTrace) {
      debugPrint('Gonen: error al restaurar la copia: $error\n$stackTrace');
      _showMessage(
        messenger,
        tr(
          'No se pudo restaurar la copia de seguridad.',
          'The backup could not be restored.',
        ),
      );
    } finally {
      if (picked != null) {
        await _service.discard(picked);
      }
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  Future<void> _showRestoreResult(BackupRestoreResult result) {
    final BackupMergeResult merge = result.merge;
    final List<String> lines = <String>[];

    if (merge.isEmpty) {
      lines.add(
        tr(
          'Este móvil ya tenía todo lo que había en la copia.',
          'This phone already had everything that was in the backup.',
        ),
      );
    } else {
      final String added = _joinParts(<String>[
        if (merge.entriesAdded > 0)
          merge.entriesAdded == 1
              ? tr('1 entrada', '1 entry')
              : tr(
                  '${merge.entriesAdded} entradas',
                  '${merge.entriesAdded} entries',
                ),
        if (merge.capsulesAdded > 0)
          merge.capsulesAdded == 1
              ? tr('1 cápsula', '1 capsule')
              : tr(
                  '${merge.capsulesAdded} cápsulas',
                  '${merge.capsulesAdded} capsules',
                ),
        if (merge.attachmentsAdded > 0)
          merge.attachmentsAdded == 1
              ? tr('1 foto o nota de voz', '1 photo or voice note')
              : tr(
                  '${merge.attachmentsAdded} fotos y notas de voz',
                  '${merge.attachmentsAdded} photos and voice notes',
                ),
      ]);
      lines.add(tr('Se ha añadido: $added.', 'Added: $added.'));
    }
    if (merge.entriesKept > 0) {
      lines.add(
        merge.entriesKept == 1
            ? tr(
                '1 día ya tenía un texto distinto en este móvil y se ha dejado '
                    'como estaba.',
                '1 day already had a different text on this phone and was left '
                    'as it was.',
              )
            : tr(
                '${merge.entriesKept} días ya tenían un texto distinto en este '
                    'móvil y se han dejado como estaban.',
                '${merge.entriesKept} days already had a different text on this '
                    'phone and were left as they were.',
              ),
      );
    }
    if (result.attachmentsWithoutFile > 0) {
      lines.add(
        tr(
          '${result.attachmentsWithoutFile} fotos o notas de voz no venían en la '
              'copia y se han omitido.',
          '${result.attachmentsWithoutFile} photos or voice notes were not in '
              'the backup and were skipped.',
        ),
      );
    }

    return showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text(
            merge.isEmpty
                ? tr('Nada nuevo', 'Nothing new')
                : tr('Copia restaurada', 'Backup restored'),
          ),
          content: Text(lines.join('\n\n')),
          actions: <Widget>[
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: Text(tr('Entendido', 'Got it')),
            ),
          ],
        );
      },
    );
  }

  // ---------------------------------------------------------------------------
  // Pantalla
  // ---------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final bool premium = context
        .select<PremiumProvider, bool>((PremiumProvider p) => p.isPremium);
    final TextStyle? bodyStyle = theme.textTheme.bodyMedium?.copyWith(
      color: scheme.onSurfaceVariant,
      height: 1.5,
    );
    final DateTime? last = _lastBackup;

    return Scaffold(
      appBar: AppBar(title: Text(context.tr('Copia de seguridad', 'Backup'))),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
              children: <Widget>[
                if (_busy) ...<Widget>[
                  const LinearProgressIndicator(),
                  const SizedBox(height: 12),
                ],
                Text(
                  context.tr(
                    'Guarda tu diario, tus cápsulas, tus fotos y tus notas de voz '
                        'en un archivo. Si cambias de móvil o reinstalas la app, '
                        'puedes recuperarlo todo desde ese archivo.',
                    'Save your diary, capsules, photos and voice notes in one '
                        'file. If you change phones or reinstall the app, you '
                        'can recover everything from that file.',
                  ),
                  style: bodyStyle,
                ),
                const SizedBox(height: 20),
                PaperCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        context.tr('CREAR COPIA', 'CREATE BACKUP'),
                        style: _headingStyle(theme),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        last == null
                            ? context.tr(
                                'Todavía no has hecho ninguna copia.',
                                'You have not made a backup yet.',
                              )
                            : context.tr(
                                'Última copia: ${fullDateLabel(last)}.',
                                'Last backup: ${fullDateLabel(last)}.',
                              ),
                        style: theme.textTheme.titleSmall,
                      ),
                      const SizedBox(height: 6),
                      Text(
                        context.tr(
                          'Elige dónde guardarla: Google Drive, tu móvil, un '
                              'ordenador... Es un archivo con extensión .gonen.',
                          'Choose where to save it: Google Drive, your phone, a '
                              'computer... It is a file with the .gonen extension.',
                        ),
                        style: bodyStyle,
                      ),
                      const SizedBox(height: 14),
                      FilledButton.icon(
                        onPressed: _busy ? null : () => unawaited(_create()),
                        icon: const Icon(Icons.save_alt_rounded),
                        label: Text(context.tr('Crear copia', 'Create backup')),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                _buildAutoBackupCard(theme, bodyStyle, premium: premium),
                const SizedBox(height: 12),
                PaperCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        context.tr('RESTAURAR', 'RESTORE'),
                        style: _headingStyle(theme),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        context.tr(
                          'Restaurar una copia es gratis. Solo se añade lo que '
                              'falta en este móvil: nunca se borra ni se cambia lo '
                              'que ya tienes.',
                          'Restoring a backup is free. Only what is missing on '
                              'this phone is added: nothing you already have is '
                              'ever deleted or changed.',
                        ),
                        style: bodyStyle,
                      ),
                      const SizedBox(height: 14),
                      OutlinedButton.icon(
                        onPressed: _busy ? null : () => unawaited(_restore()),
                        icon: const Icon(Icons.restore_rounded),
                        label: Text(context.tr('Restaurar una copia', 'Restore a backup')),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Icon(
                      Icons.info_outline_rounded,
                      size: 18,
                      color: scheme.onSurfaceVariant,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        context.tr(
                          'El archivo de la copia no está cifrado: quien lo '
                              'tenga podrá leer tu diario. Guárdalo en un lugar '
                              'privado.\n\n'
                              'Además, si tienes activada la copia de seguridad de '
                              'Google en tu móvil, Android guarda también los textos '
                              'de forma automática (las fotos y las notas de voz, '
                              'no).',
                          'The backup file is not encrypted: anyone who has it '
                              'can read your diary. Keep it somewhere private.\n\n'
                              'Also, if Google backup is turned on on your phone, '
                              'Android saves your texts automatically too (but not '
                              'photos or voice notes).',
                        ),
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: scheme.onSurfaceVariant,
                          height: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  TextStyle? _headingStyle(ThemeData theme) {
    return theme.textTheme.labelMedium?.copyWith(
      color: theme.colorScheme.primary,
      letterSpacing: 1.6,
    );
  }
}
