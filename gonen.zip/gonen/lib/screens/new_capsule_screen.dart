import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/tr.dart';
import '../models/attachment_model.dart';
import '../models/capsule_model.dart';
import '../providers/capsules_provider.dart';
import '../providers/premium_provider.dart';
import '../services/attachment_service.dart';
import '../services/capsule_sender.dart';
import '../services/capsule_share_service.dart';
import '../theme/app_theme.dart';
import '../utils/date_labels.dart';
import '../widgets/capsule_attachments_editor.dart';
import '../widgets/capsule_dialogs.dart';
import 'premium_screen.dart';

/// Formulario para escribir y sellar una cápsula del tiempo nueva.
class NewCapsuleScreen extends StatefulWidget {
  const NewCapsuleScreen({super.key});

  @override
  State<NewCapsuleScreen> createState() => _NewCapsuleScreenState();
}

class _NewCapsuleScreenState extends State<NewCapsuleScreen> {
  final TextEditingController _title = TextEditingController();
  final TextEditingController _message = TextEditingController();

  /// Nombre de quien envía y de quien recibe (solo si la cápsula es para otra
  /// persona).
  final TextEditingController _senderName = TextEditingController();
  final TextEditingController _recipientName = TextEditingController();

  final CapsuleShareService _shareService = CapsuleShareService();
  late final CapsuleSender _sender = CapsuleSender(shareService: _shareService);

  /// Verdadero si la cápsula es para enviarla a otra persona (Premium).
  bool _forOther = false;

  /// Verdadero si el título no debe verse al recibirla (solo con título).
  bool _hideTitle = false;

  /// Fotos y notas de voz añadidas, todavía sin guardar en la cápsula.
  final List<Attachment> _attachments = <Attachment>[];

  DateTime? _openDate;
  bool _saving = false;

  /// Verdadero cuando ya se ha sellado: a partir de ahí se puede salir sin preguntar.
  bool _done = false;

  /// Verdadero solo si la cápsula se guardó: sus archivos ya no se pueden borrar.
  bool _sealed = false;

  bool get _hasDraft =>
      _title.text.trim().isNotEmpty ||
      _message.text.trim().isNotEmpty ||
      _attachments.isNotEmpty;

  /// El título se oculta de verdad: la casilla está marcada y hay título.
  bool get _titleHidden => _hideTitle && _title.text.trim().isNotEmpty;

  /// Lo único que verá quien reciba la cápsula, según lo escrito ahora.
  String get _arrivalPreview => CapsuleShareService.arrivalText(
        sender: _senderName.text,
        title: _title.text,
        hideTitle: _titleHidden,
      );

  bool get _canSeal =>
      !_saving &&
      _message.text.trim().isNotEmpty &&
      _openDate != null &&
      (!_forOther || _senderName.text.trim().isNotEmpty);

  @override
  void initState() {
    super.initState();
    _title.addListener(_onChanged);
    _message.addListener(_onChanged);
    _senderName.addListener(_onChanged);
    unawaited(_loadSenderName());
  }

  /// Rellena tu nombre con el que se usó la última vez que se envió una cápsula.
  Future<void> _loadSenderName() async {
    final String saved = await _shareService.loadSenderName();
    if (mounted && saved.isNotEmpty && _senderName.text.isEmpty) {
      _senderName.text = saved;
    }
  }

  Future<void> _toggleForOther(bool value) async {
    if (value && !context.read<PremiumProvider>().isPremium) {
      // Enviar cápsulas a otras personas es de Gonen Premium.
      await Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (BuildContext context) => const PremiumScreen(),
        ),
      );
      return;
    }
    if (mounted) {
      setState(() => _forOther = value);
    }
  }

  @override
  void dispose() {
    _title.dispose();
    _message.dispose();
    _senderName.dispose();
    _recipientName.dispose();
    if (!_sealed) {
      // Se salió sin sellar: las fotos y notas de voz no se quedan huérfanas.
      for (final Attachment attachment in _attachments) {
        unawaited(AttachmentService.instance.delete(attachment.relativePath));
      }
    }
    super.dispose();
  }

  void _addAttachment(Attachment attachment) {
    if (!mounted) {
      return;
    }
    setState(() => _attachments.add(attachment));
  }

  Future<void> _removeAttachment(Attachment attachment) async {
    await AttachmentService.instance.delete(attachment.relativePath);
    if (!mounted) {
      return;
    }
    setState(() => _attachments.remove(attachment));
  }

  void _onChanged() => setState(() {});

  /// Suma [months] meses a [from] sin pasarse de mes (31 de enero + 1 mes = 28/29 de febrero).
  DateTime _plusMonths(DateTime from, int months) {
    final int total = from.year * 12 + (from.month - 1) + months;
    final int year = total ~/ 12;
    final int month = total % 12 + 1;
    final int lastDay = DateTime(year, month + 1, 0).day;
    return DateTime(year, month, from.day > lastDay ? lastDay : from.day);
  }

  Future<void> _pickDate() async {
    final DateTime today = context.read<CapsulesProvider>().today;
    final DateTime tomorrow = DateTime(today.year, today.month, today.day + 1);
    // Si la pantalla se quedó abierta pasada la medianoche, la fecha elegida
    // antes puede haber quedado en el pasado: el calendario no la admitiría.
    DateTime initial = _openDate ?? _plusMonths(today, 12);
    if (initial.isBefore(tomorrow)) {
      initial = tomorrow;
    }

    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: tomorrow,
      lastDate: DateTime(today.year + 100, 12, 31),
      helpText: tr('Elegir día de apertura', 'Choose the opening day'),
    );
    if (picked != null && mounted) {
      setState(() => _openDate = Capsule.dateOnly(picked));
    }
  }

  Future<void> _seal() async {
    final DateTime? openDate = _openDate;
    if (openDate == null || !_canSeal) {
      return;
    }

    final bool forOther = _forOther;
    final bool confirmed = await confirmSealCapsule(
      context,
      openDate,
      forOther: forOther,
      arrival: forOther ? _arrivalPreview : null,
    );
    if (!confirmed || !mounted) {
      return;
    }

    final CapsulesProvider capsules = context.read<CapsulesProvider>();
    final NavigatorState navigator = Navigator.of(context);
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);

    setState(() => _saving = true);
    final CapsuleCreateResult result = await capsules.create(
      title: _title.text,
      content: _message.text,
      openDate: openDate,
      attachments: List<Attachment>.of(_attachments),
      senderName: forOther ? _senderName.text : null,
      recipientName: _recipientName.text,
      hideTitle: forOther && _titleHidden,
    );
    if (!mounted) {
      return;
    }

    if (!result.success) {
      setState(() => _saving = false);
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(result.errorMessage!)));
      return;
    }

    // La cápsula ya está guardada: sus archivos no se pueden borrar al salir.
    _sealed = true;

    String? sendNote;
    final Capsule? saved = result.capsule;
    if (forOther && saved != null) {
      await _shareService.saveSenderName(_senderName.text);
      sendNote = await _sendFile(saved, result.attachments);
      if (!mounted) {
        return;
      }
    }

    _done = true;
    navigator.pop();
    final String reminder = result.reminderScheduled
        ? tr(
            'Cápsula sellada. Te avisaremos el ${dayMonthLabel(openDate)}.',
            'Capsule sealed. We will remind you on ${dayMonthLabel(openDate)}.',
          )
        : tr(
            'Cápsula sellada. Sin notificaciones no recibirás el aviso '
                'del día de apertura.',
            'Capsule sealed. Without notifications you will not get the '
                'reminder on the opening day.',
          );
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(sendNote == null ? reminder : '$reminder $sendNote'),
        ),
      );
  }

  /// Prepara el archivo y abre el menú de compartir. Devuelve una frase para
  /// añadir al aviso final cuando hay algo que contar, o null si todo fue bien.
  Future<String?> _sendFile(Capsule capsule, List<Attachment> files) async {
    try {
      final CapsuleSendResult sent = await _sender.send(capsule, files);
      switch (sent) {
        case CapsuleSendResult.shared:
          return null;
        case CapsuleSendResult.saved:
          return tr(
            'El archivo está guardado: envíaselo tú a la otra persona.',
            'The file is saved: send it to the other person yourself.',
          );
        case CapsuleSendResult.cancelled:
          return tr(
            'Aún no has enviado el archivo: pulsa Enviar en la cápsula.',
            'You have not sent the file yet: tap Send on the capsule.',
          );
      }
    } on CapsuleSendException catch (error) {
      return tr(
        '${error.message} Puedes enviarla desde la cápsula.',
        '${error.message} You can send it from the capsule.',
      );
    } catch (error) {
      debugPrint('Gonen: error al enviar la cápsula: $error');
      return tr(
        'No se pudo enviar el archivo. Puedes hacerlo desde la cápsula.',
        'The file could not be sent. You can do it from the capsule.',
      );
    }
  }

  Future<void> _onPopBlocked() async {
    // Mientras se está sellando no se puede salir: la cápsula se guardaría igual.
    if (_saving) {
      return;
    }
    final bool discard = await confirmDiscardCapsule(context);
    if (discard && mounted) {
      setState(() => _done = true);
      Navigator.of(context).pop();
    }
  }

  /// Interruptor «Es para otra persona» y, si está activo, los nombres.
  List<Widget> _buildRecipientSection(ThemeData theme, ColorScheme scheme) {
    final bool premium = context
        .select<PremiumProvider, bool>((PremiumProvider p) => p.isPremium);

    return <Widget>[
      Text(
        context.tr('PARA QUIÉN ES', 'WHO IT IS FOR'),
        style: theme.textTheme.labelMedium?.copyWith(
          color: scheme.primary,
          letterSpacing: 1.6,
        ),
      ),
      const SizedBox(height: 4),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        value: _forOther,
        onChanged: _saving ? null : (bool value) => unawaited(_toggleForOther(value)),
        secondary: Icon(
          premium ? Icons.send_outlined : Icons.lock_outline_rounded,
        ),
        title: Text(
          premium
              ? context.tr('Es para otra persona', 'It is for someone else')
              : context.tr(
                  'Es para otra persona (Premium)',
                  'It is for someone else (Premium)',
                ),
        ),
        subtitle: Text(
          context.tr(
            'Se crea un archivo para enviárselo por WhatsApp, correo...',
            'A file is created so you can send it by WhatsApp, email...',
          ),
        ),
      ),
      if (_forOther) ...<Widget>[
        const SizedBox(height: 8),
        TextField(
          controller: _senderName,
          maxLength: CapsuleShareService.maxSenderLength,
          enabled: !_saving,
          textCapitalization: TextCapitalization.words,
          textInputAction: TextInputAction.next,
          decoration: InputDecoration(
            labelText: context.tr('Tu nombre', 'Your name'),
            helperText: context.tr(
              'Es el que verá la otra persona.',
              'This is what the other person will see.',
            ),
            border: const OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _recipientName,
          maxLength: CapsuleShareService.maxSenderLength,
          enabled: !_saving,
          textCapitalization: TextCapitalization.words,
          decoration: InputDecoration(
            labelText: context.tr('Para (opcional)', 'For (optional)'),
            helperText: context.tr(
              'Solo lo ves tú, para reconocerla en tu lista.',
              'Only you see this, to recognise it in your list.',
            ),
            border: const OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 4),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          value: _titleHidden,
          onChanged: _saving || _title.text.trim().isEmpty
              ? null
              : (bool? value) => setState(() => _hideTitle = value ?? false),
          title: Text(
            context.tr('Ocultar también el título', 'Hide the title too'),
          ),
          subtitle: Text(
            context.tr(
              'Quien la reciba solo verá tu nombre. El título no saldrá en el '
                  'archivo ni en el mensaje, y lo verá cuando la abra.',
              'The person receiving it will only see your name. The title will '
                  'not show in the file or the message, and they will see it '
                  'once they open the capsule.',
            ),
          ),
        ),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            border: Border.all(color: scheme.outlineVariant),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                context.tr(
                  'LO QUE VERÁ QUIEN LA RECIBA',
                  'WHAT THE RECIPIENT WILL SEE',
                ),
                style: theme.textTheme.labelSmall?.copyWith(
                  color: scheme.primary,
                  letterSpacing: 1.4,
                ),
              ),
              const SizedBox(height: 6),
              Text(_arrivalPreview, style: theme.textTheme.titleMedium),
              const SizedBox(height: 6),
              Text(
                context.tr(
                  'Se envía como un archivo adjunto, pero su nombre y el '
                      'mensaje que lo acompaña solo dicen esto. El texto, las '
                      'fotos, las notas de voz y la fecha van cifrados dentro '
                      'del archivo.',
                  'It is sent as an attached file, but its name and the '
                      'message with it say only this. The text, photos, voice '
                      'notes and date are encrypted inside the file.',
                ),
                style: theme.textTheme.bodySmall?.copyWith(
                  color: scheme.onSurfaceVariant,
                  height: 1.5,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Text(
          context.tr(
            'La otra persona necesita Gonen. El archivo va cifrado y la app no '
                'la deja abrir antes de la fecha, pero la clave está dentro de la '
                'app: alguien con muchos conocimientos podría saltarse ese candado. '
                'No metas nada de lo que dependa algo importante.',
            'The other person needs Gonen. The file is encrypted and the app '
                'will not let them open it before the date, but the key is '
                'inside the app: someone with a lot of expertise could get '
                'around that lock. Do not include anything that something important depends on.',
          ),
          style: theme.textTheme.bodySmall?.copyWith(
            color: scheme.onSurfaceVariant,
            height: 1.5,
          ),
        ),
      ],
    ];
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final DateTime today = context.read<CapsulesProvider>().today;

    final List<({String label, DateTime date})> shortcuts =
        <({String label, DateTime date})>[
      (label: context.tr('En 1 mes', 'In 1 month'), date: _plusMonths(today, 1)),
      (
        label: context.tr('En 6 meses', 'In 6 months'),
        date: _plusMonths(today, 6)
      ),
      (label: context.tr('En 1 año', 'In 1 year'), date: _plusMonths(today, 12)),
      (
        label: context.tr('En 5 años', 'In 5 years'),
        date: _plusMonths(today, 60)
      ),
    ];

    return PopScope<Object?>(
      canPop: _done || (!_hasDraft && !_saving),
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) {
          unawaited(_onPopBlocked());
        }
      },
      child: Scaffold(
        appBar: AppBar(title: Text(context.tr('Nueva cápsula', 'New capsule'))),
        body: SafeArea(
          child: Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 680),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
                keyboardDismissBehavior:
                    ScrollViewKeyboardDismissBehavior.onDrag,
                children: <Widget>[
                  Text(
                    context.tr(
                      'Escribe un mensaje para tu yo del futuro. Quedará sellado '
                          'y no podrás leerlo hasta el día que elijas.',
                      'Write a message to your future self. It will be sealed '
                          'and you will not be able to read it until the day '
                          'you choose.',
                    ),
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: scheme.onSurfaceVariant,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _title,
                    maxLength: 60,
                    textCapitalization: TextCapitalization.sentences,
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                      labelText:
                          context.tr('Título (opcional)', 'Title (optional)'),
                      border: const OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _message,
                    minLines: 8,
                    maxLines: null,
                    keyboardType: TextInputType.multiline,
                    textCapitalization: TextCapitalization.sentences,
                    style: theme.textTheme.bodyLarge?.copyWith(
                      fontFamily: context.appStyle.bodyFamily,
                      fontSize: 17,
                      height: 1.6,
                    ),
                    decoration: InputDecoration(
                      labelText: context.tr('Mensaje', 'Message'),
                      alignLabelWithHint: true,
                      border: const OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    context.tr('FOTOS Y NOTAS DE VOZ', 'PHOTOS AND VOICE NOTES'),
                    style: theme.textTheme.labelMedium?.copyWith(
                      color: scheme.primary,
                      letterSpacing: 1.6,
                    ),
                  ),
                  const SizedBox(height: 8),
                  CapsuleAttachmentsEditor(
                    attachments: _attachments,
                    enabled: !_saving,
                    onAdded: _addAttachment,
                    onRemoved: _removeAttachment,
                  ),
                  const SizedBox(height: 24),
                  Text(
                    context.tr('SE PODRÁ ABRIR EL', 'CAN BE OPENED ON'),
                    style: theme.textTheme.labelMedium?.copyWith(
                      color: scheme.primary,
                      letterSpacing: 1.6,
                    ),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _saving ? null : _pickDate,
                    icon: const Icon(Icons.event_outlined),
                    label: Text(
                      _openDate == null
                          ? context.tr('Elegir fecha', 'Choose a date')
                          : fullDateLabel(_openDate!),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: <Widget>[
                      for (final ({String label, DateTime date}) option
                          in shortcuts)
                        ChoiceChip(
                          label: Text(option.label),
                          selected: _openDate == option.date,
                          onSelected: _saving
                              ? null
                              : (bool selected) =>
                                  setState(() => _openDate = option.date),
                        ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  ..._buildRecipientSection(theme, scheme),
                  const SizedBox(height: 28),
                  FilledButton.icon(
                    onPressed: _canSeal ? () => unawaited(_seal()) : null,
                    icon: _saving
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Icon(
                            _forOther
                                ? Icons.send_outlined
                                : Icons.lock_outline_rounded,
                          ),
                    label: Text(
                      _forOther
                          ? context.tr('Sellar y enviar', 'Seal and send')
                          : context.tr('Sellar cápsula', 'Seal capsule'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
