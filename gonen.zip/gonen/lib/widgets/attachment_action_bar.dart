import 'dart:async';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../l10n/tr.dart';
import '../models/attachment_limits.dart';
import '../models/attachment_model.dart';
import '../providers/diary_provider.dart';
import '../providers/premium_provider.dart';
import '../screens/premium_screen.dart';
import '../services/external_activity_guard.dart';
import 'voice_recorder_sheet.dart';

/// Botones para añadir una foto (cámara o galería) o una nota de voz al día de hoy.
///
/// Sin Gonen Premium se ve un único botón (con un candado) que abre la pantalla
/// de compra; con premium aparecen foto, galería y voz, que solo funcionan
/// mientras el día es editable (hasta las 23:59), igual que el texto.
class AttachmentActionBar extends StatelessWidget {
  const AttachmentActionBar({super.key, this.onIdea});

  /// Si se da, a la derecha del botón de voz aparece el dado, que no es de
  /// pago y llama a esta función.
  final VoidCallback? onIdea;

  void _showMessage(ScaffoldMessengerState messenger, String text) {
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _openPremium(BuildContext context) {
    return Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => const PremiumScreen(),
      ),
    );
  }

  /// Comprueba premium, día editable y límite. Devuelve false (avisando al
  /// usuario) si no se puede añadir ahora mismo.
  Future<bool> _canAdd(BuildContext context, AttachmentType type) async {
    final PremiumProvider premium = context.read<PremiumProvider>();
    final DiaryProvider diary = context.read<DiaryProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);

    if (!premium.isPremium) {
      await _openPremium(context);
      return false;
    }
    if (!diary.canWriteCurrentYear) {
      _showMessage(
        messenger,
        tr(
          'Este día ya terminó (23:59): no se pueden añadir más archivos.',
          'This day has ended (11:59 pm): no more files can be added.',
        ),
      );
      return false;
    }
    if (diary.attachmentCount(type) >= DiaryProvider.attachmentLimit(type)) {
      _showMessage(
        messenger,
        type == AttachmentType.image
            ? tr(
                'Ya tienes ${AttachmentLimits.maxImagesPerDay} fotos en este día.',
                'You already have ${AttachmentLimits.maxImagesPerDay} photos on '
                    'this day.',
              )
            : tr(
                'Ya tienes ${AttachmentLimits.maxVoiceNotesPerDay} notas de voz '
                    'en este día.',
                'You already have ${AttachmentLimits.maxVoiceNotesPerDay} voice '
                    'notes on this day.',
              ),
      );
      return false;
    }
    return true;
  }

  Future<void> _pickImage(BuildContext context, ImageSource source) async {
    if (!await _canAdd(context, AttachmentType.image)) {
      return;
    }
    if (!context.mounted) {
      return;
    }

    final DiaryProvider diary = context.read<DiaryProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    // El día y el año se anotan ahora, antes de salir a la cámara o a la galería.
    final String dayKey = diary.dayKey;
    final int year = diary.entryYear;

    XFile? picked;
    try {
      picked = await pickPhoto(source);
    } catch (error) {
      debugPrint('Gonen: no se pudo abrir la cámara o la galería: $error');
      _showMessage(
        messenger,
        source == ImageSource.camera
            ? tr('No se pudo abrir la cámara.', 'The camera could not be opened.')
            : tr(
                'No se pudo abrir la galería.',
                'The gallery could not be opened.',
              ),
      );
      return;
    }

    if (picked == null) {
      return;
    }
    final String? error = await diary.addImage(
      sourcePath: picked.path,
      dayKey: dayKey,
      year: year,
    );
    if (error != null) {
      _showMessage(messenger, error);
    }
  }

  Future<void> _recordVoice(BuildContext context) async {
    if (!await _canAdd(context, AttachmentType.audio)) {
      return;
    }
    if (!context.mounted) {
      return;
    }

    final DiaryProvider diary = context.read<DiaryProvider>();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final String dayKey = diary.dayKey;
    final int year = diary.entryYear;

    final RecordedVoice? voice = await showModalBottomSheet<RecordedVoice>(
      context: context,
      isDismissible: false,
      enableDrag: false,
      builder: (BuildContext sheetContext) =>
          VoiceRecorderSheet(dayKey: dayKey, year: year),
    );
    if (voice == null) {
      return;
    }

    final String? error = await diary.addVoiceNote(
      relativePath: voice.relativePath,
      durationMs: voice.durationMs,
      dayKey: dayKey,
      year: year,
    );
    if (error != null) {
      _showMessage(messenger, error);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool premium = context
        .select<PremiumProvider, bool>((PremiumProvider p) => p.isPremium);

    return AttachmentButtons(
      premium: premium,
      onCamera: () => unawaited(_pickImage(context, ImageSource.camera)),
      onGallery: () => unawaited(_pickImage(context, ImageSource.gallery)),
      onVoice: () => unawaited(_recordVoice(context)),
      onLocked: () => unawaited(_openPremium(context)),
      onIdea: onIdea,
    );
  }
}

/// Abre la cámara o la galería y devuelve la foto elegida (ya reducida), o
/// null si se cancela. Lanza una excepción si no se puede abrir.
///
/// La cámara y la galería sacan a la app a segundo plano: mientras tanto no se
/// vuelve a pedir la huella al regresar.
Future<XFile?> pickPhoto(ImageSource source) async {
  try {
    ExternalActivityGuard.allowFor(const Duration(minutes: 5));
    return await ImagePicker().pickImage(
      source: source,
      maxWidth: AttachmentLimits.imageMaxSide,
      maxHeight: AttachmentLimits.imageMaxSide,
      imageQuality: AttachmentLimits.imageQuality,
    );
  } finally {
    ExternalActivityGuard.clear();
  }
}

/// Fila con los botones de adjuntos. Son solo iconos, para que la tarjeta se
/// vea ligera; cada uno lleva su nombre como ayuda (al mantenerlo pulsado y
/// para los lectores de pantalla).
///
/// Con [premium] se ven foto, galería y voz. Sin él se combinan en un único
/// botón con un candado, que no ocupa más que uno y avisa de que son de pago
/// sin escribir ninguna frase. Si hay [onIdea], el dado va siempre a la
/// derecha: no es de pago y nunca lleva candado.
class AttachmentButtons extends StatelessWidget {
  const AttachmentButtons({
    super.key,
    required this.premium,
    required this.onCamera,
    required this.onGallery,
    required this.onVoice,
    this.onLocked,
    this.onIdea,
  });

  final bool premium;
  final VoidCallback onCamera;
  final VoidCallback onGallery;
  final VoidCallback onVoice;

  /// Pulsar el botón único de sin Premium. Si es null se usa [onCamera], que
  /// ya comprueba Premium y abre su pantalla.
  final VoidCallback? onLocked;

  /// Pulsar el dado. Null = no se enseña el dado (por ejemplo, en las cápsulas).
  final VoidCallback? onIdea;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 4,
      children: <Widget>[
        if (premium) ...<Widget>[
          _ActionButton(
            icon: Icons.photo_camera_outlined,
            tooltip: context.tr('Hacer una foto', 'Take a photo'),
            onPressed: onCamera,
          ),
          _ActionButton(
            icon: Icons.photo_library_outlined,
            tooltip: context.tr('Elegir de la galería', 'Pick from the gallery'),
            onPressed: onGallery,
          ),
          _ActionButton(
            icon: Icons.mic_none_rounded,
            tooltip: context.tr('Grabar una nota de voz', 'Record a voice note'),
            onPressed: onVoice,
          ),
        ] else
          _LockedButton(
            tooltip: context.tr(
              'Fotos y notas de voz con Gonen Premium',
              'Photos and voice notes with Gonen Premium',
            ),
            onPressed: onLocked ?? onCamera,
          ),
        if (onIdea != null) _DiceButton(onPressed: onIdea!),
      ],
    );
  }
}

/// El dado de las ideas para escribir: un botón solo con el icono, para que
/// quepa en la misma línea que foto, galería y voz.
class _DiceButton extends StatelessWidget {
  const _DiceButton({required this.onPressed});

  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    return ActionChip(
      tooltip: context.tr('Dame una idea para escribir', 'Give me an idea to write about'),
      label: Icon(Icons.casino_outlined, size: 20, color: scheme.primary),
      labelPadding: const EdgeInsets.symmetric(horizontal: 2),
      onPressed: onPressed,
    );
  }
}

/// Botón de foto, galería o voz: solo el icono, igual que el del dado.
class _ActionButton extends StatelessWidget {
  const _ActionButton({
    required this.icon,
    required this.tooltip,
    required this.onPressed,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    return ActionChip(
      tooltip: tooltip,
      label: Icon(icon, size: 20, color: scheme.onSurface),
      labelPadding: const EdgeInsets.symmetric(horizontal: 2),
      onPressed: onPressed,
    );
  }
}

/// El botón único que sustituye a foto, galería y voz mientras no hay Premium:
/// una cámara con un candadito en la esquina. Al pulsarlo se abre Premium.
class _LockedButton extends StatelessWidget {
  const _LockedButton({required this.tooltip, required this.onPressed});

  final String tooltip;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    return ActionChip(
      tooltip: tooltip,
      label: SizedBox(
        width: 26,
        height: 22,
        child: Stack(
          clipBehavior: Clip.none,
          children: <Widget>[
            Positioned(
              left: 0,
              top: 1,
              child: Icon(
                Icons.add_a_photo_outlined,
                size: 20,
                color: scheme.onSurfaceVariant,
              ),
            ),
            Positioned(
              right: -1,
              bottom: -1,
              child: Icon(
                Icons.lock_rounded,
                size: 11,
                color: scheme.onSurface,
              ),
            ),
          ],
        ),
      ),
      labelPadding: const EdgeInsets.symmetric(horizontal: 2),
      onPressed: onPressed,
    );
  }
}
