import 'package:flutter/material.dart';

import '../providers/capsules_provider.dart';
import '../theme/app_style.dart';

/// Aviso sobre la fecha del móvil y las cápsulas. Por defecto dice que Gonen
/// no puede comprobar qué día es de verdad (la fecha del móvil es manual) y por
/// eso no abre las cápsulas; con [adjusted] dice que alguien ha cambiado la
/// fecha y que Gonen está usando la de verdad.
class ClockNotice extends StatelessWidget {
  const ClockNotice({super.key, this.adjusted = false});

  /// La fecha del móvil está cambiada, pero Gonen conoce la de verdad.
  final bool adjusted;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: scheme.errorContainer,
        borderRadius: BorderRadius.circular(context.appStyle.cornerRadius),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(Icons.schedule_rounded, color: scheme.onErrorContainer),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              adjusted
                  ? CapsulesProvider.clockAdjustedMessage
                  : CapsulesProvider.clockUnverifiedMessage,
              style: TextStyle(color: scheme.onErrorContainer),
            ),
          ),
        ],
      ),
    );
  }
}
