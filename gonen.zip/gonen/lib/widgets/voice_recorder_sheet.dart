import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:record/record.dart';

import '../l10n/tr.dart';
import '../models/attachment_limits.dart';
import '../services/attachment_service.dart';
import '../utils/duration_label.dart';

/// Nota de voz grabada: dónde está el archivo y cuánto dura.
class RecordedVoice {
  const RecordedVoice({required this.relativePath, required this.durationMs});

  /// Ruta del archivo relativa a la carpeta de adjuntos de la app.
  final String relativePath;

  final int durationMs;
}

enum _Phase { ready, starting, recording, saving, denied, failed }

/// Hoja inferior para grabar una nota de voz. Al cerrarse devuelve un
/// [RecordedVoice], o null si se cancela.
///
/// La grabación se detiene sola al llegar a [AttachmentLimits.maxVoiceSeconds].
class VoiceRecorderSheet extends StatefulWidget {
  const VoiceRecorderSheet({
    super.key,
    required this.dayKey,
    required this.year,
  });

  /// Nota de voz para una cápsula del tiempo (no pertenece a ningún día).
  const VoiceRecorderSheet.forCapsule({super.key})
      : dayKey = null,
        year = null;

  /// Día ("MM-DD") y año al que pertenece la nota. Son null en las cápsulas.
  final String? dayKey;
  final int? year;

  @override
  State<VoiceRecorderSheet> createState() => _VoiceRecorderSheetState();
}

class _VoiceRecorderSheetState extends State<VoiceRecorderSheet> {
  static const Duration _maxDuration =
      Duration(seconds: AttachmentLimits.maxVoiceSeconds);

  final AudioRecorder _recorder = AudioRecorder();
  final Stopwatch _stopwatch = Stopwatch();
  Timer? _ticker;
  _Phase _phase = _Phase.ready;
  String? _relativePath;

  @override
  void dispose() {
    _ticker?.cancel();
    unawaited(_recorder.dispose());
    super.dispose();
  }

  Future<void> _start() async {
    setState(() => _phase = _Phase.starting);
    try {
      if (!await _recorder.hasPermission()) {
        if (mounted) {
          setState(() => _phase = _Phase.denied);
        }
        return;
      }

      final String? dayKey = widget.dayKey;
      final int? year = widget.year;
      final String relativePath = (dayKey == null || year == null)
          ? AttachmentService.instance.newCapsuleRelativePath(extension: 'm4a')
          : AttachmentService.instance.newRelativePath(
              dayKey: dayKey,
              year: year,
              extension: 'm4a',
            );
      final File file =
          await AttachmentService.instance.prepareFile(relativePath);
      // Se anota ya, para que "Cancelar" borre el archivo aunque la grabación
      // aún no haya terminado de arrancar.
      _relativePath = relativePath;
      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: AttachmentLimits.voiceBitRate,
          sampleRate: 44100,
          numChannels: 1,
        ),
        path: file.path,
      );

      if (!mounted) {
        // La hoja se cerró mientras arrancaba: no queda nadie que la use.
        await AttachmentService.instance.delete(relativePath);
        return;
      }
      _stopwatch
        ..reset()
        ..start();
      _ticker = Timer.periodic(const Duration(milliseconds: 250), (Timer timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }
        setState(() {});
        if (_stopwatch.elapsed >= _maxDuration) {
          unawaited(_finish());
        }
      });
      setState(() => _phase = _Phase.recording);
    } catch (error) {
      debugPrint('Gonen: no se pudo empezar a grabar: $error');
      if (mounted) {
        setState(() => _phase = _Phase.failed);
      }
    }
  }

  /// Detiene la grabación y devuelve la nota.
  Future<void> _finish() async {
    if (_phase != _Phase.recording) {
      return;
    }
    setState(() => _phase = _Phase.saving);
    _ticker?.cancel();
    _stopwatch.stop();
    final int durationMs = _stopwatch.elapsedMilliseconds;
    final String? relativePath = _relativePath;

    try {
      await _recorder.stop();
      if (relativePath == null || durationMs < 1000) {
        // Una grabación de menos de un segundo se descarta.
        if (relativePath != null) {
          await AttachmentService.instance.delete(relativePath);
        }
        if (mounted) {
          Navigator.of(context).pop();
        }
        return;
      }
      if (mounted) {
        Navigator.of(context).pop(
          RecordedVoice(relativePath: relativePath, durationMs: durationMs),
        );
      }
    } catch (error) {
      debugPrint('Gonen: no se pudo terminar la grabación: $error');
      if (relativePath != null) {
        await AttachmentService.instance.delete(relativePath);
      }
      if (mounted) {
        setState(() => _phase = _Phase.failed);
      }
    }
  }

  /// Descarta la grabación (si la hay) y cierra la hoja.
  Future<void> _cancel() async {
    if (_phase == _Phase.saving) {
      return;
    }
    _ticker?.cancel();
    _stopwatch.stop();
    try {
      if (_phase == _Phase.recording) {
        await _recorder.cancel();
      }
    } catch (error) {
      debugPrint('Gonen: no se pudo cancelar la grabación: $error');
    }
    final String? relativePath = _relativePath;
    if (relativePath != null) {
      await AttachmentService.instance.delete(relativePath);
    }
    if (mounted) {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    final List<Widget> content;
    switch (_phase) {
      case _Phase.ready:
        content = <Widget>[
          Text(
            context.tr(
              'Graba hasta ${AttachmentLimits.maxVoiceSeconds ~/ 60} minutos. '
                  'Se guarda en este dispositivo.',
              'Record up to ${AttachmentLimits.maxVoiceSeconds ~/ 60} minutes. '
                  'It is saved on this device.',
            ),
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: scheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: () => unawaited(_start()),
            icon: const Icon(Icons.mic_rounded),
            label: Text(context.tr('Empezar a grabar', 'Start recording')),
          ),
          TextButton(
            onPressed: () => unawaited(_cancel()),
            child: Text(context.tr('Cancelar', 'Cancel')),
          ),
        ];
      case _Phase.starting:
      case _Phase.saving:
        content = const <Widget>[
          SizedBox(height: 12),
          CircularProgressIndicator(),
          SizedBox(height: 12),
        ];
      case _Phase.recording:
        content = <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(Icons.fiber_manual_record_rounded, color: scheme.error),
              const SizedBox(width: 8),
              Text(
                '${formatDuration(_stopwatch.elapsed)} / '
                '${formatDuration(_maxDuration)}',
                style: theme.textTheme.headlineSmall,
              ),
            ],
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: () => unawaited(_finish()),
            icon: const Icon(Icons.stop_rounded),
            label: Text(context.tr('Detener y guardar', 'Stop and save')),
          ),
          TextButton(
            onPressed: () => unawaited(_cancel()),
            child: Text(context.tr('Descartar', 'Discard')),
          ),
        ];
      case _Phase.denied:
        content = <Widget>[
          Text(
            context.tr(
              'Gonen necesita permiso para usar el micrófono. Puedes darlo en '
                  'los ajustes del sistema, en Aplicaciones > Gonen > Permisos.',
              'Gonen needs permission to use the microphone. You can grant it '
                  'in the system settings, under Apps > Gonen > Permissions.',
            ),
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium,
          ),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () => unawaited(_cancel()),
            child: Text(context.tr('Cerrar', 'Close')),
          ),
        ];
      case _Phase.failed:
        content = <Widget>[
          Text(
            context.tr(
              'No se pudo grabar la nota de voz. Inténtalo de nuevo.',
              'The voice note could not be recorded. Please try again.',
            ),
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium,
          ),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () => unawaited(_cancel()),
            child: Text(context.tr('Cerrar', 'Close')),
          ),
        ];
    }

    return PopScope<Object?>(
      // Con la hoja abierta, "atrás" descarta la grabación en vez de dejarla huérfana.
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) {
          unawaited(_cancel());
        }
      },
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Text(
                context.tr('Nota de voz', 'Voice note'),
                textAlign: TextAlign.center,
                style: theme.textTheme.titleLarge,
              ),
              const SizedBox(height: 16),
              ...content,
            ],
          ),
        ),
      ),
    );
  }
}
