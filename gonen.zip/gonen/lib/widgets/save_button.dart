import 'package:flutter/material.dart';

import '../l10n/tr.dart';
import '../providers/diary_provider.dart';
import '../theme/app_style.dart';

/// Botón de guardar del día de hoy.
///
/// Dice «Guardar» (y se puede pulsar) solo cuando hay cambios sin guardar o
/// el último guardado falló. Mientras guarda dice «Guardando…», y cuando todo
/// está en la base de datos dice «Guardado» y queda apagado hasta que se
/// vuelva a cambiar algo.
///
/// En los estilos editoriales es un rectángulo relleno con letras de máquina
/// de escribir; en los demás, un botón de texto.
class SaveButton extends StatelessWidget {
  const SaveButton({
    super.key,
    required this.status,
    required this.hasStoredText,
    required this.onPressed,
  });

  final SaveStatus status;

  /// Verdadero si el día ya tiene un texto guardado. Sirve para el estado
  /// inicial (`idle`): un día con texto guardado se ve «Guardado»; uno vacío,
  /// «Guardar» apagado, porque no hay nada que guardar.
  final bool hasStoredText;

  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final AppStyle style = context.appStyle;

    final String save = context.tr('Guardar', 'Save');
    final String saving = context.tr('Guardando…', 'Saving…');
    final String saved = context.tr('Guardado', 'Saved');

    if (style.isEditorial) {
      return _buildFilled(
        context,
        scheme,
        style,
        save: save,
        saving: saving,
        saved: saved,
      );
    }

    switch (status) {
      case SaveStatus.unsaved:
        return TextButton.icon(
          onPressed: onPressed,
          icon: const Icon(Icons.check_rounded, size: 18),
          label: Text(save),
        );
      case SaveStatus.error:
        // El fallo se avisa en el propio botón (en rojo y con otro icono), sin
        // tocar el resto de la tarjeta; al pulsarlo se vuelve a intentar.
        return TextButton.icon(
          onPressed: onPressed,
          style: TextButton.styleFrom(foregroundColor: scheme.error),
          icon: const Icon(Icons.error_outline_rounded, size: 18),
          label: Text(save),
        );
      case SaveStatus.saving:
        return TextButton.icon(
          onPressed: null,
          icon: const SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
          label: Text(saving),
        );
      case SaveStatus.saved:
        return _saved(scheme, saved);
      case SaveStatus.idle:
        if (hasStoredText) {
          return _saved(scheme, saved);
        }
        return TextButton.icon(
          onPressed: null,
          icon: const Icon(Icons.check_rounded, size: 18),
          label: Text(save),
        );
    }
  }

  Widget _saved(ColorScheme scheme, String label) {
    return TextButton.icon(
      onPressed: null,
      style: TextButton.styleFrom(disabledForegroundColor: scheme.secondary),
      icon: const Icon(Icons.check_circle_outline_rounded, size: 18),
      label: Text(label),
    );
  }

  // ---------------------------------------------------------------------------
  // Estilos editoriales
  // ---------------------------------------------------------------------------

  Widget _buildFilled(
    BuildContext context,
    ColorScheme scheme,
    AppStyle style, {
    required String save,
    required String saving,
    required String saved,
  }) {
    // La editorial japonesa rellena el botón con el bermellón.
    final Color fill = scheme.primary;
    final Color onFill = scheme.onPrimary;

    ButtonStyle buttonStyle({
      Color? background,
      Color? foreground,
      bool dimWhenDisabled = true,
    }) {
      final Color bg = background ?? fill;
      final Color fg = foreground ?? onFill;
      return FilledButton.styleFrom(
        minimumSize: const Size(0, 40),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        // La letra de máquina de escribir, algo más pequeña que la de serie.
        textStyle: TextStyle(
          fontFamily: style.labelFamily,
          fontSize: 12,
          letterSpacing: 0.8,
          fontWeight: FontWeight.w500,
        ),
        backgroundColor: bg,
        foregroundColor: fg,
        disabledBackgroundColor:
            dimWhenDisabled ? scheme.outline.withValues(alpha: 0.25) : bg,
        disabledForegroundColor: dimWhenDisabled ? scheme.onSurfaceVariant : fg,
      );
    }

    Widget filled({
      required String label,
      required IconData icon,
      required VoidCallback? onTap,
      required ButtonStyle look,
    }) {
      return FilledButton.icon(
        onPressed: onTap,
        style: look,
        icon: Icon(icon, size: 16),
        label: Text(label.toUpperCase()),
      );
    }

    switch (status) {
      case SaveStatus.unsaved:
        return filled(
          label: save,
          icon: Icons.check_rounded,
          onTap: onPressed,
          look: buttonStyle(),
        );
      case SaveStatus.error:
        return filled(
          label: save,
          icon: Icons.error_outline_rounded,
          onTap: onPressed,
          look: buttonStyle(
            background: scheme.error,
            foreground: scheme.onError,
          ),
        );
      case SaveStatus.saving:
        return FilledButton.icon(
          onPressed: null,
          style: buttonStyle(),
          icon: const SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
          label: Text(saving.toUpperCase()),
        );
      case SaveStatus.saved:
        // «Guardado» se ve igual de lleno que «Guardar», pero sin poder pulsarse.
        return filled(
          label: saved,
          icon: Icons.check_rounded,
          onTap: null,
          look: buttonStyle(dimWhenDisabled: false),
        );
      case SaveStatus.idle:
        if (hasStoredText) {
          return filled(
            label: saved,
            icon: Icons.check_rounded,
            onTap: null,
            look: buttonStyle(dimWhenDisabled: false),
          );
        }
        return filled(
          label: save,
          icon: Icons.check_rounded,
          onTap: null,
          look: buttonStyle(),
        );
    }
  }
}
