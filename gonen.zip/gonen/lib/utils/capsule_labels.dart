import '../l10n/tr.dart';
import '../models/capsule_model.dart';

/// «Para Lucía» (cápsula enviada), «De Ana» (cápsula recibida), o null si es
/// una cápsula normal, solo para uno mismo.
String? capsulePeerLabel(Capsule capsule) {
  final String? recipient = capsule.recipient;
  if (recipient != null) {
    final String name = recipient.trim();
    return name.isEmpty
        ? tr('Para otra persona', 'For someone else')
        : tr('Para $name', 'For $name');
  }
  final String? sender = capsule.sender;
  if (sender != null) {
    return tr('De $sender', 'From $sender');
  }
  return null;
}

/// Título que se enseña de [capsule] en las listas y en su pantalla.
///
/// Una cápsula recibida cuyo remitente pidió ocultar el título lo esconde hasta
/// que se abre ([opened]); en el resto de casos se ve siempre.
String capsuleTitleLabel(Capsule capsule, {required bool opened}) {
  final String title = capsule.title.trim();
  if (title.isEmpty) {
    return tr('Sin título', 'Untitled');
  }
  if (capsule.isReceived && capsule.hideTitle && !opened) {
    return tr('Título oculto', 'Hidden title');
  }
  return title;
}
