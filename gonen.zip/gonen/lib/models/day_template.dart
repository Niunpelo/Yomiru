/// Plantilla del día (Gonen Premium): un texto, normalmente unas preguntas, que
/// aparece ya escrito en la tarjeta de hoy para que el usuario lo desarrolle.
///
/// La plantilla no es una entrada: solo es el punto de partida del campo de
/// texto. Si el usuario no escribe nada suyo, ese día no se guarda nada (no
/// cuenta para la racha ni aparece en el calendario ni en la búsqueda). Si
/// escribe, se guarda todo el texto, preguntas incluidas, y en los años
/// siguientes se ve junto a sus respuestas.
class DayTemplate {
  DayTemplate._();

  /// Máximo de caracteres de la plantilla.
  static const int maxLength = 800;

  /// Deja la plantilla lista para guardar: saltos de línea normales, sin
  /// espacios ni líneas vacías sobrantes en los extremos y sin pasar de
  /// [maxLength].
  static String clean(String text) {
    String value = text.replaceAll('\r\n', '\n').trim();
    if (value.length > maxLength) {
      int end = maxLength;
      // No partir un carácter que ocupa dos unidades (por ejemplo, un emoji).
      final int last = value.codeUnitAt(end - 1);
      if (last >= 0xD800 && last <= 0xDBFF) {
        end--;
      }
      value = value.substring(0, end).trim();
    }
    return value;
  }

  /// Texto con el que arranca la tarjeta de hoy: la plantilla y un hueco debajo
  /// para empezar a escribir. Vacío si no hay plantilla.
  static String starter(String template) {
    final String value = template.trim();
    return value.isEmpty ? '' : '$value\n\n';
  }

  /// Verdadero si el usuario aún no ha escrito nada propio: el campo está
  /// vacío o solo contiene la plantilla tal como apareció.
  static bool isUntouched(String text, String template) {
    final String value = text.trim();
    if (value.isEmpty) {
      return true;
    }
    final String base = template.trim();
    return base.isNotEmpty && value == base;
  }

  /// Texto que hay que guardar: nada si el usuario no ha escrito nada propio.
  static String toSave(String text, String template) {
    return isUntouched(text, template) ? '' : text;
  }
}
