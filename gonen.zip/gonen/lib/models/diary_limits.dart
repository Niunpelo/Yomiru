/// Límites del ajuste "años anteriores que se muestran".
class DiaryLimits {
  DiaryLimits._();

  /// Solo se muestra la tarjeta del año actual.
  static const int minYearsBack = 0;

  /// Máximo de años anteriores que se pueden mostrar.
  static const int maxYearsBack = 5;

  /// Por defecto: el año actual más 1 anterior (2 tarjetas). Quien quiera ver
  /// más años los elige en Ajustes.
  static const int defaultYearsBack = 1;

  /// Ajusta [value] al rango permitido.
  static int clampYearsBack(int value) {
    if (value < minYearsBack) {
      return minYearsBack;
    }
    if (value > maxYearsBack) {
      return maxYearsBack;
    }
    return value;
  }
}
