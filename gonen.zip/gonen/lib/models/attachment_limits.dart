/// Límites de fotos y notas de voz por día.
class AttachmentLimits {
  AttachmentLimits._();

  /// Fotos por día y año (y por cápsula).
  static const int maxImagesPerDay = 5;

  /// Notas de voz por día y año (y por cápsula).
  static const int maxVoiceNotesPerDay = 2;

  /// Duración máxima de una nota de voz. La grabación se detiene sola al llegar.
  static const int maxVoiceSeconds = 300;

  /// Lado máximo, en píxeles, al que se reducen las fotos al adjuntarlas.
  ///
  /// 1280 px con calidad 75 pesa casi la mitad que 1600 px con calidad 80 y,
  /// a tamaño de pantalla apenas se nota. Solo afecta a las fotos nuevas: las
  /// que ya están guardadas no se tocan.
  static const double imageMaxSide = 1280;

  /// Calidad JPEG (0-100) con la que se guardan las fotos.
  static const int imageQuality = 75;

  /// Velocidad de grabación de las notas de voz (AAC mono), en bits por segundo.
  /// A 32 kbps una nota pesa la mitad que a 64 kbps (unos 0,25 MB por minuto) y
  /// para la voz sigue siendo suficiente. Solo afecta a las notas nuevas.
  static const int voiceBitRate = 32000;
}
