import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../l10n/tr.dart';
import 'backup_service.dart';
import 'file_transfer_service.dart';

/// Ajustes y estado de la copia de seguridad automática.
@immutable
class AutoBackupSettings {
  const AutoBackupSettings({
    this.enabled = false,
    this.intervalDays = AutoBackupService.defaultIntervalDays,
    this.folder,
    this.lastSuccess,
    this.lastAttempt,
    this.lastError,
  });

  /// El usuario la ha activado.
  final bool enabled;

  /// Cada cuántos días se hace la copia.
  final int intervalDays;

  /// Carpeta elegida (null hasta que el usuario la elige).
  final BackupFolder? folder;

  /// Cuándo se hizo bien la última copia automática.
  final DateTime? lastSuccess;

  /// Cuándo se intentó por última vez, con o sin éxito.
  final DateTime? lastAttempt;

  /// Por qué falló el último intento, o null si fue bien.
  final String? lastError;

  bool get hasFolder => folder != null;
}

/// Cómo terminó una vuelta de la copia automática.
enum AutoBackupStatus {
  /// La copia se ha guardado.
  done,

  /// No tocaba hacer nada (apagada, sin Premium, sin carpeta o aún no toca).
  skipped,

  /// Se intentó y falló; [AutoBackupResult.message] dice por qué.
  failed,
}

class AutoBackupResult {
  const AutoBackupResult(this.status, {this.message});

  final AutoBackupStatus status;

  /// Explicación para el usuario cuando [status] es `failed`.
  final String? message;
}

/// Copia de seguridad automática (Gonen Premium).
///
/// Cada cierto número de días que elige el usuario, guarda una copia completa
/// en la carpeta que él eligió, **sustituyendo la anterior**: siempre hay un
/// único archivo, [fileName]. No se ejecuta en segundo plano con la app cerrada:
/// Gonen mira si toca cuando se abre o se vuelve a ella, que es cuando el
/// diario puede haber cambiado.
class AutoBackupService {
  AutoBackupService({
    BackupService? backup,
    FileTransferService? transfer,
    DateTime Function()? clock,
  })  : _backup = backup ?? BackupService(),
        _transfer = transfer ?? const FileTransferService(),
        _clock = clock ?? DateTime.now;

  /// Instancia compartida por la pantalla de copias y la pantalla de inicio,
  /// para que nunca corran dos copias a la vez.
  static final AutoBackupService instance = AutoBackupService();

  /// Nombre fijo del archivo: la copia nueva se escribe encima de la anterior.
  static const String fileName = 'gonen-copia-automatica.gonen';

  /// Opciones de frecuencia, en días.
  static const List<int> intervalOptions = <int>[1, 3, 7, 14, 30];

  static const int defaultIntervalDays = 7;

  /// Tras un fallo no se vuelve a intentar hasta pasado este tiempo, para no
  /// repetirlo cada vez que se vuelve a la app.
  static const Duration retryAfterFailure = Duration(hours: 1);

  static const String _enabledKey = 'autobackup_enabled';
  static const String _daysKey = 'autobackup_days';
  static const String _uriKey = 'autobackup_uri';
  static const String _nameKey = 'autobackup_name';
  static const String _lastKey = 'autobackup_last_ms';
  static const String _attemptKey = 'autobackup_attempt_ms';
  static const String _errorKey = 'autobackup_error';

  final BackupService _backup;
  final FileTransferService _transfer;
  final DateTime Function() _clock;

  bool _running = false;

  /// Verdadero mientras se está haciendo una copia.
  bool get isRunning => _running;

  /// Cierra [days] a una de las frecuencias que se ofrecen.
  static int clampInterval(int days) {
    if (intervalOptions.contains(days)) {
      return days;
    }
    return defaultIntervalDays;
  }

  /// Días de calendario entre [from] y [to] (sin contar horas).
  static int _daysBetween(DateTime from, DateTime to) {
    return DateTime.utc(to.year, to.month, to.day)
        .difference(DateTime.utc(from.year, from.month, from.day))
        .inDays;
  }

  /// Si toca hacer la copia en el momento [now].
  ///
  /// * Hace falta que esté activada y que haya carpeta.
  /// * Si el último intento falló, se reintenta pasado [retryAfterFailure].
  /// * Si no, toca cuando han pasado los días elegidos desde la última copia
  ///   (por fechas de calendario: «cada día» es una vez cada día, no cada 24 h).
  /// * Si nunca se hizo ninguna, toca ya.
  @visibleForTesting
  static bool isDue(AutoBackupSettings settings, DateTime now) {
    if (!settings.enabled || !settings.hasFolder) {
      return false;
    }
    if (settings.lastError != null) {
      final DateTime? attempt = settings.lastAttempt;
      return attempt == null ||
          now.isBefore(attempt) ||
          now.difference(attempt) >= retryAfterFailure;
    }
    final DateTime? last = settings.lastSuccess;
    if (last == null || now.isBefore(last)) {
      // Nunca se hizo, o el reloj del móvil se ha movido hacia atrás.
      return true;
    }
    return _daysBetween(last, now) >= settings.intervalDays;
  }

  // ---------------------------------------------------------------------------
  // Ajustes
  // ---------------------------------------------------------------------------

  Future<AutoBackupSettings> load() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final String uri = prefs.getString(_uriKey) ?? '';
      final int? lastMs = prefs.getInt(_lastKey);
      final int? attemptMs = prefs.getInt(_attemptKey);
      final String error = prefs.getString(_errorKey) ?? '';
      return AutoBackupSettings(
        enabled: prefs.getBool(_enabledKey) ?? false,
        intervalDays: clampInterval(
          prefs.getInt(_daysKey) ?? defaultIntervalDays,
        ),
        folder: uri.isEmpty
            ? null
            : BackupFolder(uri: uri, name: prefs.getString(_nameKey) ?? ''),
        lastSuccess:
            lastMs == null ? null : DateTime.fromMillisecondsSinceEpoch(lastMs),
        lastAttempt: attemptMs == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(attemptMs),
        lastError: error.isEmpty ? null : error,
      );
    } catch (error) {
      debugPrint('Gonen: no se pudieron leer los ajustes de la copia: $error');
      return const AutoBackupSettings();
    }
  }

  Future<void> setEnabled(bool enabled) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_enabledKey, enabled);
  }

  Future<void> setIntervalDays(int days) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_daysKey, clampInterval(days));
  }

  /// Guarda la carpeta elegida. Al cambiar de carpeta se olvida el error
  /// anterior: el siguiente intento empieza limpio.
  Future<void> setFolder(BackupFolder folder) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(_uriKey, folder.uri);
    await prefs.setString(_nameKey, folder.name);
    await prefs.remove(_errorKey);
  }

  // ---------------------------------------------------------------------------
  // Hacer la copia
  // ---------------------------------------------------------------------------

  /// Hace la copia solo si toca y hay Gonen Premium. Es lo que se llama al
  /// abrir la app y al volver a ella. Nunca lanza excepciones.
  Future<AutoBackupResult> runIfDue({required bool premium}) async {
    if (!premium || _running) {
      return const AutoBackupResult(AutoBackupStatus.skipped);
    }
    final AutoBackupSettings settings = await load();
    if (!isDue(settings, _clock())) {
      return const AutoBackupResult(AutoBackupStatus.skipped);
    }
    return _run(settings);
  }

  /// Hace la copia ahora, toque o no (botón «Hacer copia ahora»).
  Future<AutoBackupResult> runNow() async {
    final AutoBackupSettings settings = await load();
    if (!settings.hasFolder) {
      return AutoBackupResult(
        AutoBackupStatus.failed,
        message: tr('Elige primero una carpeta.', 'Choose a folder first.'),
      );
    }
    if (_running) {
      return AutoBackupResult(
        AutoBackupStatus.failed,
        message: tr(
          'Ya se está haciendo una copia.',
          'A backup is already in progress.',
        ),
      );
    }
    return _run(settings);
  }

  Future<AutoBackupResult> _run(AutoBackupSettings settings) async {
    final BackupFolder? folder = settings.folder;
    if (folder == null || _running) {
      return const AutoBackupResult(AutoBackupStatus.skipped);
    }
    _running = true;
    BackupCreateResult? created;
    try {
      created = await _backup.create(fileName: fileName);
      await _transfer.writeToFolder(
        folderUri: folder.uri,
        sourcePath: created.file.path,
        fileName: fileName,
      );
      await _remember(error: null);
      return const AutoBackupResult(AutoBackupStatus.done);
    } on FileTransferException catch (error) {
      await _remember(error: error.message);
      return AutoBackupResult(AutoBackupStatus.failed, message: error.message);
    } catch (error, stackTrace) {
      debugPrint('Gonen: error en la copia automática: $error\n$stackTrace');
      final String message = tr(
        'No se pudo crear la copia de seguridad.',
        'The backup could not be created.',
      );
      await _remember(error: message);
      return AutoBackupResult(AutoBackupStatus.failed, message: message);
    } finally {
      if (created != null) {
        await _backup.discard(created.file);
      }
      _running = false;
    }
  }

  /// Anota el resultado del intento: la fecha de la copia si fue bien, o el
  /// motivo si falló.
  Future<void> _remember({required String? error}) async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final int now = _clock().millisecondsSinceEpoch;
      await prefs.setInt(_attemptKey, now);
      if (error == null) {
        await prefs.setInt(_lastKey, now);
        await prefs.remove(_errorKey);
      } else {
        await prefs.setString(_errorKey, error);
      }
    } catch (exception) {
      debugPrint('Gonen: no se pudo anotar el resultado de la copia: $exception');
    }
  }
}
