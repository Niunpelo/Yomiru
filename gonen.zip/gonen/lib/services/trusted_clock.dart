import 'dart:io' show Platform;

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Hasta qué punto se puede fiar Gonen de la fecha del móvil.
enum ClockTrust {
  /// La fecha es fiable: es automática (la pone la red) o coincide con el
  /// contador interno de Android.
  ok,

  /// La fecha del móvil se ha cambiado a mano. Gonen usa la que calcula con el
  /// contador interno de Android, que el usuario no puede tocar.
  adjusted,

  /// No hay forma de saber qué día es de verdad: la fecha es manual y Gonen no
  /// tiene un punto de referencia anterior. No se abre ninguna cápsula hasta
  /// que se activen la fecha y la hora automáticas.
  unverifiable,
}

/// Lo que Android cuenta del reloj y el usuario no puede cambiar a mano.
@immutable
class ClockSnapshot {
  const ClockSnapshot({
    required this.elapsedMs,
    required this.bootCount,
    required this.autoTime,
  });

  /// Milisegundos desde que arrancó el móvil (también cuenta el reposo). Solo
  /// avanza y no depende de la fecha.
  final int elapsedMs;

  /// Cuántas veces ha arrancado el móvil, o -1 si Android no lo dice.
  final int bootCount;

  /// «Fecha y hora automáticas» está activado: la fecha la pone la red y no se
  /// puede cambiar desde los ajustes.
  final bool autoTime;
}

/// Último momento en que Gonen supo qué hora era de verdad.
@immutable
class ClockAnchor {
  const ClockAnchor({
    required this.trustedMs,
    required this.elapsedMs,
    required this.bootCount,
  });

  /// La fecha real en ese momento (milisegundos desde 1970).
  final int trustedMs;

  /// El contador desde el arranque en ese momento.
  final int elapsedMs;

  /// El número de arranques en ese momento.
  final int bootCount;
}

/// Resultado de mirar el reloj.
@immutable
class ClockReading {
  const ClockReading({
    required this.wall,
    required this.now,
    required this.trust,
  });

  /// Lo que marca el reloj del móvil.
  final DateTime wall;

  /// La fecha y hora que Gonen da por buenas.
  final DateTime now;

  final ClockTrust trust;
}

/// Calcula la fecha de verdad aunque se cambie la del móvil, para que no se
/// pueda abrir una cápsula antes de tiempo adelantando el reloj.
///
/// Se apoya en el contador de Android desde el arranque
/// (`SystemClock.elapsedRealtime`), que solo avanza —también con el móvil en
/// reposo— y no depende de la fecha, y en un punto de referencia que Gonen
/// guarda: «a esta fecha real, el contador marcaba tanto».
///
/// * **Mismo arranque que el punto de referencia** (lo normal): la fecha real
///   es la del punto de referencia más lo que ha contado Android desde
///   entonces. Si el reloj del móvil coincide (margen de unos minutos), se usa
///   el reloj. Si no coincide —alguien ha adelantado o atrasado la fecha—, manda
///   el contador. Esto vale **también con «Fecha y hora automáticas»
///   activado**: sin internet se puede dejar una fecha falsa y volver a activar
///   la automática, y el ajuste seguiría diciendo «automática». La única
///   excepción es un reloj *atrasado* con la fecha automática: es la red
///   corrigiéndolo hacia atrás, y atrasar nunca abre una cápsula antes.
/// * **Sin punto de referencia o tras reiniciar el móvil** (el contador vuelve
///   a cero): con la fecha automática se da por buena la del reloj y se guarda
///   como punto de referencia; con la fecha manual no hay forma de saber qué
///   día es y no se abre nada hasta activar la fecha automática.
///
/// Si no se puede leer el contador en un móvil Android, tampoco se da la
/// fecha por buena: así la protección no se apaga en silencio. Fuera de Android
/// (las pruebas) se usa el reloj sin más.
///
/// Límite que queda: con el móvil sin internet, cambiar la fecha a mano,
/// reiniciar y volver a activar la fecha automática engaña a Gonen hasta que el
/// móvil se conecte y corrija el reloj (entonces lo detecta y lo arregla). Y no
/// puede frenar a quien tenga acceso a los archivos del móvil (root): las
/// cápsulas se guardan en la base de datos local.
class TrustedClock {
  TrustedClock({
    DateTime Function()? wallClock,
    Future<ClockSnapshot?> Function()? probe,
    bool? failClosed,
  })  : _wallClock = wallClock ?? DateTime.now,
        _probe = probe ?? _platformProbe,
        _failClosed = failClosed ?? Platform.isAndroid;

  static const MethodChannel _channel = MethodChannel('gonen/files');

  static const String _trustedKey = 'clock_anchor_trusted_ms';
  static const String _elapsedKey = 'clock_anchor_elapsed_ms';
  static const String _bootKey = 'clock_anchor_boot_count';

  /// Diferencia máxima entre el reloj del móvil y el contador de Android para
  /// dar la fecha por buena con la fecha manual.
  static const Duration tolerance = Duration(minutes: 3);

  /// Lo mismo con la fecha automática, donde la red puede corregir el reloj un
  /// poco más (tras muchos días sin conexión, por ejemplo).
  static const Duration autoTolerance = Duration(minutes: 10);

  final DateTime Function() _wallClock;
  final Future<ClockSnapshot?> Function() _probe;

  /// Si no se puede comprobar nada, no se da la fecha por buena (en Android).
  final bool _failClosed;

  /// Mira el reloj, aplica las reglas y guarda el nuevo punto de referencia.
  /// Nunca lanza excepciones.
  Future<ClockReading> read() async {
    final DateTime wall = _wallClock();
    try {
      final ClockSnapshot? snapshot = await _probe();
      if (snapshot == null) {
        return _unknown(wall);
      }
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final ({ClockReading reading, ClockAnchor? anchor}) result = evaluate(
        wall: wall,
        snapshot: snapshot,
        anchor: _loadAnchor(prefs),
      );
      final ClockAnchor? next = result.anchor;
      if (next != null) {
        await prefs.setInt(_trustedKey, next.trustedMs);
        await prefs.setInt(_elapsedKey, next.elapsedMs);
        await prefs.setInt(_bootKey, next.bootCount);
      }
      return result.reading;
    } catch (error) {
      debugPrint('Gonen: no se pudo comprobar la fecha del móvil: $error');
      return _unknown(wall);
    }
  }

  /// Cuando no hay datos del sistema: en Android no se fía; fuera de Android
  /// (pruebas) se usa el reloj.
  ClockReading _unknown(DateTime wall) => ClockReading(
        wall: wall,
        now: wall,
        trust: _failClosed ? ClockTrust.unverifiable : ClockTrust.ok,
      );

  /// Las reglas, sin tocar el móvil: con lo que marca el reloj ([wall]), lo que
  /// cuenta Android ([snapshot]) y el último punto de referencia ([anchor]),
  /// dice qué fecha dar por buena y cuál es el nuevo punto de referencia (null
  /// si no hay que guardar ninguno).
  @visibleForTesting
  static ({ClockReading reading, ClockAnchor? anchor}) evaluate({
    required DateTime wall,
    required ClockSnapshot snapshot,
    required ClockAnchor? anchor,
  }) {
    // Mismo arranque que el punto de referencia: el contador de Android sigue
    // contando bien, así que sirve de árbitro también con la fecha automática
    // (ver la explicación de la clase).
    final bool sameBoot = anchor != null &&
        anchor.bootCount == snapshot.bootCount &&
        snapshot.elapsedMs >= anchor.elapsedMs;
    if (anchor != null && sameBoot) {
      final DateTime counted = DateTime.fromMillisecondsSinceEpoch(
        anchor.trustedMs + (snapshot.elapsedMs - anchor.elapsedMs),
      );
      final Duration gap = wall.difference(counted);
      final Duration limit = snapshot.autoTime ? autoTolerance : tolerance;
      final bool agrees = gap.abs() <= limit;
      // Con la fecha automática, un reloj atrasado es la red corrigiéndolo hacia
      // atrás: se acepta (atrasar no abre nada antes de tiempo). Un reloj
      // adelantado no se acepta nunca.
      final bool networkFix = snapshot.autoTime && gap.isNegative;
      final bool useWall = agrees || networkFix;
      // Si coinciden, manda el reloj (así el error del contador no se
      // acumula); si no, la fecha del móvil está cambiada y manda el contador.
      final DateTime trusted = useWall ? wall : counted;
      return (
        reading: ClockReading(
          wall: wall,
          now: trusted,
          trust: useWall ? ClockTrust.ok : ClockTrust.adjusted,
        ),
        anchor: ClockAnchor(
          trustedMs: trusted.millisecondsSinceEpoch,
          elapsedMs: snapshot.elapsedMs,
          bootCount: snapshot.bootCount,
        ),
      );
    }

    // Sin punto de referencia utilizable (primera vez o móvil reiniciado) y con
    // la fecha automática: se da por buena la del reloj y se guarda.
    if (snapshot.autoTime) {
      return (
        reading: ClockReading(wall: wall, now: wall, trust: ClockTrust.ok),
        anchor: ClockAnchor(
          trustedMs: wall.millisecondsSinceEpoch,
          elapsedMs: snapshot.elapsedMs,
          bootCount: snapshot.bootCount,
        ),
      );
    }

    // Fecha manual y ningún punto de referencia utilizable: no hay forma de
    // saber qué día es. No se guarda nada, para no fiarse de una fecha sin
    // comprobar.
    return (
      reading: ClockReading(wall: wall, now: wall, trust: ClockTrust.unverifiable),
      anchor: null,
    );
  }

  static ClockAnchor? _loadAnchor(SharedPreferences prefs) {
    final int? trusted = prefs.getInt(_trustedKey);
    final int? elapsed = prefs.getInt(_elapsedKey);
    final int? boot = prefs.getInt(_bootKey);
    if (trusted == null || elapsed == null || boot == null) {
      return null;
    }
    return ClockAnchor(trustedMs: trusted, elapsedMs: elapsed, bootCount: boot);
  }

  /// Pregunta a Android (canal `gonen/files`, ver `tool/patch_android.py`).
  static Future<ClockSnapshot?> _platformProbe() async {
    try {
      final Map<Object?, Object?>? info =
          await _channel.invokeMapMethod<Object?, Object?>('clockInfo');
      if (info == null) {
        return null;
      }
      final Object? elapsed = info['elapsed'];
      final Object? boot = info['boot'];
      final Object? auto = info['auto'];
      if (elapsed is! int) {
        return null;
      }
      return ClockSnapshot(
        elapsedMs: elapsed,
        bootCount: boot is int ? boot : -1,
        autoTime: auto is bool ? auto : true,
      );
    } on MissingPluginException {
      return null;
    } on PlatformException {
      return null;
    }
  }
}
