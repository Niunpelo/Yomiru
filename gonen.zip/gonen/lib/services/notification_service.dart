import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart' show Color, TimeOfDay;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

import '../l10n/reminder_phrases.dart';
import '../l10n/tr.dart';

/// Programa el recordatorio diario para escribir en el diario.
class NotificationService {
  NotificationService._();

  /// Instancia única compartida por toda la aplicación.
  static final NotificationService instance = NotificationService._();

  /// Aviso diario de las versiones anteriores a la 1.8.0 (uno solo, que se
  /// repetía con la misma frase). Ya no se usa; se cancela al reprogramar para
  /// que no suene además de los nuevos.
  static const int legacyReminderId = 1001;

  /// El recordatorio son siete avisos semanales, uno por cada día de la semana
  /// y cada uno con su propia frase, con los identificadores desde este número.
  /// (En la 1.8.0 había hasta quince, que también se cancelan.)
  static const int reminderSlotBase = 1100;

  /// Cuántos avisos hay: uno por día de la semana.
  static const int reminderSlots = 7;

  /// Identificadores que usó la 1.8.0, para limpiarlos al actualizar.
  static const int _legacySlotCount = 15;

  /// Tiempo que se deja a Android para entregar un aviso «inexacto» que ya
  /// debería haber salido antes de tocarlo.
  static const Duration reminderLateWindow = Duration(hours: 3);

  /// Cómo quedó programado el recordatorio la última vez (hora, idioma y zona
  /// horaria); si no cambia, no hace falta volver a programarlo desde cero.
  static const String _reminderSignatureKey = 'reminder_signature';

  /// Si los avisos se renovaron hace menos que esto en esta sesión, no se repite.
  static const Duration _renewEvery = Duration(minutes: 30);

  /// Las cápsulas usan identificadores de aviso a partir de este número, para
  /// no chocar nunca con el recordatorio diario.
  static const int capsuleIdOffset = 100000;

  /// Hora del día (en punto) a la que avisa una cápsula del tiempo.
  static const int capsuleReminderHour = 9;

  // Android fija la importancia de un canal cuando se crea y la app ya no
  // puede subirla. Los canales antiguos («gonen_daily_reminder» y
  // «gonen_capsules») se crearon con importancia normal, que no enseña el
  // aviso emergente en pantalla; por eso los avisos usan canales nuevos (_v2)
  // con importancia alta y los antiguos se borran.
  static const List<String> _retiredChannelIds = <String>[
    'gonen_daily_reminder',
    'gonen_capsules',
  ];

  static const String _capsuleChannelId = 'gonen_capsules_v2';
  static String get _capsuleChannelName =>
      tr('Cápsulas del tiempo', 'Time capsules');
  static String get _capsuleChannelDescription => tr(
        'Aviso cuando llega el día de abrir una cápsula del tiempo',
        'Notice when the day to open a time capsule arrives',
      );

  static const String _channelId = 'gonen_daily_reminder_v2';
  static String get _channelName => tr('Recordatorio diario', 'Daily reminder');
  static String get _channelDescription => tr(
        'Aviso diario para escribir en tu diario Gonen',
        'Daily notice to write in your Gonen diary',
      );

  /// Icono blanco y transparente (drawable) que añade tool/patch_android.py.
  static const String _androidIcon = 'ic_stat_gonen';

  /// Bermellón de Gonen: tiñe el icono pequeño del aviso.
  static const Color _accentColor = Color(0xFFB04A3C);

  // Los avisos se configuran como los de un mensaje de WhatsApp: importancia y
  // prioridad altas (salen como emergentes sobre lo que estés haciendo y
  // encienden la pantalla), con sonido y vibración. En Android 8 o posterior el
  // sonido y la vibración los fija el canal; aquí se repiten para Android 7.
  // La categoría «recordatorio» le dice al sistema qué tipo de aviso es (el
  // modo No molestar puede dejar pasar los recordatorios).
  static NotificationDetails get _notificationDetails => NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          _channelName,
          channelDescription: _channelDescription,
          importance: Importance.high,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          category: AndroidNotificationCategory.reminder,
          color: _accentColor,
        ),
      );

  static NotificationDetails get _capsuleNotificationDetails =>
      NotificationDetails(
        android: AndroidNotificationDetails(
          _capsuleChannelId,
          _capsuleChannelName,
          channelDescription: _capsuleChannelDescription,
          importance: Importance.high,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          category: AndroidNotificationCategory.reminder,
          color: _accentColor,
        ),
      );

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  Future<void>? _initializing;

  /// Cuándo se renovó por última vez la ventana de avisos en esta sesión.
  DateTime? _lastRenewal;

  /// La parte de Android del plugin (null en otras plataformas).
  AndroidFlutterLocalNotificationsPlugin? get _android =>
      _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  /// Prepara el plugin y la zona horaria local. Se puede llamar varias veces,
  /// también a la vez: todas las llamadas esperan a la misma inicialización.
  Future<void> initialize() => _initializing ??= _runInitialize();

  Future<void> _runInitialize() async {
    try {
      tz_data.initializeTimeZones();
      await _configureLocalTimezone();

      const AndroidInitializationSettings androidSettings =
          AndroidInitializationSettings(_androidIcon);
      const InitializationSettings settings =
          InitializationSettings(android: androidSettings);
      await _plugin.initialize(settings: settings);
      // Los canales se crean ya, antes de pedir permiso o programar nada: así
      // Android los conoce desde el primer momento (y el usuario los ve en los
      // ajustes del sistema) en vez de esperar al primer aviso.
      await _createChannels();
    } catch (_) {
      // Si falla, la próxima llamada vuelve a intentarlo.
      _initializing = null;
      rethrow;
    }
  }

  /// Crea (o actualiza el nombre y la descripción de) los dos canales de avisos
  /// y borra los antiguos. Repetirlo es seguro: Android ignora lo que no puede
  /// cambiar y borrar un canal que no existe no hace nada.
  Future<void> _createChannels() async {
    final AndroidFlutterLocalNotificationsPlugin? android = _android;
    if (android == null) {
      return;
    }
    for (final String retired in _retiredChannelIds) {
      await android.deleteNotificationChannel(channelId: retired);
    }
    // Importancia alta: es la que hace que el aviso salga como emergente.
    await android.createNotificationChannel(
      AndroidNotificationChannel(
        _channelId,
        _channelName,
        description: _channelDescription,
        importance: Importance.high,
      ),
    );
    await android.createNotificationChannel(
      AndroidNotificationChannel(
        _capsuleChannelId,
        _capsuleChannelName,
        description: _capsuleChannelDescription,
        importance: Importance.high,
      ),
    );
  }

  Future<void> _configureLocalTimezone() async {
    try {
      final info = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(info.identifier));
    } catch (error) {
      debugPrint('Gonen: zona horaria no disponible, uso el desfase: $error');
      tz.setLocalLocation(_locationFromCurrentOffset());
    }
  }

  /// Plan B: busca una zona de la base de datos con el mismo desfase horario
  /// que el dispositivo en este momento.
  tz.Location _locationFromCurrentOffset() {
    final DateTime now = DateTime.now();
    final int offsetMs = now.timeZoneOffset.inMilliseconds;
    final int nowMs = now.millisecondsSinceEpoch;
    for (final tz.Location location in tz.timeZoneDatabase.locations.values) {
      if (location.timeZone(nowMs).offset == offsetMs) {
        return location;
      }
    }
    return tz.UTC;
  }

  /// Pide permiso para mostrar notificaciones (obligatorio desde Android 13).
  ///
  /// Devuelve true solo si Android dejará mostrar los avisos de Gonen: aunque
  /// el permiso esté concedido, el usuario puede haber apagado las
  /// notificaciones de la app en los ajustes del sistema.
  Future<bool> requestPermission() async {
    await initialize();
    final AndroidFlutterLocalNotificationsPlugin? android = _android;
    if (android == null) {
      return true;
    }
    final bool? granted = await android.requestNotificationsPermission();
    if (granted == false) {
      return false;
    }
    final bool? enabled = await android.areNotificationsEnabled();
    return enabled ?? granted ?? true;
  }

  /// Si Android deja mostrar ahora mismo las notificaciones de Gonen (permiso
  /// concedido y avisos de la app no apagados). Ante cualquier duda devuelve
  /// true, para no avisar de un problema que quizá no existe.
  Future<bool> areNotificationsEnabled() async {
    try {
      await initialize();
      return await _android?.areNotificationsEnabled() ?? true;
    } catch (error) {
      debugPrint('Gonen: no se pudo comprobar el permiso de avisos: $error');
      return true;
    }
  }

  /// Programa (o reprograma desde cero) los avisos diarios a la hora indicada.
  ///
  /// Un aviso que se repite lleva siempre el mismo texto, y un segundo aviso
  /// «de repuesto» sonaría además del bueno (el plugin dispara los repetidos
  /// desde hoy, no desde la fecha que se le da). Por eso son **siete avisos
  /// semanales**, uno por día de la semana, y cada uno con la frase de
  /// [ReminderPhrases] que toca ese día. Cada vez que se abre la app se renuevan
  /// las frases; si pasan semanas sin abrirla, cada día de la semana repite la
  /// suya. Nunca hay dos avisos el mismo día.
  ///
  /// Son avisos «inexactos» (`inexactAllowWhileIdle`): suenan aunque el móvil
  /// esté en reposo, pero Android decide el momento justo y puede retrasarlos
  /// unos minutos. No usan alarmas exactas a propósito: el permiso
  /// `SCHEDULE_EXACT_ALARM` está reservado por Google Play a apps de alarmas y
  /// calendarios, y para un recordatorio como este Android recomienda las
  /// inexactas.
  Future<void> scheduleDailyReminder(TimeOfDay time) async {
    await initialize();
    // La zona horaria y el idioma pueden haber cambiado desde el arranque (un
    // viaje, el cambio de idioma): se ponen al día antes de calcular la hora.
    await _configureLocalTimezone();
    await _createChannels();
    await _cancelReminderNotifications();
    await _scheduleReminderWeek(time, keepDueToday: false);
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(_reminderSignatureKey, _reminderSignature(time));
    _lastRenewal = DateTime.now();
  }

  /// Deja el recordatorio programado, sin tocarlo más de lo necesario.
  ///
  /// Es lo que se llama al abrir la app y al volver a ella. Si el recordatorio
  /// cambió (hora, idioma, zona horaria) o Android ya no tiene los siete
  /// avisos, se programa desde cero. Si no, solo se renuevan las frases, sin
  /// cancelar nada: así un aviso de hoy que Android está retrasando unos
  /// minutos no se pierde porque el usuario abra la app justo entonces.
  Future<void> ensureDailyReminder(TimeOfDay time) async {
    await initialize();
    await _configureLocalTimezone();
    final DateTime? last = _lastRenewal;
    if (last != null && DateTime.now().difference(last) < _renewEvery) {
      return;
    }
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.getString(_reminderSignatureKey) != _reminderSignature(time) ||
        await _pendingReminderCount() < reminderSlots) {
      await scheduleDailyReminder(time);
      return;
    }
    await _scheduleReminderWeek(time, keepDueToday: true);
    _lastRenewal = DateTime.now();
  }

  /// Identificador del aviso del día de la semana de [date].
  @visibleForTesting
  static int reminderSlotId(DateTime date) =>
      reminderSlotBase + (date.weekday - 1);

  /// Programa los siete avisos semanales: el de cada día de la semana, para su
  /// próxima fecha y con la frase de esa fecha. Programar de nuevo un
  /// identificador sustituye al anterior.
  ///
  /// Con [keepDueToday], si la hora de hoy acaba de pasar (menos de
  /// [reminderLateWindow]), el aviso de este día de la semana no se toca: puede
  /// que Android esté a punto de entregarlo con retraso, y sustituirlo lo haría
  /// saltar hasta la semana que viene sin haber sonado hoy.
  Future<void> _scheduleReminderWeek(
    TimeOfDay time, {
    required bool keepDueToday,
  }) async {
    final bool english = AppLocale.isEnglish;
    final tz.TZDateTime now = tz.TZDateTime.now(tz.local);
    final tz.TZDateTime first = _nextInstanceOf(time);
    final tz.TZDateTime todayAt = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      time.hour,
      time.minute,
    );
    final bool justDue = keepDueToday &&
        !todayAt.isAfter(now) &&
        now.difference(todayAt) < reminderLateWindow;

    for (int offset = 0; offset < reminderSlots; offset++) {
      // Se construye con day + offset (y no sumando 24 h) para respetar el
      // cambio de hora.
      final tz.TZDateTime when = tz.TZDateTime(
        tz.local,
        first.year,
        first.month,
        first.day + offset,
        time.hour,
        time.minute,
      );
      if (justDue && when.weekday == now.weekday) {
        continue;
      }
      await _plugin.zonedSchedule(
        id: reminderSlotId(when),
        title: 'Gonen',
        body: ReminderPhrases.forDate(when, english: english),
        scheduledDate: when,
        notificationDetails: _notificationDetails,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
      );
    }
  }

  /// Quita los avisos diarios, también los de las versiones anteriores.
  Future<void> _cancelReminderNotifications() async {
    await _plugin.cancel(id: legacyReminderId);
    for (int i = 0; i < _legacySlotCount; i++) {
      await _plugin.cancel(id: reminderSlotBase + i);
    }
  }

  /// Cuántos de los siete avisos semanales tiene programados el plugin.
  Future<int> _pendingReminderCount() async {
    final List<PendingNotificationRequest> pending =
        await _plugin.pendingNotificationRequests();
    return pending
        .where(
          (PendingNotificationRequest request) =>
              request.id >= reminderSlotBase &&
              request.id < reminderSlotBase + reminderSlots,
        )
        .length;
  }

  /// «v3» distingue este sistema (siete avisos semanales) de los anteriores (uno
  /// que se repetía, y uno por día más un repetido): al actualizar la app, el
  /// recordatorio se reprograma desde cero.
  String _reminderSignature(TimeOfDay time) =>
      'v3|${time.hour}:${time.minute}|${AppLocale.current.code}|${tz.local.name}';

  /// Quita todos los avisos diarios.
  Future<void> cancelDailyReminder() async {
    await initialize();
    await _cancelReminderNotifications();
    _lastRenewal = null;
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove(_reminderSignatureKey);
  }

  /// Programa el aviso de una cápsula para las 09:00 de su día de apertura.
  ///
  /// El texto no menciona el título, el contenido ni quién la envió para no
  /// enseñarlos en la pantalla de bloqueo. Con [received] avisa de una cápsula
  /// que ha dejado otra persona. Devuelve false si esa hora ya ha pasado.
  Future<bool> scheduleCapsuleOpening({
    required int capsuleId,
    required DateTime openDate,
    bool received = false,
  }) async {
    await initialize();
    await _configureLocalTimezone();
    final tz.TZDateTime scheduled = tz.TZDateTime(
      tz.local,
      openDate.year,
      openDate.month,
      openDate.day,
      capsuleReminderHour,
    );
    if (!scheduled.isAfter(tz.TZDateTime.now(tz.local))) {
      return false;
    }

    await _plugin.zonedSchedule(
      id: capsuleIdOffset + capsuleId,
      title: tr('Gonen · Cápsula del tiempo', 'Gonen · Time capsule'),
      body: received
          ? tr(
              'Hoy puedes abrir una cápsula que te han dejado.',
              'Today you can open a capsule that someone left for you.',
            )
          : tr(
              'Hoy puedes abrir una cápsula que escribiste hace tiempo.',
              'Today you can open a capsule you wrote a while ago.',
            ),
      scheduledDate: scheduled,
      notificationDetails: _capsuleNotificationDetails,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
    );
    return true;
  }

  /// Quita el aviso de una cápsula (al abrirla o borrarla).
  Future<void> cancelCapsuleOpening(int capsuleId) async {
    await initialize();
    await _plugin.cancel(id: capsuleIdOffset + capsuleId);
  }

  /// Próxima vez que el reloj marcará [time]: hoy si aún no ha pasado, si no mañana.
  tz.TZDateTime _nextInstanceOf(TimeOfDay time) {
    final tz.TZDateTime now = tz.TZDateTime.now(tz.local);
    tz.TZDateTime scheduled = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      time.hour,
      time.minute,
    );
    if (!scheduled.isAfter(now)) {
      // Se construye con day + 1 (y no sumando 24 h) para respetar el cambio de hora.
      scheduled = tz.TZDateTime(
        tz.local,
        now.year,
        now.month,
        now.day + 1,
        time.hour,
        time.minute,
      );
    }
    return scheduled;
  }
}
