import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../l10n/tr.dart';
import '../models/premium_entitlement.dart';
import '../services/external_activity_guard.dart';

/// Gonen Premium: fotos y notas de voz en el diario.
///
/// Se cobra con Google Play Billing:
/// * [yearlyProductId]: suscripción anual (4,99 €/año).
/// * [lifetimeProductId]: producto de pago único (14,99 €), no caduca.
///
/// Los precios reales los fija Google Play Console; la app muestra los que
/// devuelve la tienda. Esas dos ids hay que crearlas allí con esos nombres.
///
/// Las compras solo funcionan en una app instalada desde Google Play (o desde
/// una pista de pruebas). En un APK instalado a mano la tienda no reconoce los
/// productos y el premium queda bloqueado.
class PremiumProvider extends ChangeNotifier {
  PremiumProvider({InAppPurchase? inAppPurchase, DateTime Function()? clock})
      : _injectedStore = inAppPurchase,
        _clock = clock ?? DateTime.now;

  /// Id de la suscripción anual en Google Play Console.
  static const String yearlyProductId = 'gonen_premium_yearly';

  /// Id del producto de pago único en Google Play Console.
  static const String lifetimeProductId = 'gonen_premium_lifetime';

  static const Set<String> _productIds = <String>{
    yearlyProductId,
    lifetimeProductId,
  };

  static const String _planKey = 'premium_plan';
  static const String _verifiedKey = 'premium_verified_ms';

  /// Verdadero solo en compilaciones de PRUEBA hechas con
  /// `--dart-define=GONEN_PREMIUM_TEST=true`: desbloquea el premium sin pagar
  /// para poder probar las fotos y las notas de voz. Nunca se debe publicar una
  /// compilación así.
  static const bool testUnlock = bool.fromEnvironment('GONEN_PREMIUM_TEST');

  /// Tiempo máximo que se espera a que Google Play conteste a una compra.
  static const Duration _purchaseWindow = Duration(minutes: 5);

  /// Cada cuánto, como mucho, se vuelve a preguntar a Google Play por las
  /// compras activas mientras la app sigue abierta en segundo plano.
  static const Duration refreshEvery = Duration(hours: 12);

  final InAppPurchase? _injectedStore;
  final DateTime Function() _clock;

  InAppPurchase get _store => _injectedStore ?? InAppPurchase.instance;

  SharedPreferences? _prefs;
  StreamSubscription<List<PurchaseDetails>>? _purchaseSubscription;
  Timer? _busyTimer;

  PremiumEntitlement _entitlement = PremiumEntitlement.none;
  ProductDetails? _yearly;
  ProductDetails? _lifetime;
  bool _initialized = false;
  bool _storeAvailable = false;
  bool _busy = false;
  String? _message;
  bool _disposed = false;

  /// Última vez que se pidió a Google Play que confirmara las compras activas.
  DateTime? _lastStoreCheck;

  // ---------------------------------------------------------------------------
  // Lectura del estado
  // ---------------------------------------------------------------------------

  /// Verdadero si se pueden añadir fotos y notas de voz.
  bool get isPremium => testUnlock || _entitlement.isActiveAt(_clock());

  /// Compilación de prueba con el premium desbloqueado sin pagar.
  bool get isTestUnlock => testUnlock;

  /// Plan activo ahora mismo ([PremiumPlan.none] si no hay premium).
  PremiumPlan get plan {
    if (!_entitlement.isActiveAt(_clock())) {
      return PremiumPlan.none;
    }
    return _entitlement.plan;
  }

  /// Verdadero si se ha podido hablar con Google Play.
  bool get storeAvailable => _storeAvailable;

  /// Verdadero si la tienda ha devuelto al menos uno de los dos productos.
  bool get productsLoaded => _yearly != null || _lifetime != null;

  bool get yearlyAvailable => _yearly != null;
  bool get lifetimeAvailable => _lifetime != null;

  /// Precio de la suscripción anual tal y como lo muestra Google Play (null si no se cargó).
  String? get yearlyPrice => _yearly?.price;

  /// Precio del pago único tal y como lo muestra Google Play (null si no se cargó).
  String? get lifetimePrice => _lifetime?.price;

  /// Verdadero mientras hay una compra en curso.
  bool get isBusy => _busy;

  /// Último aviso para mostrar en la pantalla premium (éxito o error).
  String? get message => _message;

  void clearMessage() {
    if (_message != null) {
      _message = null;
      _notify();
    }
  }

  // ---------------------------------------------------------------------------
  // Arranque
  // ---------------------------------------------------------------------------

  /// Lee el derecho guardado, se suscribe a las compras de Google Play, carga
  /// los precios y pide a Play que vuelva a enviar las compras activas.
  /// Nunca lanza: si algo falla, el premium simplemente queda como estaba.
  Future<void> initialize() async {
    if (_initialized) {
      return;
    }
    _initialized = true;

    await _loadCache();
    _notify();

    try {
      final InAppPurchase store = _store;
      // Hay que escuchar las compras cuanto antes: las pendientes llegan solas.
      _purchaseSubscription = store.purchaseStream.listen(
        (List<PurchaseDetails> purchases) => unawaited(_onPurchases(purchases)),
        onError: (Object error) {
          debugPrint('Gonen: error en el flujo de compras: $error');
        },
      );

      _storeAvailable = await store.isAvailable();
      if (_storeAvailable) {
        await _loadProducts(store);
        // Play responde por el flujo de compras con las que siguen activas.
        _lastStoreCheck = _clock();
        await store.restorePurchases();
      }
    } catch (error) {
      debugPrint('Gonen: Google Play no está disponible: $error');
      _storeAvailable = false;
    }
    _notify();
  }

  /// Vuelve a preguntar a Google Play por las compras activas si hace más de
  /// [refreshEvery] que no se hace. Se llama al volver a la app: la suscripción
  /// anual solo vale unos días sin confirmación de Play, y si la app lleva
  /// abierta en segundo plano más tiempo que eso, sin esta consulta perdería el
  /// premium aunque la suscripción siga activa. Nunca lanza.
  Future<void> refreshIfStale() async {
    if (_disposed || !_initialized || !_storeAvailable || _busy) {
      return;
    }
    final DateTime now = _clock();
    final DateTime? last = _lastStoreCheck;
    if (last != null && !now.isBefore(last) && now.difference(last) < refreshEvery) {
      return;
    }
    _lastStoreCheck = now;
    try {
      await _store.restorePurchases();
    } catch (error) {
      debugPrint('Gonen: no se pudieron revisar las compras: $error');
    }
  }

  Future<void> _loadCache() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      _prefs = prefs;
      final String? planName = prefs.getString(_planKey);
      final PremiumPlan plan = PremiumPlan.values.firstWhere(
        (PremiumPlan candidate) => candidate.name == planName,
        orElse: () => PremiumPlan.none,
      );
      final int? verifiedMs = prefs.getInt(_verifiedKey);
      _entitlement = PremiumEntitlement(
        plan: plan,
        verifiedAt: verifiedMs == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(verifiedMs),
      );
    } catch (error) {
      debugPrint('Gonen: no se pudo leer el estado premium: $error');
    }
  }

  Future<void> _saveCache() async {
    try {
      final SharedPreferences? prefs = _prefs;
      if (prefs == null) {
        return;
      }
      await prefs.setString(_planKey, _entitlement.plan.name);
      final DateTime? verified = _entitlement.verifiedAt;
      if (verified != null) {
        await prefs.setInt(_verifiedKey, verified.millisecondsSinceEpoch);
      }
    } catch (error) {
      debugPrint('Gonen: no se pudo guardar el estado premium: $error');
    }
  }

  Future<void> _loadProducts(InAppPurchase store) async {
    final ProductDetailsResponse response =
        await store.queryProductDetails(_productIds);
    if (response.notFoundIDs.isNotEmpty) {
      debugPrint(
        'Gonen: Google Play no conoce estos productos: ${response.notFoundIDs}',
      );
    }
    for (final ProductDetails details in response.productDetails) {
      if (details.id == yearlyProductId) {
        _yearly ??= details;
      } else if (details.id == lifetimeProductId) {
        _lifetime ??= details;
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Compras
  // ---------------------------------------------------------------------------

  /// Abre la ventana de compra de Google Play para [plan]. El resultado llega
  /// después por el flujo de compras. Devuelve un mensaje de error o null.
  Future<String?> purchase(PremiumPlan plan) async {
    if (_busy) {
      return null;
    }
    final ProductDetails? details = switch (plan) {
      PremiumPlan.yearly => _yearly,
      PremiumPlan.lifetime => _lifetime,
      PremiumPlan.none => null,
    };
    if (details == null) {
      return tr('Esta compra no está disponible ahora mismo.', 'This purchase is not available right now.');
    }

    _busy = true;
    _message = null;
    _notify();
    // La ventana de Google Play saca a la app a segundo plano: que al volver no
    // pida la huella de nuevo.
    ExternalActivityGuard.allowFor(_purchaseWindow);
    _busyTimer?.cancel();
    _busyTimer = Timer(_purchaseWindow, _finishPurchaseAttempt);

    try {
      final bool started = await _store.buyNonConsumable(
        purchaseParam: PurchaseParam(productDetails: details),
      );
      if (!started) {
        _finishPurchaseAttempt();
        return tr('No se pudo iniciar la compra.', 'The purchase could not be started.');
      }
      return null;
    } catch (error) {
      debugPrint('Gonen: error al iniciar la compra: $error');
      _finishPurchaseAttempt();
      return tr('No se pudo iniciar la compra.', 'The purchase could not be started.');
    }
  }

  /// Pide a Google Play las compras anteriores de esta cuenta. Si hay alguna
  /// activa, se recupera por el flujo de compras. Devuelve un error o null.
  Future<String?> restorePurchases() async {
    if (!_storeAvailable) {
      return tr('Google Play no está disponible en este dispositivo.', 'Google Play is not available on this device.');
    }
    try {
      await _store.restorePurchases();
      return null;
    } catch (error) {
      debugPrint('Gonen: error al restaurar compras: $error');
      return tr('No se pudo consultar Google Play.', 'Google Play could not be reached.');
    }
  }

  void _finishPurchaseAttempt() {
    _busyTimer?.cancel();
    _busyTimer = null;
    _busy = false;
    ExternalActivityGuard.clear();
    _notify();
  }

  Future<void> _onPurchases(List<PurchaseDetails> purchases) async {
    bool anyPending = false;

    for (final PurchaseDetails purchase in purchases) {
      if (!_productIds.contains(purchase.productID)) {
        continue;
      }

      final PurchaseStatus status = purchase.status;
      if (status == PurchaseStatus.pending) {
        anyPending = true;
        continue;
      }

      if (status == PurchaseStatus.purchased ||
          status == PurchaseStatus.restored) {
        await _grant(
          purchase.productID == lifetimeProductId
              ? PremiumPlan.lifetime
              : PremiumPlan.yearly,
          announce: status == PurchaseStatus.purchased,
        );
      } else if (status == PurchaseStatus.error) {
        debugPrint('Gonen: la compra falló: ${purchase.error?.message}');
        _message = tr(
          'No se pudo completar la compra. No se te ha cobrado nada.',
          'The purchase could not be completed. You have not been charged.',
        );
      }
      // Cancelada por el usuario: no hace falta avisar de nada.

      // Si no se confirma la compra a Google Play en 3 días, la devuelve sola.
      if (purchase.pendingCompletePurchase) {
        try {
          await _store.completePurchase(purchase);
        } catch (error) {
          debugPrint('Gonen: no se pudo confirmar la compra: $error');
        }
      }
    }

    _busy = anyPending;
    if (!anyPending) {
      _busyTimer?.cancel();
      _busyTimer = null;
      ExternalActivityGuard.clear();
    }
    _notify();
  }

  Future<void> _grant(PremiumPlan plan, {required bool announce}) async {
    // Un pago único no se degrada porque Play también devuelva una suscripción.
    if (_entitlement.plan == PremiumPlan.lifetime &&
        plan == PremiumPlan.yearly) {
      return;
    }
    _entitlement = PremiumEntitlement(plan: plan, verifiedAt: _clock());
    if (announce) {
      _message = tr(
        'Gonen Premium está activo. ¡Gracias por apoyar la app!',
        'Gonen Premium is active. Thank you for supporting the app!',
      );
    }
    await _saveCache();
  }

  void _notify() {
    if (!_disposed) {
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _busyTimer?.cancel();
    unawaited(_purchaseSubscription?.cancel());
    super.dispose();
  }
}
