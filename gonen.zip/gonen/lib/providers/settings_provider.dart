import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../l10n/tr.dart';
import '../models/diary_limits.dart';
import '../services/biometric_service.dart';
import '../services/notification_service.dart';
import '../theme/app_style.dart';

/// Ajustes de la app: años anteriores visibles, bloqueo biométrico,
/// recordatorio diario, aspecto (estilo y claro/oscuro) e idioma.
///
/// Los métodos que pueden fallar devuelven un mensaje de error en español
/// listo para mostrar, o null si todo ha ido bien.
class SettingsProvider extends ChangeNotifier {
  SettingsProvider({
    required BiometricService biometricService,
    NotificationService? notificationService,
  })  : _biometric = biometricService,
        _notifications = notificationService ?? NotificationService.instance;

  static const String _biometricKey = 'biometric_enabled';
  static const String _reminderEnabledKey = 'reminder_enabled';
  static const String _reminderHourKey = 'reminder_hour';
  static const String _reminderMinuteKey = 'reminder_minute';
  static const String _themeModeKey = 'theme_mode';
  static const String _styleKey = 'app_style';
  static const String _languageKey = 'app_language';
  static const String _yearsBackKey = 'years_back';

  final BiometricService _biometric;
  final NotificationService _notifications;
  SharedPreferences? _prefs;

  int _yearsBack = DiaryLimits.defaultYearsBack;
  bool _biometricEnabled = false;
  bool _reminderEnabled = false;
  TimeOfDay _reminderTime = const TimeOfDay(hour: 21, minute: 0);
  ThemeMode _themeMode = ThemeMode.system;
  AppStyle _style = AppStyle.defaultStyle;
  AppLanguage _language = AppLanguage.es;
  bool _notificationsBlocked = false;
  bool _refreshingReminder = false;

  /// Cuántos años anteriores al actual se enseñan en la pantalla de inicio.
  int get yearsBack => _yearsBack;
  bool get biometricEnabled => _biometricEnabled;
  bool get reminderEnabled => _reminderEnabled;
  TimeOfDay get reminderTime => _reminderTime;
  ThemeMode get themeMode => _themeMode;

  /// Aspecto elegido: editorial japonesa (por defecto) o hilo rojo.
  AppStyle get style => _style;

  /// Idioma de la app (español por defecto).
  AppLanguage get language => _language;

  /// El recordatorio está activado, pero Android no deja mostrar las
  /// notificaciones de Gonen (permiso denegado o avisos de la app apagados en
  /// los ajustes del sistema). Ajustes lo explica y dice dónde activarlas.
  bool get notificationsBlocked => _reminderEnabled && _notificationsBlocked;

  /// Lee los ajustes guardados. Nunca lanza excepciones: si algo falla, se
  /// usan los valores por defecto. No toca las notificaciones: eso lo hace
  /// [refreshReminder], que se lanza aparte para no retrasar el arranque.
  Future<void> load() async {
    try {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      _prefs = prefs;
      _yearsBack = DiaryLimits.clampYearsBack(
        prefs.getInt(_yearsBackKey) ?? DiaryLimits.defaultYearsBack,
      );
      _biometricEnabled = prefs.getBool(_biometricKey) ?? false;
      _reminderEnabled = prefs.getBool(_reminderEnabledKey) ?? false;
      _reminderTime = TimeOfDay(
        hour: prefs.getInt(_reminderHourKey) ?? 21,
        minute: prefs.getInt(_reminderMinuteKey) ?? 0,
      );
      final int themeIndex = prefs.getInt(_themeModeKey) ?? ThemeMode.system.index;
      if (themeIndex >= 0 && themeIndex < ThemeMode.values.length) {
        _themeMode = ThemeMode.values[themeIndex];
      }
      _style = AppStyle.fromStorageId(prefs.getString(_styleKey));
      _language = AppLanguage.fromCode(prefs.getString(_languageKey));
    } catch (error) {
      debugPrint('Gonen: no se pudieron leer los ajustes: $error');
    }
    AppLocale.current = _language;
  }

  /// Vuelve a programar el recordatorio diario (si está activado) y comprueba
  /// que Android deja mostrarlo. Se llama al arrancar y cada vez que se vuelve
  /// a la app: así se recupera el aviso si el sistema lo ha perdido, si ha
  /// cambiado la zona horaria o si el usuario acaba de activar los permisos.
  /// Nunca lanza excepciones.
  Future<void> refreshReminder() async {
    if (!_reminderEnabled) {
      _setNotificationsBlocked(false);
      return;
    }
    if (_refreshingReminder) {
      return;
    }
    _refreshingReminder = true;
    try {
      await _notifications.scheduleDailyReminder(_reminderTime);
    } catch (error) {
      debugPrint('Gonen: no se pudo reprogramar el recordatorio: $error');
    }
    try {
      _setNotificationsBlocked(!await _notifications.areNotificationsEnabled());
    } catch (error) {
      debugPrint('Gonen: no se pudo comprobar los avisos: $error');
    } finally {
      _refreshingReminder = false;
    }
  }

  void _setNotificationsBlocked(bool blocked) {
    if (blocked == _notificationsBlocked) {
      return;
    }
    _notificationsBlocked = blocked;
    notifyListeners();
  }


  // ---------------------------------------------------------------------------
  // Pantalla de inicio
  // ---------------------------------------------------------------------------

  /// Cambia cuántos años anteriores se enseñan. Reducirlo solo oculta tarjetas:
  /// las entradas antiguas siguen guardadas.
  Future<void> setYearsBack(int value) async {
    final int next = DiaryLimits.clampYearsBack(value);
    if (next == _yearsBack) {
      return;
    }
    _yearsBack = next;
    notifyListeners();
    try {
      await _prefs?.setInt(_yearsBackKey, next);
    } catch (error) {
      debugPrint('Gonen: no se pudo guardar el número de años: $error');
    }
  }

  // ---------------------------------------------------------------------------
  // Seguridad biométrica
  // ---------------------------------------------------------------------------

  /// Activa o desactiva el bloqueo. En ambos casos se pide identificarse antes.
  Future<String?> setBiometricEnabled(bool enabled) async {
    if (enabled == _biometricEnabled) {
      return null;
    }

    final bool available = await _biometric.isAvailable();
    if (!available) {
      if (enabled) {
        return tr(
          'Este dispositivo no tiene huella, rostro ni bloqueo de pantalla '
              'configurados. Actívalos en los ajustes del sistema.',
          'This device has no fingerprint, face unlock or screen lock set up. '
              'Turn one on in the system settings.',
        );
      }
      // Si ya no hay forma de autenticar, se permite desactivar sin más.
      await _storeBiometric(false);
      return null;
    }

    final bool verified = await _biometric.authenticate(
      reason: enabled
          ? tr(
              'Confirma tu identidad para activar el bloqueo de Gonen',
              'Confirm your identity to turn on the Gonen lock',
            )
          : tr(
              'Confirma tu identidad para desactivar el bloqueo de Gonen',
              'Confirm your identity to turn off the Gonen lock',
            ),
    );
    if (!verified) {
      return tr(
        'No se pudo verificar tu identidad.',
        'Your identity could not be verified.',
      );
    }

    await _storeBiometric(enabled);
    return null;
  }

  /// Desactiva el bloqueo sin pedir autenticación. Solo lo usa la pantalla de
  /// bloqueo cuando el dispositivo ya no puede autenticar a nadie, para que el
  /// diario no quede inaccesible.
  Future<void> disableBiometricWithoutPrompt() => _storeBiometric(false);

  Future<void> _storeBiometric(bool enabled) async {
    _biometricEnabled = enabled;
    await _prefs?.setBool(_biometricKey, enabled);
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Recordatorio diario
  // ---------------------------------------------------------------------------

  Future<String?> setReminderEnabled(bool enabled) async {
    if (enabled == _reminderEnabled) {
      return null;
    }
    try {
      if (enabled) {
        final bool granted = await _notifications.requestPermission();
        if (!granted) {
          return tr(
            'Permite las notificaciones de Gonen en los ajustes del '
                'sistema para recibir el recordatorio.',
            'Allow Gonen notifications in the system settings to receive '
                'the reminder.',
          );
        }
        await _notifications.scheduleDailyReminder(_reminderTime);
      } else {
        await _notifications.cancelDailyReminder();
      }
    } catch (error) {
      debugPrint('Gonen: error con el recordatorio: $error');
      return tr(
        'No se pudo programar el recordatorio.',
        'The reminder could not be scheduled.',
      );
    }

    _reminderEnabled = enabled;
    // El permiso se acaba de conceder (o el recordatorio se ha apagado).
    _notificationsBlocked = false;
    await _prefs?.setBool(_reminderEnabledKey, enabled);
    notifyListeners();
    return null;
  }

  Future<String?> setReminderTime(TimeOfDay time) async {
    if (_reminderEnabled) {
      try {
        await _notifications.scheduleDailyReminder(time);
      } catch (error) {
        debugPrint('Gonen: error al cambiar la hora: $error');
        return tr(
          'No se pudo cambiar la hora del recordatorio.',
          'The reminder time could not be changed.',
        );
      }
    }

    _reminderTime = time;
    await _prefs?.setInt(_reminderHourKey, time.hour);
    await _prefs?.setInt(_reminderMinuteKey, time.minute);
    notifyListeners();
    return null;
  }

  // ---------------------------------------------------------------------------
  // Apariencia
  // ---------------------------------------------------------------------------

  Future<void> setThemeMode(ThemeMode mode) async {
    if (mode == _themeMode) {
      return;
    }
    _themeMode = mode;
    await _prefs?.setInt(_themeModeKey, mode.index);
    notifyListeners();
  }

  /// Cambia el aspecto de la app (colores, tipografías y forma del inicio).
  Future<void> setStyle(AppStyle style) async {
    if (style == _style) {
      return;
    }
    _style = style;
    notifyListeners();
    try {
      await _prefs?.setString(_styleKey, style.storageId);
    } catch (error) {
      debugPrint('Gonen: no se pudo guardar el estilo: $error');
    }
  }

  // ---------------------------------------------------------------------------
  // Idioma
  // ---------------------------------------------------------------------------

  /// Cambia el idioma de la app. El aviso diario ya programado se vuelve a
  /// programar para que salga en el idioma nuevo.
  Future<void> setLanguage(AppLanguage language) async {
    if (language == _language) {
      return;
    }
    _language = language;
    // Antes de avisar a los widgets, para que al redibujarse ya lean el idioma
    // nuevo también desde el código que no tiene BuildContext.
    AppLocale.current = language;
    notifyListeners();
    try {
      await _prefs?.setString(_languageKey, language.code);
    } catch (error) {
      debugPrint('Gonen: no se pudo guardar el idioma: $error');
    }
    if (_reminderEnabled) {
      try {
        await _notifications.scheduleDailyReminder(_reminderTime);
      } catch (error) {
        debugPrint('Gonen: no se pudo reprogramar el recordatorio: $error');
      }
    }
  }
}
