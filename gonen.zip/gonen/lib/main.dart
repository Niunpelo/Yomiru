import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:provider/provider.dart';

import 'providers/capsules_provider.dart';
import 'providers/diary_provider.dart';
import 'providers/settings_provider.dart';
import 'screens/home_screen.dart';
import 'services/biometric_service.dart';
import 'theme/app_theme.dart';
import 'widgets/app_lock_gate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('es');

  final BiometricService biometric = BiometricService();
  final SettingsProvider settings = SettingsProvider(biometricService: biometric);
  // Se cargan antes de dibujar nada para saber si hay que arrancar bloqueada.
  await settings.load();

  runApp(GonenApp(biometric: biometric, settings: settings));
}

class GonenApp extends StatelessWidget {
  const GonenApp({
    super.key,
    required this.biometric,
    required this.settings,
  });

  final BiometricService biometric;
  final SettingsProvider settings;

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<BiometricService>.value(value: biometric),
        ChangeNotifierProvider<SettingsProvider>.value(value: settings),
        // El diario depende del ajuste "años anteriores": cuando cambia, se
        // actualiza el mismo DiaryProvider en lugar de crear otro.
        ChangeNotifierProxyProvider<SettingsProvider, DiaryProvider>(
          create: (_) => DiaryProvider(yearsBack: settings.yearsBack),
          update: (
            BuildContext context,
            SettingsProvider current,
            DiaryProvider? previous,
          ) {
            final DiaryProvider diary =
                previous ?? DiaryProvider(yearsBack: current.yearsBack);
            diary.applyYearsBack(current.yearsBack);
            return diary;
          },
        ),
        ChangeNotifierProvider<CapsulesProvider>(
          create: (_) => CapsulesProvider(),
        ),
      ],
      child: const _GonenMaterialApp(),
    );
  }
}

class _GonenMaterialApp extends StatelessWidget {
  const _GonenMaterialApp();

  @override
  Widget build(BuildContext context) {
    final ThemeMode themeMode =
        context.select<SettingsProvider, ThemeMode>((SettingsProvider s) => s.themeMode);

    return MaterialApp(
      title: 'Gonen',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: themeMode,
      locale: const Locale('es'),
      supportedLocales: const <Locale>[Locale('es')],
      localizationsDelegates: const <LocalizationsDelegate<dynamic>>[
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (BuildContext context, Widget? child) {
        return AppLockGate(child: child ?? const SizedBox.shrink());
      },
      home: const HomeScreen(),
    );
  }
}
