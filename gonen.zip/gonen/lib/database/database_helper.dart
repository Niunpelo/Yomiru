import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/attachment_model.dart';
import '../models/backup_snapshot.dart';
import '../models/capsule_model.dart';
import '../models/entry_model.dart';

/// Acceso a la base de datos SQLite local donde viven las entradas del diario,
/// las cápsulas del tiempo y los datos de las fotos y notas de voz adjuntas.
class DatabaseHelper {
  DatabaseHelper._internal();

  /// Instancia única compartida por toda la aplicación.
  static final DatabaseHelper instance = DatabaseHelper._internal();

  static const String _databaseName = 'gonen.db';

  /// Versión 1: tabla de entradas. Versión 2: añade la tabla de cápsulas.
  /// Versión 3: añade la tabla de adjuntos (fotos y notas de voz).
  /// Versión 4: los adjuntos pueden pertenecer a una cápsula (`capsule_id`).
  /// Versión 5: las cápsulas pueden enviarse a otra persona o recibirse de
  /// ella (`sender`, `recipient` y `uid`).
  /// Versión 6: las cápsulas pueden ocultar su título (`hide_title`).
  static const int _databaseVersion = 6;

  static const String tableEntries = 'entries';
  static const String tableCapsules = 'capsules';
  static const String tableAttachments = 'attachments';

  Database? _database;
  Future<Database>? _opening;

  /// Base de datos abierta. La primera vez que se pide, se crea o se abre el archivo.
  Future<Database> get database {
    final Database? existing = _database;
    if (existing != null) {
      return Future<Database>.value(existing);
    }
    return _opening ??= _open();
  }

  Future<Database> _open() async {
    try {
      final String directory = await getDatabasesPath();
      final String path = p.join(directory, _databaseName);
      final Database db = await openDatabase(
        path,
        version: _databaseVersion,
        onCreate: _onCreate,
        onUpgrade: _onUpgrade,
      );
      _database = db;
      return db;
    } catch (_) {
      // Si falla, la próxima llamada vuelve a intentarlo desde cero.
      _opening = null;
      rethrow;
    }
  }

  Future<void> _onCreate(Database db, int version) async {
    await _createEntriesTable(db);
    await _createCapsulesTable(db);
    await _createAttachmentsTable(db);
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      // La tabla nueva ya incluye las columnas de las versiones siguientes.
      await _createCapsulesTable(db);
    } else if (oldVersion < 5) {
      await db.execute('ALTER TABLE $tableCapsules ADD COLUMN sender TEXT');
      await db.execute('ALTER TABLE $tableCapsules ADD COLUMN recipient TEXT');
      await db.execute('ALTER TABLE $tableCapsules ADD COLUMN uid TEXT');
      await db.execute('''
        CREATE INDEX IF NOT EXISTS idx_capsules_uid
        ON $tableCapsules (uid)
      ''');
    }
    if (oldVersion >= 2 && oldVersion < 6) {
      // Si la tabla se acaba de crear arriba (versión 1), ya trae la columna.
      await db.execute(
        'ALTER TABLE $tableCapsules '
        'ADD COLUMN hide_title INTEGER NOT NULL DEFAULT 0',
      );
    }
    if (oldVersion < 3) {
      // La tabla nueva ya incluye la columna capsule_id.
      await _createAttachmentsTable(db);
    } else if (oldVersion < 4) {
      await db.execute(
        'ALTER TABLE $tableAttachments ADD COLUMN capsule_id INTEGER',
      );
      await db.execute('''
        CREATE INDEX IF NOT EXISTS idx_attachments_capsule
        ON $tableAttachments (capsule_id)
      ''');
    }
  }

  Future<void> _createAttachmentsTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $tableAttachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        day_of_year TEXT NOT NULL,
        year INTEGER NOT NULL,
        type TEXT NOT NULL,
        file_path TEXT NOT NULL,
        duration_ms INTEGER,
        created_at INTEGER NOT NULL,
        capsule_id INTEGER
      )
    ''');
    await db.execute('''
      CREATE INDEX IF NOT EXISTS idx_attachments_day
      ON $tableAttachments (day_of_year, year)
    ''');
    await db.execute('''
      CREATE INDEX IF NOT EXISTS idx_attachments_capsule
      ON $tableAttachments (capsule_id)
    ''');
  }

  Future<void> _createEntriesTable(Database db) async {
    await db.execute('''
      CREATE TABLE $tableEntries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        day_of_year TEXT NOT NULL,
        year INTEGER NOT NULL,
        content TEXT NOT NULL,
        updated_at INTEGER NOT NULL,
        UNIQUE (day_of_year, year)
      )
    ''');
  }

  Future<void> _createCapsulesTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $tableCapsules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        open_date TEXT NOT NULL,
        opened_at INTEGER,
        sender TEXT,
        recipient TEXT,
        uid TEXT,
        hide_title INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE INDEX IF NOT EXISTS idx_capsules_uid
      ON $tableCapsules (uid)
    ''');
  }

  // ---------------------------------------------------------------------------
  // Entradas del diario
  // ---------------------------------------------------------------------------

  /// Entrada de un día y un año concretos, o null si no existe.
  Future<Entry?> getEntry({
    required String dayOfYear,
    required int year,
  }) async {
    final Database db = await database;
    final List<Map<String, Object?>> rows = await db.query(
      tableEntries,
      where: 'day_of_year = ? AND year = ?',
      whereArgs: <Object?>[dayOfYear, year],
      limit: 1,
    );
    if (rows.isEmpty) {
      return null;
    }
    return Entry.fromMap(rows.first);
  }

  /// Todas las entradas de un día del año ("MM-DD"), de la más reciente a la más antigua.
  ///
  /// Si se indican [fromYear] y [toYear] solo se devuelven los años de ese
  /// rango, ambos incluidos.
  Future<List<Entry>> getEntriesForDay(
    String dayOfYear, {
    int? fromYear,
    int? toYear,
  }) async {
    final Database db = await database;

    final StringBuffer where = StringBuffer('day_of_year = ?');
    final List<Object?> args = <Object?>[dayOfYear];
    if (fromYear != null) {
      where.write(' AND year >= ?');
      args.add(fromYear);
    }
    if (toYear != null) {
      where.write(' AND year <= ?');
      args.add(toYear);
    }

    final List<Map<String, Object?>> rows = await db.query(
      tableEntries,
      where: where.toString(),
      whereArgs: args,
      orderBy: 'year DESC',
    );
    return rows.map(Entry.fromMap).toList();
  }

  /// Años que tienen una entrada guardada para ese día, de más reciente a más antiguo.
  Future<List<int>> getYearsWithEntries(String dayOfYear) async {
    final Database db = await database;
    final List<Map<String, Object?>> rows = await db.query(
      tableEntries,
      columns: <String>['year'],
      where: 'day_of_year = ?',
      whereArgs: <Object?>[dayOfYear],
      orderBy: 'year DESC',
    );
    return rows.map((Map<String, Object?> row) => row['year']! as int).toList();
  }

  /// Guarda o actualiza la entrada de [dayOfYear] y [year].
  ///
  /// * Si ya existía, se actualiza su texto y su fecha de modificación.
  /// * Si no existía, se crea.
  /// * Si [content] está vacío, se borra la entrada existente (si la hay) y
  ///   se devuelve null, de modo que ese año vuelve a mostrarse como "sin entrada".
  ///
  /// Devuelve la entrada resultante, o null si no queda ninguna.
  Future<Entry?> saveEntry({
    required String dayOfYear,
    required int year,
    required String content,
    DateTime? now,
  }) async {
    final Database db = await database;
    final DateTime timestamp = now ?? DateTime.now();
    final bool blank = content.trim().isEmpty;

    return db.transaction<Entry?>((Transaction txn) async {
      final List<Map<String, Object?>> rows = await txn.query(
        tableEntries,
        where: 'day_of_year = ? AND year = ?',
        whereArgs: <Object?>[dayOfYear, year],
        limit: 1,
      );

      if (rows.isNotEmpty) {
        final Entry existing = Entry.fromMap(rows.first);
        if (blank) {
          await txn.delete(
            tableEntries,
            where: 'id = ?',
            whereArgs: <Object?>[existing.id],
          );
          return null;
        }
        if (existing.content == content) {
          return existing;
        }
        final Entry updated = existing.copyWith(
          content: content,
          updatedAt: timestamp,
        );
        await txn.update(
          tableEntries,
          updated.toMap(),
          where: 'id = ?',
          whereArgs: <Object?>[existing.id],
        );
        return updated;
      }

      if (blank) {
        return null;
      }

      final Entry created = Entry(
        dayOfYear: dayOfYear,
        year: year,
        content: content,
        updatedAt: timestamp,
      );
      final int id = await txn.insert(tableEntries, created.toMap());
      return created.copyWith(id: id);
    });
  }

  /// Borra la entrada de un día y un año concretos.
  Future<void> deleteEntry({
    required String dayOfYear,
    required int year,
  }) async {
    final Database db = await database;
    await db.delete(
      tableEntries,
      where: 'day_of_year = ? AND year = ?',
      whereArgs: <Object?>[dayOfYear, year],
    );
  }

  // ---------------------------------------------------------------------------
  // Cápsulas del tiempo
  // ---------------------------------------------------------------------------

  /// Todas las cápsulas, ordenadas por fecha de apertura.
  Future<List<Capsule>> getCapsules() async {
    final Database db = await database;
    final List<Map<String, Object?>> rows = await db.query(
      tableCapsules,
      orderBy: 'open_date ASC, id ASC',
    );
    return rows.map(Capsule.fromMap).toList();
  }

  /// Guarda una cápsula nueva y la devuelve con su identificador.
  Future<Capsule> insertCapsule(Capsule capsule) async {
    final Database db = await database;
    final int id = await db.insert(tableCapsules, capsule.toMap());
    return capsule.copyWith(id: id);
  }

  /// Verdadero si ya hay una cápsula con ese identificador único (enviada o
  /// recibida), para no guardar dos veces la misma.
  Future<bool> hasCapsuleUid(String uid) async {
    final Database db = await database;
    final List<Map<String, Object?>> rows = await db.query(
      tableCapsules,
      columns: <String>['id'],
      where: 'uid = ?',
      whereArgs: <Object?>[uid],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  /// Anota el momento en que se abrió una cápsula.
  Future<void> markCapsuleOpened(int id, DateTime openedAt) async {
    final Database db = await database;
    await db.update(
      tableCapsules,
      <String, Object?>{'opened_at': openedAt.millisecondsSinceEpoch},
      where: 'id = ?',
      whereArgs: <Object?>[id],
    );
  }

  /// Borra una cápsula y los datos de sus fotos y notas de voz (los archivos
  /// se borran aparte).
  Future<void> deleteCapsule(int id) async {
    final Database db = await database;
    await db.transaction<void>((Transaction txn) async {
      await txn.delete(
        tableAttachments,
        where: 'capsule_id = ?',
        whereArgs: <Object?>[id],
      );
      await txn.delete(
        tableCapsules,
        where: 'id = ?',
        whereArgs: <Object?>[id],
      );
    });
  }

  /// Guarda una cápsula nueva junto con sus fotos y notas de voz, todo o nada.
  /// Devuelve la cápsula y los adjuntos ya con su identificador.
  Future<({Capsule capsule, List<Attachment> attachments})>
      insertCapsuleWithAttachments(
    Capsule capsule,
    List<Attachment> attachments,
  ) async {
    final Database db = await database;
    return db.transaction<({Capsule capsule, List<Attachment> attachments})>(
      (Transaction txn) async {
        final int capsuleId = await txn.insert(tableCapsules, capsule.toMap());
        final List<Attachment> saved = <Attachment>[];
        for (final Attachment attachment in attachments) {
          final Attachment linked = Attachment.forCapsule(
            capsuleId: capsuleId,
            type: attachment.type,
            relativePath: attachment.relativePath,
            durationMs: attachment.durationMs,
            createdAt: attachment.createdAt,
          );
          final int id = await txn.insert(tableAttachments, linked.toMap());
          saved.add(linked.copyWith(id: id));
        }
        return (capsule: capsule.copyWith(id: capsuleId), attachments: saved);
      },
    );
  }

  // ---------------------------------------------------------------------------
  // Adjuntos (fotos y notas de voz)
  // ---------------------------------------------------------------------------

  /// Adjuntos de un día del año ("MM-DD") en un rango de años, ambos incluidos.
  /// Salen ordenados por año (el más reciente primero) y por orden de creación.
  Future<List<Attachment>> getAttachmentsForDay(
    String dayOfYear, {
    required int fromYear,
    required int toYear,
  }) async {
    final Database db = await database;
    final List<Map<String, Object?>> rows = await db.query(
      tableAttachments,
      where: 'capsule_id IS NULL AND day_of_year = ? '
          'AND year >= ? AND year <= ?',
      whereArgs: <Object?>[dayOfYear, fromYear, toYear],
      orderBy: 'year DESC, created_at ASC, id ASC',
    );
    return rows.map(Attachment.fromMap).toList();
  }

  /// Guarda un adjunto nuevo y lo devuelve con su identificador.
  Future<Attachment> insertAttachment(Attachment attachment) async {
    final Database db = await database;
    final int id = await db.insert(tableAttachments, attachment.toMap());
    return attachment.copyWith(id: id);
  }

  /// Borra un adjunto de la base de datos (el archivo se borra aparte).
  Future<void> deleteAttachment(int id) async {
    final Database db = await database;
    await db.delete(
      tableAttachments,
      where: 'id = ?',
      whereArgs: <Object?>[id],
    );
  }

  /// Fotos y notas de voz de todas las cápsulas, por orden de creación.
  Future<List<Attachment>> getCapsuleAttachments() async {
    final Database db = await database;
    final List<Map<String, Object?>> rows = await db.query(
      tableAttachments,
      where: 'capsule_id IS NOT NULL',
      orderBy: 'created_at ASC, id ASC',
    );
    return rows.map(Attachment.fromMap).toList();
  }

  // ---------------------------------------------------------------------------
  // Calendario, búsqueda y copias de seguridad
  // ---------------------------------------------------------------------------

  /// Todas las entradas del diario, de la más antigua a la más reciente.
  Future<List<Entry>> getAllEntries() async {
    final Database db = await database;
    final List<Map<String, Object?>> rows = await db.query(
      tableEntries,
      orderBy: 'year ASC, day_of_year ASC',
    );
    return rows.map(Entry.fromMap).toList();
  }

  /// Todos los adjuntos, tanto de días como de cápsulas.
  Future<List<Attachment>> getAllAttachments() async {
    final Database db = await database;
    final List<Map<String, Object?>> rows = await db.query(
      tableAttachments,
      orderBy: 'created_at ASC, id ASC',
    );
    return rows.map(Attachment.fromMap).toList();
  }

  /// Días (sin hora) en los que se escribió algo o se adjuntó una foto o una
  /// nota de voz. Sirve para el calendario y las rachas.
  Future<Set<DateTime>> getWrittenDays() async {
    final Database db = await database;
    final List<Map<String, Object?>> rows = await db.rawQuery(
      'SELECT year, day_of_year FROM $tableEntries '
      'UNION '
      'SELECT year, day_of_year FROM $tableAttachments '
      'WHERE capsule_id IS NULL',
    );

    final Set<DateTime> days = <DateTime>{};
    for (final Map<String, Object?> row in rows) {
      final int? year = row['year'] as int?;
      final String? key = row['day_of_year'] as String?;
      if (year == null || key == null || key.length != 5) {
        continue;
      }
      final int? month = int.tryParse(key.substring(0, 2));
      final int? day = int.tryParse(key.substring(3, 5));
      if (month == null || day == null) {
        continue;
      }
      final DateTime date = DateTime(year, month, day);
      // El 29 de febrero de un año no bisiesto pasaría al 1 de marzo.
      if (date.month == month) {
        days.add(date);
      }
    }
    return days;
  }

  /// Añade a esta base de datos lo que haya en [snapshot] y todavía no esté.
  ///
  /// Nunca borra ni sobrescribe nada de lo que ya hay:
  /// * una entrada del mismo día y año se conserva como estaba;
  /// * una cápsula idéntica (mismo texto, fechas y título) no se duplica;
  /// * un adjunto con la misma ruta de archivo no se duplica.
  Future<BackupMergeResult> mergeSnapshot(BackupSnapshot snapshot) async {
    final Database db = await database;
    return db.transaction<BackupMergeResult>((Transaction txn) async {
      int entriesAdded = 0;
      int entriesKept = 0;
      int capsulesAdded = 0;
      int attachmentsAdded = 0;

      for (final Entry entry in snapshot.entries) {
        if (entry.isBlank) {
          continue;
        }
        final List<Map<String, Object?>> rows = await txn.query(
          tableEntries,
          where: 'day_of_year = ? AND year = ?',
          whereArgs: <Object?>[entry.dayOfYear, entry.year],
          limit: 1,
        );
        if (rows.isEmpty) {
          final Map<String, Object?> values = entry.toMap()..remove('id');
          await txn.insert(tableEntries, values);
          entriesAdded++;
        } else if ((rows.first['content'] as String?) != entry.content) {
          entriesKept++;
        }
      }

      // Identificador que tenía cada cápsula en la copia -> el que tiene aquí.
      final Map<int, int> capsuleIds = <int, int>{};
      for (final Capsule capsule in snapshot.capsules) {
        final List<Map<String, Object?>> rows = await txn.query(
          tableCapsules,
          columns: <String>['id'],
          where: 'created_at = ? AND open_date = ? AND title = ? AND content = ?',
          whereArgs: <Object?>[
            capsule.createdAt.millisecondsSinceEpoch,
            Capsule.dateKey(capsule.openDate),
            capsule.title,
            capsule.content,
          ],
          limit: 1,
        );
        final int newId;
        if (rows.isEmpty) {
          final Map<String, Object?> values = capsule.toMap()..remove('id');
          newId = await txn.insert(tableCapsules, values);
          capsulesAdded++;
        } else {
          newId = rows.first['id']! as int;
        }
        final int? oldId = capsule.id;
        if (oldId != null) {
          capsuleIds[oldId] = newId;
        }
      }

      for (final Attachment attachment in snapshot.attachments) {
        final List<Map<String, Object?>> existing = await txn.query(
          tableAttachments,
          columns: <String>['id'],
          where: 'file_path = ?',
          whereArgs: <Object?>[attachment.relativePath],
          limit: 1,
        );
        if (existing.isNotEmpty) {
          continue;
        }
        final Map<String, Object?> values = attachment.toMap()..remove('id');
        final int? oldCapsuleId = attachment.capsuleId;
        if (oldCapsuleId != null) {
          final int? newCapsuleId = capsuleIds[oldCapsuleId];
          if (newCapsuleId == null) {
            continue;
          }
          values['capsule_id'] = newCapsuleId;
        }
        await txn.insert(tableAttachments, values);
        attachmentsAdded++;
      }

      return BackupMergeResult(
        entriesAdded: entriesAdded,
        entriesKept: entriesKept,
        capsulesAdded: capsulesAdded,
        attachmentsAdded: attachmentsAdded,
      );
    });
  }

  /// Cierra la base de datos. Solo hace falta en pruebas.
  Future<void> close() async {
    final Database? db = _database;
    _database = null;
    _opening = null;
    if (db != null) {
      await db.close();
    }
  }
}
