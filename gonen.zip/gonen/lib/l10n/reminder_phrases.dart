/// Frases del aviso diario para escribir en el diario.
///
/// Cada día sale una distinta, para que el aviso no sea siempre el mismo. La
/// frase de un día concreto es siempre la misma (depende solo de la fecha), así
/// que reprogramar los avisos no la cambia.
class ReminderPhrases {
  const ReminderPhrases._();

  /// Todas las frases, en español y en inglés. La primera es la de siempre.
  static const List<({String es, String en})> all = <({String es, String en})>[
    (
      es: '¿Qué ha pasado hoy? Escribe tu entrada del diario.',
      en: 'What happened today? Write your diary entry.',
    ),
    (
      es: 'Un minuto para ti: cuéntale a tu diario cómo ha ido el día.',
      en: 'One minute for you: tell your diary how the day went.',
    ),
    (
      es: 'Hoy también merece quedarse escrito.',
      en: 'Today deserves to be written down too.',
    ),
    (
      es: '¿Qué es lo que más te ha gustado de hoy?',
      en: 'What did you like most about today?',
    ),
    (
      es: 'Tu yo del futuro querrá recordar este día. Escríbelo.',
      en: 'Your future self will want to remember today. Write it down.',
    ),
    (
      es: '¿Hay algo de hoy que no quieras olvidar?',
      en: 'Is there something from today you do not want to forget?',
    ),
    (
      es: 'Cierra el día con unas líneas en Gonen.',
      en: 'Close the day with a few lines in Gonen.',
    ),
    (
      es: 'Cuéntale a Gonen una cosa buena de hoy.',
      en: 'Tell Gonen one good thing about today.',
    ),
    (
      es: '¿Con quién has hablado hoy? ¿Qué te han contado?',
      en: 'Who did you talk to today? What did they tell you?',
    ),
    (
      es: 'Una frase basta. ¿Cómo ha sido tu día?',
      en: 'One sentence is enough. How was your day?',
    ),
    (
      es: '¿Qué has aprendido hoy?',
      en: 'What did you learn today?',
    ),
    (
      es: 'Los días pasan rápido. Guarda este en tu diario.',
      en: 'Days go by fast. Keep this one in your diary.',
    ),
    (
      es: '¿Cómo te sientes ahora mismo? Ponlo por escrito.',
      en: 'How do you feel right now? Put it in writing.',
    ),
    (
      es: 'Hoy es un día de tu historia. ¿Lo anotas?',
      en: 'Today is a day of your story. Will you note it down?',
    ),
    (
      es: 'Antes de acabar el día: ¿qué ha sido lo más importante?',
      en: 'Before the day ends: what was the most important thing?',
    ),
    (
      es: '¿Qué te ha hecho sonreír hoy?',
      en: 'What made you smile today?',
    ),
    (
      es: 'Tu diario te espera. ¿Qué tal ha ido el día?',
      en: 'Your diary is waiting. How did the day go?',
    ),
    (
      es: 'Dentro de un año te alegrarás de haber escrito hoy.',
      en: 'In a year you will be glad you wrote today.',
    ),
    (
      es: '¿Qué ha sido lo más difícil de hoy? ¿Y lo mejor?',
      en: 'What was the hardest part of today? And the best?',
    ),
    (
      es: 'Respira, repasa el día y escríbelo.',
      en: 'Breathe, go over your day and write it down.',
    ),
    (
      es: 'Un momento de calma: apunta cómo ha ido hoy.',
      en: 'A moment of calm: note down how today went.',
    ),
    (
      es: '¿Qué te gustaría recordar de hoy dentro de cinco años?',
      en: 'What would you like to remember about today in five years?',
    ),
    (
      es: 'Escribe hoy lo que mañana habrás olvidado.',
      en: 'Write down today what you will have forgotten tomorrow.',
    ),
    (
      es: '¿Qué ha cambiado hoy, aunque sea un poco?',
      en: 'What changed today, even a little?',
    ),
    (
      es: 'Hoy cuenta. Dedícale un par de líneas.',
      en: 'Today counts. Give it a couple of lines.',
    ),
    (
      es: '¿Por qué das las gracias hoy?',
      en: 'What are you thankful for today?',
    ),
    (
      es: 'La página de hoy sigue en blanco. ¿La llenamos?',
      en: "Today's page is still blank. Shall we fill it?",
    ),
    (
      es: 'Haz una pausa y cuéntale a Gonen cómo te ha ido.',
      en: 'Take a pause and tell Gonen how it went.',
    ),
    (
      es: 'Un día más, una entrada más. ¿Qué me cuentas?',
      en: 'One more day, one more entry. What have you got to tell me?',
    ),
    (
      es: '¿Qué ha sido lo más inesperado de hoy?',
      en: 'What was the most unexpected thing about today?',
    ),
    (
      es: 'Si hoy fuera un capítulo, ¿cómo se titularía?',
      en: 'If today were a chapter, what would it be called?',
    ),
  ];

  /// Día contado desde 1970 (en calendario, sin horas): sirve para repartir las
  /// frases sin depender de la zona horaria ni del cambio de hora.
  static int epochDay(DateTime date) =>
      DateTime.utc(date.year, date.month, date.day).millisecondsSinceEpoch ~/
      Duration.millisecondsPerDay;

  /// Salto entre una frase y la del día siguiente. Es primo con el número de
  /// frases, así que se recorren todas antes de repetir ninguna, y los días
  /// seguidos no tienen frases vecinas en la lista.
  static final int _stride = _coprimeStride(all.length);

  static int _coprimeStride(int length) {
    int step = 7;
    while (_gcd(step, length) != 1) {
      step++;
    }
    return step;
  }

  static int _gcd(int a, int b) {
    while (b != 0) {
      final int rest = a % b;
      a = b;
      b = rest;
    }
    return a;
  }

  /// Posición en [all] de la frase del día [epochDay].
  static int indexForDay(int epochDay) {
    final int length = all.length;
    return ((epochDay * _stride) % length + length) % length;
  }

  /// Frase del aviso de [date], en español o en inglés.
  static String forDate(DateTime date, {required bool english}) {
    final ({String es, String en}) phrase = all[indexForDay(epochDay(date))];
    return english ? phrase.en : phrase.es;
  }
}
