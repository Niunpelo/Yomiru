import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/models/capsule_model.dart';
import 'package:gonen/providers/capsules_provider.dart';
import 'package:gonen/widgets/capsule_import_dialog.dart';
import 'package:intl/date_symbol_data_local.dart';

Capsule _received(DateTime openDate, {bool hideTitle = false}) {
  return Capsule(
    id: 1,
    hideTitle: hideTitle,
    title: 'Hola',
    content: 'Mensaje',
    createdAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
    openDate: openDate,
    sender: 'Ana',
    uid: 'abc',
  );
}

/// Abre el diálogo desde un botón «abrir» y guarda lo que devuelva.
Widget _host(
  CapsuleImportResult result,
  void Function(bool seeList) onResult, {
  required bool offerList,
}) {
  return MaterialApp(
    home: Builder(
      builder: (BuildContext context) {
        return Scaffold(
          body: Center(
            child: ElevatedButton(
              onPressed: () async {
                final bool seeList = await showCapsuleImportResult(
                  context,
                  result,
                  offerList: offerList,
                );
                onResult(seeList);
              },
              child: const Text('abrir'),
            ),
          ),
        );
      },
    ),
  );
}

void main() {
  setUpAll(() async {
    await initializeDateFormatting('es');
  });

  testWidgets('una cápsula guardada dice de quién es y cuándo se abre', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(
      _host(
        CapsuleImportResult(
          CapsuleImportStatus.imported,
          capsule: _received(DateTime(2100, 1, 5)),
        ),
        (bool value) {},
        offerList: false,
      ),
    );

    await tester.tap(find.text('abrir'));
    await tester.pumpAndSettle();

    expect(find.text('Cápsula guardada'), findsOneWidget);
    expect(find.textContaining('Ana te ha dejado una cápsula'), findsOneWidget);
    expect(find.textContaining('«Hola»'), findsOneWidget);
    expect(find.textContaining('5 de Enero de 2100'), findsOneWidget);
    expect(find.text('Entendido'), findsOneWidget);
    expect(find.text('Ver cápsulas'), findsNothing);
  });

  testWidgets('con el título oculto el diálogo no lo enseña', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(
      _host(
        CapsuleImportResult(
          CapsuleImportStatus.imported,
          capsule: _received(DateTime(2100, 1, 5), hideTitle: true),
        ),
        (bool value) {},
        offerList: false,
      ),
    );

    await tester.tap(find.text('abrir'));
    await tester.pumpAndSettle();

    expect(find.textContaining('Ana te ha dejado una cápsula'), findsOneWidget);
    expect(find.textContaining('Hola'), findsNothing);
  });

  testWidgets('si ya se puede abrir lo dice', (WidgetTester tester) async {
    await tester.pumpWidget(
      _host(
        CapsuleImportResult(
          CapsuleImportStatus.imported,
          capsule: _received(DateTime(2000, 1, 5)),
        ),
        (bool value) {},
        offerList: false,
      ),
    );

    await tester.tap(find.text('abrir'));
    await tester.pumpAndSettle();

    expect(find.textContaining('Ya se puede abrir'), findsOneWidget);
  });

  testWidgets('desde otra pantalla ofrece ir a la lista y lo devuelve', (
    WidgetTester tester,
  ) async {
    bool? seeList;
    await tester.pumpWidget(
      _host(
        CapsuleImportResult(
          CapsuleImportStatus.imported,
          capsule: _received(DateTime(2100, 1, 5)),
        ),
        (bool value) => seeList = value,
        offerList: true,
      ),
    );

    await tester.tap(find.text('abrir'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Ver cápsulas'));
    await tester.pumpAndSettle();

    expect(seeList, isTrue);
  });

  testWidgets('«Cerrar» no pide ir a la lista', (WidgetTester tester) async {
    bool? seeList;
    await tester.pumpWidget(
      _host(
        CapsuleImportResult(
          CapsuleImportStatus.imported,
          capsule: _received(DateTime(2100, 1, 5)),
        ),
        (bool value) => seeList = value,
        offerList: true,
      ),
    );

    await tester.tap(find.text('abrir'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Cerrar'));
    await tester.pumpAndSettle();

    expect(seeList, isFalse);
  });

  testWidgets('una cápsula repetida avisa de que ya estaba', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(
      _host(
        const CapsuleImportResult(CapsuleImportStatus.duplicate),
        (bool value) {},
        offerList: true,
      ),
    );

    await tester.tap(find.text('abrir'));
    await tester.pumpAndSettle();

    expect(find.text('Ya la tenías'), findsOneWidget);
    expect(find.text('Entendido'), findsOneWidget);
    expect(find.text('Ver cápsulas'), findsNothing);
  });

  testWidgets('un archivo que no vale enseña el motivo', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(
      _host(
        const CapsuleImportResult(
          CapsuleImportStatus.invalid,
          message: 'Este archivo no es una cápsula de Gonen.',
        ),
        (bool value) {},
        offerList: false,
      ),
    );

    await tester.tap(find.text('abrir'));
    await tester.pumpAndSettle();

    expect(find.text('No se pudo guardar'), findsOneWidget);
    expect(
      find.text('Este archivo no es una cápsula de Gonen.'),
      findsOneWidget,
    );
  });
}
