import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/l10n/reminder_phrases.dart';

void main() {
  group('ReminderPhrases', () {
    test('hay una buena batería de frases, todas con texto', () {
      expect(ReminderPhrases.all.length, greaterThanOrEqualTo(20));
      for (final ({String es, String en}) phrase in ReminderPhrases.all) {
        expect(phrase.es.trim(), isNotEmpty);
        expect(phrase.en.trim(), isNotEmpty);
        // Caben en el aviso sin cortarse.
        expect(phrase.es.length, lessThanOrEqualTo(80));
        expect(phrase.en.length, lessThanOrEqualTo(80));
      }
    });

    test('ninguna frase está repetida', () {
      final Set<String> es = <String>{
        for (final ({String es, String en}) phrase in ReminderPhrases.all)
          phrase.es,
      };
      final Set<String> en = <String>{
        for (final ({String es, String en}) phrase in ReminderPhrases.all)
          phrase.en,
      };
      expect(es.length, ReminderPhrases.all.length);
      expect(en.length, ReminderPhrases.all.length);
    });

    test('la frase de un día es siempre la misma', () {
      final DateTime day = DateTime(2026, 11, 6, 21, 0);
      expect(
        ReminderPhrases.forDate(day, english: false),
        ReminderPhrases.forDate(DateTime(2026, 11, 6, 8, 30), english: false),
      );
    });

    test('dos días seguidos nunca tienen la misma frase', () {
      DateTime day = DateTime(2026, 1, 1);
      for (int i = 0; i < 800; i++) {
        final DateTime next = DateTime(day.year, day.month, day.day + 1);
        expect(
          ReminderPhrases.forDate(day, english: false),
          isNot(ReminderPhrases.forDate(next, english: false)),
        );
        day = next;
      }
    });

    test('se recorren todas las frases antes de repetir ninguna', () {
      final int length = ReminderPhrases.all.length;
      final int start = ReminderPhrases.epochDay(DateTime(2026, 11, 6));
      final Set<int> seen = <int>{
        for (int i = 0; i < length; i++) ReminderPhrases.indexForDay(start + i),
      };
      expect(seen.length, length);
    });

    test('las frases de los días seguidos no son vecinas en la lista', () {
      final int length = ReminderPhrases.all.length;
      final int start = ReminderPhrases.epochDay(DateTime(2026, 11, 6));
      for (int i = 0; i < 100; i++) {
        final int a = ReminderPhrases.indexForDay(start + i);
        final int b = ReminderPhrases.indexForDay(start + i + 1);
        final int gap = (a - b).abs();
        expect(gap > 1 && gap < length - 1, isTrue);
      }
    });

    test('el cambio de hora no altera el día que corresponde', () {
      // 30 de marzo de 2026 (cambio de hora en España): el día siguiente sigue
      // siendo el siguiente.
      expect(
        ReminderPhrases.epochDay(DateTime(2026, 3, 29)) + 1,
        ReminderPhrases.epochDay(DateTime(2026, 3, 30)),
      );
      expect(
        ReminderPhrases.epochDay(DateTime(2026, 10, 25)) + 1,
        ReminderPhrases.epochDay(DateTime(2026, 10, 26)),
      );
    });

    test('devuelve el idioma pedido', () {
      final DateTime day = DateTime(2026, 11, 6);
      final ({String es, String en}) phrase =
          ReminderPhrases.all[ReminderPhrases.indexForDay(
        ReminderPhrases.epochDay(day),
      )];
      expect(ReminderPhrases.forDate(day, english: false), phrase.es);
      expect(ReminderPhrases.forDate(day, english: true), phrase.en);
    });
  });
}
