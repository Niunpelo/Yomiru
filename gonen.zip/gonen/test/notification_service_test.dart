import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/services/notification_service.dart';

void main() {
  group('reminderSlotId', () {
    test('los siete días de la semana tienen siete identificadores distintos', () {
      // 2 de noviembre de 2026 es lunes: de lunes a domingo.
      final Set<int> ids = <int>{
        for (int i = 0; i < 7; i++)
          NotificationService.reminderSlotId(DateTime(2026, 11, 2 + i)),
      };
      expect(ids.length, NotificationService.reminderSlots);
      expect(NotificationService.reminderSlots, 7);
    });

    test('el mismo día de la semana, de semanas distintas, comparte identificador', () {
      expect(
        NotificationService.reminderSlotId(DateTime(2026, 11, 6)),
        NotificationService.reminderSlotId(DateTime(2026, 11, 13)),
      );
      expect(
        NotificationService.reminderSlotId(DateTime(2026, 11, 6)),
        NotificationService.reminderSlotId(DateTime(2026, 12, 25)),
      );
    });

    test('un aviso por día: ninguna fecha consecutiva repite identificador', () {
      for (int i = 0; i < 400; i++) {
        final DateTime day = DateTime(2026, 1, 1 + i);
        final DateTime next = DateTime(2026, 1, 2 + i);
        expect(
          NotificationService.reminderSlotId(day),
          isNot(NotificationService.reminderSlotId(next)),
        );
      }
    });

    test('no chocan con el aviso antiguo ni con las cápsulas', () {
      for (int i = 0; i < 400; i++) {
        final int id = NotificationService.reminderSlotId(
          DateTime(2026, 1, 1 + i),
        );
        expect(id, isNot(NotificationService.legacyReminderId));
        expect(id, greaterThanOrEqualTo(NotificationService.reminderSlotBase));
        expect(
          id,
          lessThan(
            NotificationService.reminderSlotBase +
                NotificationService.reminderSlots,
          ),
        );
        expect(id, lessThan(NotificationService.capsuleIdOffset));
      }
    });
  });
}
