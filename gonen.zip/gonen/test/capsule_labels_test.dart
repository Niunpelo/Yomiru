import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/models/capsule_model.dart';
import 'package:gonen/utils/capsule_labels.dart';

Capsule _capsule({
  String? sender,
  String? recipient,
  String title = 'Hola',
  bool hideTitle = false,
}) {
  return Capsule(
    hideTitle: hideTitle,
    title: title,
    content: 'Mensaje',
    createdAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
    openDate: DateTime(2028, 1, 2),
    sender: sender,
    recipient: recipient,
  );
}

void main() {
  group('capsulePeerLabel', () {
    test('una cápsula normal no lleva etiqueta', () {
      expect(capsulePeerLabel(_capsule()), isNull);
    });

    test('una cápsula enviada dice para quién es', () {
      expect(
        capsulePeerLabel(_capsule(sender: 'Ana', recipient: 'Lucía')),
        'Para Lucía',
      );
    });

    test('una cápsula enviada sin nombre dice «otra persona»', () {
      expect(
        capsulePeerLabel(_capsule(sender: 'Ana', recipient: '  ')),
        'Para otra persona',
      );
    });

    test('una cápsula recibida dice de quién es', () {
      expect(capsulePeerLabel(_capsule(sender: 'Ana')), 'De Ana');
    });
  });

  group('capsuleTitleLabel', () {
    test('una cápsula normal enseña su título, abierta o no', () {
      expect(capsuleTitleLabel(_capsule(), opened: false), 'Hola');
      expect(capsuleTitleLabel(_capsule(), opened: true), 'Hola');
    });

    test('sin título dice «Sin título»', () {
      expect(capsuleTitleLabel(_capsule(title: '  '), opened: false), 'Sin título');
    });

    test('una recibida con el título oculto lo esconde hasta abrirla', () {
      final Capsule received = _capsule(sender: 'Ana', hideTitle: true);
      expect(capsuleTitleLabel(received, opened: false), 'Título oculto');
      expect(capsuleTitleLabel(received, opened: true), 'Hola');
    });

    test('la que escribiste tú ve siempre su título', () {
      final Capsule sent =
          _capsule(sender: 'Ana', recipient: 'Lucía', hideTitle: true);
      expect(capsuleTitleLabel(sent, opened: false), 'Hola');
    });
  });
}
