import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/models/attachment_model.dart';
import 'package:gonen/models/capsule_model.dart';
import 'package:gonen/services/attachment_service.dart';
import 'package:gonen/services/backup_archive.dart';
import 'package:gonen/services/capsule_cipher.dart';
import 'package:gonen/services/capsule_share_service.dart';
import 'package:intl/date_symbol_data_local.dart';

const String _uid = '0123456789abcdef0123456789abcdef';

void main() {
  late Directory root;
  late Directory senderRoot;
  late Directory receiverRoot;
  late Directory temp;
  late CapsuleShareService sender;
  late CapsuleShareService receiver;

  setUpAll(() async {
    await initializeDateFormatting('es');
  });

  setUp(() {
    root = Directory.systemTemp.createTempSync('gonen_share_');
    senderRoot = Directory('${root.path}/sender')..createSync();
    receiverRoot = Directory('${root.path}/receiver')..createSync();
    temp = Directory('${root.path}/temp')..createSync();
    sender = CapsuleShareService(
      attachmentService: AttachmentService.forTesting(senderRoot),
      cipher: CapsuleCipher(random: Random(1)),
      temporaryDirectory: () async => temp,
    );
    receiver = CapsuleShareService(
      attachmentService: AttachmentService.forTesting(receiverRoot),
      cipher: CapsuleCipher(random: Random(2)),
      temporaryDirectory: () async => temp,
    );
  });

  tearDown(() {
    if (root.existsSync()) {
      root.deleteSync(recursive: true);
    }
  });

  Capsule sentCapsule({
    String? uid = _uid,
    String? senderName = 'Ana',
    String title = 'Para cuando nos casemos',
    bool hideTitle = false,
  }) {
    return Capsule(
      id: 4,
      title: title,
      content: 'Querida Lucía: hoy te escribo desde el pasado. ¡Un abrazo! 🎁',
      createdAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
      openDate: DateTime(2031, 5, 9),
      sender: senderName,
      recipient: 'Lucía',
      uid: uid,
      hideTitle: hideTitle,
    );
  }

  Future<List<Attachment>> senderFiles() async {
    final File photo = File('${senderRoot.path}/capsules/111.jpg');
    photo.parent.createSync(recursive: true);
    photo.writeAsBytesSync(List<int>.generate(3000, (int i) => i % 251));
    final File voice = File('${senderRoot.path}/capsules/222.m4a');
    voice.writeAsBytesSync(List<int>.generate(5000, (int i) => (i * 7) % 253));
    return <Attachment>[
      Attachment.forCapsule(
        id: 1,
        capsuleId: 4,
        type: AttachmentType.image,
        relativePath: 'capsules/111.jpg',
        createdAt: DateTime.fromMillisecondsSinceEpoch(1700000001000),
      ),
      Attachment.forCapsule(
        id: 2,
        capsuleId: 4,
        type: AttachmentType.audio,
        relativePath: 'capsules/222.m4a',
        durationMs: 42000,
        createdAt: DateTime.fromMillisecondsSinceEpoch(1700000002000),
      ),
    ];
  }

  Map<String, Object?> validMeta({
    Map<String, Object?> overrides = const <String, Object?>{},
    List<Map<String, Object?>> files = const <Map<String, Object?>>[],
  }) {
    return <String, Object?>{
      'format': 1,
      'uid': _uid,
      'sender': 'Ana',
      'title': 'Hola',
      'content': 'Un mensaje',
      'created_at': 1700000000000,
      'open_date': '2031-05-09',
      'attachments': files,
      ...overrides,
    };
  }

  /// Fabrica a mano un archivo de cápsula con los datos que se quieran.
  Future<File> craft(
    Map<String, Object?> meta, {
    Map<String, List<int>> files = const <String, List<int>>{},
  }) async {
    final File plain = File('${temp.path}/craft.tmp');
    final BackupArchiveWriter writer = await BackupArchiveWriter.create(plain);
    await writer.addBytes(
      CapsuleShareService.metaEntry,
      utf8.encode(jsonEncode(meta)),
    );
    for (final MapEntry<String, List<int>> item in files.entries) {
      await writer.addBytes('files/${item.key}', item.value);
    }
    await writer.close();
    final File output = File('${temp.path}/craft.gonencap');
    await CapsuleCipher(random: Random(5)).encryptFile(plain, output);
    plain.deleteSync();
    return output;
  }

  group('textos', () {
    test('el nombre del archivo lleva solo quién la envía y el título', () {
      expect(
        CapsuleShareService.suggestedFileName(sentCapsule()),
        'Ana - Para cuando nos casemos.gonencap',
      );
    });

    test('con el título oculto el nombre del archivo lleva solo quién la envía', () {
      expect(
        CapsuleShareService.suggestedFileName(sentCapsule(hideTitle: true)),
        'Ana.gonencap',
      );
    });

    test('sin título el nombre del archivo lleva solo quién la envía', () {
      expect(
        CapsuleShareService.suggestedFileName(sentCapsule(title: '')),
        'Ana.gonencap',
      );
    });

    test('sin nadie que la envíe ni título queda un nombre genérico', () {
      expect(
        CapsuleShareService.suggestedFileName(
          sentCapsule(senderName: null, title: ''),
        ),
        'Cápsula del tiempo.gonencap',
      );
    });

    test('el nombre del archivo no lleva caracteres que Android no admite', () {
      expect(
        CapsuleShareService.suggestedFileName(
          sentCapsule(senderName: 'A/na: "la" <mejor>?', title: 'Hola...'),
        ),
        'A na la mejor - Hola.gonencap',
      );
      expect(
        CapsuleShareService.suggestedFileName(
          sentCapsule(senderName: '///', title: '***'),
        ),
        'Cápsula del tiempo.gonencap',
      );
    });

    test('el texto que acompaña al archivo dice quién y el título, nada más', () {
      final String message = CapsuleShareService.shareMessage(sentCapsule());

      expect(message, 'De Ana · «Para cuando nos casemos»');
      expect(message, isNot(contains('2031')));
      expect(message, isNot(contains('Importar')));
      expect(message, isNot(contains('Querida')));
    });

    test('con el título oculto el texto dice solo quién la envía', () {
      expect(
        CapsuleShareService.shareMessage(sentCapsule(hideTitle: true)),
        'De Ana',
      );
      expect(
        CapsuleShareService.shareMessage(sentCapsule(title: '')),
        'De Ana',
      );
    });

    test('lo que se enseña al escribirla es lo mismo que acompaña al archivo', () {
      expect(
        CapsuleShareService.arrivalText(
          sender: ' Ana ',
          title: 'Para cuando nos casemos',
        ),
        CapsuleShareService.shareMessage(sentCapsule()),
      );
      expect(
        CapsuleShareService.arrivalText(sender: '', title: 'x', hideTitle: true),
        'De Alguien',
      );
    });
  });

  group('enviar y recibir', () {
    test('la cápsula llega entera, con sus fotos y notas de voz', () async {
      final Capsule capsule = sentCapsule();
      final List<Attachment> files = await senderFiles();

      final CapsulePackage package =
          await sender.build(capsule: capsule, attachments: files);
      final ReceivedCapsule? received = await receiver.read(package.file);

      expect(received, isNotNull);
      final Capsule got = received!.capsule;
      expect(got.title, capsule.title);
      expect(got.content, capsule.content);
      expect(got.sender, 'Ana');
      expect(got.uid, _uid);
      expect(got.openDate, DateTime(2031, 5, 9));
      expect(got.createdAt, capsule.createdAt);
      expect(got.openedAt, isNull);
      expect(got.recipient, isNull);
      expect(got.isReceived, isTrue);
      expect(got.isSent, isFalse);

      expect(received.attachments, hasLength(2));
      final Attachment photo = received.attachments[0];
      final Attachment voice = received.attachments[1];
      expect(photo.type, AttachmentType.image);
      expect(voice.type, AttachmentType.audio);
      expect(voice.durationMs, 42000);
      expect(voice.createdAt, DateTime.fromMillisecondsSinceEpoch(1700000002000));
      expect(photo.isForCapsule, isTrue);

      expect(
        File('${receiverRoot.path}/${photo.relativePath}').readAsBytesSync(),
        File('${senderRoot.path}/capsules/111.jpg').readAsBytesSync(),
      );
      expect(
        File('${receiverRoot.path}/${voice.relativePath}').readAsBytesSync(),
        File('${senderRoot.path}/capsules/222.m4a').readAsBytesSync(),
      );
      expect(photo.relativePath, startsWith('capsules/'));
      expect(photo.relativePath, endsWith('.jpg'));
      expect(voice.relativePath, endsWith('.m4a'));
    });

    test('el título oculto viaja con la cápsula y se guarda tal cual', () async {
      final CapsulePackage package = await sender.build(
        capsule: sentCapsule(hideTitle: true),
        attachments: const <Attachment>[],
      );
      final ReceivedCapsule? received = await receiver.read(package.file);

      expect(received!.capsule.hideTitle, isTrue);
      // El título sigue guardado: solo se esconde hasta que se abre.
      expect(received.capsule.title, 'Para cuando nos casemos');
      expect(package.fileName, isNot(contains('casemos')));
      expect(package.message, isNot(contains('casemos')));
    });

    test('una cápsula sin la marca de título oculto enseña el título', () async {
      final CapsulePackage package = await sender.build(
        capsule: sentCapsule(),
        attachments: const <Attachment>[],
      );
      final ReceivedCapsule? received = await receiver.read(package.file);
      expect(received!.capsule.hideTitle, isFalse);

      // Un archivo de una versión anterior no trae la marca.
      final File old = await craft(validMeta());
      final ReceivedCapsule? fromOld = await receiver.read(old);
      expect(fromOld!.capsule.hideTitle, isFalse);
    });

    test('el nombre del archivo y la propuesta coinciden con el paquete', () async {
      final CapsulePackage package = await sender.build(
        capsule: sentCapsule(),
        attachments: const <Attachment>[],
      );

      expect(package.fileName, CapsuleShareService.suggestedFileName(sentCapsule()));
      expect(package.file.path, endsWith(package.fileName));
      expect(package.message, CapsuleShareService.shareMessage(sentCapsule()));
      expect(package.subject, package.message);
    });

    test('dos cápsulas de la misma persona no se pisan; reenviar reutiliza el sitio', () async {
      final CapsulePackage first = await sender.build(
        capsule: sentCapsule(),
        attachments: const <Attachment>[],
      );
      final CapsulePackage second = await sender.build(
        capsule: sentCapsule(uid: 'fedcba9876543210fedcba9876543210'),
        attachments: const <Attachment>[],
      );
      final CapsulePackage again = await sender.build(
        capsule: sentCapsule(),
        attachments: const <Attachment>[],
      );

      expect(first.fileName, second.fileName);
      expect(first.file.path, isNot(second.file.path));
      expect(first.file.existsSync(), isTrue);
      expect(second.file.existsSync(), isTrue);
      expect(again.file.path, first.file.path);
      expect(await receiver.read(again.file), isNotNull);
    });

    test('un identificador raro no saca el archivo de la carpeta de envíos', () async {
      final CapsulePackage package = await sender.build(
        capsule: sentCapsule(uid: '../../x'),
        attachments: const <Attachment>[],
      );

      expect(package.file.path, startsWith('${temp.path}/envios/x/'));
      expect(package.file.existsSync(), isTrue);
    });

    test('borra los envíos de más de un día y deja los recientes', () async {
      final Directory oldFolder = Directory('${temp.path}/envios/viejo')
        ..createSync(recursive: true);
      final File old = File('${oldFolder.path}/Cápsula.gonencap')
        ..writeAsBytesSync(<int>[1, 2, 3]);
      old.setLastModifiedSync(DateTime.now().subtract(const Duration(days: 3)));
      final Directory recentFolder = Directory('${temp.path}/envios/reciente')
        ..createSync(recursive: true);
      final File recent = File('${recentFolder.path}/Cápsula.gonencap')
        ..writeAsBytesSync(<int>[1, 2, 3]);

      await sender.build(
        capsule: sentCapsule(),
        attachments: const <Attachment>[],
      );

      expect(oldFolder.existsSync(), isFalse);
      expect(recent.existsSync(), isTrue);
    });

    test('en el archivo no se puede leer ni el mensaje, ni el título, ni el nombre', () async {
      final CapsulePackage package = await sender.build(
        capsule: sentCapsule(),
        attachments: await senderFiles(),
      );

      final String raw = latin1.decode(package.file.readAsBytesSync());
      expect(raw.contains('Querida'), isFalse);
      expect(raw.contains('casemos'), isFalse);
      expect(raw.contains('Lucía'), isFalse);
      expect(raw.contains('2031'), isFalse);
      expect(raw.contains('capsules/'), isFalse);
    });

    test('no deja archivos temporales sin cifrar', () async {
      await sender.build(
        capsule: sentCapsule(),
        attachments: await senderFiles(),
      );

      final List<String> names = temp
          .listSync()
          .map((FileSystemEntity e) => e.uri.pathSegments.last)
          .toList();
      expect(names, hasLength(1));
      expect(names.single, endsWith('.gonencap'));
    });

    test('recibir no deja archivos temporales', () async {
      final CapsulePackage package = await sender.build(
        capsule: sentCapsule(),
        attachments: await senderFiles(),
      );
      await receiver.read(package.file);

      final List<String> names = temp
          .listSync()
          .map((FileSystemEntity e) => e.uri.pathSegments.last)
          .toList();
      expect(names, <String>[package.fileName]);
    });

    test('si la cápsula ya estaba guardada devuelve null y no copia nada', () async {
      final CapsulePackage package = await sender.build(
        capsule: sentCapsule(),
        attachments: await senderFiles(),
      );

      String? askedUid;
      final ReceivedCapsule? received = await receiver.read(
        package.file,
        alreadyHave: (String uid) async {
          askedUid = uid;
          return true;
        },
      );

      expect(received, isNull);
      expect(askedUid, _uid);
      expect(Directory('${receiverRoot.path}/capsules').existsSync(), isFalse);
    });

    test('un adjunto cuyo archivo ya no existe no se envía', () async {
      final List<Attachment> files = await senderFiles();
      File('${senderRoot.path}/capsules/222.m4a').deleteSync();

      final CapsulePackage package =
          await sender.build(capsule: sentCapsule(), attachments: files);
      final ReceivedCapsule? received = await receiver.read(package.file);

      expect(received!.attachments, hasLength(1));
      expect(received.attachments.single.type, AttachmentType.image);
    });

    test('una cápsula sin uid o sin remitente no se puede preparar', () async {
      await expectLater(
        sender.build(
          capsule: sentCapsule(uid: null),
          attachments: const <Attachment>[],
        ),
        throwsArgumentError,
      );
      await expectLater(
        sender.build(
          capsule: sentCapsule(senderName: null),
          attachments: const <Attachment>[],
        ),
        throwsArgumentError,
      );
    });
  });

  group('archivos que no valen', () {
    test('un archivo tocado se rechaza y no deja fotos copiadas', () async {
      final CapsulePackage package = await sender.build(
        capsule: sentCapsule(),
        attachments: await senderFiles(),
      );
      final Uint8List bytes = package.file.readAsBytesSync();
      bytes[CapsuleCipher.headerLength + 100] ^= 0x01;
      package.file.writeAsBytesSync(bytes);

      await expectLater(
        receiver.read(package.file),
        throwsA(isA<FormatException>()),
      );
      expect(Directory('${receiverRoot.path}/capsules').existsSync(), isFalse);
    });

    test('un archivo cualquiera no es una cápsula', () async {
      final File other = File('${temp.path}/foto.jpg')
        ..writeAsBytesSync(List<int>.generate(100, (int i) => i));

      await expectLater(
        receiver.read(other),
        throwsA(
          isA<FormatException>().having(
            (FormatException e) => e.message,
            'message',
            CapsuleCipher.notCapsuleMessage,
          ),
        ),
      );
    });

    test('una copia de seguridad se reconoce y se manda a su sitio', () async {
      final File backup = File('${temp.path}/copia.gonen');
      final BackupArchiveWriter writer = await BackupArchiveWriter.create(backup);
      await writer.addBytes(BackupArchive.dataEntry, utf8.encode('{}'));
      await writer.close();

      await expectLater(
        receiver.read(backup),
        throwsA(
          isA<FormatException>().having(
            (FormatException e) => e.message,
            'message',
            contains('copia de seguridad'),
          ),
        ),
      );
    });

    test('una fecha imposible es un archivo dañado', () async {
      final File file = await craft(
        validMeta(overrides: <String, Object?>{'open_date': '2031-13-45'}),
      );

      await expectLater(receiver.read(file), throwsA(isA<FormatException>()));
    });

    test('sin mensaje o sin identificador es un archivo dañado', () async {
      await expectLater(
        receiver.read(
          await craft(validMeta(overrides: <String, Object?>{'content': '  '})),
        ),
        throwsA(isA<FormatException>()),
      );
      await expectLater(
        receiver.read(
          await craft(validMeta(overrides: <String, Object?>{'uid': ''})),
        ),
        throwsA(isA<FormatException>()),
      );
    });

    test('una versión más nueva pide actualizar la app', () async {
      final File file = await craft(
        validMeta(overrides: <String, Object?>{'format': 2}),
      );

      await expectLater(
        receiver.read(file),
        throwsA(
          isA<FormatException>().having(
            (FormatException e) => e.message,
            'message',
            contains('Actualiza'),
          ),
        ),
      );
    });

    test('solo se aceptan los adjuntos con rutas y tipos válidos y hasta el límite', () async {
      final List<int> bytes = <int>[1, 2, 3, 4];
      final Map<String, List<int>> files = <String, List<int>>{};
      final List<Map<String, Object?>> declared = <Map<String, Object?>>[];
      for (int i = 1; i <= 7; i++) {
        final String path = 'capsules/$i.jpg';
        files[path] = bytes;
        declared.add(<String, Object?>{'type': 'image', 'path': path});
      }
      // Rutas que intentan salir de la carpeta o no son de Gonen.
      files['capsules/../../x.jpg'] = bytes;
      declared.add(<String, Object?>{
        'type': 'image',
        'path': 'capsules/../../x.jpg',
      });
      files['2024/01-01/9.jpg'] = bytes;
      declared.add(<String, Object?>{'type': 'image', 'path': '2024/01-01/9.jpg'});
      // Tipo que no corresponde a la extensión.
      files['capsules/50.m4a'] = bytes;
      declared.add(<String, Object?>{'type': 'image', 'path': 'capsules/50.m4a'});
      // Declarado, pero sin archivo dentro.
      declared.add(<String, Object?>{'type': 'audio', 'path': 'capsules/60.m4a'});

      final ReceivedCapsule? received = await receiver.read(
        await craft(validMeta(files: declared), files: files),
      );

      expect(received!.attachments, hasLength(5));
      expect(
        received.attachments.every(
          (Attachment a) => a.type == AttachmentType.image,
        ),
        isTrue,
      );
      // Nada fuera de la carpeta de adjuntos.
      expect(File('${root.path}/x.jpg').existsSync(), isFalse);
      expect(Directory('${receiverRoot.path}/2024').existsSync(), isFalse);
    });

    test('el título y el nombre muy largos se recortan', () async {
      final ReceivedCapsule? received = await receiver.read(
        await craft(
          validMeta(
            overrides: <String, Object?>{
              'title': 'T' * 200,
              'sender': 'S' * 200,
            },
          ),
        ),
      );

      expect(received!.capsule.title.length, CapsuleShareService.maxTitleLength);
      expect(received.capsule.sender!.length, CapsuleShareService.maxSenderLength);
    });

    test('sin nombre de remitente se llama «Alguien»', () async {
      final ReceivedCapsule? received = await receiver.read(
        await craft(validMeta(overrides: <String, Object?>{'sender': '  '})),
      );

      expect(received!.capsule.sender, 'Alguien');
      expect(received.capsule.isReceived, isTrue);
    });
  });
}
