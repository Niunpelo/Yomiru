import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/providers/premium_provider.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Google Play de mentira: solo cuenta cuántas veces se le piden las compras.
class _FakeStore extends Fake implements InAppPurchase {
  final StreamController<List<PurchaseDetails>> controller =
      StreamController<List<PurchaseDetails>>.broadcast();
  int restores = 0;

  @override
  Stream<List<PurchaseDetails>> get purchaseStream => controller.stream;

  @override
  Future<bool> isAvailable() async => true;

  @override
  Future<ProductDetailsResponse> queryProductDetails(
    Set<String> identifiers,
  ) async {
    return ProductDetailsResponse(
      productDetails: <ProductDetails>[],
      notFoundIDs: identifiers.toList(),
    );
  }

  @override
  Future<void> restorePurchases({String? applicationUserName}) async {
    restores++;
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  group('PremiumProvider.refreshIfStale', () {
    test('no pregunta a Google Play antes de que pase el margen', () async {
      DateTime now = DateTime(2026, 11, 6, 10);
      final _FakeStore store = _FakeStore();
      final PremiumProvider premium =
          PremiumProvider(inAppPurchase: store, clock: () => now);
      await premium.initialize();
      expect(store.restores, 1);

      now = now.add(const Duration(hours: 1));
      await premium.refreshIfStale();
      expect(store.restores, 1);

      premium.dispose();
      await store.controller.close();
    });

    test('vuelve a preguntar pasado el margen', () async {
      DateTime now = DateTime(2026, 11, 6, 10);
      final _FakeStore store = _FakeStore();
      final PremiumProvider premium =
          PremiumProvider(inAppPurchase: store, clock: () => now);
      await premium.initialize();

      now = now.add(PremiumProvider.refreshEvery + const Duration(minutes: 1));
      await premium.refreshIfStale();
      expect(store.restores, 2);

      // Justo después ya no vuelve a preguntar.
      await premium.refreshIfStale();
      expect(store.restores, 2);

      premium.dispose();
      await store.controller.close();
    });

    test('si el reloj va hacia atrás, pregunta igualmente', () async {
      DateTime now = DateTime(2026, 11, 6, 10);
      final _FakeStore store = _FakeStore();
      final PremiumProvider premium =
          PremiumProvider(inAppPurchase: store, clock: () => now);
      await premium.initialize();

      now = now.subtract(const Duration(days: 2));
      await premium.refreshIfStale();
      expect(store.restores, 2);

      premium.dispose();
      await store.controller.close();
    });

    test('sin initialize() no hace nada', () async {
      final _FakeStore store = _FakeStore();
      final PremiumProvider premium = PremiumProvider(inAppPurchase: store);
      await premium.refreshIfStale();
      expect(store.restores, 0);
      premium.dispose();
      await store.controller.close();
    });
  });
}
