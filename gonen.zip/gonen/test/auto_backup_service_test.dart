import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/services/auto_backup_service.dart';
import 'package:gonen/services/backup_service.dart';
import 'package:gonen/services/file_transfer_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

const BackupFolder _folder =
    BackupFolder(uri: 'content://tree/copias', name: 'Copias');

AutoBackupSettings _settings({
  bool enabled = true,
  int days = 7,
  BackupFolder? folder = _folder,
  DateTime? last,
  DateTime? attempt,
  String? error,
}) {
  return AutoBackupSettings(
    enabled: enabled,
    intervalDays: days,
    folder: folder,
    lastSuccess: last,
    lastAttempt: attempt,
    lastError: error,
  );
}

/// Copia falsa: crea un archivo pequeño y anota que se borró.
class _FakeBackup implements BackupService {
  _FakeBackup(this.directory);

  final Directory directory;
  int created = 0;
  int discarded = 0;
  String? lastFileName;

  @override
  Future<BackupCreateResult> create({String? fileName}) async {
    created++;
    lastFileName = fileName;
    final String name = fileName ?? 'copia.gonen';
    final File file = File('${directory.path}/$name')
      ..writeAsStringSync('copia');
    return BackupCreateResult(
      file: file,
      fileName: name,
      sizeBytes: 5,
      entries: 1,
      capsules: 0,
      photos: 0,
      voiceNotes: 0,
      missingFiles: 0,
    );
  }

  @override
  Future<void> discard(File file) async {
    discarded++;
  }

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

/// Destino falso: guarda lo que se le pide escribir, o falla si se le manda.
class _FakeTransfer implements FileTransferService {
  final List<Map<String, String>> writes = <Map<String, String>>[];
  FileTransferException? failure;

  @override
  Future<void> writeToFolder({
    required String folderUri,
    required String sourcePath,
    required String fileName,
  }) async {
    final FileTransferException? error = failure;
    if (error != null) {
      throw error;
    }
    writes.add(<String, String>{
      'folderUri': folderUri,
      'sourcePath': sourcePath,
      'fileName': fileName,
    });
  }

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

void main() {
  group('isDue', () {
    final DateTime now = DateTime(2026, 11, 6, 9, 0);

    test('apagada o sin carpeta nunca toca', () {
      expect(AutoBackupService.isDue(_settings(enabled: false), now), isFalse);
      expect(AutoBackupService.isDue(_settings(folder: null), now), isFalse);
    });

    test('si nunca se hizo ninguna, toca ya', () {
      expect(AutoBackupService.isDue(_settings(), now), isTrue);
    });

    test('cada día: toca al cambiar de día, no el mismo día', () {
      final AutoBackupSettings daily = _settings(
        days: 1,
        last: DateTime(2026, 11, 5, 22, 30),
      );
      expect(AutoBackupService.isDue(daily, DateTime(2026, 11, 5, 23, 59)), isFalse);
      // Solo han pasado 10 horas, pero es otro día.
      expect(AutoBackupService.isDue(daily, DateTime(2026, 11, 6, 8, 30)), isTrue);
    });

    test('cada semana: toca al séptimo día', () {
      final AutoBackupSettings weekly =
          _settings(days: 7, last: DateTime(2026, 10, 30, 12, 0));
      expect(AutoBackupService.isDue(weekly, DateTime(2026, 11, 5, 23, 0)), isFalse);
      expect(AutoBackupService.isDue(weekly, DateTime(2026, 11, 6, 0, 5)), isTrue);
    });

    test('si el reloj del móvil va por detrás de la última copia, toca', () {
      final AutoBackupSettings s =
          _settings(days: 30, last: DateTime(2026, 12, 1));
      expect(AutoBackupService.isDue(s, now), isTrue);
    });

    test('tras un fallo se espera antes de reintentar', () {
      final AutoBackupSettings failed = _settings(
        days: 30,
        last: DateTime(2026, 11, 5),
        attempt: DateTime(2026, 11, 6, 8, 40),
        error: 'Sin acceso',
      );
      expect(AutoBackupService.isDue(failed, now), isFalse);
      expect(AutoBackupService.isDue(failed, DateTime(2026, 11, 6, 9, 41)), isTrue);
    });

    test('un fallo sin fecha de intento se reintenta', () {
      expect(AutoBackupService.isDue(_settings(error: 'x'), now), isTrue);
    });
  });

  group('ajustes guardados', () {
    setUp(() => SharedPreferences.setMockInitialValues(<String, Object>{}));

    test('al principio está apagada, semanal y sin carpeta', () async {
      final AutoBackupSettings s = await AutoBackupService().load();

      expect(s.enabled, isFalse);
      expect(s.intervalDays, AutoBackupService.defaultIntervalDays);
      expect(s.folder, isNull);
      expect(s.lastSuccess, isNull);
      expect(s.lastError, isNull);
    });

    test('guarda y recupera carpeta, frecuencia y si está activada', () async {
      final AutoBackupService service = AutoBackupService();
      await service.setFolder(_folder);
      await service.setIntervalDays(3);
      await service.setEnabled(true);

      final AutoBackupSettings s = await service.load();
      expect(s.enabled, isTrue);
      expect(s.intervalDays, 3);
      expect(s.folder?.uri, _folder.uri);
      expect(s.folder?.name, 'Copias');
    });

    test('sin carpeta, «hacer copia ahora» pide elegirla', () async {
      final AutoBackupResult result = await AutoBackupService().runNow();

      expect(result.status, AutoBackupStatus.failed);
      expect(result.message, contains('carpeta'));
    });

    test('una frecuencia que no se ofrece vuelve a la de siempre', () async {
      final AutoBackupService service = AutoBackupService();
      await service.setIntervalDays(5);

      expect((await service.load()).intervalDays, 7);
      for (final int days in AutoBackupService.intervalOptions) {
        expect(AutoBackupService.clampInterval(days), days);
      }
    });
  });

  group('hacer la copia', () {
    late Directory temp;
    late _FakeBackup backup;
    late _FakeTransfer transfer;
    late DateTime now;
    late AutoBackupService service;

    setUp(() async {
      SharedPreferences.setMockInitialValues(<String, Object>{});
      temp = Directory.systemTemp.createTempSync('gonen_auto_');
      backup = _FakeBackup(temp);
      transfer = _FakeTransfer();
      now = DateTime(2026, 11, 6, 9, 0);
      service = AutoBackupService(
        backup: backup,
        transfer: transfer,
        clock: () => now,
      );
      await service.setFolder(_folder);
      await service.setEnabled(true);
    });

    tearDown(() {
      if (temp.existsSync()) {
        temp.deleteSync(recursive: true);
      }
    });

    test('guarda siempre con el mismo nombre en la carpeta elegida', () async {
      final AutoBackupResult result = await service.runIfDue(premium: true);

      expect(result.status, AutoBackupStatus.done);
      expect(transfer.writes, hasLength(1));
      expect(transfer.writes.single['folderUri'], _folder.uri);
      expect(transfer.writes.single['fileName'], AutoBackupService.fileName);
      expect(backup.lastFileName, AutoBackupService.fileName);
      // El archivo temporal se borra y la fecha queda anotada.
      expect(backup.discarded, 1);
      final AutoBackupSettings s = await service.load();
      expect(s.lastSuccess, now);
      expect(s.lastError, isNull);
      expect(service.isRunning, isFalse);
    });

    test('si no toca todavía, no hace nada', () async {
      await service.runIfDue(premium: true);
      now = DateTime(2026, 11, 8, 9, 0);

      final AutoBackupResult result = await service.runIfDue(premium: true);

      expect(result.status, AutoBackupStatus.skipped);
      expect(transfer.writes, hasLength(1));
    });

    test('cuando pasa el tiempo elegido, la hace otra vez', () async {
      await service.runIfDue(premium: true);
      now = DateTime(2026, 11, 13, 9, 0);

      final AutoBackupResult result = await service.runIfDue(premium: true);

      expect(result.status, AutoBackupStatus.done);
      expect(transfer.writes, hasLength(2));
    });

    test('sin Premium no hace nada', () async {
      final AutoBackupResult result = await service.runIfDue(premium: false);

      expect(result.status, AutoBackupStatus.skipped);
      expect(backup.created, 0);
      expect(transfer.writes, isEmpty);
    });

    test('si falla lo cuenta, lo anota y espera antes de reintentar', () async {
      transfer.failure = const FileTransferException('Sin acceso a la carpeta.');

      final AutoBackupResult result = await service.runIfDue(premium: true);

      expect(result.status, AutoBackupStatus.failed);
      expect(result.message, 'Sin acceso a la carpeta.');
      expect(backup.discarded, 1);
      final AutoBackupSettings s = await service.load();
      expect(s.lastError, 'Sin acceso a la carpeta.');
      expect(s.lastSuccess, isNull);

      // Enseguida no reintenta...
      now = now.add(const Duration(minutes: 20));
      expect((await service.runIfDue(premium: true)).status, AutoBackupStatus.skipped);
      expect(backup.created, 1);

      // ...pasada una hora, sí, y si ya funciona se limpia el error.
      transfer.failure = null;
      now = now.add(const Duration(hours: 2));
      expect((await service.runIfDue(premium: true)).status, AutoBackupStatus.done);
      expect((await service.load()).lastError, isNull);
    });

    test('«hacer copia ahora» la hace aunque no toque', () async {
      await service.runIfDue(premium: true);

      final AutoBackupResult result = await service.runNow();

      expect(result.status, AutoBackupStatus.done);
      expect(transfer.writes, hasLength(2));
    });

  });
}
