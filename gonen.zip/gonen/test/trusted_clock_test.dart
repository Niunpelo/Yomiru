import 'package:flutter_test/flutter_test.dart';
import 'package:gonen/models/capsule_model.dart';
import 'package:gonen/providers/capsules_provider.dart';
import 'package:gonen/services/trusted_clock.dart';
import 'package:shared_preferences/shared_preferences.dart';

const int _minute = 60 * 1000;
const int _hour = 60 * _minute;
const int _day = 24 * _hour;

// Un lunes cualquiera, a las 10:00.
final DateTime _t0 = DateTime(2026, 11, 2, 10);

ClockSnapshot _snap({
  required int elapsedMs,
  int boot = 7,
  bool auto = true,
}) =>
    ClockSnapshot(elapsedMs: elapsedMs, bootCount: boot, autoTime: auto);

ClockAnchor _anchorAt(DateTime wall, {int elapsedMs = 1000, int boot = 7}) =>
    ClockAnchor(
      trustedMs: wall.millisecondsSinceEpoch,
      elapsedMs: elapsedMs,
      bootCount: boot,
    );

void main() {
  group('TrustedClock.evaluate', () {
    test('con la fecha automática se fía del reloj y guarda el punto de referencia', () {
      final result = TrustedClock.evaluate(
        wall: _t0,
        snapshot: _snap(elapsedMs: 5000),
        anchor: null,
      );
      expect(result.reading.trust, ClockTrust.ok);
      expect(result.reading.now, _t0);
      expect(result.anchor?.trustedMs, _t0.millisecondsSinceEpoch);
      expect(result.anchor?.elapsedMs, 5000);
      expect(result.anchor?.bootCount, 7);
    });

    test('con la fecha manual y sin punto de referencia no se puede comprobar', () {
      final result = TrustedClock.evaluate(
        wall: _t0,
        snapshot: _snap(elapsedMs: 5000, auto: false),
        anchor: null,
      );
      expect(result.reading.trust, ClockTrust.unverifiable);
      expect(result.anchor, isNull, reason: 'no se guarda una fecha sin comprobar');
    });

    test('fecha manual que coincide con el contador: se da por buena', () {
      final result = TrustedClock.evaluate(
        // Han pasado 2 h según el contador y según el reloj.
        wall: _t0.add(const Duration(hours: 2, minutes: 1)),
        snapshot: _snap(elapsedMs: 1000 + 2 * _hour, auto: false),
        anchor: _anchorAt(_t0),
      );
      expect(result.reading.trust, ClockTrust.ok);
      expect(result.reading.now, _t0.add(const Duration(hours: 2, minutes: 1)));
    });

    test('adelantar la fecha a mano: manda el contador y no el reloj', () {
      final DateTime fake = _t0.add(const Duration(days: 30));
      final result = TrustedClock.evaluate(
        wall: fake,
        // Según el contador solo han pasado 5 minutos.
        snapshot: _snap(elapsedMs: 1000 + 5 * _minute, auto: false),
        anchor: _anchorAt(_t0),
      );
      expect(result.reading.trust, ClockTrust.adjusted);
      expect(result.reading.now, _t0.add(const Duration(minutes: 5)));
      expect(result.reading.wall, fake);
      // El nuevo punto de referencia es la fecha de verdad, no la falsa.
      expect(result.anchor?.trustedMs, _t0.add(const Duration(minutes: 5)).millisecondsSinceEpoch);
    });

    test('retrasar la fecha a mano también se detecta', () {
      final result = TrustedClock.evaluate(
        wall: _t0.subtract(const Duration(days: 3)),
        snapshot: _snap(elapsedMs: 1000 + 10 * _minute, auto: false),
        anchor: _anchorAt(_t0),
      );
      expect(result.reading.trust, ClockTrust.adjusted);
      expect(result.reading.now, _t0.add(const Duration(minutes: 10)));
    });

    test('el contador sigue valiendo muchos días sin reiniciar', () {
      final result = TrustedClock.evaluate(
        wall: _t0.add(const Duration(days: 20, hours: 3)),
        snapshot: _snap(elapsedMs: 1000 + 20 * _day, auto: false),
        anchor: _anchorAt(_t0),
      );
      expect(result.reading.trust, ClockTrust.adjusted);
      expect(result.reading.now, _t0.add(const Duration(days: 20)));
    });

    test('fecha manual tras reiniciar el móvil: no se puede comprobar', () {
      final result = TrustedClock.evaluate(
        wall: _t0.add(const Duration(days: 30)),
        snapshot: _snap(elapsedMs: 2 * _minute, boot: 8, auto: false),
        anchor: _anchorAt(_t0),
      );
      expect(result.reading.trust, ClockTrust.unverifiable);
      expect(result.anchor, isNull);
    });

    test('sin número de arranques, un contador que baja delata un reinicio', () {
      final result = TrustedClock.evaluate(
        wall: _t0.add(const Duration(days: 30)),
        snapshot: _snap(elapsedMs: 100, boot: -1, auto: false),
        anchor: _anchorAt(_t0, elapsedMs: 50000, boot: -1),
      );
      expect(result.reading.trust, ClockTrust.unverifiable);
    });

    test('fecha automática pero con la fecha adelantada sin internet: manda el contador', () {
      // Se desactiva la automática, se adelanta la fecha y se vuelve a activar
      // sin conexión: el ajuste dice «automática», pero el reloj sigue mal.
      final DateTime fake = _t0.add(const Duration(days: 30));
      final result = TrustedClock.evaluate(
        wall: fake,
        snapshot: _snap(elapsedMs: 1000 + 4 * _minute, auto: true),
        anchor: _anchorAt(_t0),
      );
      expect(result.reading.trust, ClockTrust.adjusted);
      expect(result.reading.now, _t0.add(const Duration(minutes: 4)));
    });

    test('fecha automática y un salto de unas horas hacia delante tampoco se acepta', () {
      final result = TrustedClock.evaluate(
        wall: _t0.add(const Duration(hours: 5)),
        snapshot: _snap(elapsedMs: 1000 + 2 * _minute, auto: true),
        anchor: _anchorAt(_t0),
      );
      expect(result.reading.trust, ClockTrust.adjusted);
      expect(result.reading.now, _t0.add(const Duration(minutes: 2)));
    });

    test('fecha automática: una corrección pequeña de la red se acepta', () {
      final DateTime corrected = _t0.add(const Duration(hours: 1, minutes: 6));
      final result = TrustedClock.evaluate(
        wall: corrected, // el contador dice 1 h; la red lo corrige 6 minutos
        snapshot: _snap(elapsedMs: 1000 + _hour, auto: true),
        anchor: _anchorAt(_t0),
      );
      expect(result.reading.trust, ClockTrust.ok);
      expect(result.reading.now, corrected);
    });

    test('fecha automática: la red corrige hacia atrás una fecha adelantada', () {
      // El punto de referencia estaba adelantado (fecha falsa guardada tras
      // reiniciar sin conexión); al volver internet el reloj vuelve a la real.
      final DateTime real = _t0.subtract(const Duration(days: 30));
      final result = TrustedClock.evaluate(
        wall: real,
        snapshot: _snap(elapsedMs: 1000 + 10 * _minute, auto: true),
        anchor: _anchorAt(_t0),
      );
      expect(result.reading.trust, ClockTrust.ok);
      expect(result.reading.now, real);
      expect(result.anchor?.trustedMs, real.millisecondsSinceEpoch);
    });

    test('volver a activar la fecha automática lo arregla todo', () {
      final result = TrustedClock.evaluate(
        wall: _t0.add(const Duration(hours: 1)),
        snapshot: _snap(elapsedMs: 3 * _minute, boot: 9, auto: true),
        anchor: _anchorAt(_t0),
      );
      expect(result.reading.trust, ClockTrust.ok);
      expect(result.reading.now, _t0.add(const Duration(hours: 1)));
    });
  });

  group('TrustedClock.read', () {
    setUp(() => SharedPreferences.setMockInitialValues(<String, Object>{}));

    test('guarda el punto de referencia y lo usa en la siguiente lectura', () async {
      DateTime wall = _t0;
      ClockSnapshot snapshot = _snap(elapsedMs: 1000);
      final TrustedClock clock = TrustedClock(
        wallClock: () => wall,
        probe: () async => snapshot,
      );

      // 1) Fecha automática: se fía y guarda la referencia.
      expect((await clock.read()).trust, ClockTrust.ok);

      // 2) El usuario desactiva la fecha automática y la adelanta 10 días,
      //    sin reiniciar: pasaron 2 minutos de verdad.
      wall = _t0.add(const Duration(days: 10));
      snapshot = _snap(elapsedMs: 1000 + 2 * _minute, auto: false);
      final ClockReading reading = await clock.read();
      expect(reading.trust, ClockTrust.adjusted);
      expect(reading.now, _t0.add(const Duration(minutes: 2)));

      // 3) Y si además reinicia el móvil, ya no hay forma de saberlo.
      snapshot = _snap(elapsedMs: 30 * 1000, boot: 8, auto: false);
      expect((await clock.read()).trust, ClockTrust.unverifiable);
    });

    test('en Android, si no se puede leer el contador, no se da la fecha por buena', () async {
      final TrustedClock clock = TrustedClock(
        wallClock: () => _t0,
        probe: () async => null,
        failClosed: true,
      );
      expect((await clock.read()).trust, ClockTrust.unverifiable);
    });

    test('en Android, un fallo al leer tampoco da la fecha por buena', () async {
      final TrustedClock clock = TrustedClock(
        wallClock: () => _t0,
        probe: () async => throw StateError('sin canal'),
        failClosed: true,
      );
      expect((await clock.read()).trust, ClockTrust.unverifiable);
    });

    test('fuera de Android, si no se puede leer el contador, se usa el reloj sin bloquear nada', () async {
      final TrustedClock clock = TrustedClock(
        wallClock: () => _t0,
        probe: () async => null,
        failClosed: false,
      );
      final ClockReading reading = await clock.read();
      expect(reading.trust, ClockTrust.ok);
      expect(reading.now, _t0);
    });

    test('un fallo al leer no lanza excepciones', () async {
      final TrustedClock clock = TrustedClock(
        wallClock: () => _t0,
        probe: () async => throw StateError('sin canal'),
        failClosed: false,
      );
      expect((await clock.read()).trust, ClockTrust.ok);
    });
  });

  group('CapsulesProvider con la fecha del móvil adelantada', () {
    setUp(() => SharedPreferences.setMockInitialValues(<String, Object>{}));

    // Cápsula sellada que se abre el 10 de noviembre.
    final Capsule capsule = Capsule(
      id: 1,
      title: 'Para mí',
      content: 'Hola',
      createdAt: DateTime(2026, 11, 2),
      openDate: DateTime(2026, 11, 10),
    );

    test('con la fecha automática, el día de apertura la cápsula está lista', () async {
      final CapsulesProvider provider = CapsulesProvider(
        clock: () => DateTime(2026, 11, 10, 9),
        trustedClock: TrustedClock(
          wallClock: () => DateTime(2026, 11, 10, 9),
          probe: () async => _snap(elapsedMs: 1000),
        ),
      );
      await provider.verifyClock();
      expect(provider.statusOf(capsule), CapsuleStatus.ready);
      expect(provider.clockVerified, isTrue);
    });

    test('si adelantan la fecha a mano, la cápsula sigue sellada', () async {
      DateTime wall = DateTime(2026, 11, 3, 9);
      ClockSnapshot snapshot = _snap(elapsedMs: 1000);
      final CapsulesProvider provider = CapsulesProvider(
        clock: () => wall,
        trustedClock: TrustedClock(
          wallClock: () => wall,
          probe: () async => snapshot,
        ),
      );
      await provider.verifyClock();
      expect(provider.statusOf(capsule), CapsuleStatus.sealed);

      // Desactiva la fecha automática y salta al 20 de noviembre.
      wall = DateTime(2026, 11, 20, 9);
      snapshot = _snap(elapsedMs: 1000 + 3 * _minute, auto: false);
      await provider.verifyClock();

      expect(provider.clockAdjusted, isTrue);
      expect(provider.statusOf(capsule), CapsuleStatus.sealed);
      expect(provider.daysUntilOpen(capsule), 7, reason: 'del 3 al 10 de noviembre');
      expect(provider.today, DateTime(2026, 11, 3));
    });

    test('con la fecha automática dejada falsa sin internet, la cápsula sigue sellada', () async {
      DateTime wall = DateTime(2026, 11, 3, 9);
      ClockSnapshot snapshot = _snap(elapsedMs: 1000);
      final CapsulesProvider provider = CapsulesProvider(
        clock: () => wall,
        trustedClock: TrustedClock(
          wallClock: () => wall,
          probe: () async => snapshot,
        ),
      );
      await provider.verifyClock();

      // Fecha manual, +20 días, y de nuevo «automática» pero sin conexión.
      wall = DateTime(2026, 11, 23, 9);
      snapshot = _snap(elapsedMs: 1000 + 5 * _minute, auto: true);
      await provider.verifyClock();

      expect(provider.clockAdjusted, isTrue);
      expect(provider.statusOf(capsule), CapsuleStatus.sealed);
      expect(provider.isHeldByClock(capsule), isFalse);
    });

    test('con la fecha sin comprobar no se deja crear una cápsula nueva', () async {
      final CapsulesProvider provider = CapsulesProvider(
        clock: () => DateTime(2026, 11, 20, 9),
        trustedClock: TrustedClock(
          wallClock: () => DateTime(2026, 11, 20, 9),
          probe: () async => _snap(elapsedMs: 1000, auto: false),
        ),
      );
      final CapsuleCreateResult result = await provider.create(
        title: 'Para mí',
        content: 'Hola',
        openDate: DateTime(2026, 12, 1),
      );
      expect(result.success, isFalse);
      expect(result.errorMessage, CapsulesProvider.clockUnverifiedMessage);
    });

    test('con la fecha manual sin referencia, la cápsula lista se queda sellada', () async {
      final CapsulesProvider provider = CapsulesProvider(
        clock: () => DateTime(2026, 11, 20, 9),
        trustedClock: TrustedClock(
          wallClock: () => DateTime(2026, 11, 20, 9),
          probe: () async => _snap(elapsedMs: 1000, auto: false),
        ),
      );
      await provider.verifyClock();

      expect(provider.clockVerified, isFalse);
      expect(provider.statusOf(capsule), CapsuleStatus.sealed);
      expect(provider.isHeldByClock(capsule), isTrue);
    });

    test('una cápsula ya abierta sigue abierta aunque no se pueda comprobar la fecha', () async {
      final Capsule opened = capsule.copyWith(openedAt: DateTime(2026, 11, 10));
      final CapsulesProvider provider = CapsulesProvider(
        clock: () => DateTime(2026, 11, 20),
        trustedClock: TrustedClock(
          wallClock: () => DateTime(2026, 11, 20),
          probe: () async => _snap(elapsedMs: 1000, auto: false),
        ),
      );
      await provider.verifyClock();
      expect(provider.statusOf(opened), CapsuleStatus.opened);
      expect(provider.isHeldByClock(opened), isFalse);
    });
  });
}
