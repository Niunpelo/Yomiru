import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../l10n/tr.dart';
import '../providers/capsules_provider.dart';
import '../providers/diary_provider.dart';
import '../providers/premium_provider.dart';
import '../providers/settings_provider.dart';
import '../services/file_transfer_service.dart';
import '../theme/app_style.dart';
import '../utils/date_labels.dart';
import '../widgets/app_drawer.dart';
import '../widgets/capsule_import_dialog.dart';
import '../widgets/date_header.dart';
import '../widgets/thread_frame.dart';
import '../widgets/year_card.dart';
import 'backup_screen.dart';
import 'calendar_screen.dart';
import 'capsules_screen.dart';
import 'premium_screen.dart';
import 'search_screen.dart';
import 'settings_screen.dart';
import 'template_screen.dart';

/// Pantalla principal: el día seleccionado y una tarjeta por cada año.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  /// Verdadero mientras se guarda una cápsula que llegó desde otra app.
  bool _importingIncoming = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        unawaited(context.read<DiaryProvider>().initialize());
        unawaited(context.read<CapsulesProvider>().load());
        unawaited(context.read<PremiumProvider>().initialize());
        // Si la app se abrió tocando un archivo de cápsula, se guarda sola.
        unawaited(_importIncomingCapsule());
      }
    });
  }

  /// Guarda la cápsula que otra app (WhatsApp, el correo, el gestor de
  /// archivos...) ha mandado abrir con Gonen, si la hay, y lo cuenta.
  Future<void> _importIncomingCapsule() async {
    if (_importingIncoming) {
      return;
    }
    _importingIncoming = true;
    File? incoming;
    try {
      incoming = await const FileTransferService().takeIncomingFile();
      if (incoming == null || !mounted) {
        return;
      }
      final CapsuleImportResult result =
          await context.read<CapsulesProvider>().importFile(incoming);
      if (!mounted) {
        return;
      }
      final bool seeList = await showCapsuleImportResult(
        context,
        result,
        offerList: true,
      );
      if (seeList && mounted) {
        await _openCapsules();
      }
    } catch (error) {
      debugPrint('Gonen: no se pudo guardar el archivo recibido: $error');
    } finally {
      if (incoming != null) {
        try {
          if (await incoming.exists()) {
            await incoming.delete();
          }
        } catch (error) {
          debugPrint('Gonen: no se pudo borrar el archivo recibido: $error');
        }
      }
      _importingIncoming = false;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final DiaryProvider diary = context.read<DiaryProvider>();
    switch (state) {
      case AppLifecycleState.inactive:
      case AppLifecycleState.hidden:
      case AppLifecycleState.paused:
      case AppLifecycleState.detached:
        // Si el sistema cierra la app en segundo plano, que no se pierda texto.
        unawaited(diary.flushPendingSave());
      case AppLifecycleState.resumed:
        // Si pasó la medianoche mientras tanto, se muestra el nuevo día, el
        // día anterior queda bloqueado y se repasan las cápsulas que ya se
        // pueden abrir.
        unawaited(diary.refreshIfNeeded());
        context.read<CapsulesProvider>().refreshStatuses();
        // Reprograma el recordatorio diario y comprueba que Android sigue
        // dejando mostrarlo (el usuario puede haber cambiado los permisos).
        unawaited(context.read<SettingsProvider>().refreshReminder());
        // Puede que la app se haya abierto de nuevo con un archivo de cápsula.
        unawaited(_importIncomingCapsule());
    }
  }

  /// Guarda lo pendiente y abre [screen] encima de la pantalla principal.
  Future<void> _openScreen(Widget screen) async {
    final DiaryProvider diary = context.read<DiaryProvider>();
    await diary.flushPendingSave();
    if (!mounted) {
      return;
    }
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (BuildContext context) => screen),
    );
  }

  Future<void> _openSettings() => _openScreen(const SettingsScreen());

  Future<void> _openCapsules() => _openScreen(const CapsulesScreen());

  Future<void> _openPremium() => _openScreen(const PremiumScreen());

  /// Con Premium abre la plantilla del día; sin él, la pantalla de Premium.
  Future<void> _openTemplate() => _openScreen(
        context.read<PremiumProvider>().isPremium
            ? const TemplateScreen()
            : const PremiumScreen(),
      );

  Future<void> _openBackup() => _openScreen(const BackupScreen());

  /// Abre una pantalla que devuelve un día (calendario o búsqueda) y, si el
  /// usuario elige uno, salta a él.
  Future<void> _openDayPicker(Widget screen) async {
    final DiaryProvider diary = context.read<DiaryProvider>();
    // Se guarda lo pendiente antes de mirar qué días tienen entrada.
    await diary.flushPendingSave();
    if (!mounted) {
      return;
    }
    final DateTime? picked = await Navigator.of(context).push<DateTime>(
      MaterialPageRoute<DateTime>(builder: (BuildContext context) => screen),
    );
    if (picked != null && mounted) {
      await diary.goToDate(picked);
    }
  }

  Future<void> _openCalendar() => _openDayPicker(const CalendarScreen());

  Future<void> _openSearch() => _openDayPicker(const SearchScreen());

  Future<void> _pickDate() async {
    final DiaryProvider diary = context.read<DiaryProvider>();
    final int year = diary.entryYear;
    final DateTime initial = diary.selectedDate ?? DateTime(year, 2, 28);

    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(year, 1, 1),
      lastDate: DateTime(year, 12, 31),
      helpText: tr('Elegir día', 'Choose a day'),
    );
    if (picked != null) {
      await diary.goToDate(picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    final DiaryProvider diary = context.watch<DiaryProvider>();
    final int readyCapsules = context
        .select<CapsulesProvider, int>((CapsulesProvider p) => p.readyCount);

    return Scaffold(
      drawer: AppDrawer(
        onOpenCalendar: () => unawaited(_openCalendar()),
        onOpenSearch: () => unawaited(_openSearch()),
        onOpenTemplate: () => unawaited(_openTemplate()),
        onOpenCapsules: () => unawaited(_openCapsules()),
        onOpenBackup: () => unawaited(_openBackup()),
        onOpenPremium: () => unawaited(_openPremium()),
        onOpenSettings: () => unawaited(_openSettings()),
      ),
      appBar: AppBar(
        title: const Text('Gonen'),
        leading: Builder(
          builder: (BuildContext innerContext) {
            return IconButton(
              onPressed: () => Scaffold.of(innerContext).openDrawer(),
              // Un punto avisa de que hay cápsulas listas para abrir.
              icon: Badge(
                isLabelVisible: readyCapsules > 0,
                child: const Icon(Icons.menu_rounded),
              ),
              tooltip: MaterialLocalizations.of(innerContext).openAppDrawerTooltip,
            );
          },
        ),
        actions: <Widget>[
          IconButton(
            onPressed: _openSearch,
            icon: const Icon(Icons.search_rounded),
            tooltip: context.tr('Buscar', 'Search'),
          ),
          IconButton(
            onPressed: _openCalendar,
            icon: const Icon(Icons.calendar_month_outlined),
            tooltip: context.tr('Calendario', 'Calendar'),
          ),
          IconButton(
            onPressed: _openSettings,
            icon: const Icon(Icons.settings_outlined),
            tooltip: context.tr('Ajustes', 'Settings'),
          ),
        ],
      ),
      body: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: _buildBody(context, diary),
          ),
        ),
      ),
    );
  }

  Widget _buildBody(BuildContext context, DiaryProvider diary) {
    final ThemeData theme = Theme.of(context);
    final AppStyle style = context.appStyle;
    // Plantilla del día: solo con Premium y con la plantilla activada.
    final bool premium = context
        .select<PremiumProvider, bool>((PremiumProvider p) => p.isPremium);
    final String template = context.select<SettingsProvider, String>(
      (SettingsProvider s) => s.activeTemplate(premium: premium),
    );

    if (diary.errorMessage != null && !diary.isReady) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(diary.errorMessage!, style: theme.textTheme.bodyLarge),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () => unawaited(diary.retry()),
              child: Text(context.tr('Reintentar', 'Try again')),
            ),
          ],
        ),
      );
    }

    if (!diary.isReady) {
      return const Center(child: CircularProgressIndicator());
    }

    final DateTime? selected = diary.selectedDate;
    final List<int> years = diary.years;

    return Column(
      children: <Widget>[
        DateHeader(
          date: diary.referenceDate,
          dayLabel: dayMonthLabel(diary.referenceDate),
          subtitle: selected == null
              ? context.tr('solo en años bisiestos', 'leap years only')
              : weekdayLabel(selected),
          yearDay: selected == null ? null : dayOfYear(selected),
          yearDays: selected == null ? null : daysInYear(diary.entryYear),
          isToday: diary.isToday,
          onPrevious: () => unawaited(diary.goToPreviousDay()),
          onNext: () => unawaited(diary.goToNextDay()),
          onToday: () => unawaited(diary.goToToday()),
          onPickDate: _pickDate,
        ),
        Expanded(
          child: ListView.separated(
            padding: EdgeInsets.fromLTRB(16, style.isEditorial ? 0 : 8, 16, 32),
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            itemCount: years.length,
            // En el hilo rojo el hueco lo pone cada tarjeta, para que el hilo
            // no se corte; en los estilos editoriales las líneas ya separan.
            separatorBuilder: (BuildContext context, int index) => SizedBox(
              height: (style.hasThread || style.isEditorial) ? 0 : 14,
            ),
            itemBuilder: (BuildContext context, int index) {
              final int year = years[index];
              final DateTime? date = _dateIn(diary, year);

              final bool isCurrent = year == diary.entryYear;
              final Widget card;
              if (isCurrent) {
                card = CurrentYearCard(
                  key: ValueKey<String>('current-$year-${diary.dayKey}'),
                  year: year,
                  date: date,
                  access: diary.access,
                  text: diary.currentEntry?.content ?? '',
                  attachments: diary.attachmentsFor(year),
                  template: template,
                );
              } else {
                card = PastYearCard(
                  key: ValueKey<String>('past-$year-${diary.dayKey}'),
                  year: year,
                  date: date,
                  entry: diary.entryFor(year),
                  attachments: diary.attachmentsFor(year),
                );
              }

              if (!style.hasThread) {
                return card;
              }
              return ThreadFrame(
                isFirst: index == 0,
                isLast: index == years.length - 1,
                isCurrent: isCurrent,
                child: card,
              );
            },
          ),
        ),
      ],
    );
  }

  /// Fecha del día seleccionado dentro de [year], o null si no existe.
  DateTime? _dateIn(DiaryProvider diary, int year) {
    if (!diary.dayExistsIn(year)) {
      return null;
    }
    return DateTime(year, diary.month, diary.day);
  }
}
