/// Versión que se muestra en el menú y en los ajustes. Debe coincidir con `version` en pubspec.yaml.
const String kAppVersion = '1.7.1';

/// Verdadero solo en el APK de PRUEBA (compilado con
/// `--dart-define=GONEN_PREMIUM_TEST=true`), que trae Premium desbloqueado sin
/// pagar. Nunca se debe publicar.
const bool kPremiumTestBuild = bool.fromEnvironment('GONEN_PREMIUM_TEST');

/// Texto de versión del menú y de los ajustes. El APK de prueba lo dice, para
/// no confundirlo con el normal.
const String kVersionLabel = kPremiumTestBuild
    ? 'Gonen $kAppVersion · PRUEBA'
    : 'Gonen $kAppVersion';
